<?php
ini_set('display_errors', 0);
ini_set('log_errors', 1);
set_exception_handler(function(Throwable $e) {
  error_log('auth_social error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
  if (session_status() === PHP_SESSION_NONE) session_start();
  $_SESSION['flash']['error'] = 'GitHub login failed. Please try again.';
  header('Location: login.php'); exit;
});
// ─── auth_social.php — OAuth Social Login Handler ────────────────────
// Supports: Google, GitHub, Facebook
// Flow: ?provider=google|github|facebook  → redirect to provider
//       ?provider=google&code=... → exchange code → upsert user → login
// ─────────────────────────────────────────────────────────────────────
require_once 'includes/config.php';

// ══════════════════════════════════════════════════════════════════════
//  CONFIGURE YOUR OAUTH APPS HERE
//  Create apps at:
//    Google  → https://console.cloud.google.com/apis/credentials
//    GitHub  → https://github.com/settings/developers
//    Facebook→ https://developers.facebook.com/apps/
//  Set Callback URI to:  https://yourdomain.com/auth_social.php
// ══════════════════════════════════════════════════════════════════════
$OAUTH = [
  'google' => [
    'client_id'     => 'YOUR_GOOGLE_CLIENT_ID',
    'client_secret' => 'YOUR_GOOGLE_CLIENT_SECRET',
    'auth_url'      => 'https://accounts.google.com/o/oauth2/v2/auth',
    'token_url'     => 'https://oauth2.googleapis.com/token',
    'userinfo_url'  => 'https://www.googleapis.com/oauth2/v3/userinfo',
    'scope'         => 'openid email profile',
    'redirect_uri'  => BASE_URL . '/auth_social.php?provider=google',
  ],
  'github' => [
    'client_id'     => 'Ov23li0IbFTyEBHvOSP4',
    'client_secret' => 'd5995588c545bf2ce468526f10b0d77020cf4aa3',
    'auth_url'      => 'https://github.com/login/oauth/authorize',
    'token_url'     => 'https://github.com/login/oauth/access_token',
    'userinfo_url'  => 'https://api.github.com/user',
    'email_url'     => 'https://api.github.com/user/emails',
    'scope'         => 'read:user user:email',
    'redirect_uri'  => BASE_URL . '/auth_social.php?provider=github',
  ],
  'facebook' => [
    'client_id'     => 'YOUR_FACEBOOK_APP_ID',
    'client_secret' => 'YOUR_FACEBOOK_APP_SECRET',
    'auth_url'      => 'https://www.facebook.com/v19.0/dialog/oauth',
    'token_url'     => 'https://graph.facebook.com/v19.0/oauth/access_token',
    'userinfo_url'  => 'https://graph.facebook.com/me?fields=id,name,email,picture.width(200)',
    'scope'         => 'email,public_profile',
    'redirect_uri'  => BASE_URL . '/auth_social.php?provider=facebook',
  ],
];

// ─── Helpers ──────────────────────────────────────────────────────────
function oauthGet(string $url, string $token): array {
  $opts = ['http' => [
    'method' => 'GET',
    'header' => "Authorization: Bearer $token\r\nUser-Agent: codeMe/1.0\r\nAccept: application/json\r\n",
    'ignore_errors' => true,
  ]];
  $res = file_get_contents($url, false, stream_context_create($opts));
  return $res ? (json_decode($res, true) ?? []) : [];
}

function oauthPost(string $url, array $params): array {
  $opts = ['http' => [
    'method'  => 'POST',
    'header'  => "Content-Type: application/x-www-form-urlencoded\r\nAccept: application/json\r\nUser-Agent: codeMe/1.0\r\n",
    'content' => http_build_query($params),
    'ignore_errors' => true,
  ]];
  $res = file_get_contents($url, false, stream_context_create($opts));
  // GitHub returns form-encoded on token exchange
  if ($res && !str_starts_with(trim($res), '{')) {
    parse_str($res, $arr);
    return $arr;
  }
  return $res ? (json_decode($res, true) ?? []) : [];
}

function slugUsername(string $name): string {
  $slug = preg_replace('/[^a-zA-Z0-9_]/', '_', $name);
  $slug = substr(trim($slug, '_'), 0, 28);
  return $slug ?: 'user';
}

function uniqueUsername(string $base): string {
  $db   = db();
  $name = $base;
  $i    = 1;
  while (true) {
    $s = $db->prepare('SELECT id FROM users WHERE username=? LIMIT 1');
    $s->execute([$name]);
    if (!$s->fetch()) return $name;
    $name = $base . $i++;
  }
}

function upsertSocialUser(string $provider, string $providerId, string $email, string $name, string $avatarUrl): void {
  $db = db();

  // 1. Try to find by provider+id
  $s = $db->prepare('SELECT id,username,avatar,avatar_img FROM users WHERE oauth_provider=? AND oauth_id=? LIMIT 1');
  $s->execute([$provider, $providerId]);
  $user = $s->fetch();

  if (!$user && $email) {
    // 2. Try to find by email (link existing account)
    $s = $db->prepare('SELECT id,username,avatar,avatar_img FROM users WHERE email=? LIMIT 1');
    $s->execute([$email]);
    $user = $s->fetch();
    if ($user) {
      // Link oauth to existing account
      $db->prepare('UPDATE users SET oauth_provider=?, oauth_id=? WHERE id=?')
         ->execute([$provider, $providerId, $user['id']]);
    }
  }

  if (!$user) {
    // 3. Create new user
    $username = uniqueUsername(slugUsername($name ?: $provider . '_user'));
    $avatar   = '🧑';
    $db->prepare('INSERT INTO users (username,email,password,avatar,oauth_provider,oauth_id) VALUES (?,?,?,?,?,?)')
       ->execute([$username, $email, '', $avatar, $provider, $providerId]);
    $id = (int)$db->lastInsertId();

    // Optionally download avatar
    $avatarPath = null;
    if ($avatarUrl) {
      $ext  = 'jpg';
      $dest = "uploads/avatars/{$id}_social.{$ext}";
      $img  = @file_get_contents($avatarUrl);
      if ($img) { file_put_contents($dest, $img); $avatarPath = $dest; }
    }
    if ($avatarPath) {
      $db->prepare('UPDATE users SET avatar_img=? WHERE id=?')->execute([$avatarPath, $id]);
    }

    $_SESSION['user'] = ['id' => $id, 'username' => $username, 'avatar' => $avatar];
    flash('success', "Welcome to codeMe, {$username}! 🎉");
  } else {
    $_SESSION['user'] = [
      'id'       => $user['id'],
      'username' => $user['username'],
      'avatar'   => $user['avatar'],
    ];
  }

  header('Location: index.php'); exit;
}

// ─── Ensure BASE_URL is never empty (failsafe) ───────────────────────
if (!defined('BASE_URL') || BASE_URL === '') {
  $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
  $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
  define('BASE_URL', $scheme . '://' . $host);
}

// ─── Main dispatch ────────────────────────────────────────────────────
$provider = strtolower(trim($_GET['provider'] ?? ''));
if (!isset($OAUTH[$provider])) {
  header('Location: login.php'); exit;
}
$cfg = $OAUTH[$provider];

// ── Step 1: Redirect to provider ─────────────────────────────────────
if (!isset($_GET['code'])) {
  $state = bin2hex(random_bytes(16));
  $_SESSION['oauth_state'] = $state;

  $params = [
    'client_id'     => $cfg['client_id'],
    'redirect_uri'  => $cfg['redirect_uri'],
    'response_type' => 'code',
    'scope'         => $cfg['scope'],
    'state'         => $state,
  ];
  if ($provider === 'google') $params['access_type'] = 'online';

  header('Location: ' . $cfg['auth_url'] . '?' . http_build_query($params));
  exit;
}

// ── Step 2: Handle callback ───────────────────────────────────────────
if (isset($_GET['error'])) {
  flash('error', 'OAuth error: ' . e($_GET['error']));
  header('Location: login.php'); exit;
}

// CSRF state check
if (!isset($_GET['state']) || $_GET['state'] !== ($_SESSION['oauth_state'] ?? '')) {
  flash('error', 'Invalid OAuth state. Please try again.');
  header('Location: login.php'); exit;
}
unset($_SESSION['oauth_state']);

// Exchange code for access token
$tokenData = oauthPost($cfg['token_url'], [
  'client_id'     => $cfg['client_id'],
  'client_secret' => $cfg['client_secret'],
  'code'          => $_GET['code'],
  'redirect_uri'  => $cfg['redirect_uri'],
  'grant_type'    => 'authorization_code',
]);

$accessToken = $tokenData['access_token'] ?? '';
if (!$accessToken) {
  flash('error', 'Could not get access token. Please try again.');
  header('Location: login.php'); exit;
}

// Fetch user info
$info = oauthGet($cfg['userinfo_url'], $accessToken);

if ($provider === 'google') {
  $providerId = $info['sub']           ?? '';
  $email      = $info['email']         ?? '';
  $name       = $info['name']          ?? '';
  $avatarUrl  = $info['picture']       ?? '';

} elseif ($provider === 'github') {
  $providerId = (string)($info['id']   ?? '');
  $email      = $info['email']         ?? '';
  $name       = $info['name'] ?: ($info['login'] ?? '');
  $avatarUrl  = $info['avatar_url']    ?? '';
  // GitHub may hide email — fetch from /user/emails
  if (!$email) {
    $emails = oauthGet($cfg['email_url'], $accessToken);
    foreach ($emails as $em) {
      if (!empty($em['primary']) && !empty($em['verified'])) {
        $email = $em['email']; break;
      }
    }
  }

} elseif ($provider === 'facebook') {
  $providerId = (string)($info['id']   ?? '');
  $email      = $info['email']         ?? '';
  $name       = $info['name']          ?? '';
  $avatarUrl  = $info['picture']['data']['url'] ?? '';
}

if (!$providerId) {
  flash('error', 'Could not retrieve profile from ' . ucfirst($provider) . '.');
  header('Location: login.php'); exit;
}

upsertSocialUser($provider, $providerId, $email, $name, $avatarUrl);
