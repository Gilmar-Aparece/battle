<?php
require_once 'includes/config.php';
require_once 'includes/layout.php';

$user = auth();

// ── Auto-migration: add allow_versus column if missing ───────────────────────
try {
  $col = db()->query("SHOW COLUMNS FROM `showcase_posts` LIKE 'allow_versus'")->fetch();
  if (!$col) {
    db()->exec("ALTER TABLE `showcase_posts` ADD COLUMN `allow_versus` TINYINT(1) NOT NULL DEFAULT 0 AFTER `js_code`");
  }
} catch (Exception $e) { /* skip if no permission — run showcase_migration.sql manually */ }

// ── Auto-migration: add showcase_post_id to challenges (links back to showcase) ──
try {
  $col2 = db()->query("SHOW COLUMNS FROM `challenges` LIKE 'showcase_post_id'")->fetch();
  if (!$col2) {
    db()->exec("ALTER TABLE `challenges` ADD COLUMN `showcase_post_id` INT DEFAULT NULL AFTER `created_at`");
  }
} catch (Exception $e) { /* skip */ }

// ── Helper: sync a showcase post → challenges table ──────────────────────────
function syncShowcaseToChallenge(int $postId): void {
  $post = db()->prepare('SELECT * FROM showcase_posts WHERE id=?');
  $post->execute([$postId]);
  $p = $post->fetch();
  if (!$p) return;

  // Check if a challenge already exists for this showcase post
  $existing = db()->prepare('SELECT id FROM challenges WHERE showcase_post_id=?');
  $existing->execute([$postId]);
  $ch = $existing->fetch();

  if ($p['allow_versus']) {
    $desc = $p['description'] ?: $p['title'];
    if ($ch) {
      // Update existing challenge
      db()->prepare('UPDATE challenges SET title=?, description=?, target_html=?, target_css=? WHERE id=?')
         ->execute([$p['title'], $desc, $p['html_code'], $p['css_code'], $ch['id']]);
    } else {
      // Insert new challenge linked to this post
      db()->prepare('INSERT INTO challenges (title, description, target_html, target_css, difficulty, created_by, showcase_post_id) VALUES (?,?,?,?,?,?,?)')
         ->execute([$p['title'], $desc, $p['html_code'], $p['css_code'], 'medium', $p['user_id'], $postId]);
    }
  } else {
    // allow_versus turned off — remove the challenge if it exists
    if ($ch) {
      db()->prepare('DELETE FROM challenges WHERE showcase_post_id=?')->execute([$postId]);
    }
  }
}

// ── Handle AJAX actions ─────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
  requireLogin();
  header('Content-Type: application/json');

  $action = $_POST['action'];

  // ── Submit post ─────────────────────────────────────────────────────────────
  if ($action === 'submit_post') {
    $title       = trim($_POST['title'] ?? '');
    $desc        = trim($_POST['description'] ?? '');
    $html        = $_POST['html_code'] ?? '';
    $css         = $_POST['css_code']  ?? '';
    $js          = $_POST['js_code']   ?? '';
    $allowVersus = isset($_POST['allow_versus']) ? 1 : 0;

    if (!$title) { echo json_encode(['ok'=>false,'msg'=>'Title is required']); exit; }
    if (mb_strlen($title) > 120) { echo json_encode(['ok'=>false,'msg'=>'Title too long (120 chars max)']); exit; }

    $stmt = db()->prepare(
      'INSERT INTO showcase_posts (user_id,title,description,html_code,css_code,js_code,allow_versus)
       VALUES (?,?,?,?,?,?,?)'
    );
    $stmt->execute([$user['id'], $title, $desc ?: null, $html, $css, $js, $allowVersus]);
    $newPostId = (int)db()->lastInsertId();
    if ($allowVersus) syncShowcaseToChallenge($newPostId);
    echo json_encode(['ok'=>true,'id'=>$newPostId]);
    exit;
  }

  // ── Toggle allow_versus permission ─────────────────────────────────────────
  if ($action === 'toggle_versus') {
    $postId = (int)($_POST['post_id'] ?? 0);
    $check  = db()->prepare('SELECT user_id, allow_versus FROM showcase_posts WHERE id=?');
    $check->execute([$postId]);
    $row = $check->fetch();
    if (!$row || (int)$row['user_id'] !== (int)$user['id']) {
      echo json_encode(['ok'=>false,'msg'=>'Not your post']); exit;
    }
    $newVal = $row['allow_versus'] ? 0 : 1;
    db()->prepare('UPDATE showcase_posts SET allow_versus=? WHERE id=?')->execute([$newVal, $postId]);
    syncShowcaseToChallenge($postId);
    echo json_encode(['ok'=>true,'allow_versus'=>$newVal]);
    exit;
  }

  // ── React / un-react ──────────────────────────────────────────────────────
  if ($action === 'react') {
    $postId = (int)($_POST['post_id'] ?? 0);
    $emoji  = $_POST['emoji'] ?? '🔥';
    $allowed = ['🔥','💯','✨','🚀','👏','❤️'];
    if (!in_array($emoji, $allowed, true)) $emoji = '🔥';

    $check = db()->prepare('SELECT id FROM showcase_reactions WHERE post_id=? AND user_id=? AND emoji=?');
    $check->execute([$postId, $user['id'], $emoji]);
    if ($check->fetch()) {
      db()->prepare('DELETE FROM showcase_reactions WHERE post_id=? AND user_id=? AND emoji=?')
          ->execute([$postId, $user['id'], $emoji]);
      $state = 'removed';
    } else {
      db()->prepare('INSERT INTO showcase_reactions (post_id,user_id,emoji) VALUES (?,?,?)')
          ->execute([$postId, $user['id'], $emoji]);
      $state = 'added';
    }
    $counts = db()->prepare('SELECT emoji, COUNT(*) as cnt FROM showcase_reactions WHERE post_id=? GROUP BY emoji');
    $counts->execute([$postId]);
    echo json_encode(['ok'=>true,'state'=>$state,'counts'=>$counts->fetchAll(PDO::FETCH_KEY_PAIR)]);
    exit;
  }

  // ── Post comment ──────────────────────────────────────────────────────────
  if ($action === 'comment') {
    $postId = (int)($_POST['post_id'] ?? 0);
    $body   = trim($_POST['body'] ?? '');
    if (!$body)  { echo json_encode(['ok'=>false,'msg'=>'Comment cannot be empty']); exit; }
    if (mb_strlen($body) > 500) { echo json_encode(['ok'=>false,'msg'=>'Comment too long (500 chars max)']); exit; }

    db()->prepare('INSERT INTO showcase_comments (post_id,user_id,body) VALUES (?,?,?)')
        ->execute([$postId, $user['id'], $body]);

    // Notify the post owner (not if they're commenting on their own post)
    $ownerRow = db()->prepare('SELECT user_id, title FROM showcase_posts WHERE id=?');
    $ownerRow->execute([$postId]);
    $ownerRow = $ownerRow->fetch();
    if ($ownerRow && (int)$ownerRow['user_id'] !== (int)$user['id']) {
      require_once __DIR__ . '/includes/notifications_helper.php';
      pushNotification((int)$ownerRow['user_id'], (int)$user['id'], 'showcase_comment', $postId, $ownerRow['title'] ?? null);
    }

    echo json_encode([
      'ok'       => true,
      'id'       => db()->lastInsertId(),
      'username' => $user['username'],
      'avatar'   => $user['avatar'],
      'body'     => $body,
      'time'     => 'just now',
    ]);
    exit;
  }

  // ── Edit post ───────────────────────────────────────────────────────────────
  if ($action === 'edit_post') {
    $postId = (int)($_POST['post_id'] ?? 0);
    $chk    = db()->prepare('SELECT user_id FROM showcase_posts WHERE id=?');
    $chk->execute([$postId]);
    $row = $chk->fetch();
    if (!$row || (int)$row['user_id'] !== (int)$user['id']) {
      echo json_encode(['ok'=>false,'msg'=>'Not your post']); exit;
    }
    $title = trim($_POST['title'] ?? '');
    $desc  = trim($_POST['description'] ?? '');
    $html  = $_POST['html_code'] ?? '';
    $css   = $_POST['css_code']  ?? '';
    $js    = $_POST['js_code']   ?? '';
    if (!$title) { echo json_encode(['ok'=>false,'msg'=>'Title is required']); exit; }
    if (mb_strlen($title) > 120) { echo json_encode(['ok'=>false,'msg'=>'Title too long']); exit; }
    db()->prepare('UPDATE showcase_posts SET title=?,description=?,html_code=?,css_code=?,js_code=? WHERE id=?')
       ->execute([$title, $desc ?: null, $html, $css, $js, $postId]);
    syncShowcaseToChallenge($postId);
    echo json_encode(['ok'=>true]);
    exit;
  }

  // ── Delete post ─────────────────────────────────────────────────────────────
  if ($action === 'delete_post') {
    $postId = (int)($_POST['post_id'] ?? 0);
    $chk    = db()->prepare('SELECT user_id FROM showcase_posts WHERE id=?');
    $chk->execute([$postId]);
    $row = $chk->fetch();
    if (!$row || (int)$row['user_id'] !== (int)$user['id']) {
      echo json_encode(['ok'=>false,'msg'=>'Not your post']); exit;
    }
    // Remove linked challenge first
    db()->prepare('DELETE FROM challenges WHERE showcase_post_id=?')->execute([$postId]);
    // Remove reactions + comments
    db()->prepare('DELETE FROM showcase_reactions WHERE post_id=?')->execute([$postId]);
    db()->prepare('DELETE FROM showcase_comments WHERE post_id=?')->execute([$postId]);
    db()->prepare('DELETE FROM showcase_posts WHERE id=?')->execute([$postId]);
    echo json_encode(['ok'=>true]);
    exit;
  }

  // ── toggle_like ────────────────────────────────────────────────────────────
  if ($action === 'toggle_like') {
    $post_id = (int)($_POST['post_id'] ?? 0);
    if (!$post_id) { echo json_encode(['ok'=>false,'error'=>'missing']); exit; }

    $chk = db()->prepare('SELECT id FROM showcase_posts WHERE id=?');
    $chk->execute([$post_id]);
    if (!$chk->fetch()) { echo json_encode(['ok'=>false,'error'=>'not_found']); exit; }

    $existing = db()->prepare('SELECT id FROM showcase_likes WHERE post_id=? AND user_id=?');
    $existing->execute([$post_id, $user['id']]);
    if ($existing->fetch()) {
      db()->prepare('DELETE FROM showcase_likes WHERE post_id=? AND user_id=?')->execute([$post_id, $user['id']]);
      $liked = false;
    } else {
      db()->prepare('INSERT IGNORE INTO showcase_likes (post_id, user_id) VALUES (?,?)')->execute([$post_id, $user['id']]);
      $liked = true;
      // Notify the post owner
      $owner = db()->prepare('SELECT user_id, title FROM showcase_posts WHERE id=?');
      $owner->execute([$post_id]);
      $ownerRow = $owner->fetch();
      if ($ownerRow) {
        require_once __DIR__ . '/includes/notifications_helper.php';
        pushNotification((int)$ownerRow['user_id'], (int)$user['id'], 'showcase_like', $post_id, $ownerRow['title'] ?? null);
      }
    }

    $count = (int)db()->query("SELECT COUNT(*) FROM showcase_likes WHERE post_id={$post_id}")->fetchColumn();
    echo json_encode(['ok'=>true, 'liked'=>$liked, 'like_count'=>$count]);
    exit;
  }

  // ── toggle_follow ──────────────────────────────────────────────────────────
  if ($action === 'toggle_follow') {
    $target_id = (int)($_POST['target_id'] ?? 0);
    if (!$target_id || $target_id === (int)$user['id']) {
      echo json_encode(['ok'=>false,'error'=>'invalid']); exit;
    }

    $chk = db()->prepare('SELECT id FROM users WHERE id=?');
    $chk->execute([$target_id]);
    if (!$chk->fetch()) { echo json_encode(['ok'=>false,'error'=>'not_found']); exit; }

    $existing = db()->prepare('SELECT id FROM user_follows WHERE follower_id=? AND following_id=?');
    $existing->execute([$user['id'], $target_id]);
    if ($existing->fetch()) {
      db()->prepare('DELETE FROM user_follows WHERE follower_id=? AND following_id=?')->execute([$user['id'], $target_id]);
      $following = false;
    } else {
      db()->prepare('INSERT IGNORE INTO user_follows (follower_id, following_id) VALUES (?,?)')->execute([$user['id'], $target_id]);
      $following = true;
      // Notify the user being followed
      require_once __DIR__ . '/includes/notifications_helper.php';
      pushNotification($target_id, (int)$user['id'], 'follow', null, null);
    }

    $followerCount = (int)db()->query("SELECT COUNT(*) FROM user_follows WHERE following_id={$target_id}")->fetchColumn();
    echo json_encode(['ok'=>true, 'following'=>$following, 'follower_count'=>$followerCount]);
    exit;
  }

  echo json_encode(['ok'=>false,'msg'=>'Unknown action']);
  exit;
}

// ── User profile page — ?user=ID ─────────────────────────────────────────────
if (isset($_GET['user'])) {
  $profileId = (int)$_GET['user'];
  $profileUser = db()->prepare('SELECT * FROM users WHERE id=?');
  $profileUser->execute([$profileId]);
  $profileUser = $profileUser->fetch();
  if (!$profileUser) { header('Location: showcase.php'); exit; }

  $page    = max(1, (int)($_GET['page'] ?? 1));
  $perPage = 12;
  $offset  = ($page - 1) * $perPage;

  $totalStmt = db()->prepare('SELECT COUNT(*) FROM showcase_posts WHERE user_id=?');
  $totalStmt->execute([$profileId]);
  $total = (int)$totalStmt->fetchColumn();

  $posts = db()->prepare(
    'SELECT p.*, u.username, u.avatar, u.avatar_img,
            (SELECT COUNT(*) FROM showcase_reactions r WHERE r.post_id=p.id) AS reaction_count,
            (SELECT COUNT(*) FROM showcase_comments c WHERE c.post_id=p.id) AS comment_count
     FROM showcase_posts p JOIN users u ON u.id=p.user_id
     WHERE p.user_id=?
     ORDER BY p.created_at DESC LIMIT ? OFFSET ?'
  );
  $posts->execute([$profileId, $perPage, $offset]);
  $posts = $posts->fetchAll();

  // Fetch all profile stats at page load — no AJAX, no spinner
  $followerCount  = (int)db()->query("SELECT COUNT(*) FROM user_follows WHERE following_id={$profileId}")->fetchColumn();
  $followingCount = (int)db()->query("SELECT COUNT(*) FROM user_follows WHERE follower_id={$profileId}")->fetchColumn();
  $totalViews     = (int)db()->query("SELECT COALESCE(SUM(views),0) FROM showcase_posts WHERE user_id={$profileId}")->fetchColumn();
  $totalReactions = (int)db()->query("SELECT COUNT(*) FROM showcase_reactions r JOIN showcase_posts p ON r.post_id=p.id WHERE p.user_id={$profileId}")->fetchColumn();
  $isFollowing    = false;
  if ($user && (int)$user['id'] !== $profileId) {
    $fchk = db()->prepare('SELECT id FROM user_follows WHERE follower_id=? AND following_id=?');
    $fchk->execute([$user['id'], $profileId]);
    $isFollowing = (bool)$fchk->fetch();
  }
  $profileStats = compact('followerCount','followingCount','totalViews','totalReactions','isFollowing');

  // Pre-fetch followers & following lists — instant display, no AJAX needed
  $followersList = db()->prepare('
    SELECT u.id, u.username, u.avatar, u.avatar_img,
           DATE_FORMAT(f.created_at, "%b %Y") AS since
    FROM user_follows f JOIN users u ON u.id = f.follower_id
    WHERE f.following_id = ? ORDER BY f.created_at DESC');
  $followersList->execute([$profileId]);
  $followersList = $followersList->fetchAll();

  $followingList = db()->prepare('
    SELECT u.id, u.username, u.avatar, u.avatar_img,
           DATE_FORMAT(f.created_at, "%b %Y") AS since
    FROM user_follows f JOIN users u ON u.id = f.following_id
    WHERE f.follower_id = ? ORDER BY f.created_at DESC');
  $followingList->execute([$profileId]);
  $followingList = $followingList->fetchAll();

  $profileStats['followersList'] = $followersList;
  $profileStats['followingList'] = $followingList;

  pageHeader(e($profileUser['username']).'\'s Posts — Showcase');
  showUserProfile($profileUser, $posts, $total, $page, $perPage, $user, $profileStats);
  pageFooter();
  exit;
}

// ── Single post view ──────────────────────────────────────────────────────────
if (isset($_GET['id'])) {
  $postId = (int)$_GET['id'];
  $post = db()->prepare(
    'SELECT p.*, u.username, u.avatar, u.avatar_img
     FROM showcase_posts p JOIN users u ON u.id=p.user_id
     WHERE p.id=?'
  );
  $post->execute([$postId]);
  $post = $post->fetch();
  if (!$post) { header('Location: showcase.php'); exit; }

  db()->prepare('UPDATE showcase_posts SET views=views+1 WHERE id=?')->execute([$postId]);

  $reactRows = db()->prepare('SELECT emoji, COUNT(*) as cnt FROM showcase_reactions WHERE post_id=? GROUP BY emoji');
  $reactRows->execute([$postId]);
  $reactions = $reactRows->fetchAll(PDO::FETCH_KEY_PAIR);

  $myReacts = [];
  if ($user) {
    $mr = db()->prepare('SELECT emoji FROM showcase_reactions WHERE post_id=? AND user_id=?');
    $mr->execute([$postId, $user['id']]);
    $myReacts = $mr->fetchAll(PDO::FETCH_COLUMN);
  }

  $comments = db()->prepare(
    'SELECT c.*, u.username, u.avatar, u.avatar_img
     FROM showcase_comments c JOIN users u ON u.id=c.user_id
     WHERE c.post_id=? ORDER BY c.created_at ASC'
  );
  $comments->execute([$postId]);
  $comments = $comments->fetchAll();

  // ── Build Open Graph meta tags for social sharing ────────────────────
  $scheme  = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https' : 'http';
  $baseUrl = $scheme . '://' . $_SERVER['HTTP_HOST'];
  $ogUrl   = $baseUrl . '/showcase.php?id=' . (int)$post['id'];
  $ogImg   = $baseUrl . '/og-image.php?id='  . (int)$post['id'];
  $ogTitle = htmlspecialchars($post['title'], ENT_QUOTES) . ' — codeMe Showcase';
  $ogDesc  = htmlspecialchars(
    $post['description']
      ? mb_strimwidth($post['description'], 0, 200, '…')
      : 'A creative HTML/CSS creation by ' . $post['username'] . ' on codeMe Versus. Click to view the live preview and code.',
    ENT_QUOTES
  );
  $ogAuthor = htmlspecialchars($post['username'], ENT_QUOTES);

  $ogExtra = <<<OG
  <!-- Open Graph / Facebook -->
  <meta property="og:type"        content="article" />
  <meta property="og:url"         content="{$ogUrl}" />
  <meta property="og:title"       content="{$ogTitle}" />
  <meta property="og:description" content="{$ogDesc}" />
  <meta property="og:image"       content="{$ogImg}" />
  <meta property="og:image:width"  content="1200" />
  <meta property="og:image:height" content="630" />
  <meta property="og:site_name"   content="codeMe Versus" />
  <meta property="article:author" content="{$ogAuthor}" />
  <!-- Twitter Card -->
  <meta name="twitter:card"        content="summary_large_image" />
  <meta name="twitter:url"         content="{$ogUrl}" />
  <meta name="twitter:title"       content="{$ogTitle}" />
  <meta name="twitter:description" content="{$ogDesc}" />
  <meta name="twitter:image"       content="{$ogImg}" />
  <!-- Canonical -->
  <link rel="canonical" href="{$ogUrl}" />
OG;

  pageHeader(e($post['title']).' — codeMe Showcase', $ogExtra);
  showSinglePost($post, $reactions, $myReacts, $comments, $user);
  pageFooter();
  exit;
}

// ── Feed / listing ─────────────────────────────────────────────────────────────
$page    = max(1, (int)($_GET['page'] ?? 1));
$perPage = 12;
$offset  = ($page - 1) * $perPage;

$total = db()->query('SELECT COUNT(*) FROM showcase_posts')->fetchColumn();

$posts = db()->prepare(
  'SELECT p.*, u.username, u.avatar, u.avatar_img,
          (SELECT COUNT(*) FROM showcase_reactions r WHERE r.post_id=p.id) AS reaction_count,
          (SELECT COUNT(*) FROM showcase_comments c WHERE c.post_id=p.id) AS comment_count
   FROM showcase_posts p
   JOIN users u ON u.id=p.user_id
   ORDER BY p.created_at DESC
   LIMIT ? OFFSET ?'
);
$posts->execute([$perPage, $offset]);
$posts = $posts->fetchAll();

pageHeader('Showcase');

// ════════════════════════════════════════════════════════════════════════════
// ── HTML OUTPUT ─────────────────────────────────────────────────────────────
// ════════════════════════════════════════════════════════════════════════════
?>
<style>
/* ── Showcase page styles ─────────────────────────────────────────── */
.sc-header{padding:40px 24px 20px;max-width:1100px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap}
.sc-header h1{font-size:28px;font-weight:800;letter-spacing:-1px}
.sc-header h1 span{color:var(--green)}
.sc-header p{font-family:var(--font-mono);font-size:12px;color:var(--muted);margin-top:4px}

/* ── Post button ────────────────────────────────────────────────── */
.btn-post{background:var(--green);color:#080b12;border:none;border-radius:10px;padding:10px 22px;font-size:13px;font-weight:800;cursor:pointer;letter-spacing:.3px;display:inline-flex;align-items:center;gap:7px;transition:filter .2s,transform .2s;font-family:var(--font-head)}
.btn-post:hover{filter:brightness(1.1);transform:translateY(-1px)}

/* ── Feed grid ──────────────────────────────────────────────────── */
.sc-feed{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:18px;max-width:1100px;margin:0 auto;padding:0 24px 60px}
.sc-card{background:var(--bg2);border:1px solid var(--border);border-radius:16px;overflow:hidden;display:flex;flex-direction:column;transition:border-color .2s,transform .2s}
.sc-card:hover{border-color:rgba(0,255,135,.25);transform:translateY(-2px)}

/* ── Preview iframe ─────────────────────────────────────────────── */
.sc-preview{width:100%;height:200px;border:none;display:block;pointer-events:none;background:#0e1320}
.sc-preview-wrap{position:relative;overflow:hidden;border-bottom:1px solid var(--border)}
.sc-preview-wrap::after{content:'';position:absolute;inset:0}

.sc-card-body{padding:14px 16px;flex:1;display:flex;flex-direction:column;gap:10px}
.sc-card-title{font-size:14px;font-weight:700;color:#fff;letter-spacing:-.3px;line-height:1.3}
.sc-card-meta{display:flex;align-items:center;gap:8px;font-size:11px;color:var(--muted);font-family:var(--font-mono);flex-wrap:wrap}
.sc-card-avatar{width:20px;height:20px;border-radius:50%;object-fit:cover;vertical-align:middle;cursor:pointer;transition:opacity .15s}
.sc-card-avatar:hover{opacity:.8}
.sc-username-link{color:var(--muted);text-decoration:none;font-weight:600;transition:color .15s}
.sc-username-link:hover{color:var(--green)}
.sc-card-footer{display:flex;align-items:center;justify-content:space-between;padding-top:8px;border-top:1px solid var(--border)}
.sc-stat{display:flex;align-items:center;gap:4px;font-size:11px;color:var(--muted);font-family:var(--font-mono)}
.sc-view-btn{font-size:11px;font-weight:700;color:var(--green);background:rgba(0,255,135,.08);border:1px solid rgba(0,255,135,.2);border-radius:6px;padding:4px 12px;cursor:pointer;text-decoration:none;transition:background .2s}
.sc-view-btn:hover{background:rgba(0,255,135,.18)}

/* ── Versus badge on card ──────────────────────────────────────── */
.vs-allowed-badge{display:inline-flex;align-items:center;gap:3px;font-size:9px;font-weight:700;font-family:var(--font-mono);letter-spacing:.5px;color:#a78bfa;background:rgba(167,139,250,.1);border:1px solid rgba(167,139,250,.25);border-radius:5px;padding:2px 6px}

/* ── Share button + dropdown ────────────────────────────────────── */
.sc-share-wrap{position:relative;display:inline-flex}
.sc-share-btn{display:inline-flex;align-items:center;gap:5px;font-size:10px;font-weight:700;font-family:var(--font-mono);color:var(--muted);background:none;border:1px solid var(--border);border-radius:6px;padding:3px 9px;cursor:pointer;transition:color .15s,border-color .15s;white-space:nowrap}
.sc-share-btn:hover{color:#fff;border-color:rgba(255,255,255,.25)}
.sc-share-btn svg{flex-shrink:0}
.share-dropdown{position:absolute;bottom:calc(100% + 8px);right:0;min-width:210px;background:var(--bg2);border:1px solid var(--border);border-radius:14px;box-shadow:0 16px 48px rgba(0,0,0,.6);z-index:600;overflow:hidden;display:none;animation:dropIn .15s ease}
@keyframes dropIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
.share-dropdown.open{display:block}
.sd-item{display:flex;align-items:center;gap:11px;width:100%;padding:11px 14px;font-size:12px;font-weight:600;color:#fff;background:none;border:none;cursor:pointer;text-align:left;font-family:var(--font-head);transition:background .12s}
.sd-item:hover{background:rgba(255,255,255,.06)}
.sd-icon{width:30px;height:30px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:14px;flex-shrink:0}
.sd-icon.fb{background:#1877f2;font-weight:900;font-family:serif;font-size:16px;color:#fff}
.sd-icon.copy{background:rgba(0,255,135,.12);font-size:16px}
.sd-icon.native{background:rgba(255,255,255,.08);font-size:15px}
.sd-sub{display:block;font-size:10px;font-weight:400;color:var(--muted);font-family:var(--font-mono);margin-top:1px}
.sd-divider{margin:0;border:none;border-top:1px solid var(--border)}

/* empty state */
.sc-empty{text-align:center;padding:80px 20px;color:var(--muted)}
.sc-empty h2{font-size:20px;font-weight:700;margin-bottom:8px;color:#fff}
.sc-empty p{font-family:var(--font-mono);font-size:12px}

/* ── Modal ──────────────────────────────────────────────────────── */
.modal-bg{position:fixed;inset:0;background:rgba(0,0,0,.7);backdrop-filter:blur(6px);z-index:500;display:none;align-items:center;justify-content:center;padding:20px}
.modal-bg.open{display:flex}
.modal{background:var(--bg2);border:1px solid var(--border);border-radius:20px;width:100%;max-width:680px;max-height:90vh;overflow-y:auto;padding:28px;position:relative}
.modal h2{font-size:20px;font-weight:800;margin-bottom:20px;letter-spacing:-.5px}
.modal-close{position:absolute;top:16px;right:18px;background:none;border:none;color:var(--muted);font-size:22px;cursor:pointer;line-height:1;padding:4px 8px;border-radius:6px}
.modal-close:hover{color:#fff;background:rgba(255,255,255,.07)}

/* ── Form controls ──────────────────────────────────────────────── */
.form-group{margin-bottom:14px}
.form-group label{display:block;font-size:11px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--muted);margin-bottom:6px;font-family:var(--font-mono)}
.form-group input,.form-group textarea{width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:10px;color:#fff;padding:10px 14px;font-size:13px;font-family:var(--font-mono);resize:vertical;transition:border-color .2s;outline:none}
.form-group input:focus,.form-group textarea:focus{border-color:rgba(0,255,135,.4)}
.form-group textarea{min-height:90px;line-height:1.5}
.tab-bar{display:flex;gap:4px;margin-bottom:8px}
.tab-btn{background:none;border:none;color:var(--muted);font-size:12px;font-weight:700;font-family:var(--font-mono);padding:6px 14px;border-radius:8px;cursor:pointer;transition:color .15s,background .15s}
.tab-btn:hover{color:#fff}
.tab-btn.active{background:rgba(0,255,135,.12);color:var(--green)}
.tab-copy-btn{margin-left:auto;background:none;border:1px solid var(--border);color:var(--muted);font-size:11px;font-weight:700;font-family:var(--font-mono);padding:4px 12px;border-radius:7px;cursor:pointer;transition:all .15s;letter-spacing:.3px}
.tab-copy-btn:hover{border-color:var(--green);color:var(--green)}
.tab-copy-btn.copied{border-color:var(--green);color:var(--green);background:rgba(0,255,135,.1)}
.form-actions{display:flex;gap:10px;justify-content:flex-end;margin-top:18px}
.btn-cancel{background:transparent;border:1px solid var(--border);color:var(--muted);border-radius:10px;padding:10px 20px;font-size:13px;font-weight:700;cursor:pointer;font-family:var(--font-head)}
.btn-cancel:hover{color:#fff}
.btn-submit{background:var(--green);color:#080b12;border:none;border-radius:10px;padding:10px 24px;font-size:13px;font-weight:800;cursor:pointer;font-family:var(--font-head)}

/* ── Versus toggle in new-post modal ───────────────────────────── */
.vs-toggle-row{display:flex;align-items:flex-start;gap:12px;background:rgba(167,139,250,.05);border:1px solid rgba(167,139,250,.2);border-radius:12px;padding:14px;margin-bottom:16px;cursor:pointer;transition:background .15s}
.vs-toggle-row:hover{background:rgba(167,139,250,.09)}
.vs-toggle-row input[type=checkbox]{width:17px;height:17px;margin-top:2px;accent-color:#a78bfa;cursor:pointer;flex-shrink:0}
.vs-toggle-label strong{display:block;font-size:13px;font-weight:700;color:#fff;margin-bottom:3px}
.vs-toggle-label span{font-size:11px;font-family:var(--font-mono);color:var(--muted);line-height:1.5}

/* ── Pagination ─────────────────────────────────────────────────── */
.sc-pagination{display:flex;gap:8px;justify-content:center;padding:0 24px 40px}
.sc-pagination a{background:var(--bg2);border:1px solid var(--border);color:var(--muted);padding:8px 16px;border-radius:9px;font-size:13px;font-weight:600;text-decoration:none;transition:color .15s,border-color .15s}
.sc-pagination a:hover,.sc-pagination a.cur{color:var(--green);border-color:rgba(0,255,135,.3)}

/* ── User profile page ──────────────────────────────────────────── */
.up-wrap{max-width:1100px;margin:0 auto;padding:0 24px 60px}
.up-hero{display:flex;align-items:center;gap:22px;padding:36px 0 28px;border-bottom:1px solid var(--border);margin-bottom:28px;flex-wrap:wrap}
.up-avatar-ring{width:80px;height:80px;border-radius:50%;border:3px solid var(--green);display:flex;align-items:center;justify-content:center;font-size:40px;background:var(--bg3);overflow:hidden;flex-shrink:0}
.up-avatar-ring img{width:100%;height:100%;object-fit:cover}
.up-name{font-size:26px;font-weight:800;letter-spacing:-1px;line-height:1}
.up-meta{font-size:12px;font-family:var(--font-mono);color:var(--muted);margin-top:6px}
.up-bio{font-size:13px;font-family:var(--font-mono);color:var(--muted);margin-top:6px;line-height:1.5}
.up-back{display:inline-flex;align-items:center;gap:6px;font-size:12px;font-family:var(--font-mono);color:var(--muted);text-decoration:none;padding:28px 24px 0;transition:color .15s;max-width:1100px;margin:0 auto;display:block}
.up-back:hover{color:#fff}
</style>

<!-- ── Header ──────────────────────────────────────────────────────────── -->
<div class="sc-header">
  <div>
    <h1>Code <span>Showcase</span></h1>
    <p>Share your HTML, CSS &amp; JS creations with the community</p>
  </div>
  <?php if ($user): ?>
    <button class="btn-post" onclick="openPostModal()">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
      Share Code
    </button>
  <?php else: ?>
    <a href="login.php" class="btn-post">Login to Share</a>
  <?php endif; ?>
</div>

<!-- ── Feed ─────────────────────────────────────────────────────────────── -->
<?php if (empty($posts)): ?>
  <div class="sc-empty">
    <h2>No posts yet</h2>
    <p>Be the first to share your code!</p>
  </div>
<?php else: ?>
  <div class="sc-feed">
    <?php foreach ($posts as $p): ?>
      <div class="sc-card">
        <div class="sc-preview-wrap">
          <iframe class="sc-preview" sandbox="allow-scripts" srcdoc="<?= htmlspecialchars(buildSrcdoc($p['html_code'], $p['css_code'], $p['js_code']), ENT_QUOTES) ?>"></iframe>
        </div>
        <div class="sc-card-body">
          <div class="sc-card-title"><?= e($p['title']) ?></div>
          <?php if ($p['description']): ?>
            <div style="font-size:12px;color:var(--muted);font-family:var(--font-mono);line-height:1.5"><?= e(mb_strimwidth($p['description'],0,80,'…')) ?></div>
          <?php endif; ?>
          <div class="sc-card-meta">
            <!-- Clickable avatar → user profile -->
            <?php if ($p['avatar_img']): ?>
              <img src="<?= e($p['avatar_img']) ?>" class="sc-card-avatar" alt=""
                   onclick="location.href='showcase.php?user=<?= (int)$p['user_id'] ?>'">
            <?php else: ?>
              <span style="cursor:pointer" onclick="location.href='showcase.php?user=<?= (int)$p['user_id'] ?>'">
                <?= e($p['avatar'] ?: '👤') ?>
              </span>
            <?php endif; ?>
            <!-- Clickable username → user profile -->
            <a class="sc-username-link" href="showcase.php?user=<?= (int)$p['user_id'] ?>"><?= e($p['username']) ?></a>
            <span>·</span>
            <span><?= timeAgo($p['created_at']) ?></span>
            <?php if (!empty($p['allow_versus'])): ?>
              <span class="vs-allowed-badge">⚔ Versus OK</span>
            <?php endif; ?>
          </div>
          <div class="sc-card-footer">
            <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
              <span class="sc-stat">🔥 <?= (int)$p['reaction_count'] ?></span>
              <span class="sc-stat">💬 <?= (int)$p['comment_count'] ?></span>
              <span class="sc-stat">👁 <?= (int)$p['views'] ?></span>
              <!-- Share button -->
              <div class="sc-share-wrap" id="sw-<?= $p['id'] ?>">
                <button class="sc-share-btn" onclick="toggleShare(event,<?= $p['id'] ?>)">
                  <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>
                  Share
                </button>
                <div class="share-dropdown" id="sd-<?= $p['id'] ?>">
                  <button class="sd-item" onclick="shareToFacebook(<?= $p['id'] ?>)">
                    <span class="sd-icon fb">f</span>
                    <span>Facebook<span class="sd-sub">Share to your timeline</span></span>
                  </button>
                  <hr class="sd-divider">
                  <button class="sd-item" onclick="shareNative(<?= $p['id'] ?>, <?= json_encode($p['title']) ?>)">
                    <span class="sd-icon native">↗</span>
                    <span>Share…<span class="sd-sub">Device share sheet</span></span>
                  </button>
                  <button class="sd-item" onclick="copyLink(<?= $p['id'] ?>)">
                    <span class="sd-icon copy">🔗</span>
                    <span>Copy Link<span class="sd-sub">Copy URL to clipboard</span></span>
                  </button>
                </div>
              </div>
            </div>
            <a href="showcase.php?id=<?= $p['id'] ?>" class="sc-view-btn">View →</a>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>

  <!-- ── Pagination ─────────────────────────────────────────────────── -->
  <?php $pages = ceil($total / $perPage); if ($pages > 1): ?>
    <div class="sc-pagination">
      <?php for ($i=1; $i<=$pages; $i++): ?>
        <a href="showcase.php?page=<?= $i ?>" class="<?= $i===$page?'cur':'' ?>"><?= $i ?></a>
      <?php endfor; ?>
    </div>
  <?php endif; ?>
<?php endif; ?>

<!-- ════════════════════════════════════════════════════════════════════
     NEW POST MODAL
════════════════════════════════════════════════════════════════════ -->
<?php if ($user): ?>
<div class="modal-bg" id="postModal">
  <div class="modal">
    <button class="modal-close" onclick="closePostModal()">✕</button>
    <h2>Share Your Code</h2>

    <div class="form-group">
      <label>Title *</label>
      <input type="text" id="postTitle" placeholder="e.g. Glowing neon button" maxlength="120">
    </div>
    <div class="form-group">
      <label>Description</label>
      <input type="text" id="postDesc" placeholder="Short description (optional)" maxlength="300">
    </div>

    <!-- ⚔ Versus permission toggle -->
    <label class="vs-toggle-row" for="chkVersus">
      <input type="checkbox" id="chkVersus">
      <div class="vs-toggle-label">
        <strong>⚔ Allow as Versus Reference</strong>
        <span>Other players can use this post as the target design in Versus mode battles</span>
      </div>
    </label>

    <div class="form-group">
      <label>Code</label>
      <div class="tab-bar">
        <button class="tab-btn active" onclick="switchTab('html',this)">HTML</button>
        <button class="tab-btn" onclick="switchTab('css',this)">CSS</button>
        <button class="tab-btn" onclick="switchTab('js',this)">JS</button>
        <button class="tab-copy-btn" onclick="copyActiveTab(this)" title="Copy code">⎘ Copy</button>
      </div>
      <textarea id="code-html" placeholder="<!-- Your HTML here -->" style="min-height:160px;display:block"></textarea>
      <textarea id="code-css"  placeholder="/* Your CSS here */"  style="min-height:160px;display:none"></textarea>
      <textarea id="code-js"   placeholder="// Your JS here"     style="min-height:160px;display:none"></textarea>
    </div>

    <div class="form-group">
      <label>Live Preview</label>
      <div style="border:1px solid var(--border);border-radius:10px;overflow:hidden;height:200px">
        <iframe id="modalPreview" sandbox="allow-scripts" style="width:100%;height:100%;border:none;background:#0e1320"></iframe>
      </div>
      <button onclick="refreshModalPreview()" style="margin-top:8px;background:var(--bg3);border:1px solid var(--border);color:var(--muted);border-radius:8px;padding:6px 14px;font-size:11px;font-weight:700;cursor:pointer;font-family:var(--font-mono)">↻ Refresh Preview</button>
    </div>

    <div class="form-actions">
      <button class="btn-cancel" onclick="closePostModal()">Cancel</button>
      <button class="btn-submit" onclick="submitPost()">Publish ✦</button>
    </div>
  </div>
</div>

<script>
/* ── Modal ────────────────────────────────────────────────────────── */
function openPostModal(){ document.getElementById('postModal').classList.add('open'); }
function closePostModal(){ document.getElementById('postModal').classList.remove('open'); }

let activeTab = 'html';
function switchTab(tab,btn){
  document.querySelectorAll('[id^="code-"]').forEach(el=>el.style.display='none');
  document.getElementById('code-'+tab).style.display='block';
  document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  activeTab=tab;
}
function copyActiveTab(btn){
  const txt = document.getElementById('code-'+activeTab)?.value || '';
  navigator.clipboard.writeText(txt).then(()=>{
    btn.textContent='✓ Copied!'; btn.classList.add('copied');
    setTimeout(()=>{ btn.textContent='⎘ Copy'; btn.classList.remove('copied'); },2000);
  });
}
function buildSrcdoc(){
  const html=document.getElementById('code-html').value;
  const css=document.getElementById('code-css').value;
  const js=document.getElementById('code-js').value;
  return `<!DOCTYPE html><html><head><meta charset="UTF-8"><style>${css}</style></head><body>${html}<script>${js}<\/script></body></html>`;
}
function refreshModalPreview(){
  document.getElementById('modalPreview').srcdoc=buildSrcdoc();
}
let previewTimer;
['code-html','code-css','code-js'].forEach(id=>{
  document.getElementById(id).addEventListener('input',()=>{
    clearTimeout(previewTimer);
    previewTimer=setTimeout(refreshModalPreview,800);
  });
});
document.getElementById('postModal').addEventListener('click',function(e){
  if(e.target===this) closePostModal();
});
async function submitPost(){
  const title=document.getElementById('postTitle').value.trim();
  if(!title){showToast('Please enter a title');return;}
  const fd=new FormData();
  fd.append('action','submit_post');
  fd.append('title',title);
  fd.append('description',document.getElementById('postDesc').value.trim());
  fd.append('html_code',document.getElementById('code-html').value);
  fd.append('css_code',document.getElementById('code-css').value);
  fd.append('js_code',document.getElementById('code-js').value);
  if(document.getElementById('chkVersus').checked) fd.append('allow_versus','1');
  const res=await fetch('showcase.php',{method:'POST',body:fd});
  const data=await res.json();
  if(data.ok){
    showToast('Posted! ✦');
    setTimeout(()=>window.location.href='showcase.php?id='+data.id,800);
  } else {
    showToast(data.msg||'Error');
  }
}

/* ── Share dropdown ───────────────────────────────────────────────── */
function getPostUrl(id){ return location.origin+location.pathname+'?id='+id; }

function toggleShare(e,id){
  e.stopPropagation();
  const dd=document.getElementById('sd-'+id);
  const wasOpen=dd.classList.contains('open');
  document.querySelectorAll('.share-dropdown').forEach(d=>d.classList.remove('open'));
  if(!wasOpen) dd.classList.add('open');
}
document.addEventListener('click',()=>
  document.querySelectorAll('.share-dropdown').forEach(d=>d.classList.remove('open'))
);
function shareToFacebook(id){
  const url='https://www.facebook.com/sharer/sharer.php?u='+encodeURIComponent(getPostUrl(id));
  window.open(url,'_blank','width=626,height=436');
  document.querySelectorAll('.share-dropdown').forEach(d=>d.classList.remove('open'));
}
async function shareNative(id,title){
  document.querySelectorAll('.share-dropdown').forEach(d=>d.classList.remove('open'));
  if(navigator.share){
    try{ await navigator.share({title,url:getPostUrl(id)}); return; }catch(e){}
  }
  copyLink(id);
}
function copyLink(id){
  document.querySelectorAll('.share-dropdown').forEach(d=>d.classList.remove('open'));
  const url=getPostUrl(id);
  navigator.clipboard.writeText(url)
    .then(()=>showToast('Link copied!'))
    .catch(()=>prompt('Copy this link:',url));
}
</script>
<?php endif; ?>

<?php
pageFooter();

// ═══════════════════════════════════════════════════════════════════════════
// ── HELPER FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════

function buildSrcdoc(?string $html, ?string $css, ?string $js): string {
  return '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>'
    . ($css ?? '')
    . '</style></head><body>'
    . ($html ?? '')
    . '<script>' . ($js ?? '') . '<\/script></body></html>';
}

function timeAgo(string $dt): string {
  $diff = time() - strtotime($dt);
  if ($diff < 60)      return 'just now';
  if ($diff < 3600)    return (int)($diff/60).'m ago';
  if ($diff < 86400)   return (int)($diff/3600).'h ago';
  if ($diff < 2592000) return (int)($diff/86400).'d ago';
  return date('M j, Y', strtotime($dt));
}

// ═══════════════════════════════════════════════════════════════════════════
// ── USER PROFILE PAGE renderer
// ═══════════════════════════════════════════════════════════════════════════
function showUserProfile(array $pu, array $posts, int $total, int $page, int $perPage, ?array $me, array $profileStats = []): void {
  // All stats already fetched at page load — no extra DB queries here
  $followerCount  = (int)($profileStats['followerCount']  ?? 0);
  $followingCount = (int)($profileStats['followingCount'] ?? 0);
  $totalViews     = (int)($profileStats['totalViews']     ?? 0);
  $totalReactions = (int)($profileStats['totalReactions'] ?? 0);
  $isFollowing    =  (bool)($profileStats['isFollowing']  ?? false);
  $followersList  = $profileStats['followersList'] ?? [];
  $followingList  = $profileStats['followingList'] ?? [];
  $isOwn          = $me && (int)$me['id'] === (int)$pu['id'];
?>
<style>
/* ── Profile page redesign ─────────────────────────────────────── */
.up2-wrap{max-width:1100px;margin:0 auto;padding:0 24px 80px}

/* Back link */
.up2-back{display:inline-flex;align-items:center;gap:6px;font-size:12px;font-family:var(--font-mono);color:var(--muted);text-decoration:none;padding:24px 24px 0;max-width:1100px;margin:0 auto;display:block;transition:color .15s}
.up2-back:hover{color:var(--green)}

/* Banner + Hero */
.up2-banner{height:160px;background:linear-gradient(135deg,#0d1f14 0%,#0a1628 40%,#130d24 100%);border-radius:20px 20px 0 0;position:relative;overflow:hidden;border:1px solid var(--border);border-bottom:none}
.up2-banner::before{content:'';position:absolute;inset:0;background:repeating-linear-gradient(45deg,rgba(0,255,135,.03) 0px,rgba(0,255,135,.03) 1px,transparent 1px,transparent 28px)}
.up2-banner-glow{position:absolute;top:-60px;left:50%;transform:translateX(-50%);width:400px;height:200px;background:radial-gradient(ellipse,rgba(0,255,135,.12) 0%,transparent 70%);pointer-events:none}

.up2-hero-card{background:var(--bg2);border:1px solid var(--border);border-top:none;border-radius:0 0 20px 20px;padding:0 28px 28px;margin-bottom:28px;position:relative}
.up2-avatar-wrap{position:absolute;top:-44px;left:28px}
.up2-avatar{width:88px;height:88px;border-radius:50%;border:4px solid var(--bg2);background:var(--bg3);display:flex;align-items:center;justify-content:center;font-size:42px;overflow:hidden;box-shadow:0 0 0 2px var(--green)}
.up2-avatar img{width:100%;height:100%;object-fit:cover}

.up2-hero-top{display:flex;align-items:flex-start;justify-content:space-between;padding-top:54px;flex-wrap:wrap;gap:12px}
.up2-name{font-size:24px;font-weight:800;letter-spacing:-1px;line-height:1.1}
.up2-handle{font-size:12px;font-family:var(--font-mono);color:var(--muted);margin-top:3px}
.up2-bio{font-size:13px;font-family:var(--font-mono);color:var(--muted);margin-top:10px;line-height:1.6;max-width:520px}
.up2-joined{font-size:11px;font-family:var(--font-mono);color:var(--muted);margin-top:8px;display:flex;align-items:center;gap:5px}

/* Stats bar */
.up2-stats{display:flex;gap:0;border-top:1px solid var(--border);margin-top:20px;padding-top:20px;flex-wrap:wrap}
.up2-stat{flex:1;min-width:80px;text-align:center;padding:0 12px;border-right:1px solid var(--border)}
.up2-stat:last-child{border-right:none}
.up2-stat-val{font-size:20px;font-weight:800;letter-spacing:-1px;color:#fff;line-height:1}
.up2-stat-lbl{font-size:10px;font-family:var(--font-mono);color:var(--muted);margin-top:4px;letter-spacing:.5px;text-transform:uppercase}
.up2-stat-clickable{cursor:pointer;border-radius:10px;transition:background .15s;padding:8px 12px;margin:-8px -12px}
.up2-stat-clickable:hover{background:rgba(255,255,255,.05)}
.up2-stat-clickable:hover .up2-stat-lbl{color:var(--green)}

/* Followers/Following modal */
.fol-modal-bg{position:fixed;inset:0;background:rgba(0,0,0,.7);backdrop-filter:blur(6px);z-index:800;display:none;align-items:center;justify-content:center;padding:20px}
.fol-modal-bg.open{display:flex}
.fol-modal{background:var(--bg2);border:1px solid var(--border);border-radius:20px;width:100%;max-width:400px;overflow:hidden;position:relative}
.fol-modal-head{padding:18px 20px 0;display:flex;align-items:center;justify-content:space-between}
.fol-modal-title{font-size:15px;font-weight:800;letter-spacing:-.3px}
.fol-modal-close{background:none;border:none;color:var(--muted);font-size:20px;cursor:pointer;line-height:1;padding:4px 8px;border-radius:6px}
.fol-modal-close:hover{color:#fff;background:rgba(255,255,255,.07)}
.fol-tabs{display:flex;border-bottom:1px solid var(--border);margin-top:14px}
.fol-tab{flex:1;padding:10px;text-align:center;font-size:11px;font-family:var(--font-mono);font-weight:700;letter-spacing:1px;color:var(--muted);cursor:pointer;border:none;background:none;border-bottom:3px solid transparent;transition:all .15s}
.fol-tab.active{color:var(--green);border-bottom-color:var(--green)}
.fol-list{max-height:280px;overflow-y:auto;padding:8px 0 12px}
.fol-item{display:flex;align-items:center;gap:12px;padding:10px 20px;transition:background .15s;text-decoration:none}
.fol-item:hover{background:rgba(255,255,255,.04)}
.fol-avt{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:18px;background:var(--bg3);border:1px solid var(--border);overflow:hidden;flex-shrink:0}
.fol-avt img{width:100%;height:100%;object-fit:cover}
.fol-username{font-size:13px;font-weight:700;color:#fff}
.fol-since{font-size:10px;font-family:var(--font-mono);color:var(--muted);margin-top:2px}
.fol-empty{text-align:center;padding:30px 20px;font-family:var(--font-mono);font-size:11px;color:var(--muted)}

/* Follow button */
.up2-follow-btn{display:inline-flex;align-items:center;gap:7px;padding:10px 22px;border-radius:10px;font-size:13px;font-weight:700;font-family:var(--font-head);cursor:pointer;transition:all .2s;border:none;white-space:nowrap}
.up2-follow-btn.follow{background:var(--green);color:#080b12}
.up2-follow-btn.follow:hover{filter:brightness(1.1);transform:translateY(-1px)}
.up2-follow-btn.unfollow{background:transparent;color:var(--muted);border:1px solid var(--border)}
.up2-follow-btn.unfollow:hover{border-color:rgba(255,80,80,.4);color:#ff6b6b}

/* Section header */
.up2-section-hd{display:flex;align-items:center;justify-content:space-between;margin-bottom:18px}
.up2-section-hd h2{font-size:16px;font-weight:800;letter-spacing:-.5px}
.up2-section-hd span{font-size:12px;font-family:var(--font-mono);color:var(--muted)}

/* Cards */
.up2-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:18px}
.up2-card{background:var(--bg2);border:1px solid var(--border);border-radius:16px;overflow:hidden;display:flex;flex-direction:column;transition:border-color .2s,transform .2s,box-shadow .2s}
.up2-card:hover{border-color:rgba(0,255,135,.3);transform:translateY(-3px);box-shadow:0 12px 32px rgba(0,0,0,.4)}
.up2-card-preview{position:relative;border-bottom:1px solid var(--border);background:#0e1320}
.up2-card-preview iframe{width:100%;height:190px;border:none;display:block;pointer-events:none}
.up2-card-preview .up2-view-overlay{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;opacity:0;transition:opacity .2s;background:rgba(0,0,0,.5);cursor:pointer;z-index:2}
.up2-card:hover .up2-view-overlay{opacity:1}
.up2-view-overlay a{background:var(--green);color:#080b12;font-size:12px;font-weight:800;font-family:var(--font-head);padding:8px 20px;border-radius:8px;text-decoration:none;pointer-events:auto}

.up2-card-body{padding:14px 16px;flex:1;display:flex;flex-direction:column;gap:8px}
.up2-card-title{font-size:14px;font-weight:700;color:#fff;letter-spacing:-.3px;line-height:1.3}
.up2-card-desc{font-size:11px;color:var(--muted);font-family:var(--font-mono);line-height:1.5}
.up2-card-time{font-size:10px;font-family:var(--font-mono);color:var(--muted)}

.up2-card-footer{display:flex;align-items:center;justify-content:space-between;padding-top:8px;border-top:1px solid var(--border);margin-top:auto}
.up2-foot-stats{display:flex;gap:10px}
.up2-foot-stat{display:flex;align-items:center;gap:3px;font-size:11px;color:var(--muted);font-family:var(--font-mono)}

.up2-vs-badge{display:inline-flex;align-items:center;gap:3px;font-size:9px;font-weight:700;font-family:var(--font-mono);letter-spacing:.5px;color:#a78bfa;background:rgba(167,139,250,.1);border:1px solid rgba(167,139,250,.25);border-radius:5px;padding:2px 6px}

/* Share */
.sc-share-wrap{position:relative;display:inline-flex}
.sc-share-btn{display:inline-flex;align-items:center;gap:5px;font-size:10px;font-weight:700;font-family:var(--font-mono);color:var(--muted);background:none;border:1px solid var(--border);border-radius:6px;padding:3px 9px;cursor:pointer;transition:color .15s,border-color .15s;white-space:nowrap}
.sc-share-btn:hover{color:#fff;border-color:rgba(255,255,255,.25)}
.share-dropdown{position:absolute;bottom:calc(100% + 8px);right:0;min-width:210px;background:var(--bg2);border:1px solid var(--border);border-radius:14px;box-shadow:0 16px 48px rgba(0,0,0,.6);z-index:600;overflow:hidden;display:none;animation:dropIn .15s ease}
@keyframes dropIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
.share-dropdown.open{display:block}
.sd-item{display:flex;align-items:center;gap:11px;width:100%;padding:11px 14px;font-size:12px;font-weight:600;color:#fff;background:none;border:none;cursor:pointer;text-align:left;font-family:var(--font-head);transition:background .12s}
.sd-item:hover{background:rgba(255,255,255,.06)}
.sd-icon{width:30px;height:30px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:14px;flex-shrink:0}
.sd-icon.fb{background:#1877f2;font-weight:900;font-family:serif;font-size:16px;color:#fff}
.sd-icon.copy{background:rgba(0,255,135,.12)}
.sd-icon.native{background:rgba(255,255,255,.08)}
.sd-sub{display:block;font-size:10px;font-weight:400;color:var(--muted);font-family:var(--font-mono);margin-top:1px}
.sd-divider{margin:0;border:none;border-top:1px solid var(--border)}

/* Empty */
.up2-empty{text-align:center;padding:60px 20px;color:var(--muted)}
.up2-empty h3{font-size:18px;font-weight:700;color:#fff;margin-bottom:8px}
.up2-empty p{font-size:12px;font-family:var(--font-mono)}

/* Pagination */
.up2-pagination{display:flex;gap:8px;justify-content:center;padding:28px 0 0}
.up2-pagination a{background:var(--bg2);border:1px solid var(--border);color:var(--muted);padding:8px 16px;border-radius:9px;font-size:13px;font-weight:600;text-decoration:none;transition:color .15s,border-color .15s}
.up2-pagination a:hover,.up2-pagination a.cur{color:var(--green);border-color:rgba(0,255,135,.3)}

@media(max-width:600px){
  .up2-stats{gap:0}.up2-stat{min-width:60px;padding:0 8px}
  .up2-stat-val{font-size:16px}
  .up2-hero-top{padding-top:50px}
  .up2-name{font-size:20px}
}
</style>

<a href="showcase.php" class="up2-back">← Back to Showcase</a>

<div style="max-width:1100px;margin:0 auto;padding:16px 24px 0">
  <!-- Banner -->
  <div class="up2-banner">
    <div class="up2-banner-glow"></div>
  </div>

  <!-- Hero card -->
  <div class="up2-hero-card">
    <div class="up2-avatar-wrap">
      <div class="up2-avatar">
        <?php if (!empty($pu['avatar_img'])): ?>
          <img src="<?= e($pu['avatar_img']) ?>" alt="">
        <?php else: ?>
          <?= e($pu['avatar'] ?: '👤') ?>
        <?php endif; ?>
      </div>
    </div>

    <div class="up2-hero-top">
      <div>
        <div class="up2-name"><?= e($pu['username']) ?></div>
        <div class="up2-handle">@<?= strtolower(e($pu['username'])) ?></div>
        <?php if (!empty($pu['bio'])): ?>
          <div class="up2-bio"><?= e($pu['bio']) ?></div>
        <?php endif; ?>
        <div class="up2-joined">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
          Joined <?= date('F Y', strtotime($pu['created_at'])) ?>
        </div>
      </div>
      <?php if ($me && !$isOwn): ?>
        <div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center">
          <button class="up2-follow-btn <?= $isFollowing ? 'unfollow' : 'follow' ?>"
                  id="followBtn"
                  onclick="upToggleFollow(<?= (int)$pu['id'] ?>)">
            <?= $isFollowing ? '✓ Following' : '+ Follow' ?>
          </button>
          <a href="messages.php?with=<?= (int)$pu['id'] ?>"
             style="display:inline-flex;align-items:center;gap:7px;padding:10px 18px;border-radius:10px;font-size:13px;font-weight:700;font-family:var(--font-head);color:var(--text);border:1px solid var(--border);background:var(--bg3);text-decoration:none;transition:all .2s"
             onmouseover="this.style.borderColor='rgba(0,255,135,.35)';this.style.color='var(--green)'"
             onmouseout="this.style.borderColor='var(--border)';this.style.color='var(--text)'">
            💬 Message
          </a>
          <button onclick="upVoiceCall(<?= (int)$pu['id'] ?>, <?= json_encode(e($pu['username'])) ?>, <?= json_encode($pu['avatar_img'] ? e($pu['avatar_img']) : '') ?>, <?= json_encode(e($pu['avatar'] ?: '👤')) ?>)"
             style="display:inline-flex;align-items:center;gap:7px;padding:10px 18px;border-radius:10px;font-size:13px;font-weight:700;font-family:var(--font-head);color:var(--text);border:1px solid var(--border);background:var(--bg3);cursor:pointer;transition:all .2s"
             onmouseover="this.style.borderColor='rgba(0,255,135,.35)';this.style.color='var(--green)'"
             onmouseout="this.style.borderColor='var(--border)';this.style.color='var(--text)'">
            📞 Call
          </button>
          <button onclick="upVideoCall(<?= (int)$pu['id'] ?>, <?= json_encode(e($pu['username'])) ?>, <?= json_encode($pu['avatar_img'] ? e($pu['avatar_img']) : '') ?>, <?= json_encode(e($pu['avatar'] ?: '👤')) ?>)"
             style="display:inline-flex;align-items:center;gap:7px;padding:10px 18px;border-radius:10px;font-size:13px;font-weight:700;font-family:var(--font-head);color:var(--text);border:1px solid var(--border);background:var(--bg3);cursor:pointer;transition:all .2s"
             onmouseover="this.style.borderColor='rgba(0,200,255,.35)';this.style.color='var(--blue)'"
             onmouseout="this.style.borderColor='var(--border)';this.style.color='var(--text)'">
            📹 Video
          </button>
        </div>
      <?php elseif ($isOwn): ?>
        <a href="profile.php" style="display:inline-flex;align-items:center;gap:7px;padding:10px 22px;border-radius:10px;font-size:13px;font-weight:700;font-family:var(--font-head);color:var(--muted);border:1px solid var(--border);text-decoration:none;transition:border-color .2s">
          ✏ Edit Profile
        </a>
      <?php endif; ?>
    </div>

    <!-- Stats bar -->
    <div class="up2-stats">
      <div class="up2-stat">
        <div class="up2-stat-val"><?= $total ?></div>
        <div class="up2-stat-lbl">Posts</div>
      </div>
      <div class="up2-stat">
        <div class="up2-stat-clickable" onclick="openFolModal('followers')">
          <div class="up2-stat-val" id="followerCount"><?= $followerCount ?></div>
          <div class="up2-stat-lbl">Followers</div>
        </div>
      </div>
      <div class="up2-stat">
        <div class="up2-stat-clickable" onclick="openFolModal('following')">
          <div class="up2-stat-val"><?= $followingCount ?></div>
          <div class="up2-stat-lbl">Following</div>
        </div>
      </div>
      <div class="up2-stat">
        <div class="up2-stat-val"><?= $totalViews >= 1000 ? round($totalViews/1000,1).'k' : $totalViews ?></div>
        <div class="up2-stat-lbl">Views</div>
      </div>
      <div class="up2-stat">
        <div class="up2-stat-val"><?= $totalReactions ?></div>
        <div class="up2-stat-lbl">Reactions</div>
      </div>
      <div class="up2-stat">
        <div class="up2-stat-val"><?= (int)$pu['wins'] ?></div>
        <div class="up2-stat-lbl">Wins</div>
      </div>
    </div>
  </div>

  <!-- Posts section -->
  <div class="up2-section-hd">
    <h2>🎨 Code Creations</h2>
    <span><?= $total ?> post<?= $total !== 1 ? 's' : '' ?></span>
  </div>

  <?php if (empty($posts)): ?>
    <div class="up2-empty">
      <h3>No posts yet</h3>
      <p><?= e($pu['username']) ?> hasn't shared any code yet.</p>
    </div>
  <?php else: ?>
    <div class="up2-grid">
      <?php foreach ($posts as $p): ?>
        <div class="up2-card">
          <div class="up2-card-preview">
            <iframe sandbox="allow-scripts"
              srcdoc="<?= htmlspecialchars(buildSrcdoc($p['html_code'], $p['css_code'], $p['js_code']), ENT_QUOTES) ?>"></iframe>
            <div class="up2-view-overlay">
              <a href="showcase.php?id=<?= $p['id'] ?>">View →</a>
            </div>
          </div>
          <div class="up2-card-body">
            <div class="up2-card-title"><?= e($p['title']) ?></div>
            <?php if ($p['description']): ?>
              <div class="up2-card-desc"><?= e(mb_strimwidth($p['description'],0,80,'…')) ?></div>
            <?php endif; ?>
            <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
              <span class="up2-card-time"><?= timeAgo($p['created_at']) ?></span>
              <?php if (!empty($p['allow_versus'])): ?>
                <span class="up2-vs-badge">⚔ Versus OK</span>
              <?php endif; ?>
            </div>
            <div class="up2-card-footer">
              <div class="up2-foot-stats">
                <span class="up2-foot-stat">🔥 <?= (int)$p['reaction_count'] ?></span>
                <span class="up2-foot-stat">💬 <?= (int)$p['comment_count'] ?></span>
                <span class="up2-foot-stat">👁 <?= (int)$p['views'] ?></span>
              </div>
              <div class="sc-share-wrap" id="sw-p<?= $p['id'] ?>">
                <button class="sc-share-btn" onclick="toggleShare(event,'p<?= $p['id'] ?>')">
                  <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>
                  Share
                </button>
                <div class="share-dropdown" id="sd-p<?= $p['id'] ?>">
                  <button class="sd-item" onclick="shareToFacebook(<?= $p['id'] ?>)">
                    <span class="sd-icon fb">f</span>
                    <span>Facebook<span class="sd-sub">Share to your timeline</span></span>
                  </button>
                  <hr class="sd-divider">
                  <button class="sd-item" onclick="shareNative(<?= $p['id'] ?>, <?= json_encode($p['title']) ?>)">
                    <span class="sd-icon native">↗</span>
                    <span>Share…<span class="sd-sub">Device share sheet</span></span>
                  </button>
                  <button class="sd-item" onclick="copyLink(<?= $p['id'] ?>)">
                    <span class="sd-icon copy">🔗</span>
                    <span>Copy Link<span class="sd-sub">Copy URL to clipboard</span></span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <?php $pages = ceil($total / $perPage); if ($pages > 1): ?>
      <div class="up2-pagination">
        <?php for ($i=1; $i<=$pages; $i++): ?>
          <a href="showcase.php?user=<?= $pu['id'] ?>&page=<?= $i ?>" class="<?= $i===$page?'cur':'' ?>"><?= $i ?></a>
        <?php endfor; ?>
      </div>
    <?php endif; ?>
  <?php endif; ?>
</div>

<script>
function getPostUrl(id){ return location.origin+'/showcase.php?id='+id; }
function toggleShare(e,id){
  e.stopPropagation();
  const dd=document.getElementById('sd-'+id);
  const wasOpen=dd.classList.contains('open');
  document.querySelectorAll('.share-dropdown').forEach(d=>d.classList.remove('open'));
  if(!wasOpen) dd.classList.add('open');
}
document.addEventListener('click',()=>
  document.querySelectorAll('.share-dropdown').forEach(d=>d.classList.remove('open'))
);
function shareToFacebook(id){
  const url='https://www.facebook.com/sharer/sharer.php?u='+encodeURIComponent(getPostUrl(id));
  window.open(url,'_blank','width=626,height=436');
  document.querySelectorAll('.share-dropdown').forEach(d=>d.classList.remove('open'));
}
async function shareNative(id,title){
  document.querySelectorAll('.share-dropdown').forEach(d=>d.classList.remove('open'));
  if(navigator.share){ try{ await navigator.share({title,url:getPostUrl(id)}); return; }catch(e){} }
  copyLink(id);
}
function copyLink(id){
  document.querySelectorAll('.share-dropdown').forEach(d=>d.classList.remove('open'));
  const url=getPostUrl(id);
  navigator.clipboard.writeText(url).then(()=>showToast('Link copied!')).catch(()=>prompt('Copy this link:',url));
}
async function upToggleFollow(targetId){
  const btn=document.getElementById('followBtn');
  const fd=new FormData();
  fd.append('action','toggle_follow'); fd.append('target_id',targetId);
  const res=await fetch('showcase.php',{method:'POST',body:fd});
  const data=await res.json();
  if(!data.ok){showToast(data.error||'Error');return;}
  btn.textContent=data.following?'✓ Following':'+ Follow';
  btn.className='up2-follow-btn '+(data.following?'unfollow':'follow');
  document.getElementById('followerCount').textContent=data.follower_count;
  showToast(data.following?'Following!':'Unfollowed');
}

// ── Followers / Following modal (pre-loaded, no fetch) ─────────────────
function escHtml(s){const d=document.createElement('div');d.textContent=s;return d.innerHTML;}
let _currentFolTab = 'followers';
const _folData = {
  followers: <?= json_encode(array_values($followersList)) ?>,
  following:  <?= json_encode(array_values($followingList)) ?>
};

function openFolModal(tab) {
  _currentFolTab = tab;
  document.getElementById('folModal').classList.add('open');
  renderFolTab(tab);
}
function closeFolModal() {
  document.getElementById('folModal').classList.remove('open');
}
function switchFolTab(tab) {
  _currentFolTab = tab;
  document.getElementById('fol-tab-followers').classList.toggle('active', tab === 'followers');
  document.getElementById('fol-tab-following').classList.toggle('active', tab === 'following');
  renderFolTab(tab);
}
function renderFolTab(tab) {
  document.getElementById('fol-tab-followers').classList.toggle('active', tab === 'followers');
  document.getElementById('fol-tab-following').classList.toggle('active', tab === 'following');
  const list  = document.getElementById('folList');
  const users = _folData[tab] || [];
  if (!users.length) {
    list.innerHTML = `<div class="fol-empty">${tab === 'followers' ? 'No followers yet.' : 'Not following anyone yet.'}</div>`;
    return;
  }
  list.innerHTML = users.map(u => `
    <a class="fol-item" href="showcase.php?user=${u.id}">
      <div class="fol-avt">
        ${u.avatar_img ? `<img src="${escHtml(u.avatar_img)}" alt="">` : escHtml(u.avatar || '👤')}
      </div>
      <div>
        <div class="fol-username">${escHtml(u.username)}</div>
        <div class="fol-since">Since ${escHtml(u.since)}</div>
      </div>
    </a>
  `).join('');
}
document.getElementById('folModal').addEventListener('click', function(e){
  if (e.target === this) closeFolModal();
});

// ── Voice Call ───────────────────────────────────────────────────────────────
let _callTimer = null, _callSecs = 0;

function upVoiceCall(uid, uname, avatarImg, avatarEmoji) {
  const modal = document.getElementById('upVoiceModal');
  document.getElementById('upVcName').textContent = uname;
  const avt = document.getElementById('upVcAvt');
  avt.innerHTML = avatarImg
    ? `<img src="${escHtml(avatarImg)}" style="width:80px;height:80px;border-radius:50%;border:3px solid var(--green);object-fit:cover" alt="">`
    : avatarEmoji;
  const status = document.getElementById('upVcStatus');
  status.textContent = 'Calling…';
  status.style.animation = 'upPulse 1s infinite';
  modal.style.display = 'flex';
  setTimeout(() => {
    status.textContent = 'Connected · 00:00';
    status.style.animation = '';
    _callSecs = 0;
    _callTimer = setInterval(() => {
      _callSecs++;
      const m = String(Math.floor(_callSecs/60)).padStart(2,'0');
      const s = String(_callSecs%60).padStart(2,'0');
      status.textContent = `Connected · ${m}:${s}`;
    }, 1000);
  }, 2000);
}

function upEndCall() {
  clearInterval(_callTimer);
  document.getElementById('upVoiceModal').style.display = 'none';
}

// ── Video Call ────────────────────────────────────────────────────────────────
let _localStream = null, _videoTimer = null, _videoSecs = 0, _micMuted = false, _camOff = false;

async function upVideoCall(uid, uname, avatarImg, avatarEmoji) {
  const modal = document.getElementById('upVideoModal');
  document.getElementById('upVideoName').textContent    = uname;
  document.getElementById('upVideoNameBig').textContent = uname;
  document.getElementById('upVideoAvt').innerHTML = avatarImg
    ? `<img src="${escHtml(avatarImg)}" style="width:80px;height:80px;border-radius:50%;border:3px solid var(--green);object-fit:cover" alt="">`
    : avatarEmoji;
  document.getElementById('upVideoStatus').textContent = 'Connecting…';
  document.getElementById('upVideoTimer').textContent  = '00:00';
  document.getElementById('upRemotePlaceholder').style.display = 'flex';
  document.getElementById('upRemoteVideo').style.display = 'none';
  modal.style.display = 'flex';
  try {
    _localStream = await navigator.mediaDevices.getUserMedia({video:true, audio:true});
    document.getElementById('upLocalVideo').srcObject = _localStream;
  } catch(e) {
    document.getElementById('upVideoStatus').textContent = 'Camera unavailable · Audio only';
  }
  setTimeout(() => {
    document.getElementById('upVideoStatus').textContent = 'Waiting for ' + uname + '…';
    _videoSecs = 0;
    _videoTimer = setInterval(() => {
      _videoSecs++;
      const m = String(Math.floor(_videoSecs/60)).padStart(2,'0');
      const s = String(_videoSecs%60).padStart(2,'0');
      document.getElementById('upVideoTimer').textContent = m + ':' + s;
    }, 1000);
  }, 1500);
}

function upEndVideoCall() {
  if (_localStream) { _localStream.getTracks().forEach(t => t.stop()); _localStream = null; }
  clearInterval(_videoTimer);
  document.getElementById('upVideoModal').style.display = 'none';
  document.getElementById('upLocalVideo').srcObject = null;
  _micMuted = false; _camOff = false;
}

function upToggleMic() {
  if (!_localStream) return;
  _micMuted = !_micMuted;
  _localStream.getAudioTracks().forEach(t => t.enabled = !_micMuted);
  const btn = document.getElementById('upMuteBtn');
  btn.textContent = _micMuted ? '🔇' : '🎤';
  btn.style.background = _micMuted ? 'rgba(255,80,80,.2)' : 'rgba(255,255,255,.12)';
}

function upToggleCam() {
  if (!_localStream) return;
  _camOff = !_camOff;
  _localStream.getVideoTracks().forEach(t => t.enabled = !_camOff);
  const btn = document.getElementById('upCamBtn');
  btn.textContent = _camOff ? '🚫' : '📷';
  btn.style.background = _camOff ? 'rgba(255,80,80,.2)' : 'rgba(255,255,255,.12)';
}
</script>

<!-- Voice Call Modal -->
<div id="upVoiceModal" style="position:fixed;inset:0;background:rgba(0,0,0,.85);backdrop-filter:blur(10px);z-index:1000;display:none;align-items:center;justify-content:center">
  <div style="background:var(--bg2);border:1px solid var(--border);border-radius:24px;padding:40px 52px;text-align:center;min-width:300px;position:relative">
    <div style="position:absolute;top:14px;right:14px;font-size:11px;font-family:var(--font-mono);color:var(--muted);background:var(--bg3);border:1px solid var(--border);border-radius:6px;padding:3px 8px">📞 Voice Call</div>
    <div id="upVcAvt" style="font-size:64px;margin-bottom:16px;line-height:1">👤</div>
    <div id="upVcName" style="font-size:22px;font-weight:800;letter-spacing:-1px;margin-bottom:6px"></div>
    <div id="upVcStatus" style="font-size:13px;font-family:var(--font-mono);color:var(--muted);margin-bottom:32px">Calling…</div>
    <style>@keyframes upPulse{0%,100%{opacity:1}50%{opacity:.3}}</style>
    <div style="display:flex;justify-content:center">
      <button onclick="upEndCall()" style="width:60px;height:60px;border-radius:50%;background:#ff4444;color:#fff;border:none;cursor:pointer;font-size:24px;display:flex;align-items:center;justify-content:center;transition:transform .15s" onmouseover="this.style.transform='scale(1.08)'" onmouseout="this.style.transform=''">📵</button>
    </div>
  </div>
</div>

<!-- Video Call Modal -->
<div id="upVideoModal" style="position:fixed;inset:0;background:#000;z-index:1000;display:none;flex-direction:column">
  <div style="flex:1;position:relative;display:flex;align-items:center;justify-content:center;background:#080b12">
    <div style="position:absolute;top:0;left:0;right:0;padding:16px 24px;display:flex;align-items:center;justify-content:space-between;background:linear-gradient(to bottom,rgba(0,0,0,.7),transparent);z-index:2">
      <div id="upVideoName" style="font-size:15px;font-weight:700;color:#fff"></div>
      <div id="upVideoTimer" style="font-size:13px;font-family:var(--font-mono);color:rgba(255,255,255,.6)">00:00</div>
    </div>
    <video id="upRemoteVideo" style="width:100%;height:100%;object-fit:cover;display:none" autoplay playsinline></video>
    <div id="upRemotePlaceholder" style="display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px;color:var(--muted)">
      <div id="upVideoAvt" style="font-size:80px;line-height:1">👤</div>
      <div id="upVideoNameBig" style="font-size:24px;font-weight:800;color:#fff"></div>
      <div id="upVideoStatus" style="font-size:13px;font-family:var(--font-mono)">Connecting…</div>
    </div>
    <div style="position:absolute;bottom:80px;right:20px;width:160px;height:110px;border-radius:12px;overflow:hidden;border:2px solid rgba(255,255,255,.15);background:#0e1320">
      <video id="upLocalVideo" style="width:100%;height:100%;object-fit:cover;transform:scaleX(-1)" autoplay muted playsinline></video>
    </div>
  </div>
  <div style="height:80px;background:rgba(0,0,0,.8);display:flex;align-items:center;justify-content:center;gap:16px;border-top:1px solid rgba(255,255,255,.06)">
    <button id="upMuteBtn" onclick="upToggleMic()" style="width:52px;height:52px;border-radius:50%;border:none;cursor:pointer;font-size:22px;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.12);color:#fff;transition:transform .15s" title="Mute">🎤</button>
    <button onclick="upEndVideoCall()" style="width:52px;height:52px;border-radius:50%;background:#ff4444;color:#fff;border:none;cursor:pointer;font-size:22px;display:flex;align-items:center;justify-content:center" title="End Call">📵</button>
    <button id="upCamBtn" onclick="upToggleCam()" style="width:52px;height:52px;border-radius:50%;border:none;cursor:pointer;font-size:22px;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.12);color:#fff;transition:transform .15s" title="Camera Off">📷</button>
  </div>
</div>

<!-- Followers / Following Modal -->
<div class="fol-modal-bg" id="folModal">
  <div class="fol-modal">
    <div class="fol-modal-head">
      <div class="fol-modal-title"><?= e($pu['username']) ?></div>
      <button class="fol-modal-close" onclick="closeFolModal()">✕</button>
    </div>
    <div class="fol-tabs">
      <button class="fol-tab active" id="fol-tab-followers" onclick="switchFolTab('followers')">Followers · <?= $followerCount ?></button>
      <button class="fol-tab" id="fol-tab-following" onclick="switchFolTab('following')">Following · <?= $followingCount ?></button>
    </div>
    <div class="fol-list" id="folList"></div>
  </div>
</div>

<?php
}

// ═══════════════════════════════════════════════════════════════════════════
// ── SINGLE POST renderer
// ═══════════════════════════════════════════════════════════════════════════
function showSinglePost(array $post, array $reactions, array $myReacts, array $comments, ?array $user): void {
  $emojis  = ['🔥','💯','✨','🚀','👏','❤️'];
  $isOwner = $user && (int)$user['id'] === (int)$post['user_id'];
  $postUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS']==='on' ? 'https' : 'http')
             . '://' . $_SERVER['HTTP_HOST'] . '/showcase.php?id=' . (int)$post['id'];
?>
<style>
/* ── Single post view ──────────────────────────────────────────── */
.sp-wrap{max-width:1000px;margin:0 auto;padding:28px 20px 80px;display:grid;grid-template-columns:1fr 340px;gap:22px;align-items:start}
@media(max-width:760px){.sp-wrap{grid-template-columns:1fr}}

.sp-code-panel{background:var(--bg2);border:1px solid var(--border);border-radius:16px;overflow:hidden}
.sp-tab-bar{display:flex;border-bottom:1px solid var(--border);background:var(--bg3)}
.sp-tab{flex:1;padding:10px 0;font-size:12px;font-weight:700;font-family:var(--font-mono);color:var(--muted);background:none;border:none;cursor:pointer;letter-spacing:.5px;transition:color .15s,background .15s}
.sp-tab.active{color:var(--green);background:var(--bg2)}
.sp-copy-btn{padding:0 16px;font-size:11px;font-weight:700;font-family:var(--font-mono);color:var(--muted);background:none;border:none;border-left:1px solid var(--border);cursor:pointer;letter-spacing:.3px;transition:all .15s;white-space:nowrap}
.sp-copy-btn:hover{color:var(--green)}
.sp-copy-btn.copied{color:var(--green)}
.sp-code-body{padding:16px;font-family:var(--font-mono);font-size:12px;line-height:1.7;color:#c8d0e7;white-space:pre-wrap;word-break:break-all;max-height:320px;overflow-y:auto}
.sp-code-body::-webkit-scrollbar{width:5px}
.sp-code-body::-webkit-scrollbar-track{background:transparent}
.sp-code-body::-webkit-scrollbar-thumb{background:var(--border);border-radius:4px}

.sp-preview-box{background:var(--bg2);border:1px solid var(--border);border-radius:16px;overflow:hidden}
.sp-preview-label{font-size:11px;font-weight:700;font-family:var(--font-mono);color:var(--muted);letter-spacing:1px;padding:10px 14px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}
.sp-preview-iframe{width:100%;height:340px;border:none;display:block;background:#0e1320}

.sp-sidebar{display:flex;flex-direction:column;gap:14px}
.sp-card{background:var(--bg2);border:1px solid var(--border);border-radius:14px;padding:16px}

/* meta card */
.sp-title{font-size:20px;font-weight:800;letter-spacing:-.5px;line-height:1.2;margin-bottom:8px}
.sp-desc{font-size:13px;color:var(--muted);font-family:var(--font-mono);line-height:1.6;margin-bottom:14px}
.sp-author{display:flex;align-items:center;gap:10px}
.sp-author-img{width:36px;height:36px;border-radius:50%;object-fit:cover;flex-shrink:0;cursor:pointer}
.sp-author-name{font-weight:700;font-size:13px}
.sp-author-name a{color:inherit;text-decoration:none;transition:color .15s}
.sp-author-name a:hover{color:var(--green)}
.sp-author-time{font-size:11px;color:var(--muted);font-family:var(--font-mono)}
.sp-stats{display:flex;gap:16px;margin-top:14px;padding-top:14px;border-top:1px solid var(--border)}
.sp-stat{font-size:12px;color:var(--muted);font-family:var(--font-mono)}
.sp-stat strong{color:#fff}

/* share card */
.sp-share-label{font-size:11px;font-weight:700;font-family:var(--font-mono);color:var(--muted);letter-spacing:1px;margin-bottom:12px}
.sp-share-btns{display:flex;gap:8px;flex-wrap:wrap}
.sp-share-opt{display:inline-flex;align-items:center;gap:7px;padding:9px 14px;border-radius:10px;border:1px solid var(--border);background:var(--bg3);cursor:pointer;font-size:12px;font-weight:700;color:#fff;font-family:var(--font-head);transition:border-color .15s,background .15s}
.sp-share-opt:hover{background:rgba(255,255,255,.06);border-color:rgba(255,255,255,.2)}
.sp-share-opt.fb-btn{border-color:rgba(24,119,242,.4);color:#4a8ef5}
.sp-share-opt.fb-btn:hover{background:rgba(24,119,242,.1)}

/* versus card */
.sp-vs-label{font-size:11px;font-weight:700;font-family:var(--font-mono);color:var(--muted);letter-spacing:1px;margin-bottom:12px}
.vs-toggle-btn{display:flex;align-items:center;justify-content:space-between;gap:10px;width:100%;background:var(--bg3);border:1px solid rgba(167,139,250,.25);border-radius:10px;padding:12px 14px;cursor:pointer;transition:border-color .2s,background .15s}
.vs-toggle-btn:hover{border-color:rgba(167,139,250,.5);background:rgba(167,139,250,.05)}
.vs-toggle-text{text-align:left}
.vs-toggle-text strong{display:block;font-size:13px;font-weight:700;color:#fff;margin-bottom:2px}
.vs-toggle-text span{font-size:11px;font-family:var(--font-mono);color:var(--muted)}
.vs-state-pill{flex-shrink:0;padding:4px 12px;border-radius:20px;font-size:11px;font-weight:700;font-family:var(--font-mono);letter-spacing:.5px}
.vs-state-pill.on{background:rgba(167,139,250,.15);color:#a78bfa;border:1px solid rgba(167,139,250,.3)}
.vs-state-pill.off{background:rgba(255,255,255,.05);color:var(--muted);border:1px solid var(--border)}
.vs-public-note{margin-top:10px;font-size:11px;font-family:var(--font-mono);line-height:1.5}

/* reactions */
.sp-react-label{font-size:11px;font-weight:700;font-family:var(--font-mono);color:var(--muted);letter-spacing:1px;margin-bottom:10px}
.sp-react-grid{display:flex;gap:6px;flex-wrap:wrap}
.react-btn{display:inline-flex;align-items:center;gap:5px;padding:7px 12px;border-radius:10px;border:1px solid var(--border);background:var(--bg3);cursor:pointer;font-size:14px;font-weight:700;font-family:var(--font-mono);color:var(--muted);transition:all .15s}
.react-btn:hover{border-color:rgba(0,255,135,.3);color:#fff}
.react-btn.active{background:rgba(0,255,135,.1);border-color:rgba(0,255,135,.4);color:var(--green)}
.react-btn .cnt{font-size:11px}

/* comments */
.sp-comment-card h3{font-size:14px;font-weight:800;margin-bottom:14px;letter-spacing:-.3px}
.comment-list{display:flex;flex-direction:column;gap:12px;margin-bottom:14px;max-height:320px;overflow-y:auto}
.comment-item{display:flex;gap:10px;align-items:flex-start}
.comment-avatar{width:28px;height:28px;border-radius:50%;object-fit:cover;flex-shrink:0;font-size:18px;line-height:28px;text-align:center}
.comment-body{flex:1}
.comment-user{font-size:12px;font-weight:700;color:#fff}
.comment-time{font-size:10px;color:var(--muted);font-family:var(--font-mono);margin-left:6px}
.comment-text{font-size:12px;color:var(--muted);line-height:1.5;margin-top:2px;font-family:var(--font-mono)}
.comment-form{display:flex;flex-direction:column;gap:8px}
.comment-form textarea{background:var(--bg3);border:1px solid var(--border);border-radius:10px;color:#fff;padding:10px 12px;font-size:12px;font-family:var(--font-mono);resize:none;min-height:70px;outline:none;transition:border-color .2s}
.comment-form textarea:focus{border-color:rgba(0,255,135,.35)}
.comment-form button{background:var(--green);color:#080b12;border:none;border-radius:9px;padding:9px 18px;font-size:12px;font-weight:800;cursor:pointer;align-self:flex-end;font-family:var(--font-head)}
.login-nudge{text-align:center;font-size:12px;color:var(--muted);font-family:var(--font-mono);padding:12px 0}
.login-nudge a{color:var(--green)}
.back-link{display:inline-flex;align-items:center;gap:6px;font-size:13px;color:var(--muted);margin:18px 20px 0;font-family:var(--font-mono);text-decoration:none;transition:color .15s}
.back-link:hover{color:#fff}
</style>

<a href="showcase.php" class="back-link">← Back to Showcase</a>

<div class="sp-wrap">

  <!-- ── Left col: preview + code ──────────────────────────────────── -->
  <div style="display:flex;flex-direction:column;gap:14px">

    <div class="sp-preview-box">
      <div class="sp-preview-label">
        <span>▶ LIVE PREVIEW</span>
        <button onclick="openFullscreen()" style="background:none;border:1px solid var(--border);color:var(--muted);font-size:10px;font-family:var(--font-mono);font-weight:700;padding:3px 10px;border-radius:6px;cursor:pointer">⛶ Fullscreen</button>
      </div>
      <iframe id="mainPreview" sandbox="allow-scripts" class="sp-preview-iframe"
        srcdoc="<?= htmlspecialchars(buildSrcdoc($post['html_code'], $post['css_code'], $post['js_code']), ENT_QUOTES) ?>"></iframe>
    </div>

    <div class="sp-code-panel">
      <div class="sp-tab-bar">
        <button class="sp-tab active" onclick="spSwitchTab('html',this)">HTML</button>
        <button class="sp-tab" onclick="spSwitchTab('css',this)">CSS</button>
        <button class="sp-tab" onclick="spSwitchTab('js',this)">JS</button>
        <button class="sp-copy-btn" onclick="spCopyTab(this)" title="Copy code">⎘ Copy</button>
      </div>
      <div id="sp-html" class="sp-code-body"><?= e($post['html_code'] ?? '<!-- no HTML -->')?></div>
      <div id="sp-css"  class="sp-code-body" style="display:none"><?= e($post['css_code'] ?? '/* no CSS */')?></div>
      <div id="sp-js"   class="sp-code-body" style="display:none"><?= e($post['js_code'] ?? '// no JS')?></div>
    </div>
  </div>

  <!-- ── Right col: sidebar cards ──────────────────────────────────── -->
  <div class="sp-sidebar">

    <!-- ① Meta card -->
    <div class="sp-card">
      <div class="sp-title"><?= e($post['title']) ?></div>
      <?php if ($post['description']): ?>
        <div class="sp-desc"><?= e($post['description']) ?></div>
      <?php endif; ?>
      <div class="sp-author">
        <?php if ($post['avatar_img']): ?>
          <img src="<?= e($post['avatar_img']) ?>" class="sp-author-img" alt=""
               onclick="location.href='showcase.php?user=<?= (int)$post['user_id'] ?>'">
        <?php else: ?>
          <span class="sp-author-img" style="font-size:22px;text-align:center;line-height:36px;cursor:pointer"
                onclick="location.href='showcase.php?user=<?= (int)$post['user_id'] ?>'">
            <?= e($post['avatar'] ?: '👤') ?>
          </span>
        <?php endif; ?>
        <div>
          <div class="sp-author-name">
            <a href="showcase.php?user=<?= (int)$post['user_id'] ?>"><?= e($post['username']) ?></a>
          </div>
          <div class="sp-author-time"><?= timeAgo($post['created_at']) ?></div>
        </div>
      </div>
      <div class="sp-stats">
        <span class="sp-stat"><strong><?= (int)($post['views']+1) ?></strong> views</span>
        <span class="sp-stat"><strong><?= count($reactions) ?></strong> reacts</span>
        <span class="sp-stat"><strong><?= count($comments) ?></strong> comments</span>
      </div>
    </div>

    <!-- ② Share card -->
    <div class="sp-card">
      <div class="sp-share-label">SHARE THIS POST</div>
      <div class="sp-share-btns">
        <!-- Facebook share -->
        <button class="sp-share-opt fb-btn" onclick="spShareFacebook()">
          <span style="font-size:15px;font-weight:900;font-family:serif;line-height:1">f</span>
          Facebook
        </button>
        <!-- Native share sheet (falls back to copy) -->
        <button class="sp-share-opt" onclick="spShareNative()">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>
          Share…
        </button>
        <!-- Copy link -->
        <button class="sp-share-opt" onclick="spCopyLink()">
          🔗 Copy Link
        </button>
      </div>
    </div>

    <!-- ③ Versus permission card -->
    <div class="sp-card">
      <div class="sp-vs-label">⚔ VERSUS REFERENCE</div>
      <?php if ($isOwner): ?>
        <!-- Owner sees toggle -->
        <button class="vs-toggle-btn" id="vsBtnEl" onclick="toggleVersus(<?= (int)$post['id'] ?>)">
          <div class="vs-toggle-text">
            <strong>Allow as challenge reference</strong>
            <span>Let others pick this post as a target in Versus battles</span>
          </div>
          <span class="vs-state-pill <?= $post['allow_versus'] ? 'on' : 'off' ?>" id="vsPillEl">
            <?= $post['allow_versus'] ? 'ON' : 'OFF' ?>
          </span>
        </button>
        <p class="vs-public-note" style="color:var(--muted)">
          You can change this anytime. When <strong style="color:#a78bfa">ON</strong>, this post appears in the Versus challenge picker.
        </p>
      <?php elseif (!empty($post['allow_versus'])): ?>
        <!-- Public: enabled -->
        <p class="vs-public-note" style="color:#a78bfa">
          ⚔ This post is available as a Versus challenge reference.
        </p>
        <a href="versus.php" style="display:inline-block;margin-top:8px;font-size:12px;font-weight:700;color:var(--green);font-family:var(--font-mono)">Start a Versus battle →</a>
      <?php else: ?>
        <!-- Public: disabled -->
        <p class="vs-public-note" style="color:var(--muted)">
          The author has not allowed this post to be used as a Versus challenge reference.
        </p>
      <?php endif; ?>
    </div>

    <!-- ④ Reactions card -->
    <div class="sp-card">
      <div class="sp-react-label">REACT</div>
      <div class="sp-react-grid" id="reactGrid">
        <?php foreach ($emojis as $em): ?>
          <button class="react-btn <?= in_array($em,$myReacts)?'active':'' ?>"
            data-emoji="<?= htmlspecialchars($em,ENT_QUOTES) ?>"
            onclick="doReact('<?= (int)$post['id'] ?>','<?= htmlspecialchars($em,ENT_QUOTES) ?>',this)"
            <?= !$user ? 'disabled title="Login to react"' : '' ?>>
            <span><?= $em ?></span>
            <span class="cnt"><?= (int)($reactions[$em] ?? 0) ?></span>
          </button>
        <?php endforeach; ?>
      </div>
      <?php if (!$user): ?>
        <p style="font-size:11px;color:var(--muted);font-family:var(--font-mono);margin-top:10px">
          <a href="login.php" style="color:var(--green)">Login</a> to react
        </p>
      <?php endif; ?>
    </div>

    <!-- ⑤ Comments card -->
    <div class="sp-card sp-comment-card" id="comments">
      <h3>💬 Comments (<?= count($comments) ?>)</h3>
      <div class="comment-list" id="commentList">
        <?php if (empty($comments)): ?>
          <p style="font-size:12px;color:var(--muted);font-family:var(--font-mono)">No comments yet. Be the first!</p>
        <?php else: foreach ($comments as $c): ?>
          <div class="comment-item">
            <?php if ($c['avatar_img']): ?>
              <img src="<?= e($c['avatar_img']) ?>" class="comment-avatar" alt="">
            <?php else: ?>
              <span class="comment-avatar"><?= e($c['avatar'] ?: '👤') ?></span>
            <?php endif; ?>
            <div class="comment-body">
              <span class="comment-user"><?= e($c['username']) ?></span>
              <span class="comment-time"><?= timeAgo($c['created_at']) ?></span>
              <div class="comment-text"><?= e($c['body']) ?></div>
            </div>
          </div>
        <?php endforeach; endif; ?>
      </div>

      <?php if ($user): ?>
      <div class="comment-form">
        <textarea id="commentBox" placeholder="Add a comment…" maxlength="500"></textarea>
        <button onclick="postComment(<?= (int)$post['id'] ?>)">Post Comment</button>
      </div>
      <?php else: ?>
        <p class="login-nudge"><a href="login.php">Login</a> to comment</p>
      <?php endif; ?>
    </div>

  </div><!-- /sidebar -->
</div><!-- /sp-wrap -->

<!-- Fullscreen overlay -->
<div id="fsOverlay" style="display:none;position:fixed;inset:0;z-index:800;background:#000">
  <button onclick="closeFullscreen()" style="position:absolute;top:14px;right:16px;z-index:2;background:rgba(0,0,0,.6);border:1px solid rgba(255,255,255,.15);color:#fff;font-size:13px;font-weight:700;padding:7px 14px;border-radius:8px;cursor:pointer">✕ Close</button>
  <iframe id="fsFrame" sandbox="allow-scripts" style="width:100%;height:100%;border:none"></iframe>
</div>
<script src="assets/security.js"></script>
<script>
const SP_POST_URL = <?= json_encode($postUrl) ?>;

/* Auto-scroll to comments if #comments hash in URL */
if (window.location.hash === '#comments') {
  window.addEventListener('load', () => {
    const el = document.getElementById('comments');
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
}

/* tabs + fullscreen */
let spActiveTab = 'html';
function spSwitchTab(tab,btn){
  document.querySelectorAll('[id^="sp-"]').forEach(el=>el.style.display='none');
  document.getElementById('sp-'+tab).style.display='block';
  document.querySelectorAll('.sp-tab').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  spActiveTab = tab;
}
function spCopyTab(btn){
  const el = document.getElementById('sp-'+spActiveTab);
  const txt = el ? el.innerText : '';
  navigator.clipboard.writeText(txt).then(()=>{
    btn.textContent='✓ Copied!'; btn.classList.add('copied');
    setTimeout(()=>{ btn.textContent='⎘ Copy'; btn.classList.remove('copied'); },2000);
  });
}
function openFullscreen(){
  document.getElementById('fsFrame').srcdoc=document.getElementById('mainPreview').srcdoc;
  document.getElementById('fsOverlay').style.display='block';
}
function closeFullscreen(){ document.getElementById('fsOverlay').style.display='none'; }

/* reactions */
async function doReact(postId,emoji,btn){
  const fd=new FormData();
  fd.append('action','react'); fd.append('post_id',postId); fd.append('emoji',emoji);
  const res=await fetch('showcase.php',{method:'POST',body:fd});
  const data=await res.json();
  if(!data.ok) return;
  document.getElementById('reactGrid').querySelectorAll('.react-btn').forEach(b=>{
    const em=b.dataset.emoji;
    b.querySelector('.cnt').textContent=data.counts[em]||0;
    if(em===emoji) b.classList.toggle('active',data.state==='added');
  });
}

/* comments */
async function postComment(postId){
  const box=document.getElementById('commentBox');
  const body=box.value.trim();
  if(!body){showToast('Comment cannot be empty');return;}
  const fd=new FormData();
  fd.append('action','comment'); fd.append('post_id',postId); fd.append('body',body);
  const res=await fetch('showcase.php',{method:'POST',body:fd});
  const data=await res.json();
  if(!data.ok){showToast(data.msg||'Error');return;}
  const list=document.getElementById('commentList');
  const placeholder=list.querySelector('p');
  if(placeholder) placeholder.remove();
  const div=document.createElement('div');
  div.className='comment-item';
  div.innerHTML=`<span class="comment-avatar">${escHtml(data.avatar||'👤')}</span>
    <div class="comment-body">
      <span class="comment-user">${escHtml(data.username)}</span>
      <span class="comment-time">just now</span>
      <div class="comment-text">${escHtml(data.body)}</div>
    </div>`;
  list.appendChild(div);
  list.scrollTop=list.scrollHeight;
  box.value='';
  showToast('Comment posted!');
  if (window.refreshNotifBadge) window.refreshNotifBadge();
}
function escHtml(s){const d=document.createElement('div');d.textContent=s;return d.innerHTML;}

/* versus toggle (owner only) */
async function toggleVersus(postId){
  const fd=new FormData();
  fd.append('action','toggle_versus'); fd.append('post_id',postId);
  const res=await fetch('showcase.php',{method:'POST',body:fd});
  const data=await res.json();
  if(!data.ok){showToast(data.msg||'Error');return;}
  const pill=document.getElementById('vsPillEl');
  pill.textContent=data.allow_versus?'ON':'OFF';
  pill.className='vs-state-pill '+(data.allow_versus?'on':'off');
  showToast(data.allow_versus?'⚔ Versus reference enabled!':'Versus reference disabled');
}

/* share */
function spShareFacebook(){
  window.open('https://www.facebook.com/sharer/sharer.php?u='+encodeURIComponent(SP_POST_URL),'_blank','width=626,height=436');
}
async function spShareNative(){
  if(navigator.share){ try{await navigator.share({title:document.title,url:SP_POST_URL});return;}catch(e){} }
  spCopyLink();
}
function spCopyLink(){
  navigator.clipboard.writeText(SP_POST_URL)
    .then(()=>showToast('Link copied!'))
    .catch(()=>prompt('Copy this link:',SP_POST_URL));
}
</script>
<?php
}
?>
