<?php
require_once 'includes/config.php';
require_once 'includes/layout.php';

// ── Inline JSON API — must be BEFORE any HTML output ─────────────────────
if (isset($_GET['action'])) {
  $me      = auth();
  $action  = $_GET['action'];
  $queryId = (int)($_GET['user_id'] ?? 0);
  header('Content-Type: application/json');

  if ($action === 'get_followers') {
    $stmt = db()->prepare('
      SELECT u.id, u.username, u.avatar, u.avatar_img,
             DATE_FORMAT(f.created_at, "%b %Y") AS since
      FROM user_follows f
      JOIN users u ON u.id = f.follower_id
      WHERE f.following_id = ?
      ORDER BY f.created_at DESC
    ');
    $stmt->execute([$queryId]);
    echo json_encode(['users' => $stmt->fetchAll()]);
    exit;
  }

  if ($action === 'get_following') {
    $stmt = db()->prepare('
      SELECT u.id, u.username, u.avatar, u.avatar_img,
             DATE_FORMAT(f.created_at, "%b %Y") AS since
      FROM user_follows f
      JOIN users u ON u.id = f.following_id
      WHERE f.follower_id = ?
      ORDER BY f.created_at DESC
    ');
    $stmt->execute([$queryId]);
    echo json_encode(['users' => $stmt->fetchAll()]);
    exit;
  }

  if ($action === 'get_follow_counts') {
    $fcStmt = db()->prepare('SELECT COUNT(*) FROM user_follows WHERE following_id=?');
    $fcStmt->execute([$queryId]);
    $followers = (int)$fcStmt->fetchColumn();

    $fgStmt = db()->prepare('SELECT COUNT(*) FROM user_follows WHERE follower_id=?');
    $fgStmt->execute([$queryId]);
    $following = (int)$fgStmt->fetchColumn();

    $iFollow = 0;
    if ($me) {
      $chk = db()->prepare('SELECT id FROM user_follows WHERE follower_id=? AND following_id=?');
      $chk->execute([$me['id'], $queryId]);
      $iFollow = $chk->fetch() ? 1 : 0;
    }
    echo json_encode(['followers' => $followers, 'following' => $following, 'i_follow' => $iFollow]);
    exit;
  }

  echo json_encode(['error' => 'unknown action']);
  exit;
}

$rows = db()->query(
  'SELECT u.id, u.username, u.avatar, u.avatar_img, u.bio,
          u.wins, u.losses, u.total_score,
          CASE WHEN u.wins+u.losses>0 THEN ROUND(u.wins/(u.wins+u.losses)*100) ELSE 0 END AS win_rate,
          RANK() OVER (ORDER BY u.wins DESC, u.total_score DESC) AS `rank`
   FROM users u
   ORDER BY u.wins DESC, u.total_score DESC
   LIMIT 50'
)->fetchAll();

$me = auth();

// ── Preload follow data for logged-in user ──────────────────────────────
$myFollowingIds = [];
if ($me) {
  try {
    $fStmt = db()->prepare('SELECT following_id FROM user_follows WHERE follower_id=?');
    $fStmt->execute([$me['id']]);
    $myFollowingIds = array_column($fStmt->fetchAll(), 'following_id');
  } catch(Exception $e) {}
}

// ── Follower & following counts for every user on the board ──────────────
$followerCounts  = [];
$followingCounts = [];
$followersLists  = []; // uid => [{id,username,avatar,avatar_img,since}]
$followingLists  = []; // uid => [{id,username,avatar,avatar_img,since}]
if ($rows) {
  $ids = array_column($rows, 'id');
  $ph  = implode(',', array_fill(0, count($ids), '?'));
  try {
    $fcStmt = db()->prepare("SELECT following_id, COUNT(*) AS cnt FROM user_follows WHERE following_id IN ($ph) GROUP BY following_id");
    $fcStmt->execute($ids);
    foreach ($fcStmt->fetchAll() as $fc) $followerCounts[$fc['following_id']] = (int)$fc['cnt'];
  } catch(Exception $e) {}
  try {
    $fgStmt = db()->prepare("SELECT follower_id, COUNT(*) AS cnt FROM user_follows WHERE follower_id IN ($ph) GROUP BY follower_id");
    $fgStmt->execute($ids);
    foreach ($fgStmt->fetchAll() as $fg) $followingCounts[$fg['follower_id']] = (int)$fg['cnt'];
  } catch(Exception $e) {}
  // Pre-load full follower lists for each user
  try {
    $flStmt = db()->prepare("
      SELECT f.following_id AS uid, u.id, u.username, u.avatar, u.avatar_img,
             DATE_FORMAT(f.created_at, '%b %Y') AS since
      FROM user_follows f JOIN users u ON u.id = f.follower_id
      WHERE f.following_id IN ($ph) ORDER BY f.created_at DESC");
    $flStmt->execute($ids);
    foreach ($flStmt->fetchAll() as $row) $followersLists[$row['uid']][] = $row;
  } catch(Exception $e) {}
  // Pre-load full following lists for each user
  try {
    $fgListStmt = db()->prepare("
      SELECT f.follower_id AS uid, u.id, u.username, u.avatar, u.avatar_img,
             DATE_FORMAT(f.created_at, '%b %Y') AS since
      FROM user_follows f JOIN users u ON u.id = f.following_id
      WHERE f.follower_id IN ($ph) ORDER BY f.created_at DESC");
    $fgListStmt->execute($ids);
    foreach ($fgListStmt->fetchAll() as $row) $followingLists[$row['uid']][] = $row;
  } catch(Exception $e) {}
}

pageHeader('Leaderboard');
?>
<style>
.lb-wrap{max-width:900px;margin:0 auto;padding:40px 24px}
.lb-hero{margin-bottom:44px}
.lb-hero h1{font-size:44px;font-weight:800;letter-spacing:-2px}
.lb-hero h1 span{color:var(--green)}
.lb-hero p{margin-top:10px;color:var(--muted);font-size:13px;font-family:var(--font-mono)}

/* Podium */
.podium{display:flex;align-items:flex-end;justify-content:center;gap:16px;margin-bottom:48px;padding:0 20px}
.podium-slot{display:flex;flex-direction:column;align-items:center;gap:10px;flex:1;max-width:200px;cursor:pointer}
.podium-slot:hover .pod-avatar{transform:scale(1.06)}
.pod-avatar{width:80px;height:80px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:38px;overflow:hidden;border:3px solid var(--border);transition:transform .2s;background:var(--bg3)}
.pod-avatar img{width:100%;height:100%;object-fit:cover}
.pod-rank-icon{font-size:22px;margin-bottom:-4px}
.pod-name{font-size:13px;font-weight:700;text-align:center;max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.pod-score{font-family:var(--font-mono);font-size:11px;color:var(--muted)}
.pod-block{border-radius:12px 12px 0 0;width:100%;display:flex;align-items:center;justify-content:center;font-family:var(--font-mono);font-size:22px;font-weight:800}
.pod-1 .pod-block{height:100px;background:linear-gradient(180deg,rgba(255,215,0,.15),rgba(255,215,0,.05));border:1px solid rgba(255,215,0,.3);color:gold}
.pod-2 .pod-block{height:72px;background:linear-gradient(180deg,rgba(192,192,192,.12),rgba(192,192,192,.04));border:1px solid rgba(192,192,192,.25);color:silver}
.pod-3 .pod-block{height:52px;background:linear-gradient(180deg,rgba(205,127,50,.12),rgba(205,127,50,.04));border:1px solid rgba(205,127,50,.25);color:#cd7f32}
.pod-1 .pod-avatar{border-color:gold;width:92px;height:92px}
.pod-2 .pod-avatar{border-color:silver}
.pod-3 .pod-avatar{border-color:#cd7f32}

/* Table */
.lb-table{width:100%;border-collapse:collapse}
.lb-table th{font-family:var(--font-mono);font-size:10px;letter-spacing:2px;text-transform:uppercase;color:var(--muted);font-weight:400;padding:10px 16px;border-bottom:1px solid var(--border);text-align:left}
.lb-table td{padding:12px 16px;border-bottom:1px solid rgba(255,255,255,.04)}
.lb-row{cursor:pointer;transition:background .15s}
.lb-row:hover{background:rgba(255,255,255,.04)}
.lb-row.is-me{background:rgba(0,255,135,.04)}
.rank-badge{display:inline-flex;align-items:center;justify-content:center;width:30px;height:30px;border-radius:8px;font-weight:700;font-size:12px;font-family:var(--font-mono)}
.rank-1{background:rgba(255,215,0,.12);color:gold;border:1px solid rgba(255,215,0,.3)}
.rank-2{background:rgba(192,192,192,.1);color:silver;border:1px solid rgba(192,192,192,.25)}
.rank-3{background:rgba(205,127,50,.1);color:#cd7f32;border:1px solid rgba(205,127,50,.25)}
.rank-n{background:var(--bg3);color:var(--muted);border:1px solid var(--border)}
.player-cell{display:flex;align-items:center;gap:12px}
.cell-avatar{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:18px;overflow:hidden;background:var(--bg3);border:1px solid var(--border);flex-shrink:0}
.cell-avatar img{width:100%;height:100%;object-fit:cover}
.cell-name{font-weight:700;font-size:14px}
.cell-bio{font-size:11px;color:var(--muted);font-family:var(--font-mono);margin-top:2px}
.wr-bar-wrap{display:flex;align-items:center;gap:8px}
.wr-bar{height:4px;border-radius:2px;background:linear-gradient(90deg,var(--green),var(--blue))}

/* Online presence */
.online-pip{display:inline-block;width:9px;height:9px;border-radius:50%;background:var(--bg3);border:2px solid var(--bg2);flex-shrink:0;transition:background .4s,box-shadow .4s}
.online-pip.online{background:var(--green);box-shadow:0 0 6px var(--green)}
.online-pip.offline{background:var(--pink);box-shadow:0 0 6px var(--pink)}
.avatar-wrap{position:relative;display:inline-block;flex-shrink:0}
.avatar-wrap .online-pip{position:absolute;bottom:1px;right:1px;width:10px;height:10px;border:2px solid var(--bg2)}
.pod-avatar-wrap{position:relative;display:inline-block}
.pod-avatar-wrap .online-pip{position:absolute;bottom:4px;right:4px;width:12px;height:12px;border:2px solid var(--bg2)}
.online-badge{display:inline-flex;align-items:center;gap:5px;font-size:11px;font-family:var(--font-mono);margin-top:5px}
.online-badge .online-pip{position:static;border:none}

/* Profile modal */
.modal-bg{display:none;position:fixed;inset:0;z-index:500;background:rgba(8,11,18,.85);backdrop-filter:blur(12px);align-items:center;justify-content:center}
.modal-bg.open{display:flex}
.modal-card{background:var(--bg2);border:1px solid var(--border);border-radius:24px;width:420px;max-width:95vw;overflow:hidden;animation:popIn .3s cubic-bezier(.22,1,.36,1)}
.modal-header{background:var(--bg3);padding:24px;display:flex;align-items:flex-start;gap:18px;position:relative}
.modal-avatar{width:80px;height:80px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:40px;overflow:hidden;border:3px solid var(--green);background:var(--bg);flex-shrink:0}
.modal-avatar img{width:100%;height:100%;object-fit:cover}
.modal-username{font-size:22px;font-weight:800;letter-spacing:-0.5px}
.modal-bio{font-size:12px;font-family:var(--font-mono);color:var(--muted);margin-top:4px;line-height:1.5;max-width:220px}
.modal-rank{font-size:11px;font-family:var(--font-mono);color:var(--muted);margin-top:4px}
.modal-close{position:absolute;top:16px;right:16px;width:28px;height:28px;border-radius:8px;background:var(--bg);border:1px solid var(--border);cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:14px;color:var(--muted)}
.modal-close:hover{color:#fff;border-color:rgba(255,255,255,.2)}

/* Follow stats row */
.modal-follow-row{display:flex;gap:0;border-bottom:1px solid var(--border)}
.mfr-stat{flex:1;padding:12px 16px;text-align:center;border-right:1px solid var(--border);cursor:pointer;transition:background .15s}
.mfr-stat:last-child{border-right:none}
.mfr-stat:hover{background:rgba(255,255,255,.04)}
.mfr-stat .v{font-size:18px;font-weight:800;color:var(--text)}
.mfr-stat .l{font-size:10px;font-family:var(--font-mono);color:var(--muted);margin-top:2px;letter-spacing:1px}

/* Modal stats grid */
.modal-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:1px;background:var(--border)}
.modal-stat{background:var(--bg2);padding:16px;text-align:center}
.modal-stat .v{font-size:22px;font-weight:800;color:var(--green)}
.modal-stat .l{font-size:10px;font-family:var(--font-mono);color:var(--muted);margin-top:2px;letter-spacing:1px}

/* Modal footer */
.modal-footer{padding:16px 20px;display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap}
.modal-btn{padding:8px 20px;border-radius:9px;font-size:12px;font-weight:700;cursor:pointer;border:none;transition:filter .2s,background .2s,color .2s;text-decoration:none;display:inline-flex;align-items:center;gap:6px}
.modal-btn:hover{filter:brightness(1.12)}
.modal-btn.primary{background:var(--green);color:#080b12}
.modal-btn.secondary{background:var(--bg3);color:var(--text);border:1px solid var(--border)}
.follow-btn{padding:8px 20px;border-radius:9px;font-size:12px;font-weight:700;cursor:pointer;transition:all .2s;border:1px solid rgba(0,255,135,.4);background:rgba(0,255,135,.08);color:var(--green);display:inline-flex;align-items:center;gap:6px}
.follow-btn.following{border-color:rgba(255,45,111,.3);background:rgba(255,45,111,.08);color:var(--pink)}
.follow-btn:hover{filter:brightness(1.15)}
.follow-btn:disabled{opacity:.5;cursor:not-allowed}

/* Follow list mini modal (inside modal) */
.follow-sub-panel{display:none;padding:0 0 8px}
.follow-sub-panel.open{display:block}
.fsp-tabs{display:flex;border-bottom:1px solid var(--border)}
.fsp-tab{flex:1;padding:10px;text-align:center;font-size:11px;font-family:var(--font-mono);font-weight:700;letter-spacing:1px;color:var(--muted);cursor:pointer;border:none;background:none;border-bottom:2px solid transparent;transition:all .15s}
.fsp-tab.active{color:var(--green);border-bottom-color:var(--green)}
.fsp-list{max-height:180px;overflow-y:auto;padding:4px 0}
.fsp-item{display:flex;align-items:center;gap:10px;padding:8px 20px;transition:background .15s}
.fsp-item:hover{background:rgba(255,255,255,.04)}
.fsp-avt{width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:16px;background:var(--bg3);border:1px solid var(--border);overflow:hidden;flex-shrink:0}
.fsp-avt img{width:100%;height:100%;object-fit:cover}
.fsp-name{font-size:13px;font-weight:700}
.fsp-since{font-size:10px;font-family:var(--font-mono);color:var(--muted)}
.fsp-empty{text-align:center;padding:20px;font-family:var(--font-mono);font-size:11px;color:var(--muted)}

@keyframes popIn{from{opacity:0;transform:scale(.92) translateY(12px)}to{opacity:1;transform:none}}

/* Responsive */
@media(max-width:640px){
  .lb-wrap{padding:20px 16px}
  .lb-hero{margin-bottom:28px}
  .lb-hero h1{font-size:32px;letter-spacing:-1.5px}
  .podium{gap:10px;padding:0;margin-bottom:36px}
  .podium-slot{gap:8px}
  .pod-rank-icon{font-size:18px}
  .pod-avatar{width:64px;height:64px;font-size:28px;border-width:2px}
  .pod-1 .pod-avatar{width:76px;height:76px}
  .pod-name{font-size:12px;max-width:90px}
  .pod-score{font-size:10px}
  .pod-block{font-size:18px}
  .pod-1 .pod-block{height:80px}
  .pod-2 .pod-block{height:58px}
  .pod-3 .pod-block{height:44px}
  .lb-table{display:block}
  .lb-table thead{display:none}
  .lb-table tbody{display:flex;flex-direction:column;gap:8px}
  .lb-table tbody tr{display:grid;grid-template-columns:36px 1fr;grid-template-rows:auto auto;column-gap:12px;row-gap:6px;padding:14px 14px 12px;background:var(--bg2);border:1px solid var(--border);border-radius:14px;cursor:pointer;transition:border-color .2s}
  .lb-table tbody tr:hover{border-color:rgba(255,255,255,.14)}
  .lb-table tbody tr.is-me{border-color:rgba(0,255,135,.3);background:rgba(0,255,135,.03)}
  .lb-table tbody td{display:block;padding:0;border:none}
  .lb-table tbody td:nth-child(1){grid-column:1;grid-row:1/3;display:flex;align-items:center;justify-content:center;align-self:center}
  .lb-table tbody td:nth-child(2){grid-column:2;grid-row:1}
  .lb-table tbody td:nth-child(3),.lb-table tbody td:nth-child(4),.lb-table tbody td:nth-child(5),.lb-table tbody td:nth-child(6){display:none}
  .lb-table tbody td:nth-child(2)::after{content:attr(data-stats);display:block;margin-top:5px;font-family:var(--font-mono);font-size:11px;color:var(--muted);letter-spacing:.3px}
  .cell-avatar{width:32px;height:32px;font-size:15px}
  .cell-name{font-size:13px}
  .cell-bio{display:none}
  .rank-badge{width:28px;height:28px;font-size:11px;border-radius:7px}
  .wr-bar{display:none}
}
</style>

<div class="lb-wrap">
  <div class="lb-hero">
    <h1>Leader<span>board</span></h1>
    <p>Top coders ranked by wins & score. Click any player to see their profile.</p>
  </div>

<?php if (!$rows): ?>
  <p style="color:var(--muted);font-family:var(--font-mono)">No battles yet — be the first!</p>
<?php else: ?>

  <!-- Podium (top 3) -->
  <?php
    $top = array_slice($rows, 0, 3);
    $podOrder = [];
    if (isset($top[1])) $podOrder[] = ['data'=>$top[1],'cls'=>'pod-2'];
    if (isset($top[0])) $podOrder[] = ['data'=>$top[0],'cls'=>'pod-1'];
    if (isset($top[2])) $podOrder[] = ['data'=>$top[2],'cls'=>'pod-3'];
  ?>
  <div class="podium">
    <?php foreach ($podOrder as $p):
      $r    = $p['data'];
      $icon = $r['rank']==1?'👑':($r['rank']==2?'🥈':'🥉');
      // Build extra data for modal
      $r['follower_count']  = $followerCounts[$r['id']] ?? 0;
      $r['following_count'] = $followingCounts[$r['id']] ?? 0;
      $r['i_follow']        = in_array($r['id'], $myFollowingIds) ? 1 : 0;
    ?>
    <div class="podium-slot <?= $p['cls'] ?>" data-uid="<?= (int)$r['id'] ?>"
         onclick="openModal(<?= htmlspecialchars(json_encode($r), ENT_QUOTES) ?>)">
      <span class="pod-rank-icon"><?= $icon ?></span>
      <div class="pod-avatar-wrap">
        <div class="pod-avatar">
          <?php if (!empty($r['avatar_img'])): ?>
            <img src="<?= e($r['avatar_img']) ?>" alt="">
          <?php else: ?>
            <?= e($r['avatar'] ?: '👾') ?>
          <?php endif; ?>
        </div>
        <span class="online-pip offline pod-pip"></span>
      </div>
      <div class="pod-name"><?= e($r['username']) ?></div>
      <div class="pod-score"><?= number_format($r['total_score']) ?> pts</div>
      <div class="pod-block"><?= $r['wins'] ?></div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Full table -->
  <table class="lb-table">
    <thead>
      <tr>
        <th>#</th><th>Player</th><th>Wins</th><th>Losses</th><th>Win Rate</th><th>Score</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($rows as $r):
        $rank = (int)$r['rank'];
        $cls  = match(true) { $rank===1=>'rank-1',$rank===2=>'rank-2',$rank===3=>'rank-3',default=>'rank-n' };
        $icon = match(true) { $rank===1=>'🥇',$rank===2=>'🥈',$rank===3=>'🥉',default=>$rank };
        $isMe = $me && $me['id']==$r['id'];
        $r['follower_count']  = $followerCounts[$r['id']]  ?? 0;
        $r['following_count'] = $followingCounts[$r['id']] ?? 0;
        $r['i_follow']        = in_array($r['id'], $myFollowingIds) ? 1 : 0;
      ?>
      <tr class="lb-row <?= $isMe?'is-me':'' ?>" data-uid="<?= (int)$r['id'] ?>"
          onclick="openModal(<?= htmlspecialchars(json_encode($r), ENT_QUOTES) ?>)">
        <td><span class="rank-badge <?= $cls ?>"><?= $icon ?></span></td>
        <td data-stats="<?= $r['wins'] ?>W · <?= $r['losses'] ?>L · <?= $r['win_rate'] ?>% · <?= number_format($r['total_score']) ?>pts">
          <div class="player-cell">
            <div class="avatar-wrap">
              <div class="cell-avatar">
                <?php if (!empty($r['avatar_img'])): ?><img src="<?= e($r['avatar_img']) ?>" alt="">
                <?php else: ?><?= e($r['avatar'] ?: '👾') ?><?php endif; ?>
              </div>
              <span class="online-pip offline row-pip"></span>
            </div>
            <div>
              <div class="cell-name" style="<?= $isMe?'color:var(--green)':'' ?>"><?= e($r['username']) ?><?= $isMe?' (you)':'' ?></div>
              <?php if (!empty($r['bio'])): ?>
                <div class="cell-bio"><?= e(mb_strimwidth($r['bio'],0,50,'…')) ?></div>
              <?php endif; ?>
            </div>
          </div>
        </td>
        <td style="color:var(--green);font-weight:700;font-size:15px"><?= $r['wins'] ?></td>
        <td style="color:var(--pink)"><?= $r['losses'] ?></td>
        <td>
          <div class="wr-bar-wrap">
            <div class="wr-bar" style="width:<?= min(100,$r['win_rate']) ?>px"></div>
            <span style="font-family:var(--font-mono);font-size:12px"><?= $r['win_rate'] ?>%</span>
          </div>
        </td>
        <td style="font-family:var(--font-mono);font-size:13px"><?= number_format($r['total_score']) ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
<?php endif; ?>
</div>

<!-- ── Profile Modal ───────────────────────────────────────────────── -->
<div class="modal-bg" id="playerModal" onclick="if(event.target===this)closeModal()">
  <div class="modal-card">
    <div class="modal-header">
      <div class="modal-avatar" id="mAvatar"></div>
      <div style="flex:1;min-width:0">
        <div class="modal-username" id="mUsername"></div>
        <div class="modal-bio" id="mBio"></div>
        <div class="modal-rank" id="mRank"></div>
        <div class="online-badge" id="mOnlineBadge">
          <span class="online-pip offline" id="mOnlinePip"></span>
          <span id="mOnlineLabel" style="color:var(--muted)">—</span>
        </div>
      </div>
      <div class="modal-close" onclick="closeModal()">✕</div>
    </div>

    <!-- Follower / Following counts row -->
    <div class="modal-follow-row">
      <div class="mfr-stat" onclick="openFollowSub('followers')" title="See followers">
        <div class="v" id="mFollowers">0</div>
        <div class="l">Followers</div>
      </div>
      <div class="mfr-stat" onclick="openFollowSub('following')" title="See following">
        <div class="v" id="mFollowing">0</div>
        <div class="l">Following</div>
      </div>
    </div>

    <!-- Expandable follow sub-panel -->
    <div class="follow-sub-panel" id="followSubPanel">
      <div class="fsp-tabs">
        <button class="fsp-tab active" id="fsp-tab-followers" onclick="switchFollowSub('followers')">Followers</button>
        <button class="fsp-tab" id="fsp-tab-following" onclick="switchFollowSub('following')">Following</button>
      </div>
      <div class="fsp-list" id="fspList"></div>
    </div>

    <div class="modal-stats">
      <div class="modal-stat"><div class="v" id="mWins">0</div><div class="l">Wins</div></div>
      <div class="modal-stat"><div class="v" id="mLosses" style="color:var(--pink)">0</div><div class="l">Losses</div></div>
      <div class="modal-stat"><div class="v" id="mRate" style="color:var(--blue)">0%</div><div class="l">Win Rate</div></div>
      <div class="modal-stat"><div class="v" id="mScore" style="font-size:16px;color:var(--blue)">0</div><div class="l">Score</div></div>
    </div>

    <div class="modal-footer">
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <?php if ($me): ?>
        <button class="follow-btn" id="followBtn" onclick="toggleFollow()">➕ Follow</button>
        <a class="modal-btn secondary" id="messageBtn" href="#" style="display:none">💬 Message</a>
        <?php endif; ?>
      </div>
      <button class="modal-btn secondary" onclick="closeModal()">Close</button>
    </div>
  </div>
</div>
<script src="assets/security.js"></script>
<script>
const MY_ID     = <?= $me ? (int)$me['id'] : 'null' ?>;
const ALL_USER_IDS = <?= json_encode(array_column($rows ?? [], 'id')) ?>;

let currentModalUid      = null;
let currentFollowSubTab  = 'followers';
let followSubOpen        = false;

// ── Heartbeat ─────────────────────────────────────────────────────────────
<?php if ($me): ?>
(function heartbeat(){
  fetch('api.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'heartbeat'})});
  setInterval(function(){
    fetch('api.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'heartbeat'})});
  }, 20000);
})();
<?php endif; ?>

// ── Online presence ───────────────────────────────────────────────────────
var onlineSet = new Set();
function refreshOnlineStatus() {
  if (!ALL_USER_IDS.length) return;
  var qs = ALL_USER_IDS.map(id => 'ids[]=' + id).join('&');
  fetch('api.php?action=get_online&' + qs)
    .then(r => r.json())
    .then(data => {
      onlineSet = new Set((data.online || []).map(Number));
      document.querySelectorAll('tr[data-uid]').forEach(row => {
        var pip = row.querySelector('.row-pip');
        if (pip) applyPip(pip, onlineSet.has(+row.dataset.uid));
      });
      document.querySelectorAll('.podium-slot[data-uid]').forEach(slot => {
        var pip = slot.querySelector('.pod-pip');
        if (pip) applyPip(pip, onlineSet.has(+slot.dataset.uid));
      });
      if (currentModalUid) updateModalPip(currentModalUid);
    });
}
function applyPip(pip, isOnline) {
  pip.classList.toggle('online', isOnline);
  pip.classList.toggle('offline', !isOnline);
}
function updateModalPip(uid) {
  var pip   = document.getElementById('mOnlinePip');
  var label = document.getElementById('mOnlineLabel');
  var on    = onlineSet.has(uid);
  applyPip(pip, on);
  label.textContent = on ? 'Online now' : 'Offline';
  label.style.color = on ? 'var(--green)' : 'var(--pink)';
}
refreshOnlineStatus();
setInterval(refreshOnlineStatus, 20000);

// ── Modal open/close ──────────────────────────────────────────────────────
function openModal(player) {
  const rankIcons = {1:'🥇',2:'🥈',3:'🥉'};
  const rank = parseInt(player.rank);
  const icon = rankIcons[rank] || '#' + rank;

  currentModalUid = parseInt(player.id);
  followSubOpen   = false;
  document.getElementById('followSubPanel').classList.remove('open');

  // Avatar
  const av = document.getElementById('mAvatar');
  if (player.avatar_img) {
    av.innerHTML = `<img src="${player.avatar_img}" alt="" style="width:100%;height:100%;object-fit:cover">`;
  } else {
    av.textContent = player.avatar || '👾';
  }

  document.getElementById('mUsername').textContent = player.username;
  document.getElementById('mBio').textContent      = player.bio || 'No bio yet.';
  document.getElementById('mRank').textContent     = `${icon} Rank ${rank}`;
  document.getElementById('mWins').textContent     = player.wins;
  document.getElementById('mLosses').textContent   = player.losses;
  document.getElementById('mRate').textContent     = player.win_rate + '%';
  document.getElementById('mScore').textContent    = Number(player.total_score).toLocaleString();

  // Follower / following counts
  document.getElementById('mFollowers').textContent = player.follower_count || 0;
  document.getElementById('mFollowing').textContent = player.following_count || 0;

  // Follow button + Message button
  const followBtn = document.getElementById('followBtn');
  const messageBtn = document.getElementById('messageBtn');
  if (followBtn) {
    if (MY_ID && MY_ID === currentModalUid) {
      followBtn.style.display = 'none';
      if (messageBtn) messageBtn.style.display = 'none';
    } else {
      followBtn.style.display = 'inline-flex';
      setFollowBtnState(player.i_follow == 1);
      if (messageBtn) {
        messageBtn.style.display = 'inline-flex';
        messageBtn.href = `messages.php?with=${currentModalUid}`;
      }
    }
  }

  document.getElementById('playerModal').dataset.uid = currentModalUid;
  updateModalPip(currentModalUid);
  document.getElementById('playerModal').classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  document.getElementById('playerModal').classList.remove('open');
  document.getElementById('playerModal').dataset.uid = '';
  document.getElementById('followSubPanel').classList.remove('open');
  followSubOpen = false;
  currentModalUid = null;
  document.body.style.overflow = '';
}
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });

// ── Unfollow confirm toast ────────────────────────────────────────────────
let unfollowToastTimer = null;
let pendingUnfollowUid = null;

function showUnfollowToast(username) {
  let toast = document.getElementById('unfollowToast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'unfollowToast';
    toast.style.cssText = [
      'position:fixed','bottom:28px','left:50%',
      'transform:translateX(-50%) translateY(20px)',
      'background:var(--bg2)','border:1px solid rgba(255,45,111,.4)',
      'border-radius:14px','padding:14px 20px',
      'display:flex','align-items:center','gap:14px','z-index:9999',
      'box-shadow:0 8px 32px rgba(0,0,0,.5)',
      'font-family:var(--font-mono)','font-size:13px',
      'opacity:0','transition:opacity .2s,transform .2s',
      'pointer-events:none','white-space:nowrap'
    ].join(';');
    document.body.appendChild(toast);
  }
  toast.innerHTML =
    `<span style="color:var(--text)">Unfollow <strong style="color:var(--pink)">${escHtml(username)}</strong>?</span>` +
    `<button onclick="confirmUnfollow()" style="padding:6px 14px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;border:none;background:var(--pink);color:#fff;font-family:var(--font-mono)">Unfollow</button>` +
    `<button onclick="dismissUnfollowToast()" style="padding:6px 14px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;border:1px solid var(--border);background:var(--bg3);color:var(--muted);font-family:var(--font-mono)">Cancel</button>`;
  toast.style.pointerEvents = 'all';
  requestAnimationFrame(() => {
    toast.style.opacity = '1';
    toast.style.transform = 'translateX(-50%) translateY(0)';
  });
  clearTimeout(unfollowToastTimer);
  unfollowToastTimer = setTimeout(dismissUnfollowToast, 5000);
}

function dismissUnfollowToast() {
  clearTimeout(unfollowToastTimer);
  const toast = document.getElementById('unfollowToast');
  if (!toast) return;
  toast.style.opacity = '0';
  toast.style.transform = 'translateX(-50%) translateY(20px)';
  toast.style.pointerEvents = 'none';
  pendingUnfollowUid = null;
}

async function confirmUnfollow() {
  dismissUnfollowToast();
  if (!pendingUnfollowUid) return;
  const uid = pendingUnfollowUid;
  pendingUnfollowUid = null;

  // Instant UI update
  setFollowBtnState(false);
  const countEl = document.getElementById('mFollowers');
  const prev = parseInt(countEl.textContent) || 0;
  countEl.textContent = Math.max(0, prev - 1);

  try {
    const fd = new FormData();
    fd.append('action',    'toggle_follow');
    fd.append('target_id', uid);
    const res  = await fetch('showcase.php', { method: 'POST', body: fd });
    const data = await res.json();
    if (data.ok) {
      countEl.textContent = data.follower_count;
    } else {
      // Revert on failure
      setFollowBtnState(true);
      countEl.textContent = prev;
    }
  } catch(e) {
    setFollowBtnState(true);
    countEl.textContent = prev;
  }
}

// ── Follow toggle ─────────────────────────────────────────────────────────
function setFollowBtnState(isFollowing) {
  const btn = document.getElementById('followBtn');
  if (!btn) return;
  if (isFollowing) {
    btn.innerHTML = '✓ Following';
    btn.classList.add('following');
  } else {
    btn.innerHTML = '➕ Follow';
    btn.classList.remove('following');
  }
}

async function toggleFollow() {
  if (!MY_ID || !currentModalUid) return;
  const btn = document.getElementById('followBtn');

  // Already following → show unfollow confirm toast instead
  if (btn.classList.contains('following')) {
    pendingUnfollowUid = currentModalUid;
    showUnfollowToast(document.getElementById('mUsername').textContent);
    return;
  }

  // Not yet following → instant optimistic follow, request in background
  setFollowBtnState(true);
  const countEl  = document.getElementById('mFollowers');
  const prevCount = parseInt(countEl.textContent) || 0;
  countEl.textContent = prevCount + 1;

  try {
    const fd = new FormData();
    fd.append('action',    'toggle_follow');
    fd.append('target_id', currentModalUid);
    const res  = await fetch('showcase.php', { method: 'POST', body: fd });
    const data = await res.json();
    if (data.ok) {
      countEl.textContent = data.follower_count;
      setFollowBtnState(data.following);
      if (data.following && window.refreshNotifBadge) window.refreshNotifBadge();
    } else {
      // Revert on failure
      setFollowBtnState(false);
      countEl.textContent = prevCount;
    }
  } catch(e) {
    setFollowBtnState(false);
    countEl.textContent = prevCount;
  }
}

// ── Follow sub-panel (pre-loaded, no fetch) ───────────────────────────────
const _lbFollowData = {
  followers: <?= json_encode((object)array_map('array_values', $followersLists)) ?>,
  following:  <?= json_encode((object)array_map('array_values', $followingLists)) ?>
};

function openFollowSub(tab) {
  const panel = document.getElementById('followSubPanel');
  if (followSubOpen && currentFollowSubTab === tab) {
    panel.classList.remove('open');
    followSubOpen = false;
    return;
  }
  followSubOpen = true;
  currentFollowSubTab = tab;
  panel.classList.add('open');
  document.getElementById('fsp-tab-followers').classList.toggle('active', tab === 'followers');
  document.getElementById('fsp-tab-following').classList.toggle('active', tab === 'following');
  renderFollowSubList(tab);
}

function switchFollowSub(tab) {
  currentFollowSubTab = tab;
  document.getElementById('fsp-tab-followers').classList.toggle('active', tab === 'followers');
  document.getElementById('fsp-tab-following').classList.toggle('active', tab === 'following');
  renderFollowSubList(tab);
}

function renderFollowSubList(tab) {
  const list  = document.getElementById('fspList');
  const key   = tab === 'followers' ? 'followers' : 'following';
  const users = (_lbFollowData[key] && _lbFollowData[key][currentModalUid]) || [];
  if (!users.length) {
    list.innerHTML = `<div class="fsp-empty">${tab === 'followers' ? 'No followers yet.' : 'Not following anyone.'}</div>`;
    return;
  }
  list.innerHTML = users.map(u => `
    <a class="fsp-item" href="showcase.php?user=${u.id}" style="text-decoration:none;color:inherit;cursor:pointer">
      <div class="fsp-avt">
        ${u.avatar_img ? `<img src="${escHtml(u.avatar_img)}" alt="">` : escHtml(u.avatar || '👾')}
      </div>
      <div>
        <div class="fsp-name">${escHtml(u.username)}</div>
        <div class="fsp-since">Since ${escHtml(u.since)}</div>
      </div>
    </a>
  `).join('');
}

function escHtml(str) {
  const d = document.createElement('div'); d.textContent = str; return d.innerHTML;
}
</script>

<?php
pageFooter();
?>
