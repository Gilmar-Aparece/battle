<?php
// ── notifications.php — Notification centre + JSON API ────────────────
require_once 'includes/config.php';
require_once 'includes/layout.php';
requireLogin();

$user = auth();

require_once 'includes/notifications_helper.php';

// ── Auto-create notifications table if missing ────────────────────────
try {
  // NOTE: No FOREIGN KEY constraints — shared hosts reject FK creation from PHP.
  db()->exec("CREATE TABLE IF NOT EXISTS `notifications` (
    `id`         INT(11)      NOT NULL AUTO_INCREMENT,
    `user_id`    INT(11)      NOT NULL,
    `actor_id`   INT(11)      NOT NULL,
    `type`       ENUM('follow','showcase_like','showcase_comment','arena_join','arena_invite') NOT NULL,
    `ref_id`     INT(11)      DEFAULT NULL,
    `ref_label`  VARCHAR(120) DEFAULT NULL,
    `is_read`    TINYINT(1)   NOT NULL DEFAULT 0,
    `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_user_id`  (`user_id`),
    KEY `idx_actor_id` (`actor_id`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
} catch (Exception $e) {}

// ── JSON API ──────────────────────────────────────────────────────────
if (isset($_GET['action']) || isset($_POST['action'])) {
  header('Content-Type: application/json');
  $action = $_GET['action'] ?? $_POST['action'] ?? '';

  // ── get_notifications — fetch latest 40 notifications (exclude hidden) ─
  if ($action === 'get_notifications') {
    $stmt = db()->prepare("
      SELECT n.id, n.type, n.ref_id, n.ref_label, n.is_read,
             n.created_at,
             u.id AS actor_id, u.username AS actor_name,
             u.avatar AS actor_avatar, u.avatar_img AS actor_img
      FROM notifications n
      JOIN users u ON u.id = n.actor_id
      WHERE n.user_id = ? AND n.is_read != 2
      ORDER BY n.created_at DESC
      LIMIT 40
    ");
    $stmt->execute([$user['id']]);
    $rows = $stmt->fetchAll();

    $unread = (int)db()->query("SELECT COUNT(*) FROM notifications WHERE user_id={$user['id']} AND is_read=0")->fetchColumn();
    echo json_encode(['ok'=>true, 'notifications'=>$rows, 'unread'=>$unread]);
    exit;
  }

  // ── unread_count — lightweight poll for badge ───────────────────────
  if ($action === 'unread_count') {
    $unread = (int)db()->query("SELECT COUNT(*) FROM notifications WHERE user_id={$user['id']} AND is_read=0")->fetchColumn();
    echo json_encode(['unread' => $unread]);
    exit;
  }

  // ── mark_read — mark one or all as read ────────────────────────────
  if ($action === 'mark_read') {
    $id = (int)($_POST['id'] ?? 0);
    if ($id) {
      db()->prepare("UPDATE notifications SET is_read=1 WHERE id=? AND user_id=?")->execute([$id, $user['id']]);
    } else {
      db()->prepare("UPDATE notifications SET is_read=1 WHERE user_id=?")->execute([$user['id']]);
    }
    echo json_encode(['ok'=>true]);
    exit;
  }

  // ── follow_back — follow or unfollow the actor from a notification ──
  if ($action === 'follow_back') {
    $target_id = (int)($_POST['target_id'] ?? 0);
    if (!$target_id || $target_id === (int)$user['id']) {
      echo json_encode(['ok'=>false,'error'=>'invalid']); exit;
    }
    $chk = db()->prepare('SELECT id FROM users WHERE id=?');
    $chk->execute([$target_id]);
    if (!$chk->fetch()) { echo json_encode(['ok'=>false,'error'=>'not_found']); exit; }

    $existing = db()->prepare('SELECT id FROM user_follows WHERE follower_id=? AND following_id=?');
    $existing->execute([$user['id'], $target_id]);
    if ($existing->fetch()) {
      // Already following — unfollow
      db()->prepare('DELETE FROM user_follows WHERE follower_id=? AND following_id=?')->execute([$user['id'], $target_id]);
      echo json_encode(['ok'=>true, 'following'=>false]);
    } else {
      db()->prepare('INSERT IGNORE INTO user_follows (follower_id, following_id) VALUES (?,?)')->execute([$user['id'], $target_id]);
      pushNotification($target_id, $user['id'], 'follow', null, null);
      echo json_encode(['ok'=>true, 'following'=>true]);
    }
    exit;
  }

  // ── check_following — check if current user follows a target ────────
  if ($action === 'check_following') {
    $target_id = (int)($_GET['target_id'] ?? 0);
    $chk = db()->prepare('SELECT id FROM user_follows WHERE follower_id=? AND following_id=?');
    $chk->execute([$user['id'], $target_id]);
    echo json_encode(['following' => (bool)$chk->fetch()]);
    exit;
  }

  // ── hide_notification — soft-delete (is_read=2) ─────────────────────
  if ($action === 'hide_notification') {
    $id = (int)($_POST['id'] ?? 0);
    if (!$id) { echo json_encode(['ok'=>false,'error'=>'invalid']); exit; }
    db()->prepare("UPDATE notifications SET is_read=2 WHERE id=? AND user_id=?")->execute([$id, $user['id']]);
    echo json_encode(['ok'=>true]);
    exit;
  }

  // ── delete_notification — permanent removal ──────────────────────────
  if ($action === 'delete_notification') {
    $id = (int)($_POST['id'] ?? 0);
    if (!$id) { echo json_encode(['ok'=>false,'error'=>'invalid']); exit; }
    db()->prepare("DELETE FROM notifications WHERE id=? AND user_id=?")->execute([$id, $user['id']]);
    echo json_encode(['ok'=>true]);
    exit;
  }

  echo json_encode(['ok'=>false,'error'=>'unknown_action']);
  exit;
}

// ── Full page render ──────────────────────────────────────────────────
pageHeader('Notifications');
?>
<style>
  /* ── Page layout ── */
  .notif-page{max-width:600px;margin:0 auto;padding:32px 16px 60px}

  /* ── Header ── */
  .notif-header{margin-bottom:24px}
  .notif-header h1{font-size:24px;font-weight:800;letter-spacing:-0.5px;margin-bottom:4px;display:flex;align-items:center;gap:10px}
  .notif-header .sub{font-family:var(--font-mono);font-size:11px;color:var(--muted)}

  /* ── Toolbar ── */
  .notif-toolbar{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px}
  .notif-toolbar .badge{font-family:var(--font-mono);font-size:11px;color:var(--muted)}
  .mark-all-btn{background:none;border:1px solid var(--border);color:var(--muted);font-size:11px;font-family:var(--font-mono);padding:5px 12px;border-radius:8px;cursor:pointer;transition:all .15s}
  .mark-all-btn:hover{color:#fff;border-color:rgba(255,255,255,.2)}

  /* ── Notification list ── */
  .notif-list{display:flex;flex-direction:column;gap:6px}

  /* ── Single notification card ──
     3 columns: [avatar 44px] [body flex] [menu-slot 32px]
     This keeps the unread dot + 3-dot btn inside the card bounds (fixes red overflow from screenshot) */
  .notif-item{
    display:grid;
    grid-template-columns:44px 1fr 32px;
    gap:0 12px;
    align-items:start;
    background:var(--bg2);
    border:1px solid var(--border);
    border-radius:14px;
    padding:14px 10px 14px 16px;
    position:relative;
    cursor:pointer;
    transition:border-color .2s, background .2s, opacity .3s, transform .3s;
  }
  .notif-item.unread{border-color:rgba(0,200,255,.2);background:rgba(0,200,255,.03)}
  .notif-item:hover{border-color:rgba(255,255,255,.14);background:var(--bg3)}
  .notif-item.removing{opacity:0;transform:translateX(40px)}

  /* Avatar column */
  .notif-avatar{
    width:44px;height:44px;border-radius:50%;
    border:2px solid var(--border);
    display:flex;align-items:center;justify-content:center;
    font-size:22px;background:var(--bg3);
    overflow:hidden;flex-shrink:0;
    grid-row:1;grid-column:1;
  }
  .notif-avatar img{width:100%;height:100%;object-fit:cover}

  /* Body column */
  .notif-body{grid-row:1;grid-column:2;min-width:0}

  /* Top row: text */
  .notif-text{font-size:13px;line-height:1.55;color:var(--text)}
  .notif-text strong{color:#fff;font-weight:700}
  .notif-text em{color:var(--muted);font-style:normal}

  /* Meta row */
  .notif-meta{display:flex;align-items:center;gap:8px;margin-top:5px;flex-wrap:wrap}
  .notif-time{font-family:var(--font-mono);font-size:10px;color:var(--muted)}
  .type-badge{font-size:9px;font-family:var(--font-mono);padding:2px 7px;border-radius:4px;font-weight:700;letter-spacing:.5px;text-transform:uppercase}
  .type-follow  {background:rgba(0,255,135,.1);color:var(--green)}
  .type-like    {background:rgba(255,45,111,.1);color:var(--pink)}
  .type-comment {background:rgba(0,200,255,.1);color:var(--blue)}
  .type-arena   {background:rgba(255,180,0,.1);color:#ffb400}
  .type-live    {background:rgba(255,68,68,.15);color:#ff6b6b;animation:liveBadgePulse 2s infinite}
  @keyframes liveBadgePulse{0%,100%{opacity:1}50%{opacity:.6}}

  /* Action buttons */
  .notif-actions{display:flex;gap:8px;margin-top:10px;flex-wrap:wrap}
  .notif-btn{
    display:inline-flex;align-items:center;gap:5px;
    padding:6px 14px;border-radius:8px;
    font-size:11px;font-weight:700;
    cursor:pointer;border:none;
    transition:all .15s;font-family:var(--font-mono);
    text-decoration:none;white-space:nowrap;
  }
  .notif-btn.follow{background:var(--green);color:#080b12}
  .notif-btn.follow:hover{filter:brightness(1.1)}
  .notif-btn.follow.following{background:var(--bg3);color:var(--muted);border:1px solid var(--border)}
  .notif-btn.view{background:var(--bg3);color:var(--muted);border:1px solid var(--border)}
  .notif-btn.view:hover{color:#fff;border-color:rgba(255,255,255,.2)}
  .notif-btn.join-arena{background:linear-gradient(135deg,#ffb400,#ff6a00);color:#000;font-weight:800;box-shadow:0 0 14px rgba(255,140,0,.35)}
  .notif-btn.join-arena:hover{filter:brightness(1.1);box-shadow:0 0 22px rgba(255,140,0,.55)}

  /* ── Right-side slot: unread dot + 3-dot menu ── */
  .notif-slot{
    grid-row:1;grid-column:3;
    display:flex;flex-direction:column;align-items:center;gap:6px;
    padding-top:2px;
  }

  /* Unread dot */
  .notif-dot{
    width:7px;height:7px;border-radius:50%;
    background:var(--blue);box-shadow:0 0 8px var(--blue);
    flex-shrink:0;
  }

  /* 3-dot menu button */
  .notif-menu-btn{
    background:none;border:none;color:var(--muted);
    font-size:18px;line-height:1;cursor:pointer;
    padding:2px 4px;border-radius:6px;
    transition:color .15s, background .15s;
    flex-shrink:0;
  }
  .notif-menu-btn:hover{color:#fff;background:var(--bg3)}

  /* ── 3-dot menu wrapper: relative so dropdown anchors to it ── */
  .notif-menu-wrap{position:relative;display:flex;flex-direction:column;align-items:center}

  /* Dropdown — absolutely positioned from the menu-wrap */
  .notif-dropdown{
    position:absolute;top:26px;right:0;
    background:var(--bg3);border:1px solid var(--border);
    border-radius:10px;min-width:140px;
    padding:4px;z-index:200;
    box-shadow:0 8px 24px rgba(0,0,0,.55);
    display:none;
    /* Stays inside notif-list, doesn't push grid layout */
  }
  .notif-dropdown.open{display:block}
  .notif-dropdown button{
    display:flex;align-items:center;gap:8px;
    width:100%;padding:8px 12px;
    background:none;border:none;border-radius:7px;
    color:var(--text);font-size:12px;font-family:var(--font-mono);
    cursor:pointer;text-align:left;transition:background .15s;
    white-space:nowrap;
  }
  .notif-dropdown button:hover{background:var(--bg2)}
  .notif-dropdown button.danger{color:var(--pink)}
  .notif-dropdown button.danger:hover{background:rgba(255,45,111,.1)}

  /* Empty / loading states */
  .notif-empty{text-align:center;padding:60px 20px;font-family:var(--font-mono);font-size:13px;color:var(--muted)}
  .notif-empty .icon{font-size:40px;margin-bottom:16px}
  .notif-loading{text-align:center;padding:40px;color:var(--muted);font-family:var(--font-mono);font-size:12px}

  /* Mobile tweaks */
  @media(max-width:480px){
    .notif-page{padding:20px 12px 60px}
    .notif-header h1{font-size:20px}
    .notif-item{padding:12px 8px 12px 12px;grid-template-columns:38px 1fr 30px;gap:0 8px}
    .notif-avatar{width:38px;height:38px;font-size:18px}
  }
</style>

<div class="notif-page">
  <div class="notif-header">
    <h1>🔔 Notifications</h1>
    <p class="sub">Follows · Likes · Comments · Arena activity</p>
  </div>

  <div class="notif-toolbar">
    <span class="badge" id="unreadBadge">Loading…</span>
    <button class="mark-all-btn" onclick="markAllRead()">✓ Mark all as read</button>
  </div>

  <div class="notif-list" id="notifList">
    <div class="notif-loading">⏳ Loading notifications…</div>
  </div>
</div>
<script src="assets/security.js"></script>
<script>
const CURRENT_USER_ID = <?= (int)$user['id'] ?>;
let notifications = [];

function timeAgo(dateStr) {
  const diff = Math.floor((Date.now() - new Date(dateStr + ' UTC').getTime()) / 1000);
  if (diff < 60)  return diff + 's ago';
  if (diff < 3600) return Math.floor(diff/60) + 'm ago';
  if (diff < 86400) return Math.floor(diff/3600) + 'h ago';
  return Math.floor(diff/86400) + 'd ago';
}

function typeLabel(type) {
  return {follow:'Follow',showcase_like:'Like',showcase_comment:'Comment',arena_join:'Arena',arena_invite:'Invite',live_started:'LIVE'}[type] || type;
}

function typeBadgeClass(type) {
  return {follow:'type-follow',showcase_like:'type-like',showcase_comment:'type-comment',arena_join:'type-arena',arena_invite:'type-arena',live_started:'type-live'}[type] || '';
}

function escHtml(s) {
  return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function buildText(n) {
  const name = `<strong>${escHtml(n.actor_name)}</strong>`;
  switch(n.type) {
    case 'follow':           return `${name} started following you`;
    case 'showcase_like':    return `${name} liked your post <em>${escHtml(n.ref_label||'')}</em>`;
    case 'showcase_comment': return `${name} commented on your post <em>${escHtml(n.ref_label||'')}</em>`;
    case 'arena_join':       return `${name} joined your Game Arena <strong>${escHtml(n.ref_label||'')}</strong>`;
    case 'arena_invite':     return `${name} invited you to a Game Arena — room <strong>${escHtml(n.ref_label||'')}</strong>`;
    case 'live_started':     return `${name} is 🔴 <strong>LIVE NOW</strong> — <em>${escHtml(n.ref_label||'')}</em>`;
    default: return `${name} interacted with you`;
  }
}

// Track follow state per actor
const followState = {};

function buildActionBtns(n) {
  let html = '';

  if (n.type === 'follow') {
    const btnId = `fb-${n.id}`;
    const isFollowing = followState[n.actor_id] === true;
    const cls = isFollowing ? 'notif-btn follow following' : 'notif-btn follow';
    const label = isFollowing ? '✓ Following' : '+ Follow Back';
    html += `<button class="${cls}" id="${btnId}" onclick="followBack(${n.actor_id}, '${btnId}', event)">${label}</button>`;
  }

  if (n.type === 'showcase_like') {
    if (n.ref_id) {
      html += `<a href="showcase.php?id=${n.ref_id}" class="notif-btn view" onclick="event.stopPropagation(); markRead(${n.id})">View Post</a>`;
    }
  }

  if (n.type === 'showcase_comment') {
    if (n.ref_id) {
      html += `<a href="showcase.php?id=${n.ref_id}#comments" class="notif-btn view" onclick="event.stopPropagation(); markRead(${n.id})">View Comment</a>`;
    }
  }

  if (n.type === 'arena_invite') {
    // Prominent "Join Game" CTA — orange gradient button
    const code = escHtml(n.ref_label||'');
    if (code) {
      html += `<a href="battle.php?code=${code}" class="notif-btn join-arena" onclick="event.stopPropagation(); markRead(${n.id})">⚔️ Join Game</a>`;
    }
  }

  if (n.type === 'arena_join') {
    const code = escHtml(n.ref_label||'');
    if (code) {
      html += `<a href="battle.php?code=${code}" class="notif-btn view" onclick="event.stopPropagation(); markRead(${n.id})">Go to Arena</a>`;
    }
  }

  if (n.type === 'live_started' && n.ref_id) {
    html += `<a href="live.php?id=${n.ref_id}" class="notif-btn join-arena" onclick="event.stopPropagation(); markRead(${n.id})">🔴 Watch Live</a>`;
  }

  return html ? `<div class="notif-actions">${html}</div>` : '';
}

function renderNotifications() {
  const list = document.getElementById('notifList');
  if (!notifications.length) {
    list.innerHTML = `<div class="notif-empty"><div class="icon">🔕</div>No notifications yet — go battle someone!</div>`;
    return;
  }
  list.innerHTML = notifications.map(n => {
    const avatarHtml = n.actor_img
      ? `<img src="${escHtml(n.actor_img)}" alt="">`
      : (n.actor_avatar || '👤');
    const unreadClass = n.is_read == 0 ? ' unread' : '';

    // Unread dot (only when unread)
    const dot = n.is_read == 0 ? '<div class="notif-dot"></div>' : '';

    // Row click (mark read) — but not for arena types (those navigate on button click only)
    const rowClick = `onclick="handleRowClick(${n.id}, event)"`;

    return `
      <div class="notif-item${unreadClass}" id="ni-${n.id}" ${rowClick}>
        <div class="notif-avatar">${avatarHtml}</div>
        <div class="notif-body">
          <div class="notif-text">${buildText(n)}</div>
          <div class="notif-meta">
            <span class="notif-time">${timeAgo(n.created_at)}</span>
            <span class="type-badge ${typeBadgeClass(n.type)}">${typeLabel(n.type)}</span>
          </div>
          ${buildActionBtns(n)}
        </div>
        <div class="notif-slot">
          ${dot}
          <div class="notif-menu-wrap">
            <button class="notif-menu-btn" onclick="toggleMenu(${n.id}, event)" title="Options">⋮</button>
            <div class="notif-dropdown" id="dd-${n.id}">
              <button onclick="hideNotif(${n.id}, event)">👁 Hide</button>
              <button class="danger" onclick="deleteNotif(${n.id}, event)">🗑 Delete</button>
            </div>
          </div>
        </div>
      </div>`;
  }).join('');
}

// ── Row click: mark read + navigate where relevant ─────────────────────
function handleRowClick(id, evt) {
  // Ignore clicks on buttons, links, and the menu
  if (evt.target.closest('button,a,.notif-dropdown,.notif-menu-wrap')) return;
  const n = notifications.find(x => x.id == id);
  markRead(id);
  if (!n) return;
  if (n.type === 'showcase_like' && n.ref_id) {
    window.location.href = `showcase.php?id=${n.ref_id}`;
  } else if (n.type === 'showcase_comment' && n.ref_id) {
    window.location.href = `showcase.php?id=${n.ref_id}#comments`;
  }
}

// ── 3-dot menu ─────────────────────────────────────────────────────────
function toggleMenu(id, evt) {
  evt.stopPropagation();
  // Close all other open dropdowns first
  document.querySelectorAll('.notif-dropdown.open').forEach(el => {
    if (el.id !== `dd-${id}`) el.classList.remove('open');
  });
  document.getElementById(`dd-${id}`)?.classList.toggle('open');
}

// Close dropdowns when clicking outside
document.addEventListener('click', () => {
  document.querySelectorAll('.notif-dropdown.open').forEach(el => el.classList.remove('open'));
});

// ── Hide notification (soft-delete: is_read=2) ──────────────────────────
async function hideNotif(id, evt) {
  evt.stopPropagation();
  document.getElementById(`dd-${id}`)?.classList.remove('open');
  animateRemove(id);
  const fd = new FormData();
  fd.append('action','hide_notification'); fd.append('id', id);
  await fetch('notifications.php', {method:'POST', body:fd});
  notifications = notifications.filter(n => n.id != id);
  updateUnreadBadge();
  setTimeout(() => renderNotifications(), 320);
}

// ── Delete notification (permanent) ────────────────────────────────────
async function deleteNotif(id, evt) {
  evt.stopPropagation();
  document.getElementById(`dd-${id}`)?.classList.remove('open');
  animateRemove(id);
  const fd = new FormData();
  fd.append('action','delete_notification'); fd.append('id', id);
  await fetch('notifications.php', {method:'POST', body:fd});
  notifications = notifications.filter(n => n.id != id);
  updateUnreadBadge();
  setTimeout(() => renderNotifications(), 320);
}

// Slide-out animation before removal
function animateRemove(id) {
  const el = document.getElementById(`ni-${id}`);
  if (el) el.classList.add('removing');
}

function updateUnreadBadge() {
  const unread = notifications.filter(n => n.is_read == 0).length;
  document.getElementById('unreadBadge').textContent =
    unread > 0 ? `${unread} unread` : 'All caught up ✓';
  updateGlobalBadge(unread);
}

async function loadNotifications() {
  try {
    const res  = await fetch('notifications.php?action=get_notifications');
    const data = await res.json();
    notifications = data.notifications || [];
    const unread  = data.unread || 0;
    document.getElementById('unreadBadge').textContent =
      unread > 0 ? `${unread} unread` : 'All caught up ✓';

    // Pre-check follow state for all follow-type notifications
    const followActors = [...new Set(
      notifications.filter(n => n.type === 'follow').map(n => n.actor_id)
    )];
    await Promise.all(followActors.map(async actorId => {
      try {
        const r = await fetch(`notifications.php?action=check_following&target_id=${actorId}`);
        const d = await r.json();
        followState[actorId] = d.following;
      } catch(e) { followState[actorId] = false; }
    }));

    renderNotifications();
  } catch(e) {
    document.getElementById('notifList').innerHTML =
      '<div class="notif-empty"><div class="icon">⚠️</div>Could not load notifications.</div>';
  }
}

async function markRead(id) {
  const fd = new FormData();
  fd.append('action','mark_read'); fd.append('id', id);
  fetch('notifications.php', {method:'POST', body:fd});
  const n = notifications.find(x => x.id == id);
  if (n) { n.is_read = 1; renderNotifications(); }
  updateGlobalBadge();
}

async function markAllRead() {
  const fd = new FormData(); fd.append('action','mark_read');
  await fetch('notifications.php', {method:'POST', body:fd});
  notifications.forEach(n => n.is_read = 1);
  document.getElementById('unreadBadge').textContent = 'All caught up ✓';
  renderNotifications();
  updateGlobalBadge(0);
}

async function followBack(targetId, btnId, evt) {
  if (evt) evt.stopPropagation();
  const btn = document.getElementById(btnId);
  if (!btn) return;
  btn.disabled = true;
  const fd = new FormData(); fd.append('action','follow_back'); fd.append('target_id', targetId);
  try {
    const res  = await fetch('notifications.php', {method:'POST', body:fd});
    const data = await res.json();
    if (data.ok) {
      followState[targetId] = data.following;
      btn.textContent = data.following ? '✓ Following' : '+ Follow Back';
      btn.classList.toggle('following', data.following);
    }
  } catch(e) {
    btn.textContent = 'Error — retry';
  } finally { btn.disabled = false; }
}

function updateGlobalBadge(count) {
  const badge = document.getElementById('navNotifBadge');
  if (!badge) return;
  if (count === undefined) {
    fetch('notifications.php?action=unread_count').then(r=>r.json()).then(d=>{
      badge.textContent = d.unread || '';
      badge.style.display = d.unread > 0 ? 'flex' : 'none';
    });
  } else {
    badge.textContent = count || '';
    badge.style.display = count > 0 ? 'flex' : 'none';
  }
}

loadNotifications();
</script>

<?php pageFooter(); ?>
