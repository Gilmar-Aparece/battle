<?php
// ─── menu_builder_api.php ────────────────────────────────────────────────────
// AJAX endpoint called by menu_builder.php to submit an export for admin review.
// Also serves approved-export downloads back to the user.
// ─────────────────────────────────────────────────────────────────────────────
require_once 'includes/config.php';
requireLogin();

$db   = db();
$user = auth();
header('Content-Type: application/json');

$action = $_POST['action'] ?? $_GET['action'] ?? '';

// ── Safe migrations (run once, harmless on repeat) ────────────────────────────
(function() use ($db) {
    try {
        $cols = $db->query("SHOW COLUMNS FROM users")->fetchAll(PDO::FETCH_COLUMN);
        if (!in_array('folio_edit_allowed', $cols)) {
            $db->exec("ALTER TABLE users ADD COLUMN folio_edit_allowed tinyint(1) NOT NULL DEFAULT 0");
        }
        $db->exec("CREATE TABLE IF NOT EXISTS `menu_builder_exports` (
            `id`           int(11)      NOT NULL AUTO_INCREMENT,
            `user_id`      int(11)      NOT NULL,
            `filename`     varchar(255) NOT NULL,
            `file_content` longtext     NOT NULL,
            `status`       enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
            `admin_note`   text         DEFAULT NULL,
            `reviewed_by`  int(11)      DEFAULT NULL,
            `reviewed_at`  datetime     DEFAULT NULL,
            `created_at`   datetime     NOT NULL DEFAULT current_timestamp(),
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } catch (Exception $e) { /* silent — don't break API responses */ }
})();

// ── Submit export for approval ────────────────────────────────────────────────
if ($action === 'submit_export' && $_SERVER['REQUEST_METHOD'] === 'POST') {

    // Check if user's builder access is blocked
    $row = $db->prepare('SELECT menu_builder_disabled FROM users WHERE id=?');
    $row->execute([$user['id']]);
    $data = $row->fetch();
    if (!empty($data['menu_builder_disabled'])) {
        echo json_encode(['ok' => false, 'error' => 'Your Menu Builder access has been disabled by an admin.']);
        exit;
    }

    $filename = preg_replace('/[^a-zA-Z0-9_\-]/', '_', trim($_POST['filename'] ?? 'export'));
    $filename = ($filename ?: 'export') . '.html';
    $content  = $_POST['content'] ?? '';

    if (strlen($content) < 50) {
        echo json_encode(['ok' => false, 'error' => 'Empty or too-short content.']);
        exit;
    }

    // Check for duplicate pending submission from same user
    $dup = $db->prepare(
        "SELECT id FROM menu_builder_exports WHERE user_id=? AND filename=? AND status='pending' LIMIT 1"
    );
    $dup->execute([$user['id'], $filename]);
    if ($dup->fetch()) {
        echo json_encode(['ok' => false, 'error' => 'You already have a pending review for this filename. Please wait for admin approval.']);
        exit;
    }

    $stmt = $db->prepare(
        'INSERT INTO menu_builder_exports (user_id, filename, file_content) VALUES (?,?,?)'
    );
    $stmt->execute([$user['id'], $filename, $content]);
    $id = $db->lastInsertId();

    echo json_encode(['ok' => true, 'export_id' => (int)$id,
        'message' => 'Your export has been submitted for admin review. You will be able to download it once approved.']);
    exit;
}

// ── Check export status ───────────────────────────────────────────────────────
if ($action === 'check_export' && isset($_GET['id'])) {
    $id   = (int)$_GET['id'];
    $stmt = $db->prepare('SELECT id, filename, status, admin_note, reviewed_at FROM menu_builder_exports WHERE id=? AND user_id=?');
    $stmt->execute([$id, $user['id']]);
    $row = $stmt->fetch();
    if (!$row) {
        echo json_encode(['ok' => false, 'error' => 'Not found.']);
        exit;
    }
    echo json_encode(['ok' => true, 'export' => $row]);
    exit;
}

// ── List user's own exports ───────────────────────────────────────────────────
if ($action === 'list_exports') {
    $stmt = $db->prepare(
        'SELECT id, filename, status, admin_note, reviewed_at, created_at
         FROM menu_builder_exports WHERE user_id=? ORDER BY created_at DESC LIMIT 20'
    );
    $stmt->execute([$user['id']]);
    echo json_encode(['ok' => true, 'exports' => $stmt->fetchAll()]);
    exit;
}

// ── Download approved export ──────────────────────────────────────────────────
if ($action === 'download_export' && isset($_GET['id'])) {
    $id   = (int)$_GET['id'];
    $stmt = $db->prepare(
        "SELECT filename, file_content FROM menu_builder_exports WHERE id=? AND user_id=? AND status='approved'"
    );
    $stmt->execute([$id, $user['id']]);
    $row = $stmt->fetch();
    if (!$row) {
        http_response_code(403);
        echo json_encode(['ok' => false, 'error' => 'File not approved or not found.']);
        exit;
    }
    header('Content-Type: text/html; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . addslashes($row['filename']) . '"');
    header('Content-Length: ' . strlen($row['file_content']));
    echo $row['file_content'];
    exit;
}

echo json_encode(['ok' => false, 'error' => 'Unknown action.']);

// ── Import an approved export back into the builder (returns HTML content) ────
if ($action === 'import_approved' && isset($_GET['id'])) {
    $id   = (int)$_GET['id'];
    $stmt = $db->prepare(
        "SELECT filename, file_content FROM menu_builder_exports WHERE id=? AND user_id=? AND status='approved'"
    );
    $stmt->execute([$id, $user['id']]);
    $row = $stmt->fetch();
    if (!$row) {
        echo json_encode(['ok' => false, 'error' => 'File not approved or not found.']);
        exit;
    }
    echo json_encode(['ok' => true, 'filename' => $row['filename'], 'content' => $row['file_content']]);
    exit;
}

// ── Check if user has FolioOne edit permission ────────────────────────────────
if ($action === 'check_folio_permission') {
    $stmt = $db->prepare('SELECT folio_edit_allowed FROM users WHERE id=?');
    $stmt->execute([$user['id']]);
    $row = $stmt->fetch();
    echo json_encode(['ok' => true, 'folio_edit_allowed' => !empty($row['folio_edit_allowed'])]);
    exit;
}
