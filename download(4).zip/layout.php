<?php
// ─── layout.php ──────────────────────────────────────────────────────
function pageHeader(string $title = SITE_NAME, string $extra = ''): void {
  $user = auth();
  $cur  = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#080b12">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <meta name="apple-mobile-web-app-title" content="codeMe">
  <meta name="description" content="codeMe — Multiplayer CSS/HTML Coding Battle Game">
  <link rel="manifest" href="manifest.json">
  <link rel="apple-touch-icon" href="icon-192.png">
  <title><?= e($title) ?> — <?= SITE_NAME ?></title>
  <link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;600;800&display=swap" rel="stylesheet">
  <style>
    :root{
      --green:#00ff87;--pink:#ff2d6f;--blue:#00c8ff;--purple:#b14fff;
      --bg:#080b12;--bg2:#0e1320;--bg3:#141b2d;
      --border:rgba(255,255,255,0.07);--text:#e8eaf0;--muted:#5a6380;
      --font-head:'Syne',sans-serif;--font-mono:'Space Mono',monospace;
      --nav-h:60px;
    }
    *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
    html,body{min-height:100%;font-family:var(--font-head);background:var(--bg);color:var(--text)}
    a{color:inherit;text-decoration:none}
    input,button,textarea,select{font-family:inherit}

    /* ══ NAVBAR ══ */
    .navbar{
      background:var(--bg2);border-bottom:1px solid var(--border);
      display:flex;align-items:center;padding:0 22px;height:var(--nav-h);
      position:sticky;top:0;z-index:300;gap:0;
    }

    /* Logo */
    .nav-logo{display:flex;align-items:center;gap:8px;flex-shrink:0;margin-right:26px}
    .logo-dot{width:9px;height:9px;border-radius:50%;background:var(--green);box-shadow:0 0 10px var(--green)}
    .logo-text{font-size:17px;font-weight:800;letter-spacing:-.5px;color:#fff;white-space:nowrap}
    .logo-text span{color:var(--green)}

    /* Nav links row */
    .nav-links{display:flex;align-items:center;gap:2px}
    .nav-spacer{flex:1}

    /* Nav item + dropdown wrapper */
    .nav-item{position:relative}
    .nav-link{
      display:flex;align-items:center;gap:5px;
      padding:7px 12px;border-radius:8px;
      font-size:13px;font-weight:600;color:var(--muted);
      transition:color .15s,background .15s;white-space:nowrap;
      cursor:pointer;border:none;background:transparent;
    }
    .nav-link:hover,.nav-link.active{color:#fff;background:rgba(255,255,255,0.06)}
    .nav-link.active{color:var(--green)}
    .nav-chev{font-size:9px;opacity:.45;transition:transform .2s,opacity .2s;display:inline-block}
    .nav-item:hover .nav-chev{transform:rotate(180deg);opacity:.9}

    /* ── Dropdown ── */
    .nav-dd{
      display:none;position:absolute;top:calc(100% + 7px);left:0;
      min-width:224px;background:var(--bg3);
      border:1px solid rgba(255,255,255,0.09);border-radius:13px;
      padding:7px;box-shadow:0 16px 44px rgba(0,0,0,.6);
      z-index:400;animation:ddIn .14s ease-out;
    }
    @keyframes ddIn{from{opacity:0;transform:translateY(-5px)}to{opacity:1;transform:none}}
    .nav-item:hover .nav-dd{display:block}

    .dd-row{
      display:flex;align-items:flex-start;gap:10px;
      padding:9px 10px;border-radius:8px;
      transition:background .12s;text-decoration:none;
    }
    .dd-row:hover{background:rgba(255,255,255,0.05)}
    .dd-icon{font-size:17px;flex-shrink:0;line-height:1.25;margin-top:1px}
    .dd-title{font-size:13px;font-weight:700;color:var(--text);line-height:1.2}
    .dd-desc{font-size:10.5px;color:var(--muted);font-family:var(--font-mono);margin-top:3px;line-height:1.45}
    .dd-sep{height:1px;background:var(--border);margin:5px 4px}

    /* Inline badges inside dropdown titles */
    .dd-badge{
      display:inline-block;font-size:10px;font-weight:700;
      padding:1px 6px;border-radius:4px;vertical-align:middle;margin-left:5px;
      letter-spacing:.2px;
    }
    .dd-badge-red{background:rgba(255,45,111,.15);color:var(--pink)}
    .dd-badge-blue{background:rgba(0,200,255,.12);color:var(--blue)}
    .dd-badge-green{background:rgba(0,255,135,.12);color:var(--green)}
    .dd-badge-live{background:rgba(255,45,111,.18);color:var(--pink);animation:livePulse 1.4s ease-in-out infinite}
    @keyframes livePulse{0%,100%{opacity:1}50%{opacity:.55}}

    /* Right area */
    .nav-right{display:flex;align-items:center;gap:8px;flex-shrink:0}
    .nav-chip{
      display:flex;align-items:center;gap:7px;
      padding:5px 11px 5px 7px;border-radius:9px;
      border:1px solid var(--border);font-size:13px;font-weight:600;
      transition:background .15s,border-color .15s;
    }
    .nav-chip:hover{background:rgba(255,255,255,0.04);border-color:rgba(255,255,255,.14)}
    .nav-av{font-size:18px;line-height:1}

    .btn-sm{
      padding:7px 15px;border-radius:8px;font-size:12px;font-weight:700;
      cursor:pointer;border:none;letter-spacing:.4px;
      transition:filter .18s,transform .15s;white-space:nowrap;display:inline-block;
    }
    .btn-sm:hover{filter:brightness(1.12);transform:scale(1.03)}
    .btn-primary{background:var(--green);color:#080b12}
    .btn-outline{background:transparent;border:1px solid var(--border);color:var(--muted)}
    .btn-outline:hover{color:#fff;border-color:rgba(255,255,255,.2)}
    .btn-danger{background:transparent;border:1px solid rgba(255,45,111,.4);color:var(--pink)}
    .btn-danger:hover{background:rgba(255,45,111,.1)}
    .btn-admin{background:rgba(177,79,255,.15);color:var(--purple);border:1px solid rgba(177,79,255,.3)}
    .btn-admin:hover{background:rgba(177,79,255,.25)}

    /* ── Hamburger ── */
    .nav-hamburger{
      display:none;flex-direction:column;justify-content:center;gap:5px;
      width:40px;height:40px;padding:8px;border-radius:10px;
      border:1px solid var(--border);background:rgba(255,255,255,0.03);
      cursor:pointer;flex-shrink:0;margin-left:auto;
      transition:background .2s,border-color .2s;
    }
    .nav-hamburger:hover{background:rgba(255,255,255,.07);border-color:rgba(255,255,255,.15)}
    .nav-hamburger span{
      display:block;height:2px;width:100%;border-radius:2px;background:var(--text);
      transition:transform .3s cubic-bezier(.68,-.6,.32,1.6),opacity .25s;
    }
    .nav-hamburger.open{border-color:rgba(0,255,135,.4);background:rgba(0,255,135,.06)}
    .nav-hamburger.open span{background:var(--green)}
    .nav-hamburger.open span:nth-child(1){transform:translateY(7px) rotate(45deg)}
    .nav-hamburger.open span:nth-child(2){opacity:0;transform:scaleX(0)}
    .nav-hamburger.open span:nth-child(3){transform:translateY(-7px) rotate(-45deg)}

    /* ── Mobile drawer ── */
    .nav-drawer{
      display:none;position:fixed;
      top:var(--nav-h);left:0;right:0;bottom:0;
      background:rgba(8,11,18,0.98);border-top:1px solid var(--border);
      z-index:299;flex-direction:column;padding:14px;gap:3px;overflow-y:auto;
    }
    .nav-drawer.open{display:flex;animation:drawerIn .22s ease-out}
    @keyframes drawerIn{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:none}}

    /* Section label inside drawer */
    .drawer-section{
      font-size:10px;font-family:var(--font-mono);letter-spacing:1.8px;
      text-transform:uppercase;color:var(--muted);
      padding:12px 16px 5px;
    }
    .nav-drawer .nav-link{
      padding:13px 16px;border-radius:12px;font-size:14px;
      font-weight:600;border:1px solid transparent;
      display:flex;align-items:center;gap:12px;
      color:var(--text);transition:background .15s,border-color .15s;
    }
    .nav-drawer .nav-link:hover{background:rgba(255,255,255,.05);border-color:var(--border)}
    .nav-drawer .nav-link.active{color:var(--green);border-color:rgba(0,255,135,.25);background:rgba(0,255,135,.06)}
    .nav-drawer .nav-link-icon{font-size:18px;width:24px;text-align:center;flex-shrink:0}
    .drawer-hint{
      font-size:10.5px;font-family:var(--font-mono);color:var(--muted);
      padding:0 16px 6px 52px;line-height:1.45;margin-top:-3px;
    }

    .drawer-divider{height:1px;background:var(--border);margin:8px 0}
    .drawer-user{
      display:flex;align-items:center;gap:12px;
      padding:12px 16px;font-size:14px;font-weight:600;
      color:var(--muted);border-radius:12px;background:var(--bg3);margin-bottom:6px;
    }
    .drawer-user-avatar{font-size:24px}
    .drawer-btn{
      padding:13px 16px;border-radius:12px;font-size:14px;font-weight:700;
      cursor:pointer;border:none;letter-spacing:.3px;text-align:center;
      text-decoration:none;display:block;transition:filter .2s,transform .15s;
    }
    .drawer-btn:active{transform:scale(.98)}

    /* ── PWA Install banner ── */
    .install-banner{
      display:none;align-items:center;gap:12px;
      background:linear-gradient(135deg,rgba(0,200,255,.1),rgba(0,255,135,.07));
      border:1px solid rgba(0,200,255,.2);border-radius:14px;padding:13px 14px;margin-bottom:10px;
    }
    .install-banner.show{display:flex}
    .install-banner-icon{font-size:24px;flex-shrink:0}
    .install-banner-text{flex:1;min-width:0}
    .install-banner-title{font-size:13px;font-weight:700;color:var(--text)}
    .install-banner-sub{font-size:10px;color:var(--muted);font-family:var(--font-mono);margin-top:2px;line-height:1.4}
    .install-banner-btn{
      padding:9px 14px;border-radius:9px;font-size:12px;font-weight:700;
      cursor:pointer;border:none;flex-shrink:0;white-space:nowrap;
      background:linear-gradient(135deg,#00c8ff,#00ff87);color:#080b12;transition:filter .2s;
    }
    .install-banner-btn:hover{filter:brightness(1.1)}
    .install-banner-close{background:none;border:none;color:var(--muted);cursor:pointer;font-size:18px;padding:2px 4px;flex-shrink:0;transition:color .2s;line-height:1}
    .install-banner-close:hover{color:var(--text)}
    .ios-install-tip{
      display:none;background:rgba(0,200,255,.08);border:1px solid rgba(0,200,255,.2);
      border-radius:12px;padding:12px 14px;margin-bottom:10px;
      font-size:12px;font-family:var(--font-mono);color:var(--muted);line-height:1.6;text-align:center;
    }
    .ios-install-tip.show{display:block}
    .ios-install-tip strong{color:var(--blue)}

    @media(max-width:700px){
      .nav-links,.nav-right{display:none}
      .nav-hamburger{display:flex}
    }

    /* ── Page wrapper ── */
    .page{max-width:1100px;margin:0 auto;padding:48px 28px}
    .page-hero{margin-bottom:44px}
    .page-hero h1{font-size:44px;font-weight:800;line-height:1;letter-spacing:-2px}
    .page-hero h1 .hi{color:var(--green)}
    .page-hero p{margin-top:12px;color:var(--muted);font-size:13px;max-width:420px;line-height:1.7;font-family:var(--font-mono)}

    /* ── Forms ── */
    .form-card{background:var(--bg2);border:1px solid var(--border);border-radius:20px;padding:40px;max-width:440px;margin:60px auto}
    .form-card h2{font-size:26px;font-weight:800;letter-spacing:-1px;margin-bottom:6px}
    .form-card p{color:var(--muted);font-size:13px;font-family:var(--font-mono);margin-bottom:28px}
    .field{margin-bottom:18px}
    .field label{display:block;font-size:11px;font-family:var(--font-mono);letter-spacing:1.5px;text-transform:uppercase;color:var(--muted);margin-bottom:8px}
    .field input,.field select{width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:10px;padding:12px 16px;color:var(--text);font-size:14px;font-family:var(--font-mono);outline:none;transition:border-color .2s}
    .field input:focus,.field select:focus{border-color:rgba(0,255,135,.4)}
    .btn-full{width:100%;padding:13px;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;border:none;background:var(--green);color:#080b12;letter-spacing:.5px;transition:filter .2s}
    .btn-full:hover{filter:brightness(1.1)}
    .form-footer{text-align:center;margin-top:20px;font-size:13px;color:var(--muted);font-family:var(--font-mono)}
    .form-footer a{color:var(--green)}
    .alert{padding:12px 16px;border-radius:10px;font-size:13px;font-family:var(--font-mono);margin-bottom:20px}
    .alert-error{background:rgba(255,45,111,.1);border:1px solid rgba(255,45,111,.3);color:var(--pink)}
    .alert-success{background:rgba(0,255,135,.08);border:1px solid rgba(0,255,135,.3);color:var(--green)}

    /* ── Toast ── */
    #toast{position:fixed;bottom:28px;right:28px;background:var(--bg3);border:1px solid var(--green);color:var(--green);padding:12px 22px;border-radius:10px;font-family:var(--font-mono);font-size:13px;opacity:0;pointer-events:none;transition:opacity .3s;z-index:9999}
    #toast.show{opacity:1}

    /* ── Section label ── */
    .sec-label{font-size:11px;font-family:var(--font-mono);color:var(--muted);letter-spacing:2px;text-transform:uppercase;margin-bottom:14px;margin-top:40px}
  </style>
  <?= $extra ?>
</head>
<body>

<nav class="navbar">

  <a href="index.php" class="nav-logo">
    <div class="logo-dot"></div>
    <span class="logo-text">code<span>Me</span></span>
  </a>

  <div class="nav-links">

    <!-- Home -->
    <div class="nav-item">
      <a href="index.php" class="nav-link <?= $cur==='index.php'?'active':'' ?>">Home</a>
    </div>

    <!-- ⚔️ Play dropdown -->
    <div class="nav-item">
      <span class="nav-link <?= in_array($cur,['versus.php','lobby.php','battle.php','live.php'])?'active':'' ?>">
        ⚔️ Play <span class="nav-chev">▾</span>
      </span>
      <div class="nav-dd">
        <a href="versus.php" class="dd-row">
          <span class="dd-icon">⚔️</span>
          <div>
            <div class="dd-title">Versus <span class="dd-badge dd-badge-red">1v1</span></div>
            <div class="dd-desc">Pick a challenge &amp; duel<br>another coder live</div>
          </div>
        </a>
        <a href="lobby.php" class="dd-row">
          <span class="dd-icon">🏟️</span>
          <div>
            <div class="dd-title">Lobby <span class="dd-badge dd-badge-blue">up to 8</span></div>
            <div class="dd-desc">Host or join an open room<br>with multiple players</div>
          </div>
        </a>
        <div class="dd-sep"></div>
        <a href="live.php" class="dd-row">
          <span class="dd-icon">📡</span>
          <div>
            <div class="dd-title">Live <span class="dd-badge dd-badge-live">● LIVE</span></div>
            <div class="dd-desc">Watch ongoing battles in real time</div>
          </div>
        </a>
      </div>
    </div>

    <!-- 🏆 Rankings -->
    <div class="nav-item">
      <a href="leaderboard.php" class="nav-link <?= $cur==='leaderboard.php'?'active':'' ?>">
        🏆 Rankings
      </a>
    </div>

    <!-- ✨ Create dropdown -->
    <div class="nav-item">
      <span class="nav-link <?= in_array($cur,['menu_builder.php','showcase.php'])?'active':'' ?>">
        ✨ Create <span class="nav-chev">▾</span>
      </span>
      <div class="nav-dd">
        <a href="menu_builder.php" class="dd-row">
          <span class="dd-icon">🎨</span>
          <div>
            <div class="dd-title">UI Builder <span class="dd-badge dd-badge-green">NEW</span></div>
            <div class="dd-desc">Design menus &amp; components<br>visually with live preview</div>
          </div>
        </a>
        <a href="showcase.php" class="dd-row">
          <span class="dd-icon">🖼️</span>
          <div>
            <div class="dd-title">Showcase</div>
            <div class="dd-desc">Browse &amp; share community<br>creations and layouts</div>
          </div>
        </a>
      </div>
    </div>

  </div>

  <div class="nav-spacer"></div>

  <div class="nav-right">
    <?php if ($user): ?>
      <a href="profile.php" class="nav-chip">
        <span class="nav-av"><?= e($user['avatar']) ?></span>
        <span><?= e($user['username']) ?></span>
      </a>
      <?php if(isAdmin()): ?>
      <a href="admin/index.php" class="btn-sm btn-admin">⚡ Admin</a>
      <?php endif; ?>
      <a href="logout.php" class="btn-sm btn-danger">Logout</a>
    <?php else: ?>
      <a href="login.php"    class="btn-sm btn-outline">Login</a>
      <a href="register.php" class="btn-sm btn-primary">Play Now</a>
    <?php endif; ?>
  </div>

  <button class="nav-hamburger" id="navHamburger" aria-label="Toggle menu" aria-expanded="false" aria-controls="navDrawer">
    <span></span><span></span><span></span>
  </button>

</nav>

<!-- ══ Mobile Drawer ══ -->
<nav class="nav-drawer" id="navDrawer" aria-label="Mobile navigation">

  <div class="install-banner" id="installBanner">
    <span class="install-banner-icon">📲</span>
    <div class="install-banner-text">
      <div class="install-banner-title">Install codeMe</div>
      <div class="install-banner-sub">Play offline · Add to Home Screen</div>
    </div>
    <button class="install-banner-btn" id="installBtn">Install</button>
    <button class="install-banner-close" id="installBannerClose" aria-label="Dismiss">×</button>
  </div>
  <div class="ios-install-tip" id="iosInstallTip">
    📲 To install: tap <strong>Share ↑</strong> then <strong>"Add to Home Screen"</strong>
  </div>

  <!-- Play section -->
  <div class="drawer-section">⚔️ Play</div>

  <a href="versus.php" class="nav-link <?= $cur==='versus.php'?'active':'' ?>">
    <span class="nav-link-icon">⚔️</span>Versus <span class="dd-badge dd-badge-red" style="margin-left:auto">1v1</span>
  </a>
  <div class="drawer-hint">Challenge a player — match your CSS to a target design</div>

  <a href="lobby.php" class="nav-link <?= $cur==='lobby.php'?'active':'' ?>">
    <span class="nav-link-icon">🏟️</span>Lobby <span class="dd-badge dd-badge-blue" style="margin-left:auto">up to 8</span>
  </a>
  <div class="drawer-hint">Host or join an open room with multiple players</div>

  <a href="live.php" class="nav-link <?= $cur==='live.php'?'active':'' ?>">
    <span class="nav-link-icon">📡</span>Live <span class="dd-badge dd-badge-live" style="margin-left:auto">● LIVE</span>
  </a>
  <div class="drawer-hint">Watch active battles happening right now</div>

  <div class="drawer-divider"></div>

  <!-- Explore section -->
  <div class="drawer-section">🏆 Explore</div>

  <a href="leaderboard.php" class="nav-link <?= $cur==='leaderboard.php'?'active':'' ?>">
    <span class="nav-link-icon">🏆</span>Rankings
  </a>
  <div class="drawer-hint">Top coders ranked by wins and score</div>

  <a href="index.php" class="nav-link <?= $cur==='index.php'?'active':'' ?>">
    <span class="nav-link-icon">🏠</span>Home
  </a>

  <div class="drawer-divider"></div>

  <!-- Create section -->
  <div class="drawer-section">✨ Create</div>

  <a href="menu_builder.php" class="nav-link <?= $cur==='menu_builder.php'?'active':'' ?>">
    <span class="nav-link-icon">🎨</span>UI Builder <span class="dd-badge dd-badge-green" style="margin-left:auto">NEW</span>
  </a>
  <div class="drawer-hint">Design menus &amp; components visually with live preview</div>

  <a href="showcase.php" class="nav-link <?= $cur==='showcase.php'?'active':'' ?>">
    <span class="nav-link-icon">🖼️</span>Showcase
  </a>
  <div class="drawer-hint">Browse &amp; share community creations</div>

  <div class="drawer-divider"></div>

  <?php if ($user): ?>
    <div class="drawer-user">
      <span class="drawer-user-avatar"><?= e($user['avatar']) ?></span>
      <span><?= e($user['username']) ?></span>
    </div>
    <a href="profile.php" class="drawer-btn" style="background:var(--bg3);border:1px solid var(--border);color:var(--text);margin-bottom:6px">👤 My Profile</a>
    <a href="logout.php"  class="drawer-btn" style="background:rgba(255,45,111,.1);border:1px solid rgba(255,45,111,.3);color:var(--pink)">🚪 Logout</a>
  <?php else: ?>
    <a href="login.php"    class="drawer-btn" style="background:var(--bg3);border:1px solid var(--border);color:var(--muted);margin-bottom:6px">🔑 Login</a>
    <a href="register.php" class="drawer-btn" style="background:var(--green);color:#080b12">🎮 Play Now — it's free</a>
  <?php endif; ?>

</nav>
<script src="assets/security.js"></script>
<script>
(function(){
  var hamburger = document.getElementById('navHamburger');
  var drawer    = document.getElementById('navDrawer');
  if(!hamburger || !drawer) return;

  function openDrawer(){
    drawer.classList.add('open');
    hamburger.classList.add('open');
    hamburger.setAttribute('aria-expanded','true');
    document.body.style.overflow = 'hidden';
  }
  function closeDrawer(){
    drawer.classList.remove('open');
    hamburger.classList.remove('open');
    hamburger.setAttribute('aria-expanded','false');
    document.body.style.overflow = '';
  }
  hamburger.addEventListener('click', function(e){
    e.stopPropagation();
    drawer.classList.contains('open') ? closeDrawer() : openDrawer();
  });
  document.addEventListener('click', function(e){
    if(drawer.classList.contains('open') && !drawer.contains(e.target) && !hamburger.contains(e.target)) closeDrawer();
  });
  document.addEventListener('keydown', function(e){ if(e.key==='Escape') closeDrawer(); });
  drawer.querySelectorAll('a').forEach(function(a){ a.addEventListener('click', closeDrawer); });

  /* PWA Install */
  var deferredPrompt = null;
  var banner   = document.getElementById('installBanner');
  var btn      = document.getElementById('installBtn');
  var closeX   = document.getElementById('installBannerClose');
  var iosTip   = document.getElementById('iosInstallTip');
  var dismissed    = localStorage.getItem('cm_install_dismissed');
  var isStandalone = window.matchMedia('(display-mode: standalone)').matches || navigator.standalone;

  window.addEventListener('beforeinstallprompt', function(e){
    e.preventDefault(); deferredPrompt = e;
    if(!dismissed && !isStandalone && banner) banner.classList.add('show');
  });
  if(btn){
    btn.addEventListener('click', function(){
      if(!deferredPrompt) return;
      deferredPrompt.prompt();
      deferredPrompt.userChoice.then(function(){ deferredPrompt = null; });
      banner.classList.remove('show');
    });
  }
  if(closeX){
    closeX.addEventListener('click', function(){
      banner.classList.remove('show');
      localStorage.setItem('cm_install_dismissed','1');
    });
  }
  var isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent) && !window.MSStream;
  if(isIOS && !isStandalone && !dismissed && iosTip) iosTip.classList.add('show');

  if('serviceWorker' in navigator){
    navigator.serviceWorker.register('sw.js').catch(function(){});
  }
})();
</script>

<div id="toast"></div>
<?php
}

function pageFooter(): void { ?>
<script>
function showToast(msg,dur){
  var t=document.getElementById('toast');
  t.textContent=msg;t.classList.add('show');
  setTimeout(function(){t.classList.remove('show')},dur||2500);
}
</script>
</body></html>
<?php }
