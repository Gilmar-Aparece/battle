<?php
require_once 'includes/config.php';
require_once 'includes/layout.php';
requireLogin();

// ── JSON API endpoints — must be BEFORE any HTML output ──────────────────
if (isset($_GET['action'])) {
  $me      = auth();
  $action  = $_GET['action'];
  $queryId = (int)($_GET['user_id'] ?? ($me ? $me['id'] : 0));
  header('Content-Type: application/json');

  if ($action === 'get_followers') {
    $stmt = db()->prepare('
      SELECT u.id, u.username, u.avatar, u.avatar_img,
             DATE_FORMAT(f.created_at, "%b %Y") AS since
      FROM user_follows f
      JOIN users u ON u.id = f.follower_id
      WHERE f.following_id = ?
      ORDER BY f.created_at DESC
    ');
    $stmt->execute([$queryId]);
    echo json_encode(['users' => $stmt->fetchAll()]);
    exit;
  }

  if ($action === 'get_following') {
    $stmt = db()->prepare('
      SELECT u.id, u.username, u.avatar, u.avatar_img,
             DATE_FORMAT(f.created_at, "%b %Y") AS since
      FROM user_follows f
      JOIN users u ON u.id = f.following_id
      WHERE f.follower_id = ?
      ORDER BY f.created_at DESC
    ');
    $stmt->execute([$queryId]);
    echo json_encode(['users' => $stmt->fetchAll()]);
    exit;
  }

  echo json_encode(['error' => 'unknown action']);
  exit;
}

$user = auth();

// ── Auto-create follows & showcase_likes tables ───────────────────────
try {
  db()->exec("CREATE TABLE IF NOT EXISTS user_follows (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    follower_id INT NOT NULL,
    following_id INT NOT NULL,
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_follow (follower_id, following_id),
    FOREIGN KEY (follower_id)  REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (following_id) REFERENCES users(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

  db()->exec("CREATE TABLE IF NOT EXISTS showcase_likes (
    id      INT AUTO_INCREMENT PRIMARY KEY,
    post_id INT NOT NULL,
    user_id INT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_like (post_id, user_id),
    FOREIGN KEY (post_id) REFERENCES showcase_posts(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
} catch (Exception $e) {}

// ── Handle profile update ─────────────────────────────────────────────
$errors  = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';

  // ── Avatar image upload ──
  if ($action === 'upload_avatar') {
    $uploadDir = __DIR__ . '/uploads/avatars/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

    if (!empty($_FILES['avatar_file']['tmp_name'])) {
      $file    = $_FILES['avatar_file'];
      $ext     = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
      $allowed = ['jpg','jpeg','png','gif','webp'];

      if (!in_array($ext, $allowed)) {
        $errors[] = 'Only JPG, PNG, GIF, WEBP allowed.';
      } elseif ($file['size'] > 2 * 1024 * 1024) {
        $errors[] = 'Max file size is 2MB.';
      } else {
        $old = db()->prepare('SELECT avatar_img FROM users WHERE id=?');
        $old->execute([$user['id']]);
        $oldImg = $old->fetchColumn();
        if ($oldImg && file_exists(__DIR__.'/'.$oldImg)) unlink(__DIR__.'/'.$oldImg);

        $filename = 'avatars/' . $user['id'] . '_' . time() . '.' . $ext;
        if (move_uploaded_file($file['tmp_name'], __DIR__.'/uploads/'.$filename)) {
          db()->prepare('UPDATE users SET avatar_img=? WHERE id=?')
               ->execute(['uploads/'.$filename, $user['id']]);
          $success = 'Profile picture updated!';
        } else {
          $errors[] = 'Upload failed. Check folder permissions.';
        }
      }
    }
  }

  // ── Remove avatar image ──
  if ($action === 'remove_avatar') {
    $old = db()->prepare('SELECT avatar_img FROM users WHERE id=?');
    $old->execute([$user['id']]);
    $oldImg = $old->fetchColumn();
    if ($oldImg && file_exists(__DIR__.'/'.$oldImg)) unlink(__DIR__.'/'.$oldImg);
    db()->prepare('UPDATE users SET avatar_img=NULL WHERE id=?')->execute([$user['id']]);
    $success = 'Profile picture removed.';
  }

  // ── Update bio + emoji avatar ──
  if ($action === 'update_profile') {
    $bio    = substr(trim($_POST['bio'] ?? ''), 0, 160);
    $avatar = trim($_POST['avatar'] ?? $user['avatar']);
    db()->prepare('UPDATE users SET bio=?, avatar=? WHERE id=?')
         ->execute([$bio, $avatar, $user['id']]);
    $success = 'Profile updated!';
  }

  // Reload user
  $userRow = db()->prepare('SELECT * FROM users WHERE id=?');
  $userRow->execute([auth()['id']]);
  $userRow = $userRow->fetch();
  $_SESSION['user'] = $userRow;
}

// Fresh load
$stmt = db()->prepare('SELECT * FROM users WHERE id=?');
$stmt->execute([$user['id'] ?? auth()['id']]);
$me = $stmt->fetch();

// Followers / Following counts
$fcStmt = db()->prepare('SELECT COUNT(*) FROM user_follows WHERE following_id=?');
$fcStmt->execute([$me['id']]);
$followerCount  = (int)$fcStmt->fetchColumn();

$fgStmt = db()->prepare('SELECT COUNT(*) FROM user_follows WHERE follower_id=?');
$fgStmt->execute([$me['id']]);
$followingCount = (int)$fgStmt->fetchColumn();

// Pre-load followers & following lists for instant display
$profileFollowersList = db()->prepare('
  SELECT u.id, u.username, u.avatar, u.avatar_img,
         DATE_FORMAT(f.created_at, "%b %Y") AS since
  FROM user_follows f JOIN users u ON u.id = f.follower_id
  WHERE f.following_id = ? ORDER BY f.created_at DESC');
$profileFollowersList->execute([$me['id']]);
$profileFollowersList = $profileFollowersList->fetchAll();

$profileFollowingList = db()->prepare('
  SELECT u.id, u.username, u.avatar, u.avatar_img,
         DATE_FORMAT(f.created_at, "%b %Y") AS since
  FROM user_follows f JOIN users u ON u.id = f.following_id
  WHERE f.follower_id = ? ORDER BY f.created_at DESC');
$profileFollowingList->execute([$me['id']]);
$profileFollowingList = $profileFollowingList->fetchAll();

// Recent battles
$battles = db()->prepare(
  'SELECT r.*,
    u1.username AS host_name, u2.username AS guest_name,
    uw.username AS winner_name
   FROM rooms r
   JOIN users u1 ON u1.id=r.host_id
   LEFT JOIN users u2 ON u2.id=r.guest_id
   LEFT JOIN users uw ON uw.id=r.winner_id
   WHERE (r.host_id=? OR r.guest_id=?) AND r.status="finished"
   ORDER BY r.finished_at DESC LIMIT 10'
);
$battles->execute([$me['id'], $me['id']]);
$myBattles = $battles->fetchAll();

// My showcase posts with like counts
$postsStmt = db()->prepare(
  'SELECT p.*,
     (SELECT COUNT(*) FROM showcase_reactions r WHERE r.post_id=p.id) AS reaction_count,
     (SELECT COUNT(*) FROM showcase_comments c WHERE c.post_id=p.id)  AS comment_count,
     (SELECT COUNT(*) FROM showcase_likes   l WHERE l.post_id=p.id)  AS like_count
   FROM showcase_posts p
   WHERE p.user_id=?
   ORDER BY p.created_at DESC'
);
$postsStmt->execute([$me['id']]);
$myPosts = $postsStmt->fetchAll();

// Rank
$rankRow = db()->query('SELECT id, RANK() OVER (ORDER BY wins DESC, total_score DESC) AS `rank` FROM users');
$rankMap = [];
foreach ($rankRow->fetchAll() as $r) $rankMap[$r['id']] = $r['rank'];
$rank = $rankMap[$me['id']] ?? '—';

$emojiOptions = ['🐱','🐶','🦊','🐼','🐸','🦁','🐯','🐻','🦄','🐲','🦋','🐙','👾','🤖','👻','🎃','⚡','🔥','💎','🌙'];

pageHeader('My Profile');
?>
<style>
/* ── Layout ────────────────────────────────────────────── */
.profile-wrap{max-width:900px;margin:0 auto;padding:40px 24px}
.profile-hero{display:flex;align-items:flex-start;gap:32px;margin-bottom:32px;flex-wrap:wrap}

/* ── Avatar ─────────────────────────────────────────────── */
.avatar-block{position:relative;flex-shrink:0}
.avatar-ring{width:114px;height:114px;border-radius:50%;border:3px solid var(--green);display:flex;align-items:center;justify-content:center;font-size:52px;background:var(--bg3);overflow:hidden;position:relative;cursor:pointer}
.avatar-ring img{width:100%;height:100%;object-fit:cover}
.avatar-overlay{position:absolute;inset:0;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center;opacity:0;transition:opacity .2s;border-radius:50%;cursor:pointer}
.avatar-ring:hover .avatar-overlay{opacity:1}
.avatar-overlay span{font-size:11px;font-family:var(--font-mono);color:#fff;text-align:center;line-height:1.3}
.avatar-edit-btn{position:absolute;bottom:4px;right:4px;width:28px;height:28px;border-radius:50%;background:var(--green);border:2px solid var(--bg);display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:13px}

/* ── Profile info ──────────────────────────────────────── */
.profile-info{flex:1;min-width:220px}
.profile-name{font-size:34px;font-weight:800;letter-spacing:-1.5px;line-height:1}
.profile-bio{font-family:var(--font-mono);font-size:12px;color:var(--muted);margin-top:6px;line-height:1.6}
.profile-rank-badge{display:inline-flex;align-items:center;gap:6px;margin-top:8px;background:var(--bg2);border:1px solid var(--border);border-radius:8px;padding:4px 12px;font-family:var(--font-mono);font-size:11px;color:var(--muted)}

/* ── Stats row ─────────────────────────────────────────── */
.stat-row{display:flex;gap:12px;flex-wrap:wrap;margin-top:18px}
.mini-stat{background:var(--bg2);border:1px solid var(--border);border-radius:12px;padding:14px 18px;text-align:center;min-width:76px;cursor:default}
.mini-stat.clickable{cursor:pointer;transition:border-color .2s,background .2s}
.mini-stat.clickable:hover{border-color:rgba(0,255,135,.4);background:var(--bg3)}
.mini-stat .v{font-size:24px;font-weight:800;color:var(--green)}
.mini-stat .l{font-size:10px;color:var(--muted);font-family:var(--font-mono);letter-spacing:1px;margin-top:2px}

/* ── Tabs ──────────────────────────────────────────────── */
.tabs{display:flex;gap:0;border-bottom:1px solid var(--border);margin-bottom:28px;margin-top:8px}
.tab-btn{padding:10px 20px;font-size:12px;font-family:var(--font-mono);font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--muted);background:none;border:none;border-bottom:2px solid transparent;cursor:pointer;transition:color .15s,border-color .15s;margin-bottom:-1px}
.tab-btn.active{color:var(--green);border-bottom-color:var(--green)}
.tab-btn:hover:not(.active){color:var(--text)}
.tab-pane{display:none}
.tab-pane.active{display:block}

/* ── Edit panel ─────────────────────────────────────────── */
.edit-section{background:var(--bg2);border:1px solid var(--border);border-radius:16px;padding:24px;margin-bottom:28px}
.edit-section h3{font-size:14px;font-weight:700;margin-bottom:16px;display:flex;align-items:center;gap:8px}
.emoji-grid{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px}
.emoji-opt{width:40px;height:40px;border-radius:10px;font-size:20px;display:flex;align-items:center;justify-content:center;cursor:pointer;border:2px solid transparent;background:var(--bg3);transition:all .15s}
.emoji-opt:hover{border-color:var(--green);transform:scale(1.1)}
.emoji-opt.selected{border-color:var(--green);background:rgba(0,255,135,.1)}
.bio-input{width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;font-family:var(--font-mono);outline:none;resize:none;transition:border-color .2s;line-height:1.5;box-sizing:border-box}
.bio-input:focus{border-color:rgba(0,255,135,.4)}
.bio-chars{font-size:11px;font-family:var(--font-mono);color:var(--muted);text-align:right;margin-top:4px}
.save-btn{padding:9px 22px;border-radius:9px;font-size:12px;font-weight:700;cursor:pointer;border:none;background:var(--green);color:#080b12;margin-top:12px;transition:filter .2s}
.save-btn:hover{filter:brightness(1.1)}
.danger-btn{padding:9px 22px;border-radius:9px;font-size:12px;font-weight:700;cursor:pointer;border:1px solid rgba(255,45,111,.3);background:rgba(255,45,111,.08);color:var(--pink);margin-top:12px;transition:filter .2s}
.danger-btn:hover{filter:brightness(1.2)}

/* ── Upload drop zone ──────────────────────────────────── */
.upload-zone{border:2px dashed var(--border);border-radius:14px;padding:28px;text-align:center;cursor:pointer;transition:border-color .2s,background .2s;margin-bottom:12px}
.upload-zone:hover,.upload-zone.drag{border-color:var(--green);background:rgba(0,255,135,.04)}
.upload-zone .uz-icon{font-size:36px;margin-bottom:8px}
.upload-zone p{font-family:var(--font-mono);font-size:12px;color:var(--muted);line-height:1.6}
.upload-zone strong{color:var(--green)}

/* ── Posts grid ─────────────────────────────────────────── */
.posts-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px;margin-top:4px}
.post-card{background:var(--bg2);border:1px solid var(--border);border-radius:14px;overflow:hidden;transition:border-color .2s}
.post-card:hover{border-color:rgba(0,255,135,.3)}
.post-preview{height:130px;background:var(--bg3);overflow:hidden;position:relative;cursor:pointer}
.post-preview iframe{width:100%;height:100%;border:none;pointer-events:none;transform-origin:top left}
.post-card-body{padding:12px 14px}
.post-card-title{font-size:13px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.post-card-meta{font-size:11px;font-family:var(--font-mono);color:var(--muted);margin-top:4px;display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.vs-badge{font-size:10px;padding:2px 7px;border-radius:5px;font-weight:700;letter-spacing:.5px}
.vs-badge.on{background:rgba(0,255,135,.12);color:var(--green);border:1px solid rgba(0,255,135,.3)}
.vs-badge.off{background:var(--bg3);color:var(--muted);border:1px solid var(--border)}
.like-btn{display:inline-flex;align-items:center;gap:4px;font-size:11px;font-family:var(--font-mono);padding:4px 10px;border-radius:6px;cursor:pointer;border:1px solid var(--border);background:var(--bg3);color:var(--muted);transition:all .15s}
.like-btn:hover,.like-btn.liked{background:rgba(255,45,111,.1);border-color:rgba(255,45,111,.3);color:var(--pink)}
.post-card-actions{display:flex;gap:8px;padding:0 14px 12px}
.pc-btn{flex:1;padding:7px 0;border-radius:8px;font-size:11px;font-weight:700;cursor:pointer;border:none;font-family:var(--font-mono);transition:filter .2s}
.pc-btn.edit{background:rgba(0,180,255,.12);color:var(--blue);border:1px solid rgba(0,180,255,.25)}
.pc-btn.edit:hover{filter:brightness(1.2)}
.pc-btn.del{background:rgba(255,45,111,.08);color:var(--pink);border:1px solid rgba(255,45,111,.2)}
.pc-btn.del:hover{filter:brightness(1.2)}
.pc-btn.view{background:rgba(0,255,135,.08);color:var(--green);border:1px solid rgba(0,255,135,.2)}
.pc-btn.view:hover{filter:brightness(1.2)}

/* ── Battles ─────────────────────────────────────────────── */
.battle-list{display:flex;flex-direction:column;gap:10px}
.battle-row{background:var(--bg2);border:1px solid var(--border);border-radius:12px;padding:14px 18px;display:flex;align-items:center;justify-content:space-between;gap:14px;transition:background .15s}
.battle-row:hover{background:var(--bg3)}
.battle-result{padding:4px 12px;border-radius:6px;font-size:11px;font-weight:700;font-family:var(--font-mono);letter-spacing:1px}
.win{background:rgba(0,255,135,0.1);color:var(--green);border:1px solid rgba(0,255,135,0.25)}
.loss{background:rgba(255,45,111,0.1);color:var(--pink);border:1px solid rgba(255,45,111,0.25)}

/* ── Followers modal ────────────────────────────────────── */
.follow-modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:900;display:none;align-items:center;justify-content:center;padding:20px}
.follow-modal-overlay.open{display:flex}
.follow-modal{background:var(--bg2);border:1px solid var(--border);border-radius:18px;width:100%;max-width:420px;max-height:80vh;display:flex;flex-direction:column}
.follow-modal-head{padding:20px 24px 16px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}
.follow-modal-head h3{font-size:15px;font-weight:800;margin:0}
.follow-modal-close{background:none;border:none;color:var(--muted);font-size:20px;cursor:pointer;padding:0;line-height:1}
.follow-modal-close:hover{color:var(--text)}
.follow-modal-tabs{display:flex;border-bottom:1px solid var(--border)}
.fmtab{flex:1;padding:10px;text-align:center;font-size:12px;font-family:var(--font-mono);font-weight:700;letter-spacing:1px;color:var(--muted);cursor:pointer;border:none;background:none;border-bottom:2px solid transparent;transition:all .15s}
.fmtab.active{color:var(--green);border-bottom-color:var(--green)}
.follow-list{overflow-y:auto;flex:1;padding:8px 0}
.follow-item{display:flex;align-items:center;gap:12px;padding:10px 24px;transition:background .15s}
.follow-item:hover{background:var(--bg3)}
.follow-avatar{width:38px;height:38px;border-radius:50%;border:2px solid var(--border);display:flex;align-items:center;justify-content:center;font-size:18px;background:var(--bg3);overflow:hidden;flex-shrink:0}
.follow-avatar img{width:100%;height:100%;object-fit:cover}
.follow-name{font-weight:700;font-size:13px}
.follow-since{font-size:11px;font-family:var(--font-mono);color:var(--muted);margin-top:1px}
.follow-empty{text-align:center;padding:32px;font-family:var(--font-mono);font-size:12px;color:var(--muted)}

/* ── Edit Post Modal ──────────────────────────────────────── */
.ep-overlay{position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:900;display:none;align-items:center;justify-content:center;padding:20px}
.ep-overlay.open{display:flex}
.ep-modal{background:var(--bg2);border:1px solid var(--border);border-radius:18px;width:100%;max-width:600px;max-height:90vh;overflow-y:auto;padding:28px}
.ep-modal h3{font-size:17px;font-weight:800;margin-bottom:20px}
.ep-field{margin-bottom:14px}
.ep-field label{font-size:11px;font-family:var(--font-mono);color:var(--muted);letter-spacing:1.5px;text-transform:uppercase;display:block;margin-bottom:6px}
.ep-field input,.ep-field textarea{width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:13px;font-family:var(--font-mono);outline:none;resize:vertical;transition:border-color .2s;box-sizing:border-box}
.ep-field input:focus,.ep-field textarea:focus{border-color:rgba(0,255,135,.4)}
.ep-actions{display:flex;gap:10px;margin-top:18px}
.ep-save{flex:1;padding:11px;border-radius:10px;font-size:13px;font-weight:700;cursor:pointer;border:none;background:var(--green);color:#080b12;transition:filter .2s}
.ep-save:hover{filter:brightness(1.1)}
.ep-cancel{padding:11px 20px;border-radius:10px;font-size:13px;font-weight:700;cursor:pointer;border:1px solid var(--border);background:var(--bg3);color:var(--muted)}
.ep-err{font-size:12px;font-family:var(--font-mono);color:var(--pink);margin-top:8px;display:none}

/* ── Alert ───────────────────────────────────────────────── */
.alert{padding:12px 16px;border-radius:10px;font-size:13px;font-family:var(--font-mono);margin-bottom:20px}
.alert-success{background:rgba(0,255,135,0.08);border:1px solid rgba(0,255,135,0.3);color:var(--green)}
.alert-error{background:rgba(255,45,111,0.1);border:1px solid rgba(255,45,111,0.3);color:var(--pink)}

.sec-label{font-size:11px;font-family:var(--font-mono);color:var(--muted);letter-spacing:2px;text-transform:uppercase;margin-bottom:14px;margin-top:4px}
</style>

<div class="profile-wrap">

<?php if ($success): ?>
  <div class="alert alert-success">✓ <?= e($success) ?></div>
<?php endif; ?>
<?php foreach ($errors as $err): ?>
  <div class="alert alert-error">✗ <?= e($err) ?></div>
<?php endforeach; ?>

<!-- Profile hero -->
<div class="profile-hero">
  <div class="avatar-block">
    <div class="avatar-ring" onclick="document.getElementById('avatarFileInput').click()">
      <?php if (!empty($me['avatar_img'])): ?>
        <img src="<?= e($me['avatar_img']) ?>" alt="avatar">
      <?php else: ?>
        <?= e($me['avatar'] ?: '👾') ?>
      <?php endif; ?>
      <div class="avatar-overlay"><span>📷<br>Change<br>Photo</span></div>
    </div>
    <div class="avatar-edit-btn" onclick="document.getElementById('avatarFileInput').click()">✏️</div>
  </div>

  <div class="profile-info">
    <div class="profile-name"><?= e($me['username']) ?></div>
    <div class="profile-bio"><?= $me['bio'] ? e($me['bio']) : '<span style="opacity:.4">No bio yet.</span>' ?></div>
    <div class="profile-rank-badge">🏆 Rank #<?= $rank ?> &nbsp;·&nbsp; Joined <?= date('M Y', strtotime($me['created_at'])) ?></div>
    <div class="stat-row">
      <div class="mini-stat"><div class="v"><?= $me['wins'] ?></div><div class="l">Wins</div></div>
      <div class="mini-stat"><div class="v" style="color:var(--pink)"><?= $me['losses'] ?></div><div class="l">Losses</div></div>
      <div class="mini-stat"><div class="v" style="color:var(--blue)"><?= number_format($me['total_score']) ?></div><div class="l">Score</div></div>
      <div class="mini-stat">
        <div class="v"><?= $me['wins']+$me['losses']>0 ? round($me['wins']/($me['wins']+$me['losses'])*100) : 0 ?>%</div>
        <div class="l">Win Rate</div>
      </div>
      <!-- Followers / Following -->
      <div class="mini-stat clickable" onclick="openFollowModal('followers')" title="View followers">
        <div class="v" id="followerCount"><?= $followerCount ?></div>
        <div class="l">Followers</div>
      </div>
      <div class="mini-stat clickable" onclick="openFollowModal('following')" title="View following">
        <div class="v" id="followingCount"><?= $followingCount ?></div>
        <div class="l">Following</div>
      </div>
    </div>
  </div>
</div>

<!-- Upload avatar form (hidden file input) -->
<form method="POST" enctype="multipart/form-data" id="avatarForm">
  <input type="hidden" name="action" value="upload_avatar">
  <input type="file" id="avatarFileInput" name="avatar_file" accept="image/*" style="display:none">
</form>

<!-- Tabs -->
<div class="tabs">
  <button class="tab-btn active" onclick="switchTab('showcase',this)">🖼 Showcase</button>
  <button class="tab-btn" onclick="switchTab('battles',this)">⚔️ Battles</button>
  <button class="tab-btn" onclick="switchTab('editprofile',this)">✏️ Edit Profile</button>
</div>

<!-- TAB: Showcase Posts -->
<div class="tab-pane active" id="tab-showcase">
  <div class="sec-label">My Showcase Posts</div>
  <?php if (!$myPosts): ?>
    <p style="color:var(--muted);font-family:var(--font-mono)">No posts yet. <a href="showcase.php" style="color:var(--green)">Share something!</a></p>
  <?php else: ?>
    <div class="posts-grid">
      <?php foreach ($myPosts as $p): ?>
      <div class="post-card" id="pcard-<?= $p['id'] ?>">
        <div class="post-preview" onclick="window.open('showcase.php?id=<?= $p['id'] ?>','_blank')">
          <iframe srcdoc="<?= htmlspecialchars('<style>'.$p['css_code'].'</style>'.$p['html_code'], ENT_QUOTES) ?>"
                  sandbox="allow-scripts" scrolling="no"></iframe>
        </div>
        <div class="post-card-body">
          <div class="post-card-title" title="<?= e($p['title']) ?>"><?= e($p['title']) ?></div>
          <div class="post-card-meta">
            <span>👁 <?= $p['views'] ?></span>
            <span>❤️ <?= $p['reaction_count'] ?></span>
            <span>💬 <?= $p['comment_count'] ?></span>
            <!-- Like button -->
            <button class="like-btn" id="like-btn-<?= $p['id'] ?>" onclick="toggleLike(<?= $p['id'] ?>, this)">
              🤍 <span id="like-count-<?= $p['id'] ?>"><?= $p['like_count'] ?></span>
            </button>
            <span class="vs-badge <?= $p['allow_versus'] ? 'on' : 'off' ?>">
              <?= $p['allow_versus'] ? '⚔ VS ON' : 'VS OFF' ?>
            </span>
          </div>
        </div>
        <div class="post-card-actions">
          <button class="pc-btn view" onclick="window.open('showcase.php?id=<?= $p['id'] ?>','_blank')">👁 View</button>
          <button class="pc-btn edit" onclick="openEditModal(<?= $p['id'] ?>,<?= htmlspecialchars(json_encode($p), ENT_QUOTES) ?>)">✏️ Edit</button>
          <button class="pc-btn del" onclick="deletePost(<?= $p['id'] ?>)">🗑 Del</button>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<!-- TAB: Recent Battles -->
<div class="tab-pane" id="tab-battles">
  <div class="sec-label">Recent Battles</div>
  <?php if (!$myBattles): ?>
    <p style="color:var(--muted);font-family:var(--font-mono)">No battles yet. <a href="versus.php" style="color:var(--green)">Start one!</a></p>
  <?php else: ?>
    <div class="battle-list">
      <?php foreach ($myBattles as $b): ?>
        <?php
          $iWon = $b['winner_id'] == $me['id'];
          $opp  = $b['host_id'] == $me['id'] ? $b['guest_name'] : $b['host_name'];
        ?>
        <div class="battle-row">
          <div>
            <span style="font-weight:700">vs <?= e($opp ?? 'Unknown') ?></span>
            <div style="font-size:11px;color:var(--muted);font-family:var(--font-mono);margin-top:3px">
              <?= $b['finished_at'] ? date('M j, g:i a', strtotime($b['finished_at'])) : 'In progress' ?>
            </div>
          </div>
          <span class="battle-result <?= $iWon ? 'win' : 'loss' ?>"><?= $iWon ? '✓ WIN' : '✗ LOSS' ?></span>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<!-- TAB: Edit Profile -->
<div class="tab-pane" id="tab-editprofile">
  <!-- Profile picture section -->
  <div class="edit-section">
    <h3>📷 Profile Picture</h3>
    <div class="upload-zone" id="uploadZone" onclick="document.getElementById('avatarFileInput').click()">
      <div class="uz-icon">🖼️</div>
      <p>Click or drag &amp; drop an image<br><strong>JPG, PNG, GIF, WEBP</strong> · Max 2MB</p>
    </div>
    <?php if (!empty($me['avatar_img'])): ?>
      <form method="POST" style="display:inline">
        <input type="hidden" name="action" value="remove_avatar">
        <button type="submit" class="danger-btn">🗑 Remove Photo</button>
      </form>
    <?php endif; ?>
  </div>

  <!-- Emoji + bio section -->
  <div class="edit-section">
    <h3>✏️ Customize Profile</h3>
    <form method="POST">
      <input type="hidden" name="action" value="update_profile">
      <input type="hidden" name="avatar" id="selectedEmoji" value="<?= e($me['avatar']) ?>">

      <label style="font-size:11px;font-family:var(--font-mono);color:var(--muted);letter-spacing:1.5px;text-transform:uppercase;display:block;margin-bottom:10px">Emoji Avatar (shown as fallback)</label>
      <div class="emoji-grid">
        <?php foreach ($emojiOptions as $em): ?>
          <div class="emoji-opt <?= $me['avatar']===$em?'selected':'' ?>"
               onclick="selectEmoji('<?= $em ?>')">
            <?= $em ?>
          </div>
        <?php endforeach; ?>
      </div>

      <label style="font-size:11px;font-family:var(--font-mono);color:var(--muted);letter-spacing:1.5px;text-transform:uppercase;display:block;margin-bottom:8px;margin-top:16px">Bio <span style="opacity:.5">(160 chars)</span></label>
      <textarea class="bio-input" name="bio" rows="2" maxlength="160"
                oninput="document.getElementById('bioChars').textContent=this.value.length"
                placeholder="Write something about yourself..."><?= e($me['bio'] ?? '') ?></textarea>
      <div class="bio-chars"><span id="bioChars"><?= strlen($me['bio'] ?? '') ?></span>/160</div>

      <button type="submit" class="save-btn">💾 Save Profile</button>
    </form>
  </div>
</div>

</div><!-- /.profile-wrap -->

<!-- ── Followers / Following Modal ─────────────────────── -->
<div class="follow-modal-overlay" id="followModalOverlay" onclick="closeFollowModal(event)">
  <div class="follow-modal">
    <div class="follow-modal-head">
      <h3 id="followModalTitle">Followers</h3>
      <button class="follow-modal-close" onclick="closeFollowModalDirect()">✕</button>
    </div>
    <div class="follow-modal-tabs">
      <button class="fmtab active" id="fmtab-followers" onclick="switchFollowTab('followers')">
        Followers <span id="fm-fc"><?= $followerCount ?></span>
      </button>
      <button class="fmtab" id="fmtab-following" onclick="switchFollowTab('following')">
        Following <span id="fm-fg"><?= $followingCount ?></span>
      </button>
    </div>
    <div class="follow-list" id="followList"></div>
  </div>
</div>

<!-- ── Edit Post Modal ─────────────────────────────────── -->
<div class="ep-overlay" id="epOverlay">
  <div class="ep-modal">
    <h3>✏️ Edit Post</h3>
    <input type="hidden" id="epPostId">
    <div class="ep-field"><label>Title</label><input type="text" id="epTitle" maxlength="120" placeholder="Post title"></div>
    <div class="ep-field"><label>Description</label><textarea id="epDesc" rows="2" placeholder="Short description (optional)"></textarea></div>
    <div class="ep-field"><label>HTML</label><textarea id="epHtml" rows="5" style="font-size:12px" placeholder="HTML code"></textarea></div>
    <div class="ep-field"><label>CSS</label><textarea id="epCss" rows="5" style="font-size:12px" placeholder="CSS code"></textarea></div>
    <div class="ep-field"><label>JS <span style="opacity:.5">(optional)</span></label><textarea id="epJs" rows="3" style="font-size:12px" placeholder="JS code"></textarea></div>
    <div class="ep-err" id="epErr"></div>
    <div class="ep-actions">
      <button class="ep-cancel" onclick="closeEditModal()">Cancel</button>
      <button class="ep-save" id="epSaveBtn" onclick="savePost()">💾 Save Changes</button>
    </div>
  </div>
</div>
<script src="assets/security.js"></script>
<script>
const MY_ID = <?= (int)$me['id'] ?>;

// ── Tab switching ───────────────────────────────────────────────────────
function switchTab(name, btn) {
  document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.getElementById('tab-' + name).classList.add('active');
  btn.classList.add('active');
}

// ── Emoji picker ────────────────────────────────────────────────────────
function selectEmoji(em) {
  document.querySelectorAll('.emoji-opt').forEach(el => el.classList.remove('selected'));
  event.currentTarget.classList.add('selected');
  document.getElementById('selectedEmoji').value = em;
}

// ── Auto-submit on file select ──────────────────────────────────────────
document.getElementById('avatarFileInput').addEventListener('change', function() {
  if (this.files.length) document.getElementById('avatarForm').submit();
});

// ── Drag & drop ─────────────────────────────────────────────────────────
const zone = document.getElementById('uploadZone');
if (zone) {
  zone.addEventListener('dragover', e => { e.preventDefault(); zone.classList.add('drag'); });
  zone.addEventListener('dragleave', () => zone.classList.remove('drag'));
  zone.addEventListener('drop', e => {
    e.preventDefault(); zone.classList.remove('drag');
    const file = e.dataTransfer.files[0]; if (!file) return;
    const dt = new DataTransfer(); dt.items.add(file);
    document.getElementById('avatarFileInput').files = dt.files;
    document.getElementById('avatarForm').submit();
  });
}

// ── Like toggle ─────────────────────────────────────────────────────────
async function toggleLike(postId, btn) {
  btn.disabled = true;
  try {
    const fd = new FormData();
    fd.append('action', 'toggle_like');
    fd.append('post_id', postId);
    const res  = await fetch('showcase.php', { method: 'POST', body: fd });
    const data = await res.json();
    if (data.ok) {
      // ── FIXED: single clean DOM update — no more duplicate writes causing flicker
      btn.innerHTML = (data.liked ? '❤️ ' : '🤍 ') + '<span id="like-count-' + postId + '">' + data.like_count + '</span>';
      if (data.liked) btn.classList.add('liked');
      else btn.classList.remove('liked');
    }
  } catch(e) { showToast && showToast('Error updating like'); }
  btn.disabled = false;
}

// ── Followers / Following modal (pre-loaded, no fetch) ──────────────────
const _profileFollowData = {
  followers: <?= json_encode(array_values($profileFollowersList)) ?>,
  following:  <?= json_encode(array_values($profileFollowingList)) ?>
};
let currentFollowTab = 'followers';

function openFollowModal(tab) {
  currentFollowTab = tab;
  document.getElementById('followModalOverlay').classList.add('open');
  document.getElementById('fmtab-followers').classList.toggle('active', tab === 'followers');
  document.getElementById('fmtab-following').classList.toggle('active', tab === 'following');
  document.getElementById('followModalTitle').textContent = tab === 'followers' ? 'Followers' : 'Following';
  renderFollowList(tab);
}
function closeFollowModal(e) {
  if (e.target === document.getElementById('followModalOverlay')) {
    document.getElementById('followModalOverlay').classList.remove('open');
  }
}
function closeFollowModalDirect() {
  document.getElementById('followModalOverlay').classList.remove('open');
}
function switchFollowTab(tab) {
  currentFollowTab = tab;
  document.getElementById('fmtab-followers').classList.toggle('active', tab === 'followers');
  document.getElementById('fmtab-following').classList.toggle('active', tab === 'following');
  document.getElementById('followModalTitle').textContent = tab === 'followers' ? 'Followers' : 'Following';
  renderFollowList(tab);
}
function renderFollowList(tab) {
  const list  = document.getElementById('followList');
  const users = _profileFollowData[tab] || [];
  if (!users.length) {
    list.innerHTML = '<div class="follow-empty">' + (tab === 'followers' ? 'No followers yet.' : 'Not following anyone yet.') + '</div>';
    return;
  }
  list.innerHTML = users.map(u => `
    <a class="follow-item" href="showcase.php?user=${u.id}" style="text-decoration:none;color:inherit;display:flex;align-items:center;gap:12px;padding:10px 24px;transition:background .15s">
      <div class="follow-avatar">
        ${u.avatar_img ? `<img src="${escHtml(u.avatar_img)}" alt="">` : escHtml(u.avatar || '👾')}
      </div>
      <div>
        <div class="follow-name">${escHtml(u.username)}</div>
        <div class="follow-since">Since ${escHtml(u.since)}</div>
      </div>
    </a>
  `).join('');
}

function escHtml(str) {
  const d = document.createElement('div'); d.textContent = str; return d.innerHTML;
}

// ── Edit Post Modal ──────────────────────────────────────────────────────
function openEditModal(id, post) {
  document.getElementById('epPostId').value = id;
  document.getElementById('epTitle').value  = post.title || '';
  document.getElementById('epDesc').value   = post.description || '';
  document.getElementById('epHtml').value   = post.html_code || '';
  document.getElementById('epCss').value    = post.css_code  || '';
  document.getElementById('epJs').value     = post.js_code   || '';
  document.getElementById('epErr').style.display = 'none';
  document.getElementById('epOverlay').classList.add('open');
}
function closeEditModal() { document.getElementById('epOverlay').classList.remove('open'); }
document.getElementById('epOverlay').addEventListener('click', function(e) { if (e.target === this) closeEditModal(); });

async function savePost() {
  const btn = document.getElementById('epSaveBtn');
  const err = document.getElementById('epErr');
  btn.disabled = true; btn.textContent = 'Saving…'; err.style.display = 'none';
  const fd = new FormData();
  fd.append('action',      'edit_post');
  fd.append('post_id',     document.getElementById('epPostId').value);
  fd.append('title',       document.getElementById('epTitle').value);
  fd.append('description', document.getElementById('epDesc').value);
  fd.append('html_code',   document.getElementById('epHtml').value);
  fd.append('css_code',    document.getElementById('epCss').value);
  fd.append('js_code',     document.getElementById('epJs').value);
  try {
    const res  = await fetch('showcase.php', { method:'POST', body:fd });
    const data = await res.json();
    if (data.ok) {
      closeEditModal();
      const pid = document.getElementById('epPostId').value;
      const card = document.getElementById('pcard-' + pid);
      if (card) {
        const iframe = card.querySelector('iframe');
        if (iframe) iframe.srcdoc = '<style>' + document.getElementById('epCss').value + '</style>' + document.getElementById('epHtml').value;
        const t = card.querySelector('.post-card-title');
        if (t) t.textContent = document.getElementById('epTitle').value;
      }
    } else { err.textContent = data.msg || 'Save failed'; err.style.display = 'block'; }
  } catch(e) { err.textContent = 'Network error'; err.style.display = 'block'; }
  btn.disabled = false; btn.textContent = '💾 Save Changes';
}

async function deletePost(id) {
  if (!confirm('Delete this post? This cannot be undone.')) return;
  const fd = new FormData(); fd.append('action','delete_post'); fd.append('post_id', id);
  try {
    const res  = await fetch('showcase.php', { method:'POST', body:fd });
    const data = await res.json();
    if (data.ok) { const c = document.getElementById('pcard-' + id); if (c) c.remove(); }
    else alert(data.msg || 'Delete failed');
  } catch(e) { alert('Network error'); }
}
</script>

<?php
pageFooter();
?>
