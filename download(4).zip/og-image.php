<?php
// ── og-image.php ─────────────────────────────────────────────────────
// Generates a 1200×630 Open Graph social card image for a showcase post.
// Usage: og-image.php?id=42
// Returns: image/png
//
// Designed for shared hosts (InfinityFree etc.) — uses GD only.
// Falls back to a plain colored card if the font files aren't available.

require_once __DIR__ . '/includes/config.php';

// ── Helpers ──────────────────────────────────────────────────────────
function truncate(string $s, int $max): string {
  return mb_strlen($s) > $max ? mb_substr($s, 0, $max - 1) . '…' : $s;
}

// ── Fetch post ────────────────────────────────────────────────────────
$postId = (int)($_GET['id'] ?? 0);
$post   = null;

if ($postId) {
  $stmt = db()->prepare(
    'SELECT p.title, p.description, p.html_code, p.css_code,
            u.username, u.avatar, u.avatar_img
     FROM showcase_posts p
     JOIN users u ON u.id = p.user_id
     WHERE p.id = ?'
  );
  $stmt->execute([$postId]);
  $post = $stmt->fetch();
}

// ── Cache headers ─────────────────────────────────────────────────────
header('Content-Type: image/png');
header('Cache-Control: public, max-age=86400'); // 24h cache

// ── Canvas size ───────────────────────────────────────────────────────
$W = 1200;
$H = 630;

$im = imagecreatetruecolor($W, $H);
imagesavealpha($im, true);

// ── Colour palette ────────────────────────────────────────────────────
// Matches the codeMe dark theme
function hex(resource|GdImage $im, string $hex): int {
  $hex = ltrim($hex, '#');
  return imagecolorallocate($im,
    hexdec(substr($hex,0,2)),
    hexdec(substr($hex,2,2)),
    hexdec(substr($hex,4,2))
  );
}

$cBg       = hex($im, '080b12');  // --bg
$cBg2      = hex($im, '0e1320');  // --bg2
$cBg3      = hex($im, '141b2d');  // --bg3
$cBorder   = imagecolorallocatealpha($im, 255,255,255, 110); // rgba(255,255,255,.07)
$cGreen    = hex($im, '00ff87');  // --green
$cBlue     = hex($im, '00c8ff');  // --blue
$cPink     = hex($im, 'ff2d6f');  // --pink
$cText     = hex($im, 'e8eaf0');  // --text
$cMuted    = hex($im, '5a6380');  // --muted
$cWhite    = hex($im, 'ffffff');
$cBlack    = hex($im, '000000');

// ── Background gradient (faked with horizontal bands) ─────────────────
imagefill($im, 0, 0, $cBg);

// subtle top-left radial glow (green)
for ($r = 340; $r > 0; $r -= 4) {
  $alpha = (int)(127 - ($r / 340) * 127 * 0.18); // very faint
  $c = imagecolorallocatealpha($im, 0, 255, 135, max(110, 127 - (int)(($r/340)*17)));
  imagearc($im, -30, -30, $r*2, $r*2, 0, 360, $c);
}

// subtle bottom-right glow (blue)
for ($r = 280; $r > 0; $r -= 4) {
  $c = imagecolorallocatealpha($im, 0, 200, 255, max(114, 127 - (int)(($r/280)*13)));
  imagearc($im, $W+30, $H+30, $r*2, $r*2, 0, 360, $c);
}

// ── Card panel ────────────────────────────────────────────────────────
$padX = 56; $padY = 56;
$cardX = $padX; $cardY = $padY;
$cardW = $W - $padX*2; $cardH = $H - $padY*2;
$r     = 24; // corner radius

// Draw rounded rectangle (fill)
imagefilledrectangle($im, $cardX+$r, $cardY, $cardX+$cardW-$r, $cardY+$cardH, $cBg2);
imagefilledrectangle($im, $cardX, $cardY+$r, $cardX+$cardW, $cardY+$cardH-$r, $cBg2);
imagefilledellipse($im, $cardX+$r,       $cardY+$r,       $r*2, $r*2, $cBg2);
imagefilledellipse($im, $cardX+$cardW-$r,$cardY+$r,       $r*2, $r*2, $cBg2);
imagefilledellipse($im, $cardX+$r,       $cardY+$cardH-$r,$r*2, $r*2, $cBg2);
imagefilledellipse($im, $cardX+$cardW-$r,$cardY+$cardH-$r,$r*2, $r*2, $cBg2);

// ── Left accent bar ───────────────────────────────────────────────────
$barX = $cardX + 40;
$barY = $cardY + 50;
$barH = $cardH - 100;
$barW = 5;
imagefilledrectangle($im, $barX, $barY, $barX+$barW, $barY+$barH, $cGreen);
// glow effect
for ($g = 1; $g <= 8; $g++) {
  $gc = imagecolorallocatealpha($im, 0, 255, 135, 127 - (int)(($g/8)*80));
  imagefilledrectangle($im, $barX-$g, $barY, $barX+$barW+$g, $barY+$barH, $gc);
}

// ── Content area ─────────────────────────────────────────────────────
$cx = $cardX + 80;  // left padding inside card (after bar)
$cy = $cardY + 68;  // top padding
$cw = $cardW - 160; // available width

// ── Site badge (top-left) ─────────────────────────────────────────────
$badge   = 'codeMe Versus';
$bFont   = 3; // built-in GD font
$bW      = imagefontwidth($bFont)  * strlen($badge);
$bH      = imagefontheight($bFont);
$bPadX   = 14; $bPadY = 7;
$bX      = $cx; $bY = $cy;
// pill background
imagefilledrectangle($im, $bX, $bY, $bX+$bW+$bPadX*2, $bY+$bH+$bPadY*2,
  imagecolorallocatealpha($im, 0,255,135, 110));
imagestring($im, $bFont, $bX+$bPadX, $bY+$bPadY, $badge, $cGreen);

// ── Title ─────────────────────────────────────────────────────────────
$titleText = $post ? $post['title'] : 'Code Showcase';
$titleText = truncate($titleText, 52);

// Use biggest built-in font (5) for title — draw twice for "bold" effect
$titleFont = 5;
$titleFW   = imagefontwidth($titleFont);
$titleFH   = imagefontheight($titleFont);

// Wrap title at ~48 chars
$words    = explode(' ', $titleText);
$lines    = [];
$line     = '';
foreach ($words as $w) {
  if (mb_strlen($line . ' ' . $w) * $titleFW > $cw) {
    $lines[] = trim($line); $line = $w;
  } else {
    $line = trim($line . ' ' . $w);
  }
}
if ($line) $lines[] = trim($line);

$titleY = $bY + $bH + $bPadY*2 + 28;
foreach ($lines as $i => $l) {
  // "bold" by drawing twice offset by 1px
  imagestring($im, $titleFont, $cx+1, $titleY+1 + $i*($titleFH+8), $l, $cBg2);
  imagestring($im, $titleFont, $cx,   $titleY   + $i*($titleFH+8), $l, $cWhite);
}

// ── Description ───────────────────────────────────────────────────────
$desc     = $post['description'] ?? '';
if (!$desc && $post) $desc = 'A creative CSS/HTML showcase posted on codeMe Versus';
$desc     = truncate($desc, 120);
$descFont = 2;
$descFW   = imagefontwidth($descFont);
$descFH   = imagefontheight($descFont);
$descY    = $titleY + count($lines) * ($titleFH + 8) + 22;

// Word-wrap description
$dWords = explode(' ', $desc);
$dLines = [];
$dLine  = '';
foreach ($dWords as $w) {
  if (mb_strlen($dLine . ' ' . $w) * $descFW > $cw) {
    $dLines[] = trim($dLine); $dLine = $w;
  } else {
    $dLine = trim($dLine . ' ' . $w);
  }
}
if ($dLine) $dLines[] = trim($dLine);
$dLines = array_slice($dLines, 0, 3); // max 3 lines

foreach ($dLines as $i => $l) {
  imagestring($im, $descFont, $cx, $descY + $i*($descFH+6), $l, $cMuted);
}

// ── Code preview snippet ──────────────────────────────────────────────
// Show a few lines of HTML code in a styled box on the right
$previewX  = $cx + (int)($cw * 0.52);
$previewY  = $titleY - 10;
$previewW  = (int)($cw * 0.45);
$previewH  = $cardH - 130;

// Code box background
$codeBoxBg = imagecolorallocatealpha($im, 20, 27, 45, 20);
imagefilledrectangle($im, $previewX, $previewY,
  $previewX+$previewW, $previewY+$previewH, $codeBoxBg);

// Code box top bar
$topBarH = 28;
imagefilledrectangle($im, $previewX, $previewY,
  $previewX+$previewW, $previewY+$topBarH,
  imagecolorallocatealpha($im, 255,255,255, 120));

// Traffic-light dots
$dots = [[$cPink,14], [hex($im,'ffb400'),28], [$cGreen,42]];
foreach ($dots as [$dc, $dx]) {
  imagefilledellipse($im, $previewX+$dx, $previewY+$topBarH/2, 10, 10, $dc);
}
// "HTML" label in bar
imagestring($im, 1, $previewX+58, $previewY+9, 'index.html', $cMuted);

// Code lines
$codeFont = 1;
$codeFH   = imagefontheight($codeFont)+3;
$codeX    = $previewX + 12;
$codeY    = $previewY + $topBarH + 10;
$maxLines = (int)(($previewH - $topBarH - 20) / $codeFH);
$rawCode  = $post['html_code'] ?? '<div class="box">Hello World</div>';
$codeLines= array_slice(explode("\n", $rawCode), 0, $maxLines);

$syntaxColors = [$cBlue, $cGreen, $cPink, $cText, $cMuted];
foreach ($codeLines as $li => $cl) {
  if ($codeY + $li*$codeFH > $previewY+$previewH-10) break;
  $cl    = rtrim($cl);
  $color = $syntaxColors[($li % count($syntaxColors))];
  if (strpos($cl, '<') !== false) $color = $cBlue;
  elseif (strpos($cl, '{') !== false || strpos($cl, '}') !== false) $color = $cPink;
  elseif (strpos($cl, '//') !== false || strpos($cl, '/*') !== false) $color = $cMuted;
  elseif (strpos($cl, ':') !== false) $color = $cGreen;
  imagestring($im, $codeFont, $codeX, $codeY + $li*$codeFH,
    truncate(ltrim($cl), (int)($previewW / imagefontwidth($codeFont)) - 2),
    $color);
}

// ── Author row (bottom) ────────────────────────────────────────────────
$authorY = $cardY + $cardH - 60;
$sepY    = $authorY - 14;
// separator line
imageline($im, $cx, $sepY, $cx+$cw, $sepY,
  imagecolorallocatealpha($im, 255,255,255, 120));

// avatar emoji/text
$avatar   = $post ? ($post['avatar'] ?? '👤') : '🌐';
$username = $post ? $post['username'] : 'codeMe';

imagestring($im, 3, $cx, $authorY+6, $avatar . '  ' . $username, $cText);

// ── "Showcase" label (bottom right) ───────────────────────────────────
$tagText = '✦ codeMe Showcase';
$tagFont = 2;
$tagW    = imagefontwidth($tagFont) * strlen($tagText);
imagestring($im, $tagFont, $cardX+$cardW-$tagW-40, $authorY+8, $tagText, $cMuted);

// ── Output ────────────────────────────────────────────────────────────
imagepng($im);
imagedestroy($im);
