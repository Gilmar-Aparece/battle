<?php
require_once 'includes/config.php';
require_once 'includes/layout.php';

$user = auth();

// ── Auto-migration: live_sessions table ─────────────────────────────────────
try {
  db()->exec("CREATE TABLE IF NOT EXISTS `live_sessions` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `battle_id` INT DEFAULT NULL,
    `title` VARCHAR(200) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `status` ENUM('waiting','live','ended') NOT NULL DEFAULT 'waiting',
    `viewer_count` INT NOT NULL DEFAULT 0,
    `started_at` DATETIME DEFAULT NULL,
    `ended_at` DATETIME DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_status` (`status`),
    KEY `idx_user` (`user_id`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Exception $e) {}

try {
  db()->exec("CREATE TABLE IF NOT EXISTS `live_comments` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `session_id` INT NOT NULL,
    `user_id` INT NOT NULL,
    `body` VARCHAR(300) NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_session` (`session_id`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Exception $e) {}

// ── Handle AJAX ──────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
  requireLogin();
  header('Content-Type: application/json');
  $action = $_POST['action'];

  // Start a live session
  if ($action === 'start_live') {
    $title = trim($_POST['title'] ?? '');
    $desc  = trim($_POST['description'] ?? '');
    if (!$title) { echo json_encode(['ok'=>false,'msg'=>'Title is required']); exit; }
    // End any existing live sessions by this user
    db()->prepare("UPDATE live_sessions SET status='ended', ended_at=NOW() WHERE user_id=? AND status IN ('waiting','live')")
       ->execute([$user['id']]);
    $stmt = db()->prepare("INSERT INTO live_sessions (user_id, title, description, status, started_at) VALUES (?,?,?,'live',NOW())");
    $stmt->execute([$user['id'], $title, $desc ?: null]);
    $sid = db()->lastInsertId();
    echo json_encode(['ok'=>true,'session_id'=>$sid]);
    exit;
  }

  // End a live session
  if ($action === 'end_live') {
    $sid = (int)($_POST['session_id'] ?? 0);
    $chk = db()->prepare("SELECT user_id FROM live_sessions WHERE id=?");
    $chk->execute([$sid]);
    $row = $chk->fetch();
    if (!$row || (int)$row['user_id'] !== (int)$user['id']) {
      echo json_encode(['ok'=>false,'msg'=>'Not your session']); exit;
    }
    db()->prepare("UPDATE live_sessions SET status='ended', ended_at=NOW() WHERE id=?")->execute([$sid]);
    echo json_encode(['ok'=>true]);
    exit;
  }

  // Post a live comment
  if ($action === 'live_comment') {
    $sid  = (int)($_POST['session_id'] ?? 0);
    $body = trim($_POST['body'] ?? '');
    if (!$body) { echo json_encode(['ok'=>false,'msg'=>'Empty']); exit; }
    if (mb_strlen($body) > 300) { echo json_encode(['ok'=>false,'msg'=>'Too long']); exit; }
    // Check session exists and is live
    $chk = db()->prepare("SELECT id FROM live_sessions WHERE id=? AND status='live'");
    $chk->execute([$sid]);
    if (!$chk->fetch()) { echo json_encode(['ok'=>false,'msg'=>'Session not live']); exit; }
    db()->prepare("INSERT INTO live_comments (session_id,user_id,body) VALUES (?,?,?)")
       ->execute([$sid, $user['id'], $body]);
    $cid = db()->lastInsertId();
    echo json_encode([
      'ok'       => true,
      'id'       => $cid,
      'username' => $user['username'],
      'avatar'   => $user['avatar'],
      'avatar_img'=> $user['avatar_img'] ?? null,
      'body'     => $body,
      'time'     => date('H:i'),
    ]);
    exit;
  }

  // Poll for new comments (long-poll style)
  if ($action === 'poll_comments') {
    $sid      = (int)($_POST['session_id'] ?? 0);
    $lastId   = (int)($_POST['last_id'] ?? 0);
    $rows = db()->prepare(
      "SELECT lc.id, lc.body, lc.created_at, u.username, u.avatar, u.avatar_img
       FROM live_comments lc JOIN users u ON u.id=lc.user_id
       WHERE lc.session_id=? AND lc.id>?
       ORDER BY lc.id ASC LIMIT 30"
    );
    $rows->execute([$sid, $lastId]);
    $comments = $rows->fetchAll();
    // Also get current session status
    $sess = db()->prepare("SELECT status, viewer_count FROM live_sessions WHERE id=?");
    $sess->execute([$sid]);
    $sessRow = $sess->fetch();
    // ── Accurate viewer count: track unique viewers via heartbeat ──────────
    // Create live_viewers table if not exists (one row per user+session, TTL-based)
    try {
      db()->exec("CREATE TABLE IF NOT EXISTS `live_viewers` (
        `session_id` INT NOT NULL,
        `viewer_key` VARCHAR(64) NOT NULL,
        `last_seen` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`session_id`,`viewer_key`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Exception $e) {}
    if ($sessRow && $sessRow['status'] === 'live') {
      // Use user ID if logged in, otherwise anonymous session key
      $vkey = $user ? 'u'.$user['id'] : ('a'.substr(md5(($_SERVER['REMOTE_ADDR']??'').session_id()), 0, 16));
      db()->prepare("INSERT INTO live_viewers (session_id, viewer_key, last_seen) VALUES (?,?,NOW())
                     ON DUPLICATE KEY UPDATE last_seen=NOW()")
         ->execute([$sid, $vkey]);
      // Expire viewers not seen in last 12 seconds (4 poll cycles)
      db()->prepare("DELETE FROM live_viewers WHERE session_id=? AND last_seen < DATE_SUB(NOW(), INTERVAL 12 SECOND)")
         ->execute([$sid]);
      // Count active unique viewers
      $vcStmt = db()->prepare("SELECT COUNT(*) FROM live_viewers WHERE session_id=?");
      $vcStmt->execute([$sid]);
      $vcount = (int)$vcStmt->fetchColumn();
      db()->prepare("UPDATE live_sessions SET viewer_count=? WHERE id=?")->execute([$vcount, $sid]);
    } else {
      $vcount = (int)($sessRow['viewer_count'] ?? 0);
    }
    echo json_encode([
      'ok'       => true,
      'comments' => $comments,
      'status'   => $sessRow['status'] ?? 'ended',
      'viewers'  => $vcount,
    ]);
    exit;
  }

  // ── Live WebRTC signaling for viewer → broadcaster streams ───────────────
  if ($action === 'live_signal') {
    $sid     = (int)($_POST['session_id'] ?? 0);
    $type    = $_POST['type'] ?? '';
    $payload = $_POST['payload'] ?? '';
    $toOwner = (int)($_POST['to_owner'] ?? 0); // 1 = viewer sending to broadcaster
    try {
      db()->exec("CREATE TABLE IF NOT EXISTS `live_signals` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `session_id` INT NOT NULL,
        `from_user_key` VARCHAR(64) NOT NULL,
        `to_owner` TINYINT(1) NOT NULL DEFAULT 0,
        `type` VARCHAR(30) NOT NULL,
        `payload` TEXT NOT NULL,
        `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        KEY `idx_sess_owner` (`session_id`,`to_owner`,`created_at`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch(Exception $e) {}
    $fromKey = $user ? 'u'.$user['id'] : ('a'.substr(md5(($_SERVER['REMOTE_ADDR']??'').session_id()), 0, 16));
    db()->prepare("INSERT INTO live_signals (session_id,from_user_key,to_owner,type,payload) VALUES (?,?,?,?,?)")
       ->execute([$sid, $fromKey, $toOwner ? 1 : 0, $type, $payload]);
    // Cleanup old signals
    db()->prepare("DELETE FROM live_signals WHERE session_id=? AND created_at < DATE_SUB(NOW(), INTERVAL 30 SECOND)")->execute([$sid]);
    echo json_encode(['ok'=>true]);
    exit;
  }

  if ($action === 'poll_live_signals') {
    $sid     = (int)($_POST['session_id'] ?? 0);
    $sinceId = (int)($_POST['since_id'] ?? 0);
    $asOwner = (int)($_POST['as_owner'] ?? 0); // 1 = broadcaster polling viewer signals
    // owner=1 gets signals sent TO owner (to_owner=1), viewers get signals from owner (to_owner=0)
    $stmt = db()->prepare("SELECT id,from_user_key,type,payload FROM live_signals
                           WHERE session_id=? AND id>? AND to_owner=?
                           ORDER BY id ASC LIMIT 20");
    $stmt->execute([$sid, $sinceId, $asOwner ? 1 : 0]);
    $sigs = $stmt->fetchAll();
    $maxId = $sigs ? (int)end($sigs)['id'] : $sinceId;
    echo json_encode(['ok'=>true,'signals'=>$sigs,'max_id'=>$maxId]);
    exit;
  }

  echo json_encode(['ok'=>false,'msg'=>'Unknown action']);
  exit;
}

// ── Single live session view ─────────────────────────────────────────────────
if (isset($_GET['id'])) {
  $sid = (int)$_GET['id'];
  $sess = db()->prepare(
    "SELECT ls.*, u.username, u.avatar, u.avatar_img
     FROM live_sessions ls JOIN users u ON u.id=ls.user_id
     WHERE ls.id=?"
  );
  $sess->execute([$sid]);
  $sess = $sess->fetch();
  if (!$sess) { header('Location: live.php'); exit; }

  // Fetch first batch of comments
  $comments = db()->prepare(
    "SELECT lc.*, u.username, u.avatar, u.avatar_img
     FROM live_comments lc JOIN users u ON u.id=lc.user_id
     WHERE lc.session_id=? ORDER BY lc.id ASC LIMIT 100"
  );
  $comments->execute([$sid]);
  $comments = $comments->fetchAll();

  pageHeader(e($sess['title']).' — codeMe LIVE');
  showLiveSession($sess, $comments, $user);
  pageFooter();
  exit;
}

// ── Listing page ─────────────────────────────────────────────────────────────
$liveSessions = db()->query(
  "SELECT ls.*, u.username, u.avatar, u.avatar_img
   FROM live_sessions ls JOIN users u ON u.id=ls.user_id
   WHERE ls.status='live'
   ORDER BY ls.viewer_count DESC, ls.started_at DESC
   LIMIT 20"
)->fetchAll();

$recentSessions = db()->query(
  "SELECT ls.*, u.username, u.avatar, u.avatar_img
   FROM live_sessions ls JOIN users u ON u.id=ls.user_id
   WHERE ls.status='ended'
   ORDER BY ls.ended_at DESC
   LIMIT 12"
)->fetchAll();

// ── Also fetch recently auto-published showcase posts to display on live page
// This connects the Schedule feature with the Live page so scheduled posts appear here
try {
  $featuredPosts = db()->query(
    "SELECT sp.id, sp.title, sp.description, sp.created_at,
            u.username, u.avatar, u.avatar_img,
            (SELECT COUNT(*) FROM showcase_likes WHERE post_id=sp.id) AS like_count
     FROM showcase_posts sp
     JOIN users u ON u.id=sp.user_id
     JOIN scheduled_posts sched ON sched.showcase_post_id=sp.id AND sched.status='published'
     ORDER BY sp.created_at DESC
     LIMIT 8"
  )->fetchAll();
} catch(Exception $e) { $featuredPosts = []; }

pageHeader('codeMe LIVE');
?>

<style>
/* ── Live page styles ─────────────────────────────────────────── */
.live-header{padding:36px 24px 20px;max-width:1100px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap}
.live-header h1{font-size:28px;font-weight:800;letter-spacing:-1px;display:flex;align-items:center;gap:10px}
.live-dot{width:12px;height:12px;border-radius:50%;background:#ff4444;animation:livePulse 1s ease-in-out infinite;box-shadow:0 0 0 0 rgba(255,68,68,.4)}
@keyframes livePulse{0%{box-shadow:0 0 0 0 rgba(255,68,68,.4)}70%{box-shadow:0 0 0 10px rgba(255,68,68,0)}100%{box-shadow:0 0 0 0 rgba(255,68,68,0)}}
.live-badge{display:inline-flex;align-items:center;gap:5px;background:rgba(255,68,68,.15);border:1px solid rgba(255,68,68,.35);color:#ff6b6b;border-radius:20px;padding:4px 12px;font-size:11px;font-weight:700;font-family:var(--font-mono);letter-spacing:.5px}

.btn-go-live{background:#ff4444;color:#fff;border:none;border-radius:10px;padding:10px 22px;font-size:13px;font-weight:800;cursor:pointer;display:inline-flex;align-items:center;gap:7px;transition:filter .2s,transform .2s;font-family:var(--font-head)}
.btn-go-live:hover{filter:brightness(1.15);transform:translateY(-1px)}

.live-section{max-width:1100px;margin:0 auto;padding:0 24px 60px}
.live-section h2{font-size:18px;font-weight:800;margin-bottom:16px;letter-spacing:-.4px;display:flex;align-items:center;gap:8px}

.live-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:16px;margin-bottom:40px}
.live-card{background:var(--bg2);border:1px solid var(--border);border-radius:16px;overflow:hidden;display:flex;flex-direction:column;transition:border-color .2s,transform .2s;text-decoration:none;color:inherit}
.live-card:hover{border-color:rgba(255,68,68,.35);transform:translateY(-2px)}
.live-card-thumb{height:160px;background:linear-gradient(135deg,#1a0010,#200020);position:relative;display:flex;align-items:center;justify-content:center;overflow:hidden}
.live-card-thumb::before{content:'';position:absolute;inset:0;background:repeating-linear-gradient(45deg,rgba(255,68,68,.03) 0,rgba(255,68,68,.03) 1px,transparent 1px,transparent 24px)}
.live-card-thumb-icon{font-size:48px;opacity:.6}
.live-card-badge{position:absolute;top:10px;left:10px}
.live-card-viewers{position:absolute;top:10px;right:10px;background:rgba(0,0,0,.6);border-radius:20px;padding:3px 9px;font-size:10px;font-family:var(--font-mono);color:#fff;display:flex;align-items:center;gap:4px}
.live-card-body{padding:14px 16px}
.live-card-title{font-size:14px;font-weight:700;margin-bottom:6px;line-height:1.3}
.live-card-meta{display:flex;align-items:center;gap:7px;font-size:11px;color:var(--muted);font-family:var(--font-mono)}
.live-card-avatar{width:18px;height:18px;border-radius:50%;object-fit:cover}

.ended-card{background:var(--bg2);border:1px solid var(--border);border-radius:12px;padding:14px 16px;display:flex;align-items:center;gap:12px;text-decoration:none;color:inherit;transition:border-color .2s}
.ended-card:hover{border-color:rgba(255,255,255,.15)}
.ended-card-icon{width:40px;height:40px;border-radius:10px;background:var(--bg3);display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0}
.ended-card-title{font-size:13px;font-weight:700}
.ended-card-meta{font-size:11px;font-family:var(--font-mono);color:var(--muted);margin-top:2px}

.ended-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:10px}

.live-empty{text-align:center;padding:60px 20px;color:var(--muted)}
.live-empty h3{font-size:18px;font-weight:700;color:#fff;margin-bottom:8px}
.live-empty p{font-size:12px;font-family:var(--font-mono)}

/* ── Start Live modal ─────────────────────────────────────────── */
.modal-bg{position:fixed;inset:0;background:rgba(0,0,0,.75);backdrop-filter:blur(6px);z-index:500;display:none;align-items:center;justify-content:center;padding:20px}
.modal-bg.open{display:flex}
.modal{background:var(--bg2);border:1px solid var(--border);border-radius:20px;width:100%;max-width:500px;padding:28px;position:relative}
.modal h2{font-size:20px;font-weight:800;margin-bottom:20px;letter-spacing:-.5px}
.modal-close{position:absolute;top:16px;right:18px;background:none;border:none;color:var(--muted);font-size:22px;cursor:pointer;line-height:1;padding:4px 8px;border-radius:6px}
.modal-close:hover{color:#fff;background:rgba(255,255,255,.07)}
.form-group{margin-bottom:14px}
.form-group label{display:block;font-size:11px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--muted);margin-bottom:6px;font-family:var(--font-mono)}
.form-group input,.form-group textarea{width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:10px;color:#fff;padding:10px 14px;font-size:13px;font-family:var(--font-mono);resize:vertical;transition:border-color .2s;outline:none}
.form-group input:focus,.form-group textarea:focus{border-color:rgba(255,68,68,.5)}
.form-actions{display:flex;gap:10px;justify-content:flex-end;margin-top:18px}
.btn-cancel{background:transparent;border:1px solid var(--border);color:var(--muted);border-radius:10px;padding:10px 20px;font-size:13px;font-weight:700;cursor:pointer;font-family:var(--font-head)}
.btn-cancel:hover{color:#fff}
</style>

<div class="live-header">
  <div>
    <h1><span class="live-dot"></span> codeMe <span style="color:#ff6b6b">LIVE</span></h1>
    <p style="font-family:var(--font-mono);font-size:12px;color:var(--muted);margin-top:4px">Watch live coding battles · comment in real-time</p>
  </div>
  <?php if ($user): ?>
    <button class="btn-go-live" onclick="openGoLiveModal()">
      🔴 Go Live
    </button>
  <?php else: ?>
    <a href="login.php" class="btn-go-live">Login to Go Live</a>
  <?php endif; ?>
</div>

<div class="live-section">

  <!-- Active Live Sessions -->
  <h2><span class="live-badge"><span class="live-dot" style="width:8px;height:8px"></span>LIVE NOW</span></h2>
  <?php if (empty($liveSessions)): ?>
    <div class="live-empty" style="padding:40px 20px;background:var(--bg2);border:1px solid var(--border);border-radius:16px;margin-bottom:36px">
      <h3>No one is live right now</h3>
      <p>Be the first to start a live session!</p>
    </div>
  <?php else: ?>
    <div class="live-grid" style="margin-bottom:36px">
      <?php foreach ($liveSessions as $s): ?>
        <a href="live.php?id=<?= $s['id'] ?>" class="live-card">
          <div class="live-card-thumb">
            <span class="live-card-thumb-icon">⚔</span>
            <div class="live-card-badge"><span class="live-badge">🔴 LIVE</span></div>
            <div class="live-card-viewers">👁 <?= (int)$s['viewer_count'] ?></div>
          </div>
          <div class="live-card-body">
            <div class="live-card-title"><?= e($s['title']) ?></div>
            <div class="live-card-meta">
              <?php if ($s['avatar_img']): ?><img src="<?= e($s['avatar_img']) ?>" class="live-card-avatar" alt=""><?php else: ?><span><?= e($s['avatar'] ?: '👤') ?></span><?php endif; ?>
              <span><?= e($s['username']) ?></span>
              <span>·</span>
              <span><?= $s['started_at'] ? timeAgoLive($s['started_at']) : 'just started' ?></span>
            </div>
          </div>
        </a>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <!-- Recent Ended Sessions -->
  <?php if (!empty($recentSessions)): ?>
    <h2>📼 Recent Streams</h2>
    <div class="ended-grid">
      <?php foreach ($recentSessions as $s): ?>
        <div class="ended-card">
          <div class="ended-card-icon">📼</div>
          <div>
            <div class="ended-card-title"><?= e(mb_strimwidth($s['title'],0,50,'…')) ?></div>
            <div class="ended-card-meta"><?= e($s['username']) ?> · <?= $s['ended_at'] ? date('M j', strtotime($s['ended_at'])) : '' ?></div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <!-- Scheduled Posts auto-published (connects Schedule → Live page) -->
  <?php if (!empty($featuredPosts)): ?>
    <h2 style="margin-top:32px">📅 From the Scheduler</h2>
    <div class="ended-grid">
      <?php foreach ($featuredPosts as $p): ?>
        <a href="showcase.php?id=<?= (int)$p['id'] ?>" class="ended-card">
          <div class="ended-card-icon">⭐</div>
          <div>
            <div class="ended-card-title"><?= e(mb_strimwidth($p['title'],0,50,'…')) ?></div>
            <div class="ended-card-meta"><?= e($p['username']) ?> · <?= date('M j', strtotime($p['created_at'])) ?> · ❤️ <?= (int)$p['like_count'] ?></div>
          </div>
        </a>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<!-- Go Live Modal -->
<?php if ($user): ?>
<div class="modal-bg" id="goLiveModal">
  <div class="modal">
    <button class="modal-close" onclick="closeGoLiveModal()">✕</button>
    <h2>🔴 Start a Live Session</h2>
    <div class="form-group">
      <label>Stream Title *</label>
      <input type="text" id="liveTitle" placeholder="e.g. Coding battle vs Mike!" maxlength="200">
    </div>
    <div class="form-group">
      <label>Description</label>
      <textarea id="liveDesc" placeholder="What's happening in this stream?" style="min-height:80px"></textarea>
    </div>
    <div class="form-actions">
      <button class="btn-cancel" onclick="closeGoLiveModal()">Cancel</button>
      <button class="btn-go-live" onclick="startLive()">🔴 Go Live Now</button>
    </div>
  </div>
</div>
<script src="assets/security.js"></script>
<script>
function openGoLiveModal(){ document.getElementById('goLiveModal').classList.add('open'); }
function closeGoLiveModal(){ document.getElementById('goLiveModal').classList.remove('open'); }
document.getElementById('goLiveModal').addEventListener('click', function(e){ if(e.target===this) closeGoLiveModal(); });

async function startLive(){
  const title=document.getElementById('liveTitle').value.trim();
  if(!title){showToast('Please enter a stream title');return;}
  const fd=new FormData();
  fd.append('action','start_live');
  fd.append('title',title);
  fd.append('description',document.getElementById('liveDesc').value.trim());
  const res=await fetch('live.php',{method:'POST',body:fd});
  const data=await res.json();
  if(data.ok){
    window.location.href='live.php?id='+data.session_id;
  } else {
    showToast(data.msg||'Error');
  }
}
</script>
<?php endif; ?>

<?php
pageFooter();

// ── Helper ────────────────────────────────────────────────────────────────────
function timeAgoLive(string $dt): string {
  $diff = time() - strtotime($dt);
  if ($diff < 60)   return 'just now';
  if ($diff < 3600) return (int)($diff/60).'m ago';
  return (int)($diff/3600).'h ago';
}

// ── Single Live Session renderer ───────────────────────────────────────────────
function showLiveSession(array $sess, array $comments, ?array $user): void {
  $isOwner = $user && (int)$user['id'] === (int)$sess['user_id'];
  $isLive  = $sess['status'] === 'live';
  $lastId  = empty($comments) ? 0 : (int)end($comments)['id'];
?>
<style>
/* ── Live session page ─────────────────────────────────────────── */
.ls-wrap{display:grid;grid-template-columns:1fr 360px;gap:0;height:calc(100vh - 60px);max-height:calc(100vh - 60px);overflow:hidden}

/* ── Mobile: stack video on top, chat below ── */
@media(max-width:900px){
  .ls-wrap{grid-template-columns:1fr;height:auto;overflow:visible;display:flex;flex-direction:column}
  .ls-main{border-right:none;border-bottom:1px solid var(--border)}
  .ls-video-area{min-height:56vw !important;height:56vw;max-height:340px}
  .ls-chat{height:360px;min-height:0}
  .ls-chat-messages{min-height:0;flex:1}
  /* Prevent iOS from zooming in on textarea focus */
  .ls-chat-input textarea{font-size:16px !important}
  /* Bigger tap targets on mobile */
  .ls-chat-send{padding:12px 18px;font-size:15px}
  .ls-end-btn{padding:10px 18px;font-size:13px}
  /* Camera buttons bigger for fingers */
  #camBtn{width:240px !important;padding:14px 28px !important;font-size:15px !important}
  #camBtns button{width:240px !important}
}

/* Main area */
.ls-main{display:flex;flex-direction:column;overflow:hidden;border-right:1px solid var(--border)}
.ls-video-area{flex:1;background:#050709;display:flex;align-items:center;justify-content:center;position:relative;min-height:280px}
.ls-video-area video{width:100%;height:100%;object-fit:cover}
.ls-placeholder{text-align:center;color:var(--muted);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;padding:40px;width:100%;height:100%;box-sizing:border-box}
.ls-placeholder-icon{font-size:64px;opacity:.4}
.ls-placeholder p{font-family:var(--font-mono);font-size:12px;max-width:260px;line-height:1.6}
.ls-live-badge{position:absolute;top:16px;left:16px;display:inline-flex;align-items:center;gap:5px;background:rgba(255,68,68,.9);border-radius:20px;padding:5px 14px;font-size:11px;font-weight:800;font-family:var(--font-mono);letter-spacing:.5px;color:#fff}
.ls-live-dot{width:7px;height:7px;border-radius:50%;background:#fff;animation:livePulse 1s ease-in-out infinite}
@keyframes livePulse{0%{opacity:1}50%{opacity:.3}100%{opacity:1}}
.ls-viewers{position:absolute;top:16px;right:16px;background:rgba(0,0,0,.6);border-radius:20px;padding:5px 12px;font-size:11px;font-family:var(--font-mono);color:#fff}
.ls-ended-overlay{position:absolute;inset:0;background:rgba(0,0,0,.7);display:flex;align-items:center;justify-content:center;flex-direction:column;gap:8px}
.ls-ended-overlay h3{font-size:20px;font-weight:800;color:#fff}
.ls-ended-overlay p{font-size:12px;font-family:var(--font-mono);color:rgba(255,255,255,.6)}

.ls-info{padding:14px 18px;border-top:1px solid var(--border);background:var(--bg2);display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}
.ls-title{font-size:15px;font-weight:800;letter-spacing:-.3px}
.ls-meta{font-size:11px;font-family:var(--font-mono);color:var(--muted);display:flex;align-items:center;gap:7px;flex-wrap:wrap;margin-top:3px}
.ls-avatar{width:20px;height:20px;border-radius:50%;object-fit:cover}
.ls-end-btn{background:rgba(255,68,68,.15);border:1px solid rgba(255,68,68,.35);color:#ff6b6b;border-radius:9px;padding:8px 16px;font-size:12px;font-weight:700;cursor:pointer;font-family:var(--font-head);transition:all .15s;white-space:nowrap}
.ls-end-btn:hover{background:rgba(255,68,68,.3)}

/* Chat sidebar */
.ls-chat{display:flex;flex-direction:column;background:var(--bg2);overflow:hidden}
.ls-chat-head{padding:14px 16px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;flex-shrink:0}
.ls-chat-head h3{font-size:14px;font-weight:800;letter-spacing:-.3px}
.ls-chat-viewers{font-size:11px;font-family:var(--font-mono);color:var(--muted)}

.ls-chat-messages{flex:1;overflow-y:auto;-webkit-overflow-scrolling:touch;padding:12px;display:flex;flex-direction:column;gap:8px;min-height:0}
.ls-chat-messages::-webkit-scrollbar{width:4px}
.ls-chat-messages::-webkit-scrollbar-track{background:transparent}
.ls-chat-messages::-webkit-scrollbar-thumb{background:var(--border);border-radius:4px}

.ls-msg{display:flex;gap:8px;align-items:flex-start;animation:msgIn .2s ease}
@keyframes msgIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
.ls-msg-avt{width:24px;height:24px;border-radius:50%;font-size:14px;line-height:24px;text-align:center;flex-shrink:0;overflow:hidden}
.ls-msg-avt img{width:100%;height:100%;object-fit:cover}
.ls-msg-body{flex:1}
.ls-msg-user{font-size:12px;font-weight:700;color:var(--green)}
.ls-msg-time{font-size:10px;color:var(--muted);font-family:var(--font-mono);margin-left:5px}
.ls-msg-text{font-size:12px;color:#c8d0e7;line-height:1.5;margin-top:1px;font-family:var(--font-mono)}

.ls-chat-input{padding:12px;border-top:1px solid var(--border);display:flex;gap:8px;flex-shrink:0}
.ls-chat-input textarea{flex:1;background:var(--bg3);border:1px solid var(--border);border-radius:10px;color:#fff;padding:9px 12px;font-size:16px;font-family:var(--font-mono);resize:none;min-height:38px;max-height:80px;outline:none;transition:border-color .2s;line-height:1.4;-webkit-appearance:none}
.ls-chat-input textarea:focus{border-color:rgba(255,68,68,.4)}
.ls-chat-send{background:#ff4444;border:none;border-radius:10px;color:#fff;padding:9px 14px;cursor:pointer;font-size:13px;font-weight:700;font-family:var(--font-head);transition:filter .15s;white-space:nowrap;align-self:flex-end;-webkit-tap-highlight-color:transparent}
.ls-chat-send:hover{filter:brightness(1.15)}
.ls-chat-login{padding:12px;border-top:1px solid var(--border);text-align:center;font-size:12px;font-family:var(--font-mono);color:var(--muted)}
.ls-chat-login a{color:var(--green)}

.ls-back{display:inline-flex;align-items:center;gap:6px;font-size:12px;font-family:var(--font-mono);color:var(--muted);text-decoration:none;padding:14px 18px;transition:color .15s}
.ls-back:hover{color:#fff}
</style>

<a href="live.php" class="ls-back">← Back to Live</a>

<div class="ls-wrap">

  <!-- ── Main area ─────────────────────────────────────────────────── -->
  <div class="ls-main">
    <div class="ls-video-area">
      <?php if ($isOwner && $isLive): ?>
        <!-- Owner sees their own camera feed -->
        <video id="localVideo" autoplay muted playsinline webkit-playsinline style="width:100%;height:100%;object-fit:cover;display:none"></video>
        <div class="ls-placeholder" id="cameraPlaceholder" style="cursor:pointer">
          <div id="camSpinner" style="width:48px;height:48px;border-radius:50%;border:3px solid var(--green);border-top-color:transparent;animation:spin 1s linear infinite;margin-bottom:16px;display:none"></div>
          <span class="ls-placeholder-icon" id="camIcon">📹</span>
          <p style="font-weight:700;color:#fff;font-size:14px;margin-bottom:6px" id="camStartMsg">Checking camera…</p>
          <p style="font-size:11px;opacity:.7;max-width:260px;line-height:1.6;font-family:var(--font-mono)" id="camSubMsg"></p>
          <div style="display:none;flex-direction:column;gap:8px;margin-top:14px;align-items:center;width:100%" id="camBtns">
            <button onclick="enableCamera()" id="camBtn" style="background:var(--green);color:#080b12;border:none;border-radius:9px;padding:11px 28px;font-size:13px;font-weight:800;cursor:pointer;font-family:var(--font-head);width:200px">📷 Start Camera</button>
            <button onclick="toggleCamFacing()" id="camFlipBtn" style="display:none;background:rgba(255,255,255,.08);color:#fff;border:1px solid rgba(255,255,255,.2);border-radius:9px;padding:9px 16px;font-size:12px;font-weight:700;cursor:pointer;font-family:var(--font-head);width:200px">🔄 Flip Camera</button>
            <button onclick="enableScreenShare()" id="screenShareBtn" style="background:rgba(255,255,255,.08);color:#fff;border:1px solid rgba(255,255,255,.2);border-radius:9px;padding:9px 16px;font-size:12px;font-weight:700;cursor:pointer;font-family:var(--font-head);width:200px">🖥 Share Screen</button>
          </div>
        </div>
        <div class="ls-live-badge"><span class="ls-live-dot"></span> LIVE</div>
        <div class="ls-viewers" id="viewerCount">👁 0 watching</div>
      <?php elseif ($isLive): ?>
        <!-- Viewers receive live WebRTC stream from broadcaster -->
        <video id="remoteVideo" autoplay playsinline webkit-playsinline style="width:100%;height:100%;object-fit:cover;display:none"></video>
        <div class="ls-placeholder" id="viewerPlaceholder">
          <span class="ls-placeholder-icon">⚔</span>
          <p>Connecting to <strong><?= e($sess['username']) ?></strong>'s live stream…<br><small style="opacity:.6">Broadcaster must enable camera to start video</small></p>
        </div>
        <div class="ls-live-badge"><span class="ls-live-dot"></span> LIVE</div>
        <div class="ls-viewers" id="viewerCount">👁 <?= (int)$sess['viewer_count'] ?> watching</div>
      <?php else: ?>
        <div class="ls-placeholder">
          <span class="ls-placeholder-icon">📼</span>
          <p>This stream has ended.</p>
        </div>
        <div class="ls-ended-overlay">
          <h3>Stream Ended</h3>
          <p><?= $sess['ended_at'] ? 'Ended '.date('M j \a\t H:i', strtotime($sess['ended_at'])) : '' ?></p>
        </div>
      <?php endif; ?>
    </div>

    <div class="ls-info">
      <div>
        <div class="ls-title"><?= e($sess['title']) ?></div>
        <div class="ls-meta">
          <?php if ($sess['avatar_img']): ?><img src="<?= e($sess['avatar_img']) ?>" class="ls-avatar" alt=""><?php else: ?><?= e($sess['avatar'] ?: '👤') ?><?php endif; ?>
          <a href="showcase.php?user=<?= (int)$sess['user_id'] ?>" style="color:var(--muted);text-decoration:none;font-weight:700;transition:color .15s" onmouseover="this.style.color='var(--green)'" onmouseout="this.style.color='var(--muted)'"><?= e($sess['username']) ?></a>
          <?php if ($isLive): ?>
            <span>·</span><span style="color:#ff6b6b">🔴 Live</span>
          <?php else: ?>
            <span>·</span><span>Stream ended</span>
          <?php endif; ?>
        </div>
        <?php if ($sess['description']): ?>
          <div style="font-size:12px;font-family:var(--font-mono);color:var(--muted);margin-top:6px;line-height:1.5"><?= e($sess['description']) ?></div>
        <?php endif; ?>
      </div>
      <?php if ($isOwner && $isLive): ?>
        <button class="ls-end-btn" onclick="endStream(<?= (int)$sess['id'] ?>)">⏹ End Stream</button>
      <?php endif; ?>
    </div>
  </div>

  <!-- ── Chat sidebar ─────────────────────────────────────────────── -->
  <div class="ls-chat">
    <div class="ls-chat-head">
      <h3>💬 Live Chat</h3>
      <span class="ls-chat-viewers" id="chatViewers"><?= (int)$sess['viewer_count'] ?> watching</span>
    </div>

    <div class="ls-chat-messages" id="chatMessages">
      <?php foreach ($comments as $c): ?>
        <div class="ls-msg">
          <div class="ls-msg-avt">
            <?php if ($c['avatar_img']): ?><img src="<?= e($c['avatar_img']) ?>" alt=""><?php else: ?><?= e($c['avatar'] ?: '👤') ?><?php endif; ?>
          </div>
          <div class="ls-msg-body">
            <span class="ls-msg-user"><?= e($c['username']) ?></span>
            <span class="ls-msg-time"><?= date('H:i', strtotime($c['created_at'])) ?></span>
            <div class="ls-msg-text"><?= e($c['body']) ?></div>
          </div>
        </div>
      <?php endforeach; ?>
      <?php if (empty($comments)): ?>
        <div style="text-align:center;padding:30px 16px;color:var(--muted);font-family:var(--font-mono);font-size:11px">No messages yet. Say hello!</div>
      <?php endif; ?>
    </div>

    <?php if ($user): ?>
    <div class="ls-chat-input">
      <textarea id="chatBox" placeholder="Say something…" maxlength="300"
        onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();sendComment();}"></textarea>
      <button class="ls-chat-send" onclick="sendComment()">Send</button>
    </div>
    <?php else: ?>
      <div class="ls-chat-login"><a href="login.php">Login</a> to chat</div>
    <?php endif; ?>
  </div>

</div>

<script>
const SESSION_ID  = <?= (int)$sess['id'] ?>;
const IS_LIVE     = <?= $isLive ? 'true' : 'false' ?>;
const IS_OWNER    = <?= $isOwner ? 'true' : 'false' ?>;
let lastCommentId = <?= $lastId ?>;
let pollTimer     = null;
let _localStream  = null;

// ── WebRTC state ──────────────────────────────────────────────────────────────
const ICE_SERVERS = [
  {urls:'stun:stun.l.google.com:19302'},
  {urls:'stun:stun1.l.google.com:19302'},
  {urls:'stun:stun2.l.google.com:19302'}
];
let viewerPc       = null; // viewer's RTCPeerConnection
let ownerPeers     = {};   // broadcaster tracks multiple viewer PCs: {viewerKey: pc}
let lastSignalId   = 0;
let signalPollTimer= null;

function escHtml(s){const d=document.createElement('div');d.textContent=s;return d.innerHTML;}

// ── Chat ──────────────────────────────────────────────────────────────────────
function appendComment(c){
  const list = document.getElementById('chatMessages');
  const placeholder = list.querySelector('div[style*="text-align:center"]');
  if(placeholder) placeholder.remove();
  const avt = c.avatar_img
    ? `<img src="${escHtml(c.avatar_img)}" alt="" style="width:100%;height:100%;object-fit:cover;">`
    : escHtml(c.avatar||'👤');
  const div = document.createElement('div');
  div.className='ls-msg';
  div.innerHTML=`
    <div class="ls-msg-avt">${avt}</div>
    <div class="ls-msg-body">
      <span class="ls-msg-user">${escHtml(c.username)}</span>
      <span class="ls-msg-time">${escHtml(c.time||'')}</span>
      <div class="ls-msg-text">${escHtml(c.body)}</div>
    </div>`;
  list.appendChild(div);
  list.scrollTop=list.scrollHeight;
}

async function sendComment(){
  const box=document.getElementById('chatBox');
  const body=box.value.trim();
  if(!body||!IS_LIVE)return;
  const fd=new FormData();
  fd.append('action','live_comment');
  fd.append('session_id',SESSION_ID);
  fd.append('body',body);
  box.value='';
  const res=await fetch('live.php',{method:'POST',body:fd});
  const data=await res.json();
  if(data.ok) appendComment(data);
  else showToast(data.msg||'Error');
}

async function pollComments(){
  if(!IS_LIVE)return;
  try{
    const fd=new FormData();
    fd.append('action','poll_comments');
    fd.append('session_id',SESSION_ID);
    fd.append('last_id',lastCommentId);
    const res=await fetch('live.php',{method:'POST',body:fd});
    const data=await res.json();
    if(data.ok){
      for(const c of data.comments){
        appendComment({...c, time: c.created_at ? c.created_at.slice(11,16) : ''});
        lastCommentId=c.id;
      }
      const vc=document.getElementById('viewerCount');
      const cv=document.getElementById('chatViewers');
      // ── FIXED: viewer count is now accurate (unique heartbeat, not increment-per-poll)
      if(vc) vc.textContent='👁 '+data.viewers+' watching';
      if(cv) cv.textContent=data.viewers+' watching';
      if(data.status==='ended' && IS_LIVE){
        clearInterval(pollTimer);
        clearInterval(signalPollTimer);
        showToast('Stream has ended');
        setTimeout(()=>window.location.reload(),2000);
      }
    }
  }catch(e){}
}

// ── WebRTC signaling helpers ──────────────────────────────────────────────────
async function sendLiveSignal(type, payload, toOwner){
  const fd=new FormData();
  fd.append('action','live_signal');
  fd.append('session_id',SESSION_ID);
  fd.append('type',type);
  fd.append('payload',JSON.stringify(payload));
  fd.append('to_owner', toOwner ? '1' : '0');
  await fetch('live.php',{method:'POST',body:fd}).catch(()=>{});
}

async function pollLiveSignals(){
  try{
    const fd=new FormData();
    fd.append('action','poll_live_signals');
    fd.append('session_id',SESSION_ID);
    fd.append('since_id',lastSignalId);
    fd.append('as_owner', IS_OWNER ? '1' : '0');
    const res=await fetch('live.php',{method:'POST',body:fd});
    const d=await res.json();
    if(!d.ok) return;
    if(d.max_id > lastSignalId) lastSignalId=d.max_id;
    for(const sig of d.signals) await handleLiveSignal(sig);
  }catch(e){}
}

// ── BROADCASTER: handles viewer connection requests ───────────────────────────
async function handleLiveSignal(sig){
  if(IS_OWNER){
    if(sig.type==='viewer-join'){
      const vkey = sig.from_user_key;
      if(ownerPeers[vkey]) return; // already have a peer for this viewer
      const opc = new RTCPeerConnection({iceServers:ICE_SERVERS});
      ownerPeers[vkey]=opc;
      if(_localStream){
        _localStream.getTracks().forEach(t=>opc.addTrack(t,_localStream));
      }
      opc.onicecandidate=e=>{
        if(e.candidate) sendLiveSignal('ice-from-owner',{candidate:e.candidate,for:vkey},false);
      };
      opc.onconnectionstatechange=()=>{
        if(opc.connectionState==='failed'||opc.connectionState==='disconnected'){
          opc.close(); delete ownerPeers[vkey];
        }
      };
      const offer=await opc.createOffer();
      await opc.setLocalDescription(offer);
      await sendLiveSignal('owner-offer',{sdp:opc.localDescription,for:vkey},false);
    }
    if(sig.type==='viewer-answer'){
      let p; try{ p=JSON.parse(sig.payload); }catch(e){ return; }
      const opc=ownerPeers[p.from];
      if(opc && opc.signalingState==='have-local-offer') await opc.setRemoteDescription(new RTCSessionDescription(p.sdp)).catch(()=>{});
    }
    if(sig.type==='viewer-ice'){
      let p; try{ p=JSON.parse(sig.payload); }catch(e){ return; }
      const opc=ownerPeers[p.from];
      if(opc) await opc.addIceCandidate(new RTCIceCandidate(p.candidate)).catch(()=>{});
    }
  } else {
    // Viewer — only process signals addressed to ME
    let p; try{ p=JSON.parse(sig.payload); }catch(e){ return; }
    if(sig.type==='owner-offer'){
      // Only handle if this offer is addressed to my viewer key
      if(p.for !== window._myViewerKey) return;
      if(!viewerPc) return;
      await viewerPc.setRemoteDescription(new RTCSessionDescription(p.sdp)).catch(()=>{});
      const answer=await viewerPc.createAnswer();
      await viewerPc.setLocalDescription(answer);
      await sendLiveSignal('viewer-answer',{sdp:viewerPc.localDescription,from:window._myViewerKey},true);
    }
    if(sig.type==='ice-from-owner'){
      // Only handle ICE meant for me
      if(p.for !== window._myViewerKey) return;
      if(viewerPc && p.candidate) await viewerPc.addIceCandidate(new RTCIceCandidate(p.candidate)).catch(()=>{});
    }
  }
}

// ── VIEWER: set up peer connection and request stream ────────────────────────
async function initViewerConnection(){
  if(IS_OWNER || !IS_LIVE) return;
  window._myViewerKey = 'v'+Math.random().toString(36).slice(2,10);
  viewerPc = new RTCPeerConnection({iceServers:ICE_SERVERS});
  viewerPc.addTransceiver('video',{direction:'recvonly'});
  viewerPc.addTransceiver('audio',{direction:'recvonly'});
  viewerPc.ontrack=e=>{
    const remoteVid=document.getElementById('remoteVideo');
    if(remoteVid && e.streams[0]){
      remoteVid.srcObject=e.streams[0];
      remoteVid.style.display='block';
      document.getElementById('viewerPlaceholder').style.display='none';
    }
  };
  viewerPc.onicecandidate=e=>{
    if(e.candidate) sendLiveSignal('viewer-ice',{candidate:e.candidate,from:window._myViewerKey},true);
  };
  viewerPc.onconnectionstatechange=()=>{
    if(viewerPc.connectionState==='failed'){
      // Retry after 3s
      setTimeout(()=>{viewerPc.close();viewerPc=null;initViewerConnection();},3000);
    }
  };
  // Tell broadcaster we want to join
  await sendLiveSignal('viewer-join',{key:window._myViewerKey},true);
}

// ── BROADCASTER: enable camera then broadcast to all waiting viewers ──────────
let _facingMode = 'user'; // front camera by default on mobile

async function toggleCamFacing(){
  _facingMode = _facingMode === 'user' ? 'environment' : 'user';
  if(_localStream) _localStream.getTracks().forEach(t=>t.stop());
  _localStream = null;
  await enableCamera(true);
}

async function enableCamera(silent){
  const placeholder = document.getElementById('cameraPlaceholder');
  const vid         = document.getElementById('localVideo');
  const spinner     = document.getElementById('camSpinner');
  const icon        = document.getElementById('camIcon');
  const msgEl       = document.getElementById('camStartMsg');
  const subMsg      = document.getElementById('camSubMsg');
  const btns        = document.getElementById('camBtns');

  if(!silent){
    // Show loading state
    if(icon)    icon.style.display    = 'none';
    if(spinner) spinner.style.display = 'block';
    if(btns)    btns.style.display    = 'none';
    if(msgEl)   msgEl.textContent     = 'Starting camera…';
    if(subMsg)  subMsg.textContent    = '';
    if(msgEl)   msgEl.style.color     = '#fff';
  }

  // Check browser support
  if(!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia){
    _setCamError('❌ Camera not supported', 'Try Chrome or Safari on HTTPS.');
    return;
  }

  // Must be HTTPS (except localhost)
  if(location.protocol !== 'https:' && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1'){
    _setCamError('❌ HTTPS required', 'Camera only works on secure (https://) connections.');
    return;
  }

  const isMobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);

  // Build constraints — use facingMode on mobile for front/back switching
  const videoConstraints = isMobile
    ? {facingMode: _facingMode}
    : true;

  try{
    _localStream = await navigator.mediaDevices.getUserMedia({video: videoConstraints, audio: true});
  } catch(err){
    // On mobile, some browsers don't support facingMode — fall back to plain video:true
    if(isMobile && (err.name === 'OverconstrainedError' || err.name === 'ConstraintNotSatisfiedError')){
      try{
        _localStream = await navigator.mediaDevices.getUserMedia({video: true, audio: true});
      } catch(err2){
        _handleCamError(err2);
        return;
      }
    } else {
      _handleCamError(err);
      return;
    }
  }

  // ✅ Got stream — show video
  vid.srcObject = _localStream;
  // iOS Safari requires these attributes + a user-gesture play() call
  vid.setAttribute('playsinline', '');
  vid.setAttribute('webkit-playsinline', '');
  vid.muted = true;
  try { await vid.play(); } catch(e){}
  vid.style.cssText = 'width:100%;height:100%;object-fit:cover;display:block;';
  if(placeholder) placeholder.style.display = 'none';
  if(!silent && typeof showToast === 'function') showToast('🔴 Camera on — you are live!');

  // Show flip button on mobile (it stays visible over the video)
  if(isMobile){
    const flipBtn = document.getElementById('camFlipBtn');
    if(flipBtn){
      flipBtn.style.cssText='display:flex;position:absolute;bottom:14px;right:14px;width:auto;padding:8px 14px;background:rgba(0,0,0,.55);border:1px solid rgba(255,255,255,.3);border-radius:50px;color:#fff;font-size:12px;font-weight:700;cursor:pointer;z-index:10;align-items:center;gap:6px';
      document.querySelector('.ls-video-area').appendChild(flipBtn);
    }
  }

  // Push tracks to any already-connected viewer peers
  for(const [vkey, opc] of Object.entries(ownerPeers)){
    try{
      const senders = opc.getSenders();
      _localStream.getTracks().forEach(track => {
        const existing = senders.find(s => s.track && s.track.kind === track.kind);
        if(existing) existing.replaceTrack(track).catch(()=>{});
        else opc.addTrack(track, _localStream);
      });
      const offer = await opc.createOffer();
      await opc.setLocalDescription(offer);
      await sendLiveSignal('owner-offer', {sdp: opc.localDescription, for: vkey}, false);
    } catch(e){}
  }

  // Signal polling is already started in boot section
}

function _handleCamError(err){
  if(err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError'){
    _setCamError('🚫 Camera access denied', 'Tap the 🔒 lock icon in your browser address bar → Camera → Allow → then reload this page.');
  } else if(err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError'){
    // Try audio only
    navigator.mediaDevices.getUserMedia({video:false, audio:true}).then(stream=>{
      _localStream = stream;
      const spinner = document.getElementById('camSpinner');
      const icon    = document.getElementById('camIcon');
      const msgEl   = document.getElementById('camStartMsg');
      const subMsg  = document.getElementById('camSubMsg');
      if(spinner) spinner.style.display = 'none';
      if(icon)    { icon.style.display = 'block'; icon.textContent = '🎙'; }
      if(msgEl)   { msgEl.textContent = 'Audio only'; msgEl.style.color = '#f59e0b'; }
      if(subMsg)    subMsg.textContent = 'No camera found — streaming audio only.';
    }).catch(()=>{
      _setCamError('❌ No camera or mic found', 'Check that your device has a camera and it is not used by another app.');
    });
  } else {
    _setCamError('❌ Camera error', err.message);
  }
}

function _setCamError(title, detail){
  const spinner = document.getElementById('camSpinner');
  const icon    = document.getElementById('camIcon');
  const msgEl   = document.getElementById('camStartMsg');
  const subMsg  = document.getElementById('camSubMsg');
  const btns    = document.getElementById('camBtns');

  if(spinner) spinner.style.display = 'none';
  if(icon)    { icon.style.display = 'block'; icon.textContent = '⚠️'; }
  if(msgEl)   { msgEl.textContent = title; msgEl.style.color = '#ff6b6b'; }
  if(subMsg)    subMsg.textContent = detail;
  if(btns)      btns.style.display = 'flex';
  const camBtn = document.getElementById('camBtn');
  if(camBtn)  { camBtn.textContent = '🔄 Retry'; camBtn.onclick = enableCamera; }
}

async function enableScreenShare(){
  const placeholder = document.getElementById('cameraPlaceholder');
  const vid = document.getElementById('localVideo');

  if(!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia){
    _setCamError('❌ Not supported', 'Screen sharing is not supported in this browser.');
    return;
  }
  if(location.protocol !== 'https:' && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1'){
    _setCamError('❌ HTTPS required', 'Screen sharing requires a secure connection.');
    return;
  }
  try{
    // Get screen + optionally mix in microphone audio
    const screenStream = await navigator.mediaDevices.getDisplayMedia({video:true, audio:true});
    let micStream = null;
    try{ micStream = await navigator.mediaDevices.getUserMedia({audio:true, video:false}); } catch(e){}

    // Combine screen video + mic audio into one stream
    const tracks = [...screenStream.getVideoTracks()];
    if(micStream) tracks.push(...micStream.getAudioTracks());
    else if(screenStream.getAudioTracks().length) tracks.push(...screenStream.getAudioTracks());
    _localStream = new MediaStream(tracks);

    vid.srcObject = _localStream;
    vid.style.cssText = 'width:100%;height:100%;object-fit:cover;display:block;';
    vid.play().catch(()=>{});
    if(placeholder) placeholder.style.display = 'none';
    if(typeof showToast === 'function') showToast('🖥 Screen share active — you are live!');

    // When user stops screen share via browser UI
    screenStream.getVideoTracks()[0].onended = ()=>{
      if(placeholder) placeholder.style.display = 'flex';
      vid.style.display = 'none';
      _localStream = null;
      if(typeof showToast === 'function') showToast('Screen share stopped');
    };

    // Signal polling is already started in boot section
  } catch(err){
    if(err.name !== 'AbortError' && err.name !== 'NotAllowedError'){
      _setCamError('❌ Screen share error', err.message);
    }
  }
}


async function endStream(sid){
  if(_localStream) _localStream.getTracks().forEach(t=>t.stop());
  Object.values(ownerPeers).forEach(pc=>pc.close());
  ownerPeers={};
  const fd=new FormData();
  fd.append('action','end_live');
  fd.append('session_id',sid);
  const res=await fetch('live.php',{method:'POST',body:fd});
  const data=await res.json();
  if(data.ok) window.location.href='live.php';
  else showToast(data.msg||'Error');
}

// ── Boot ──────────────────────────────────────────────────────────────────────
if(IS_LIVE){
  pollTimer=setInterval(pollComments,3000);
  pollComments();
  if(!IS_OWNER){
    initViewerConnection();
    signalPollTimer=setInterval(pollLiveSignals,1500);
  } else {
    // Owner: start signal polling immediately so viewer-join signals are received
    // even before the broadcaster has enabled their camera
    signalPollTimer = setInterval(pollLiveSignals, 1500);
    pollLiveSignals();
    // Check permission state, then decide what to show
    (async function bootCamera(){
      const spinner = document.getElementById('camSpinner');
      const icon    = document.getElementById('camIcon');
      const msgEl   = document.getElementById('camStartMsg');
      const subMsg  = document.getElementById('camSubMsg');
      const btns    = document.getElementById('camBtns');
      const ph      = document.getElementById('cameraPlaceholder');

      function showTap(heading, sub){
        if(spinner) spinner.style.display = 'none';
        if(icon)    icon.style.display    = 'block';
        if(msgEl)   { msgEl.textContent = heading; msgEl.style.color = '#fff'; }
        if(subMsg)    subMsg.textContent = sub;
        if(btns)      btns.style.display = 'flex';
        // Hide screen share on mobile — getDisplayMedia not supported
        const isMobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
        const ssBtn = document.getElementById('screenShareBtn');
        if(ssBtn && isMobile) ssBtn.style.display = 'none';
      }

      try {
        const camPerm = await navigator.permissions.query({name:'camera'});
        const micPerm = await navigator.permissions.query({name:'microphone'});

        if(camPerm.state === 'denied'){
          // Hard blocked — tell them how to fix in settings
          if(spinner) spinner.style.display = 'none';
          if(icon)    { icon.style.display = 'block'; icon.textContent = '🚫'; }
          if(msgEl)   { msgEl.textContent = 'Camera access denied'; msgEl.style.color = '#ff6b6b'; }
          if(subMsg)    subMsg.textContent = 'Tap the 🔒 lock icon in your address bar → Camera → Change to Allow → reload this page.';
          if(btns)      btns.style.display = 'flex';

        } else if(camPerm.state === 'granted'){
          // Already allowed — one tap starts instantly, NO permission popup
          showTap('▶ Tap to go live', 'Camera is allowed — tap anywhere here to start.');
          if(ph) ph.onclick = () => { ph.onclick = null; enableCamera(); };

        } else {
          // 'prompt' — first time, needs tap to trigger browser permission dialog
          showTap('📷 Tap to start camera', 'Your browser will ask for camera access once. After that it starts automatically.');
          if(ph) ph.onclick = () => { ph.onclick = null; enableCamera(); };
        }
      } catch(e){
        // Permissions API not supported — show tap button
        showTap('📷 Tap to start camera', 'Tap the button below to enable your camera.');
        if(ph) ph.onclick = () => { ph.onclick = null; enableCamera(); };
      }
    })();
  }
}
</script>
<?php
}
?>
