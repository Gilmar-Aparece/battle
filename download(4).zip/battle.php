<?php
require_once 'includes/config.php';
require_once 'includes/layout.php';
requireLogin();

$user = auth();
$code = strtoupper(trim($_GET['code'] ?? ''));
if (!$code) { header('Location: versus.php'); exit; }

function columnExists(string $table, string $col): bool {
  try { return (bool)db()->query("SHOW COLUMNS FROM `{$table}` LIKE '{$col}'")->fetch(); }
  catch (Exception $e) { return false; }
}
if (!columnExists('rooms','room_mode')) {
  try { db()->exec("ALTER TABLE `rooms` ADD COLUMN `room_mode` enum('1v1','open') NOT NULL DEFAULT '1v1'"); }
  catch (Exception $e) {}
}
if (!columnExists('rooms','max_players')) {
  try { db()->exec("ALTER TABLE `rooms` ADD COLUMN `max_players` tinyint(1) NOT NULL DEFAULT 2"); }
  catch (Exception $e) {}
}

$stmt = db()->prepare('
  SELECT r.*, c.title AS ch_title, c.description AS ch_desc,
         c.target_html AS ch_html, c.target_css AS ch_css,
         c.target_image AS ch_image, c.difficulty AS ch_diff
  FROM rooms r LEFT JOIN challenges c ON c.id=r.challenge_id WHERE r.code=?
');
$stmt->execute([$code]);
$room = $stmt->fetch();

if (!$room) { flash('error','Room not found.'); header('Location: versus.php'); exit; }

$roomMode   = columnExists('rooms','room_mode')   ? ($room['room_mode']   ?? '1v1') : '1v1';
$maxPlayers = columnExists('rooms','max_players') ? ($room['max_players'] ?? 2)     : 2;
$isHost      = ($room['host_id'] == $user['id']);
$hostId      = (int)$room['host_id'];
$challengeId = (int)($room['challenge_id'] ?? 0);

$check = db()->prepare('SELECT id FROM room_players WHERE room_id=? AND user_id=?');
$check->execute([$room['id'], $user['id']]);
$alreadyIn = (bool)$check->fetch();
if (!$alreadyIn && in_array($room['status'], ['waiting', 'active'])) {
  $cnt = db()->prepare('SELECT COUNT(*) FROM room_players WHERE room_id=?');
  $cnt->execute([$room['id']]);
  if ($cnt->fetchColumn() >= $maxPlayers) {
    flash('error','This room is full.'); header('Location: versus.php'); exit;
  }
  db()->prepare('INSERT INTO room_players (room_id,user_id) VALUES (?,?)')->execute([$room['id'],$user['id']]);
  // ── Notify the host that someone joined ──
  if ((int)$user['id'] !== $hostId) {
    require_once __DIR__ . '/includes/notifications_helper.php';
    pushNotification($hostId, (int)$user['id'], 'arena_join', (int)$room['id'], $room['code']);
  }
  if ($roomMode === '1v1' && $room['status'] === 'waiting') {
    $cnt->execute([$room['id']]);
    if ($cnt->fetchColumn() >= 2) {
      db()->prepare("UPDATE rooms SET status='active' WHERE id=?")->execute([$room['id']]);
      $room['status'] = 'active';
    }
  }
}

$stmt->execute([$code]);
$room = $stmt->fetch();
if ($room['status'] === 'finished') { header('Location: versus.php'); exit; }

$chDiff  = $room['ch_diff'] ?? 'medium';
$hasImage = !empty($room['ch_image']);
$hasCSS   = !empty($room['ch_css']) || !empty($room['ch_html']);
$refSrcdocAttr = '';
if ($hasCSS) {
  $d = "<!DOCTYPE html><html><head><meta charset='utf-8'><style>*{margin:0;padding:0;box-sizing:border-box}".htmlspecialchars($room['ch_css'],ENT_QUOTES)."</style></head><body>".($room['ch_html']??'')."</body></html>";
  $refSrcdocAttr = htmlspecialchars($d, ENT_QUOTES);
}

$playersStmt = db()->prepare('SELECT rp.*,u.username,u.avatar FROM room_players rp JOIN users u ON u.id=rp.user_id WHERE rp.room_id=? ORDER BY rp.joined_at ASC');
$playersStmt->execute([$room['id']]);
$currentPlayers = $playersStmt->fetchAll();

pageHeader('Arena — '.$code);
?>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%;background:var(--bg);color:var(--text);font-family:var(--font-head)}

/* ── Arena top-nav ── */
.arena-nav{background:var(--bg2);border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;padding:0 16px;gap:10px;position:sticky;top:0;z-index:50;height:48px;min-height:48px}
.arena-nav-left{display:flex;align-items:center;gap:8px;min-width:0;overflow:hidden}
.arena-nav-right{display:flex;align-items:center;gap:8px;flex-shrink:0}
.room-code-badge{font-family:var(--font-mono);font-size:13px;font-weight:700;color:var(--green);letter-spacing:2px;white-space:nowrap}
.mode-badge{font-size:10px;font-family:var(--font-mono);padding:3px 8px;border-radius:4px;font-weight:700;background:rgba(0,255,135,.1);color:var(--green);border:1px solid rgba(0,255,135,.2);white-space:nowrap;flex-shrink:0}
.players-strip{display:flex;flex-wrap:nowrap;gap:5px;overflow:hidden}
.player-chip{display:flex;align-items:center;gap:4px;background:var(--bg3);border:1px solid var(--border);border-radius:6px;padding:3px 8px;font-size:11px;font-family:var(--font-mono);white-space:nowrap}
.player-chip.mine{border-color:var(--green);color:var(--green)}
.timer-box{font-family:var(--font-mono);font-weight:700;font-size:16px;white-space:nowrap;letter-spacing:1px}
.timer-box.urgent{color:var(--pink);animation:tpulse .5s infinite alternate}
@keyframes tpulse{to{opacity:.35}}
.arena-back{font-size:12px;font-family:var(--font-mono);color:var(--muted);white-space:nowrap;padding:4px 8px;border-radius:6px;transition:color .2s}
.arena-back:hover{color:var(--text)}

/* ─────────── WAITING LOBBY ─────────── */
.lobby-wrap{
  display:flex;flex-direction:column;align-items:center;
  justify-content:center;min-height:calc(100vh - 106px);
  padding:32px 20px;text-align:center;gap:22px;
}
.lobby-code{font-family:var(--font-mono);font-size:42px;font-weight:700;color:var(--green);letter-spacing:8px;text-shadow:0 0 40px rgba(0,255,135,.25);word-break:break-all}
.lobby-players{display:flex;flex-wrap:wrap;gap:10px;justify-content:center;max-width:500px}
.lobby-player{display:flex;align-items:center;gap:8px;padding:10px 18px;background:var(--bg2);border:1px solid var(--border);border-radius:12px;font-size:13px;font-weight:600}
.lobby-player.is-host{border-color:rgba(0,255,135,.35);color:var(--green);background:rgba(0,255,135,.04)}
.lobby-empty{padding:10px 18px;background:var(--bg2);border:1px dashed var(--border);border-radius:12px;font-size:12px;font-family:var(--font-mono);color:var(--muted)}
.share-box{background:var(--bg2);border:1px solid var(--border);border-radius:14px;padding:14px 20px;display:flex;align-items:center;gap:12px;flex-wrap:wrap;justify-content:center;max-width:400px}
.share-label{font-size:11px;font-family:var(--font-mono);color:var(--muted);text-transform:uppercase;letter-spacing:1px}
.share-code{font-family:var(--font-mono);font-size:18px;font-weight:700;color:var(--green);letter-spacing:4px}
.copy-btn{padding:7px 16px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;border:none;background:rgba(0,255,135,.15);color:var(--green);font-family:var(--font-mono);transition:background .2s;white-space:nowrap}
.copy-btn:hover{background:rgba(0,255,135,.28)}
.start-btn{padding:14px 40px;background:var(--green);color:#080b12;border:none;border-radius:14px;font-size:15px;font-weight:700;cursor:pointer;transition:filter .2s,transform .2s;letter-spacing:.3px}
.start-btn:hover{filter:brightness(1.1);transform:scale(1.03)}
.start-btn:disabled{opacity:.45;cursor:default;transform:none}
.lobby-info{font-size:13px;font-family:var(--font-mono);color:var(--muted);max-width:340px;line-height:1.6}

/* ─────────── ROOM CHAT (Waiting Lobby) ─────────── */
.room-chat{
  width:100%;max-width:480px;
  background:var(--bg2);
  border:1px solid rgba(255,255,255,0.09);
  border-radius:18px;overflow:hidden;
  display:flex;flex-direction:column;
  box-shadow:0 12px 40px rgba(0,0,0,.5),0 0 0 1px rgba(0,200,255,0.05);
}
.room-chat-header{
  background:linear-gradient(135deg,rgba(0,200,255,0.13) 0%,rgba(0,255,135,0.08) 100%);
  border-bottom:1px solid rgba(255,255,255,0.07);
  padding:13px 16px;display:flex;align-items:center;gap:10px;
}
.room-chat-icon{
  width:32px;height:32px;border-radius:50%;
  background:linear-gradient(135deg,#00c8ff,#00ff87);
  display:flex;align-items:center;justify-content:center;
  font-size:15px;flex-shrink:0;
  box-shadow:0 0 14px rgba(0,200,255,.3);
}
.room-chat-title{font-size:13px;font-weight:700;color:var(--text)}
.room-chat-status{display:flex;align-items:center;gap:5px;font-size:10px;color:var(--muted);font-family:var(--font-mono);margin-top:2px}
.live-dot{width:6px;height:6px;border-radius:50%;background:var(--green);box-shadow:0 0 5px var(--green);animation:ldpulse 1.8s ease-in-out infinite}
@keyframes ldpulse{0%,100%{opacity:1}50%{opacity:.25}}

.room-chat-messages{
  height:190px;overflow-y:auto;
  padding:12px;display:flex;flex-direction:column;gap:7px;
  scroll-behavior:smooth;
}
.room-chat-messages::-webkit-scrollbar{width:3px}
.room-chat-messages::-webkit-scrollbar-thumb{background:rgba(255,255,255,.08);border-radius:3px}

/* Chat message bubbles */
.rc-msg{display:flex;flex-direction:column;max-width:80%;animation:rcPop .18s ease-out}
@keyframes rcPop{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
.rc-msg.mine{align-self:flex-end;align-items:flex-end}
.rc-msg.theirs{align-self:flex-start;align-items:flex-start}
.rc-msg.system{align-self:center;align-items:center;max-width:100%}
.rc-author{font-size:9px;font-family:var(--font-mono);color:var(--muted);margin-bottom:3px;padding:0 5px}
.rc-bubble{padding:8px 12px;border-radius:16px;font-size:12px;line-height:1.5;word-break:break-word}
.rc-msg.mine   .rc-bubble{background:linear-gradient(135deg,#00c8ff,#00ff87);color:#080b12;border-bottom-right-radius:4px}
.rc-msg.theirs .rc-bubble{background:var(--bg3);border:1px solid var(--border);color:var(--text);border-bottom-left-radius:4px}
.rc-msg.system .rc-bubble{background:rgba(255,255,255,.04);border:1px solid var(--border);color:var(--muted);font-family:var(--font-mono);font-size:10px;border-radius:8px;text-align:center;padding:6px 14px}
.rc-time{font-size:9px;color:var(--muted);font-family:var(--font-mono);margin-top:3px;padding:0 5px}

.room-chat-input{
  padding:10px 12px;border-top:1px solid var(--border);
  display:flex;align-items:center;gap:8px;background:var(--bg2);
}
.room-chat-field{
  flex:1;background:var(--bg3);border:1px solid var(--border);
  border-radius:20px;padding:9px 14px;color:var(--text);
  font-size:12px;font-family:var(--font-mono);outline:none;
  transition:border-color .2s;
}
.room-chat-field:focus{border-color:rgba(0,200,255,.4)}
.room-chat-field::placeholder{color:var(--muted)}
.room-chat-send{
  width:36px;height:36px;border-radius:50%;flex-shrink:0;
  background:linear-gradient(135deg,#00c8ff,#00ff87);border:none;
  color:#080b12;font-size:14px;cursor:pointer;
  display:flex;align-items:center;justify-content:center;
  transition:transform .2s,filter .2s;
  box-shadow:0 2px 10px rgba(0,200,255,.2);
}
.room-chat-send:hover{transform:scale(1.1);filter:brightness(1.1)}

/* ─────────── BATTLE LAYOUT ─────────── */
.battle-wrap{
  display:grid;
  grid-template-columns:1fr 300px;
  height:calc(100vh - 106px); /* navbar 58 + arena-nav 48 */
  overflow:hidden;
}

/* Editor pane */
.editor-pane{display:flex;flex-direction:column;min-height:0;border-right:1px solid var(--border)}
.code-editor{flex:1;background:#0a0e18;border:none;color:#e8eaf0;font-family:var(--font-mono);font-size:14px;line-height:1.6;padding:16px;resize:none;outline:none;width:100%;min-height:0}
.submit-bar{background:var(--bg2);border-top:1px solid var(--border);padding:0;display:flex;flex-direction:column;flex-shrink:0}
.match-bar-wrap{padding:8px 14px 0;display:flex;flex-direction:column;gap:4px}
.match-bar-row{display:flex;align-items:center;justify-content:space-between;gap:8px}
.acc-info{font-size:12px;font-family:var(--font-mono);color:var(--muted)}
.acc-info strong{color:var(--green);font-size:13px}
.match-bar-track{height:14px;background:#1a0800;border-radius:2px;overflow:hidden;flex:1;border:1px solid #3a1200}
.match-bar-fill{height:100%;width:0%;border-radius:1px;background:linear-gradient(90deg,#cc2200,#ff5500,#ff8800);transition:width .4s ease,background .4s;box-shadow:inset 0 1px 0 rgba(255,160,0,.25)}
.submit-bar-actions{padding:8px 14px 10px;display:flex;align-items:center;justify-content:flex-end;gap:10px}
.submit-btn{background:var(--green);color:#000;border:none;padding:10px 22px;border-radius:9px;font-weight:700;font-size:13px;cursor:pointer;transition:filter .2s;white-space:nowrap;letter-spacing:.3px}
.submit-btn:hover{filter:brightness(1.1)}
.submit-btn:disabled{opacity:.5;cursor:default}

/* Challenge pane */
.challenge-pane{background:var(--bg2);display:flex;flex-direction:column;overflow-y:auto;padding:14px;gap:12px;min-height:0}
.pane-label{font-size:10px;font-family:var(--font-mono);letter-spacing:1.5px;text-transform:uppercase;color:var(--muted);margin-bottom:5px}

    /* ── Online presence dot ── */
    .online-dot{display:inline-block;width:8px;height:8px;border-radius:50%;background:var(--muted);margin-right:5px;transition:background .4s,box-shadow .4s;vertical-align:middle}
    .online-dot.online{background:var(--green);box-shadow:0 0 6px var(--green)}
    .host-status{font-size:11px;font-family:var(--font-mono);color:var(--muted);display:flex;align-items:center;gap:4px;margin-bottom:8px}

    /* ── Reactions strip ── */
    .reactions-strip{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}
    .react-btn{background:var(--bg3);border:1px solid var(--border);border-radius:20px;padding:4px 10px;font-size:13px;cursor:pointer;transition:border-color .2s,background .2s;display:flex;align-items:center;gap:5px;color:var(--text);font-family:var(--font-mono);font-size:11px}
    .react-btn:hover{border-color:rgba(0,255,135,.35);background:rgba(0,255,135,.07)}
    .react-btn.active{border-color:var(--green);background:rgba(0,255,135,.12);color:var(--green)}

    /* ── Comments panel ── */
    .comments-panel{display:flex;flex-direction:column;gap:8px}
    .comment-item{background:var(--bg3);border:1px solid var(--border);border-radius:8px;padding:8px 10px}
    .comment-meta{font-size:10px;font-family:var(--font-mono);color:var(--muted);margin-bottom:4px}
    .comment-text{font-size:12px;line-height:1.5;color:var(--text)}
    .comment-form{display:flex;gap:6px;margin-top:6px}
    .comment-input{flex:1;background:var(--bg3);border:1px solid var(--border);border-radius:8px;padding:8px 10px;color:var(--text);font-size:12px;font-family:var(--font-mono);outline:none;transition:border-color .2s}
    .comment-input:focus{border-color:rgba(0,255,135,.4)}
    .comment-send{background:var(--green);color:#080b12;border:none;border-radius:8px;padding:8px 12px;font-size:12px;font-weight:700;cursor:pointer;white-space:nowrap}
    .comment-send:hover{filter:brightness(1.1)}
    .no-comments{font-size:11px;font-family:var(--font-mono);color:var(--muted);text-align:center;padding:10px 0}
.target-frame{width:100%;height:140px;background:#fff;border-radius:8px;border:1px solid var(--border);display:block}
.preview-frame{width:100%;height:140px;background:#fff;border-radius:8px;border:1px solid var(--border)}
.diff-badge-sm{display:inline-block;font-size:10px;font-family:var(--font-mono);padding:2px 8px;border-radius:4px;font-weight:700;margin-bottom:6px}
.diff-badge-sm.easy{background:rgba(0,255,135,.15);color:var(--green)}
.diff-badge-sm.medium{background:rgba(255,190,0,.15);color:#ffbe00}
.diff-badge-sm.hard{background:rgba(255,45,111,.15);color:var(--pink)}
/* ── Versus Battle Bar ── */
.vs-battle-bar{width:100%;background:#0d0500;border:1px solid #5a1500;border-radius:10px;padding:12px 10px;display:flex;align-items:center;gap:0;position:relative;overflow:hidden;margin-bottom:8px}
.vs-battle-bar::before{content:'';position:absolute;inset:0;background:linear-gradient(180deg,rgba(200,80,0,.08) 0%,transparent 60%);pointer-events:none}
.vs-player-name{font-family:var(--font-head);font-size:12px;font-weight:700;letter-spacing:.5px;color:#c8860a;white-space:nowrap;flex-shrink:0;width:52px;overflow:hidden;text-overflow:ellipsis}
.vs-player-name.right{text-align:right;color:#c8a030}
.vs-bars-center{flex:1;display:flex;flex-direction:column;gap:4px;padding:0 8px}
.vs-bar-row{display:flex;align-items:center;height:14px;gap:0}
.vs-bar-track{flex:1;height:14px;background:#1a0800;border:1px solid #3a1200;border-radius:2px;overflow:hidden;display:flex}
.vs-bar-track.left-track{flex-direction:row-reverse}
.vs-bar-fill{height:100%;transition:width .5s ease;border-radius:1px}
.vs-bar-fill.left-fill{background:linear-gradient(270deg,#cc2200,#ff5500,#ff8800);box-shadow:inset 0 1px 0 rgba(255,160,0,.25)}
.vs-bar-fill.right-fill{background:linear-gradient(90deg,#cc2200,#ff5500,#ff8800);box-shadow:inset 0 1px 0 rgba(255,160,0,.25)}
.vs-bar-fill.left-fill.me-fill{background:linear-gradient(270deg,#007a40,#00cc66,#00ff87);box-shadow:inset 0 1px 0 rgba(0,255,135,.25)}
.vs-bar-fill.right-fill.me-fill{background:linear-gradient(90deg,#007a40,#00cc66,#00ff87);box-shadow:inset 0 1px 0 rgba(0,255,135,.25)}
.vs-score-pct{font-family:var(--font-mono);font-size:10px;color:#ff8800;min-width:30px;text-align:center;flex-shrink:0}
.vs-score-pct.me{color:#00ff87}
.vs-divider-line{width:1px;height:28px;background:linear-gradient(180deg,transparent,#8b2000,transparent);flex-shrink:0;margin:0 4px}
.vs-submitted-badge{font-size:9px;font-family:var(--font-mono);color:#00ff87;letter-spacing:.5px;text-transform:uppercase}
.opp-done{font-size:10px;color:var(--green);font-family:var(--font-mono)}

/* ─────────── FLOATING CHAT (Active Battle) ─────────── */
.chat-bubble-btn{
  position:fixed;bottom:24px;right:24px;width:52px;height:52px;border-radius:50%;
  background:linear-gradient(135deg,#00ff87,#00c8ff);border:none;cursor:pointer;
  display:flex;align-items:center;justify-content:center;font-size:20px;
  box-shadow:0 4px 20px rgba(0,255,135,.4),0 2px 8px rgba(0,0,0,.4);
  z-index:9000;transition:transform .2s,box-shadow .2s;
}
.chat-bubble-btn:hover{transform:scale(1.1);box-shadow:0 6px 28px rgba(0,255,135,.55)}
.chat-unread{position:absolute;top:-3px;right:-3px;min-width:18px;height:18px;border-radius:9px;background:var(--pink);color:#fff;font-size:10px;font-weight:700;font-family:var(--font-mono);display:none;align-items:center;justify-content:center;padding:0 4px;border:2px solid var(--bg)}
.chat-unread.show{display:flex}

.chat-widget{
  position:fixed;bottom:86px;right:24px;width:310px;height:400px;
  background:var(--bg2);border:1px solid rgba(255,255,255,.1);border-radius:20px;
  box-shadow:0 20px 60px rgba(0,0,0,.6);
  display:flex;flex-direction:column;z-index:8999;overflow:hidden;
  transform:scale(.9) translateY(20px);opacity:0;pointer-events:none;
  transition:transform .25s cubic-bezier(.22,1,.36,1),opacity .2s;
}
.chat-widget.open{transform:scale(1) translateY(0);opacity:1;pointer-events:all}
.chat-whead{background:linear-gradient(135deg,#00c8ff,#00ff87);padding:13px 15px;display:flex;align-items:center;gap:10px;flex-shrink:0}
.chat-whead-icon{width:34px;height:34px;border-radius:50%;background:rgba(0,0,0,.25);display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0;border:2px solid rgba(255,255,255,.3)}
.chat-whead-info{flex:1;min-width:0}
.chat-whead-title{font-size:13px;font-weight:700;color:#080b12;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.chat-whead-sub{font-size:10px;color:rgba(8,11,18,.6);font-family:var(--font-mono);margin-top:1px;display:flex;align-items:center;gap:4px}
.chat-online-dot{width:5px;height:5px;border-radius:50%;background:rgba(8,11,18,.7);animation:cpulse 1.8s ease-in-out infinite}
@keyframes cpulse{0%,100%{opacity:.7}50%{opacity:.2}}
.chat-whead-close{background:none;border:none;color:rgba(8,11,18,.6);font-size:18px;cursor:pointer;line-height:1;padding:2px;border-radius:4px;transition:color .2s;flex-shrink:0}
.chat-whead-close:hover{color:#080b12}
.chat-msgs{flex:1;overflow-y:auto;padding:12px;display:flex;flex-direction:column;gap:8px;scroll-behavior:smooth}
.chat-msgs::-webkit-scrollbar{width:3px}
.chat-msgs::-webkit-scrollbar-thumb{background:rgba(255,255,255,.1);border-radius:3px}
.cmsg{display:flex;flex-direction:column;max-width:80%;animation:msgPop .18s ease-out}
@keyframes msgPop{from{opacity:0;transform:translateY(7px)}to{opacity:1;transform:none}}
.cmsg.mine{align-self:flex-end;align-items:flex-end}
.cmsg.theirs{align-self:flex-start;align-items:flex-start}
.cmsg.system{align-self:center;align-items:center;max-width:100%}
.cmsg-author{font-size:9px;font-family:var(--font-mono);color:var(--muted);margin-bottom:3px;padding:0 6px}
.cmsg-bubble{padding:8px 12px;border-radius:16px;font-size:12px;line-height:1.5;word-break:break-word}
.mine .cmsg-bubble{background:linear-gradient(135deg,#00c8ff,#00ff87);color:#080b12;border-bottom-right-radius:4px}
.theirs .cmsg-bubble{background:var(--bg3);border:1px solid var(--border);color:var(--text);border-bottom-left-radius:4px}
.system .cmsg-bubble{background:rgba(255,255,255,.04);border:1px solid var(--border);color:var(--muted);font-family:var(--font-mono);font-size:10px;border-radius:8px;text-align:center}
.cmsg-time{font-size:9px;color:var(--muted);font-family:var(--font-mono);margin-top:3px;padding:0 6px}
.chat-winput{padding:10px 12px;border-top:1px solid var(--border);display:flex;align-items:center;gap:8px;flex-shrink:0;background:var(--bg2)}
.chat-winput input{flex:1;background:var(--bg3);border:1px solid var(--border);border-radius:20px;padding:9px 14px;color:var(--text);font-size:12px;font-family:var(--font-mono);outline:none;transition:border-color .2s}
.chat-winput input:focus{border-color:rgba(0,200,255,.4)}
.chat-winput input::placeholder{color:var(--muted)}
.chat-wsend{width:35px;height:35px;border-radius:50%;background:linear-gradient(135deg,#00c8ff,#00ff87);border:none;color:#080b12;font-size:14px;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:transform .2s,filter .2s}
.chat-wsend:hover{transform:scale(1.1);filter:brightness(1.1)}

/* ─────────── CONFETTI CANVAS ─────────── */
#confettiCanvas{position:fixed;inset:0;pointer-events:none;z-index:9998;display:none}
#confettiCanvas.active{display:block}

/* ─────────── RESULT OVERLAY ─────────── */
.result-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.92);backdrop-filter:blur(8px);justify-content:center;align-items:center;z-index:9999;padding:20px}
.result-overlay.active{display:flex;animation:roFadeIn .4s ease-out}
@keyframes roFadeIn{from{opacity:0}to{opacity:1}}
.result-card{background:var(--bg2);border:1px solid var(--border);padding:32px 28px;border-radius:24px;width:100%;max-width:460px;text-align:center;position:relative;overflow:hidden;box-shadow:0 30px 80px rgba(0,0,0,.7)}
.result-card::before{content:'';position:absolute;inset:0;background:linear-gradient(135deg,rgba(0,255,135,.04),rgba(0,200,255,.04));pointer-events:none}
.result-title{font-size:30px;font-weight:900;margin-bottom:4px;letter-spacing:-0.5px;animation:titlePop .5s cubic-bezier(.22,1,.36,1)}
.result-title.win{color:var(--green);text-shadow:0 0 40px rgba(0,255,135,.5)}
.result-title.lose{color:var(--text)}
@keyframes titlePop{from{transform:scale(.7);opacity:0}to{transform:scale(1);opacity:1}}
.result-sub{font-size:12px;font-family:var(--font-mono);color:var(--muted);margin-bottom:22px}
.winner-spotlight{background:linear-gradient(135deg,rgba(0,255,135,.12),rgba(0,200,255,.08));border:1px solid rgba(0,255,135,.25);border-radius:14px;padding:14px 18px;margin-bottom:14px;display:flex;align-items:center;gap:12px;animation:spotlightIn .6s .2s cubic-bezier(.22,1,.36,1) both}
@keyframes spotlightIn{from{transform:translateY(20px);opacity:0}to{transform:translateY(0);opacity:1}}
.winner-crown{font-size:32px;line-height:1;filter:drop-shadow(0 0 12px rgba(255,215,0,.6))}
.winner-name{font-size:16px;font-weight:800;color:var(--green);text-align:left}
.winner-label{font-size:10px;font-family:var(--font-mono);color:var(--muted);text-transform:uppercase;letter-spacing:1px;text-align:left}
.winner-score-big{font-size:22px;font-weight:900;font-family:var(--font-mono);color:var(--green);margin-left:auto;flex-shrink:0}
.podium-list{display:flex;flex-direction:column;gap:6px;margin-bottom:8px}
.podium-item{padding:10px 14px;background:var(--bg3);border-radius:10px;text-align:left;display:flex;align-items:center;gap:10px;animation:podiumIn .4s ease-out both}
.podium-item:nth-child(1){animation-delay:.3s}.podium-item:nth-child(2){animation-delay:.4s}.podium-item:nth-child(3){animation-delay:.5s}.podium-item:nth-child(n+4){animation-delay:.6s}
@keyframes podiumIn{from{transform:translateX(-16px);opacity:0}to{transform:translateX(0);opacity:1}}
.podium-item.first-place{border:1px solid rgba(0,255,135,.3);background:rgba(0,255,135,.06)}
.podium-rank{font-size:18px;width:26px;text-align:center;flex-shrink:0}
.podium-name{font-size:13px;font-weight:700;flex:1}
.podium-score{font-size:12px;font-family:var(--font-mono);color:var(--green)}
.back-btn{width:100%;padding:13px;background:var(--green);color:#080b12;border:none;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;margin-top:12px;transition:filter .2s,transform .2s;letter-spacing:.3px}
.back-btn:hover{filter:brightness(1.1);transform:scale(1.02)}

/* ─────────── LIVE SPECTATOR BAR ─────────── */
.spectator-bar{position:fixed;bottom:0;left:0;right:0;background:var(--bg2);border-top:1px solid var(--border);padding:8px 16px;display:none;align-items:center;gap:10px;z-index:400;font-size:12px;font-family:var(--font-mono)}
.spectator-bar.visible{display:flex}
.spec-dot{width:8px;height:8px;border-radius:50%;background:#ff2d6f;box-shadow:0 0 6px #ff2d6f;animation:specPulse 1s ease-in-out infinite}
@keyframes specPulse{0%,100%{opacity:1}50%{opacity:.3}}
.spec-label{color:var(--muted);font-size:11px;text-transform:uppercase;letter-spacing:1px}
.spec-players{display:flex;gap:6px;flex-wrap:wrap;margin-left:4px}
.spec-chip{background:var(--bg3);border:1px solid var(--border);border-radius:6px;padding:2px 8px;font-size:11px;display:flex;align-items:center;gap:5px}
.spec-chip .spec-pct{color:var(--green);font-weight:700}

/* ─────────── MOBILE RESPONSIVE ─────────── */
@media(max-width:768px){
  /* Battle layout goes vertical */
  .battle-wrap{
    display:flex;flex-direction:column;
    height:auto;min-height:calc(100vh - 106px);overflow:visible;
  }
  .editor-pane{
    border-right:none;border-bottom:1px solid var(--border);
    min-height:280px;flex-shrink:0;
  }
  .code-editor{height:240px;flex:none;font-size:13px}
  .challenge-pane{overflow-y:visible;padding:14px;max-height:none;min-height:0}
  .target-frame,.preview-frame{height:150px}
  .submit-bar{flex-direction:column;align-items:stretch;gap:8px}
  .submit-btn{text-align:center;width:100%;padding:12px}
  /* Arena nav on mobile */
  .arena-nav{height:44px;min-height:44px;padding:0 12px}
  .players-strip{display:none}
  .room-code-badge{font-size:12px;letter-spacing:1px}
  .timer-box{font-size:14px}
  /* Lobby */
  .lobby-wrap{gap:16px;padding:20px 16px;min-height:calc(100vh - 102px)}
  .lobby-code{font-size:30px;letter-spacing:4px}
  .share-box{padding:12px 14px;gap:8px;width:100%;max-width:100%}
  .share-code{font-size:14px;letter-spacing:2px}
  .start-btn{padding:12px 28px;font-size:14px}
  .lobby-player{font-size:12px;padding:8px 14px}
  /* Chat widget */
  .chat-widget{width:calc(100vw - 20px);right:10px;bottom:78px;height:360px}
  .chat-bubble-btn{right:14px;bottom:18px;width:48px;height:48px}
}

@media(max-width:480px){
  .lobby-code{font-size:24px;letter-spacing:3px}
  .code-editor{height:200px;font-size:12px;padding:12px}
  .result-card{padding:20px 14px}
  .result-title{font-size:20px}
  .room-chat{max-width:100%}
}
</style>

<?php if ($room['status'] === 'waiting'): ?>
<!-- ═══════════════ WAITING LOBBY ═══════════════ -->
<nav class="arena-nav">
  <div class="arena-nav-left">
    <span class="room-code-badge"><?= e($code) ?></span>
    <span class="mode-badge"><?= $roomMode==='1v1'?'⚔️ 1v1':'👥 OPEN' ?></span>
  </div>
  <a href="versus.php" class="arena-back">← Back</a>
</nav>

<div class="lobby-wrap">

  <div>
    <p style="font-size:10px;font-family:var(--font-mono);color:var(--muted);margin-bottom:8px;letter-spacing:2px;text-transform:uppercase">Room Code</p>
    <div class="lobby-code"><?= e($code) ?></div>
  </div>

  <?php if (!empty($room['ch_title'])): ?>
  <div style="background:var(--bg2);border:1px solid var(--border);border-radius:10px;padding:10px 18px;font-size:13px;font-family:var(--font-mono)">
    📋 <strong style="color:var(--text)"><?= e($room['ch_title']) ?></strong>
  </div>
  <?php endif; ?>

  <!-- Players grid -->
  <div class="lobby-players" id="lobbyPlayers">
    <?php foreach ($currentPlayers as $p): ?>
      <div class="lobby-player <?= $p['user_id']==$room['host_id']?'is-host':'' ?>">
        <?= e($p['avatar']) ?> <?= e($p['username']) ?>
        <?php if ($p['user_id']==$room['host_id']): ?><span style="font-size:10px;opacity:.6;margin-left:4px">👑</span><?php endif; ?>
      </div>
    <?php endforeach; ?>
    <?php for ($i=count($currentPlayers); $i<$maxPlayers; $i++): ?>
      <div class="lobby-empty">Waiting for player <?= $i+1 ?>…</div>
    <?php endfor; ?>
  </div>

  <!-- Share code box -->
  <div class="share-box">
    <span class="share-label">Share:</span>
    <span class="share-code"><?= e($code) ?></span>
    <button class="copy-btn" onclick="copyCode()">📋 Copy</button>
  </div>

  <!-- Host / guest action -->
  <?php if ($roomMode === '1v1'): ?>
    <p class="lobby-info">⚡ Battle starts automatically when your opponent joins.</p>
  <?php elseif ($isHost): ?>
    <div style="display:flex;flex-direction:column;align-items:center;gap:10px">
      <p class="lobby-info">You're the host. Start whenever everyone's ready.</p>
      <button class="start-btn" id="startBtn" onclick="hostStart()">⚡ Start Battle</button>
    </div>
  <?php else: ?>
    <p class="lobby-info">⏳ Waiting for the host to start the battle…</p>
  <?php endif; ?>

  <!-- ── Room Chat ── -->
  <div class="room-chat">
    <div class="room-chat-header">
      <div class="room-chat-icon">💬</div>
      <div>
        <div class="room-chat-title">Room Chat</div>
        <div class="room-chat-status"><span class="live-dot"></span> Live · Chat while you wait</div>
      </div>
    </div>
    <div class="room-chat-messages" id="lobbyChatMsgs">
      <div class="rc-msg system"><div class="rc-bubble">👋 Chat while you wait!</div></div>
    </div>
    <div class="room-chat-input">
      <input type="text" class="room-chat-field" id="lobbyChatInput" placeholder="Say something…" maxlength="300" autocomplete="off">
      <button class="room-chat-send" id="lobbyChatSend">➤</button>
    </div>
  </div>

</div><!-- /lobby-wrap -->
<script src="assets/security.js"></script>
<script>
const ROOM_CODE = '<?= e($code) ?>';
const MAX_P     = <?= (int)$maxPlayers ?>;
const IS_HOST   = <?= $isHost?'true':'false' ?>;
const MY_ID     = <?= (int)$user['id'] ?>;

function esc(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
function copyCode(){navigator.clipboard.writeText(ROOM_CODE).then(()=>showToast('✓ Code copied!'))}

function hostStart(){
  var btn=document.getElementById('startBtn');
  if(btn){btn.disabled=true;btn.textContent='⏳ Starting…'}
  fetch('api.php',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({action:'start_room',code:ROOM_CODE})})
    .then(r=>r.json()).then(d=>{if(d.ok)location.reload()});
}

/* ── Lobby Chat polling ── */
var lcLastId=0;
function pollLobbyChat(){
  fetch('api.php?action=poll_chat&code='+ROOM_CODE+'&after='+lcLastId)
    .then(r=>r.json()).then(data=>{
      if(!data.messages||!data.messages.length)return;
      var box=document.getElementById('lobbyChatMsgs');
      data.messages.forEach(function(m){
        lcLastId=Math.max(lcLastId,m.id);
        var mine=m.user_id==MY_ID;
        var div=document.createElement('div');
        div.className='rc-msg '+(mine?'mine':'theirs');
        var t=new Date(m.sent_at.replace(' ','T'));
        var ts=t.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
        div.innerHTML='<div class="rc-author">'+esc(m.avatar)+' '+esc(m.username)+'</div>'
          +'<div class="rc-bubble">'+esc(m.message)+'</div>'
          +'<div class="rc-time">'+ts+'</div>';
        box.appendChild(div);
      });
      box.scrollTop=box.scrollHeight;
    }).catch(function(){});
}
setInterval(pollLobbyChat,1500);
pollLobbyChat();

function sendLobbyChat(){
  var inp=document.getElementById('lobbyChatInput');
  var msg=inp.value.trim();
  if(!msg)return;
  inp.value='';
  fetch('api.php',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({action:'send_chat',code:ROOM_CODE,message:msg})});
}
document.getElementById('lobbyChatSend').onclick=sendLobbyChat;
document.getElementById('lobbyChatInput').addEventListener('keydown',function(e){
  if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendLobbyChat()}
});

/* ── Room status polling (auto-start / player updates) ── */
setInterval(function(){
  fetch('api.php?action=room_status&code='+ROOM_CODE)
    .then(r=>r.json()).then(data=>{
      if(!data)return;
      if(data.status==='active'){location.reload();return}
      var c=document.getElementById('lobbyPlayers');
      if(data.players&&c){
        var h='';
        data.players.forEach(function(p){
          var host=p.user_id==data.host_id;
          h+='<div class="lobby-player '+(host?'is-host':'')+'">'+p.avatar+' '+p.username+(host?' <span style="font-size:10px;opacity:.6">👑</span>':'')+'</div>';
        });
        for(var i=data.players.length;i<MAX_P;i++)h+='<div class="lobby-empty">Waiting for player '+(i+1)+'…</div>';
        c.innerHTML=h;
      }
    });
},2000);
</script>

<?php else: ?>
<!-- ═══════════════ ACTIVE BATTLE ═══════════════ -->
<nav class="arena-nav">
  <div class="arena-nav-left">
    <span class="room-code-badge"><?= e($code) ?></span>
    <span class="mode-badge"><?= $roomMode==='1v1'?'⚔️ 1v1':'👥 OPEN' ?></span>
    <div class="players-strip" id="livePodiumStrip"></div>
  </div>
  <div class="arena-nav-right">
    <?php if ($isAdmin): ?>
    <button id="adminLockBtn" onclick="adminToggleArenaLock()"
      style="display:flex;align-items:center;gap:5px;padding:5px 12px;border-radius:8px;border:1px solid;font-size:11px;font-weight:700;cursor:pointer;font-family:var(--font-mono);transition:all .2s;background:<?= $arenaLocked?'rgba(255,45,111,.15)':'rgba(0,255,135,.08)' ?>;color:<?= $arenaLocked?'#ff2d6f':'#00ff87' ?>;border-color:<?= $arenaLocked?'rgba(255,45,111,.3)':'rgba(0,255,135,.2)' ?>"
      title="<?= $arenaLocked?'Unlock Arena':'Lock Arena (blocks copy/paste/screenshots)' ?>">
      <?= $arenaLocked?'🔓 Unlock':'🔒 Lock Arena' ?>
    </button>
    <?php endif; ?>
    <div class="timer-box" id="timerBox">05:00</div>
  </div>
</nav>

<div class="battle-wrap">

  <!-- ── Code Editor ── -->
  <div class="editor-pane">
    <textarea class="code-editor" id="myCode" placeholder="Write your CSS / HTML here to match the target…" spellcheck="false"></textarea>
    <div class="submit-bar">
      <div class="match-bar-wrap">
        <div class="match-bar-row">
          <span class="acc-info">Match: <strong id="myAccLabel">0%</strong></span>
        </div>
        <div class="match-bar-track">
          <div class="match-bar-fill" id="matchBarFill"></div>
        </div>
      </div>
      <div class="submit-bar-actions">
        <button class="submit-btn" id="submitBtn">⚡ Submit Solution</button>
      </div>
    </div>
  </div>

  <!-- ── Challenge sidebar ── -->
  <div class="challenge-pane">
    <div>
      <div class="pane-label">Challenge</div>
      <?php if (!empty($room['ch_title'])): ?>
        <div style="font-size:14px;font-weight:700;margin-bottom:4px"><?= e($room['ch_title']) ?></div>
      <?php endif; ?>
      <span class="diff-badge-sm <?= $chDiff ?>"><?= strtoupper($chDiff) ?></span>
      <div style="font-size:12px;font-family:var(--font-mono);color:var(--muted);line-height:1.6"><?= e($room['ch_desc'] ?? $room['challenge'] ?? '') ?></div>
    </div>

    <div>
      <div class="pane-label">Target</div>
      <?php if (!empty($room['ch_title'])): ?>
        <!-- Host online status -->
        <div class="host-status">
          <span class="online-dot" id="hostOnlineDot"></span>
          <span id="hostOnlineLabel">Checking host…</span>
        </div>
      <?php endif; ?>
      <?php if ($hasImage): ?>
        <img src="<?= e($room['ch_image']) ?>" class="target-frame" alt="Target" style="height:140px;object-fit:contain">
      <?php elseif ($hasCSS): ?>
        <iframe class="target-frame" srcdoc="<?= $refSrcdocAttr ?>" sandbox="allow-scripts" scrolling="no"></iframe>
      <?php else: ?>
        <div class="target-frame" style="display:flex;align-items:center;justify-content:center;color:var(--muted);font-family:var(--font-mono);font-size:12px">No preview</div>
      <?php endif; ?>

      <?php if ($challengeId): ?>
        <!-- Reactions -->
        <div class="reactions-strip" id="reactionsStrip">
          <?php foreach(['🔥','👏','😍','💡','🎯'] as $emoji): ?>
            <button class="react-btn" data-emoji="<?= $emoji ?>" onclick="toggleReaction('<?= $emoji ?>')">
              <?= $emoji ?> <span class="react-count" id="rc-<?= urlencode($emoji) ?>">0</span>
            </button>
          <?php endforeach; ?>
        </div>

        <!-- Comments -->
        <div style="margin-top:12px">
          <div class="pane-label">Comments</div>
          <div class="comments-panel" id="commentsList"><div class="no-comments">No comments yet</div></div>
          <div class="comment-form">
            <input class="comment-input" id="commentInput" placeholder="Leave a comment…" maxlength="500">
            <button class="comment-send" onclick="postComment()">Send</button>
          </div>
        </div>
      <?php endif; ?>
    </div>

    <div>
      <div class="pane-label">Scoreboard</div>
      <div id="multiplayerScoreboard"></div>
    </div>

    <div>
      <div class="pane-label">Your Preview</div>
      <iframe class="preview-frame" id="livePreview" srcdoc="<html><body style='margin:0;background:#fff'></body></html>" sandbox="allow-scripts" scrolling="no"></iframe>
    </div>
  </div>

</div><!-- /battle-wrap -->

<!-- ── Floating Chat Button ── -->
<button class="chat-bubble-btn" id="chatBubbleBtn" title="Chat" aria-label="Open chat">
  💬
  <span class="chat-unread" id="chatUnread"></span>
</button>

<!-- ── Floating Chat Widget ── -->
<div class="chat-widget" id="chatWidget" aria-hidden="true">
  <div class="chat-whead">
    <div class="chat-whead-icon">⚔️</div>
    <div class="chat-whead-info">
      <div class="chat-whead-title">Room Chat — <?= e($code) ?></div>
      <div class="chat-whead-sub"><span class="chat-online-dot"></span> Live</div>
    </div>
    <button class="chat-whead-close" id="chatWidgetClose" aria-label="Close chat">✕</button>
  </div>
  <div class="chat-msgs" id="chatMessages">
    <div class="cmsg system"><div class="cmsg-bubble">⚡ Battle started — trash talk enabled.</div></div>
  </div>
  <div class="chat-winput">
    <input type="text" id="chatInput" placeholder="Enter your message…" maxlength="300" autocomplete="off">
    <button class="chat-wsend" id="chatSendBtn" aria-label="Send">➤</button>
  </div>
</div>

<!-- ── Confetti Canvas ── -->
<canvas id="confettiCanvas"></canvas>

<!-- ── Result overlay ── -->
<div class="result-overlay" id="resultOverlay">
  <div class="result-card">
    <div class="result-title" id="resultTitle">⚡ Battle Over!</div>
    <div class="result-sub"   id="resultSub">Final Rankings</div>
    <div id="winnerSpotlight" style="display:none" class="winner-spotlight">
      <div class="winner-crown">👑</div>
      <div>
        <div class="winner-label">Winner</div>
        <div class="winner-name" id="winnerName">—</div>
      </div>
      <div class="winner-score-big" id="winnerScore">—</div>
    </div>
    <div class="podium-list" id="podiumList"></div>
    <button class="back-btn" onclick="location.href='versus.php'">← Return to Lobby</button>
  </div>
</div>

<!-- ── Live Spectator Bar ── -->
<div class="spectator-bar" id="spectatorBar">
  <span class="spec-dot"></span>
  <span class="spec-label">Live</span>
  <div class="spec-players" id="specPlayers"></div>
</div>

<?php
// Check if arena is locked (admin protection)
$arenaLocked = false;
try {
  $lq = db()->prepare('SELECT arena_locked FROM rooms WHERE code=?');
  $lq->execute([$code]);
  $lr = $lq->fetch();
  $arenaLocked = !empty($lr['arena_locked']);
} catch(Exception $e) {}
$isAdmin = (isset($user['role']) && (int)$user['role'] === 1);
?>

<!-- ── Arena Lock Overlay ─────────────────────────────────────── -->
<div id="arenaLockOverlay" style="display:none;position:fixed;inset:0;z-index:9999;background:rgba(8,11,18,.96);backdrop-filter:blur(12px);align-items:center;justify-content:center;flex-direction:column;gap:20px;text-align:center;padding:32px">
  <div style="font-size:56px;line-height:1">🔒</div>
  <div style="font-size:22px;font-weight:800;color:#e8eaf0;letter-spacing:-0.5px">Arena Locked</div>
  <div style="font-size:13px;font-family:'Space Mono',monospace;color:#5a6380;max-width:320px;line-height:1.7">
    An admin has locked this arena.<br>Copy, paste, and screenshots are disabled.
  </div>
  <?php if ($isAdmin): ?>
  <button onclick="adminUnlockArena()" style="margin-top:8px;padding:10px 28px;background:rgba(0,255,135,.15);color:#00ff87;border:1px solid rgba(0,255,135,.3);border-radius:10px;font-weight:700;font-size:13px;cursor:pointer;font-family:inherit;transition:all .2s" onmouseover="this.style.background='rgba(0,255,135,.28)'" onmouseout="this.style.background='rgba(0,255,135,.15)'">🔓 Unlock Arena (Admin)</button>
  <?php endif; ?>
</div>

<!-- ── Screenshot Warning Toast ──────────────────────────────── -->
<div id="screenshotWarn" style="display:none;position:fixed;top:70px;left:50%;transform:translateX(-50%);z-index:10000;background:#ff2d6f;color:#fff;font-family:'Space Mono',monospace;font-size:12px;font-weight:700;padding:10px 22px;border-radius:10px;box-shadow:0 6px 24px rgba(255,45,111,.4);pointer-events:none;white-space:nowrap">
  📵 Screenshots are disabled in this arena
</div>

<script>
const ROOM_CODE  = '<?= e($code) ?>';
const MY_USER_ID = <?= (int)$user['id'] ?>;
const HOST_ID    = <?= $hostId ?>;
const CHALLENGE_ID = <?= $challengeId ?>;
const IS_ADMIN   = <?= $isAdmin ? 'true' : 'false' ?>;
const REF_CSS    = <?= json_encode($room['ch_css'] ?? '') ?>;
const REF_HTML   = <?= json_encode($room['ch_html'] ?? '') ?>;
let   ARENA_LOCKED = <?= $arenaLocked ? 'true' : 'false' ?>;
var myScore = 0;
var finished = false;

// ── Arena lock enforcement ────────────────────────────────────────────
function applyArenaLock(locked) {
  ARENA_LOCKED = locked;
  const overlay = document.getElementById('arenaLockOverlay');
  if (locked) {
    overlay.style.display = 'flex';
    // Disable editor paste/copy if not admin
    if (!IS_ADMIN) {
      const ed = document.getElementById('myCode');
      if (ed) {
        ed.setAttribute('oncopy',  'return false');
        ed.setAttribute('onpaste', 'return false');
        ed.setAttribute('oncut',   'return false');
      }
    }
  } else {
    overlay.style.display = 'none';
    const ed = document.getElementById('myCode');
    if (ed) {
      ed.removeAttribute('oncopy');
      ed.removeAttribute('onpaste');
      ed.removeAttribute('oncut');
    }
  }
}

// Block copy/paste/cut globally when locked
document.addEventListener('copy',  function(e){ if(ARENA_LOCKED && !IS_ADMIN){ e.preventDefault(); showLockToast('📋 Copying is disabled in locked arenas'); }});
document.addEventListener('paste', function(e){ if(ARENA_LOCKED && !IS_ADMIN){ e.preventDefault(); showLockToast('📋 Pasting is disabled in locked arenas'); }});
document.addEventListener('cut',   function(e){ if(ARENA_LOCKED && !IS_ADMIN){ e.preventDefault(); showLockToast('✂️ Cutting is disabled in locked arenas'); }});

// Block right-click context menu when locked
document.addEventListener('contextmenu', function(e){ if(ARENA_LOCKED && !IS_ADMIN){ e.preventDefault(); showLockToast('🚫 Right-click is disabled in locked arenas'); }});

// Block keyboard shortcuts: Ctrl+C, Ctrl+V, Ctrl+X, Ctrl+S, Ctrl+A, PrintScreen
document.addEventListener('keydown', function(e){
  if (!ARENA_LOCKED || IS_ADMIN) return;
  const k = e.key.toLowerCase();
  // PrintScreen / screenshot shortcuts
  if (e.key === 'PrintScreen' || (e.metaKey && e.shiftKey && (k==='3'||k==='4'||k==='5'))) {
    e.preventDefault(); flashScreenshotWarning(); return;
  }
  // Copy/paste/cut/selectAll/save
  if ((e.ctrlKey||e.metaKey) && ['c','v','x','a','s'].includes(k)) {
    e.preventDefault(); showLockToast('⚠️ Keyboard shortcuts are disabled in locked arenas');
  }
});

// Screenshot deterrent: detect PrintScreen key and show warning
document.addEventListener('keyup', function(e){
  if (!ARENA_LOCKED || IS_ADMIN) return;
  if (e.key === 'PrintScreen') { flashScreenshotWarning(); }
});

// Screen-capture API detection (Chrome)
if (navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia) {
  const _orig = navigator.mediaDevices.getDisplayMedia.bind(navigator.mediaDevices);
  navigator.mediaDevices.getDisplayMedia = function(opts) {
    if (ARENA_LOCKED && !IS_ADMIN) {
      flashScreenshotWarning();
      return Promise.reject(new DOMException('Not allowed','NotAllowedError'));
    }
    return _orig(opts);
  };
}

// Visibility change: warn when user switches tab (could be screenshotting)
document.addEventListener('visibilitychange', function(){
  if (ARENA_LOCKED && !IS_ADMIN && document.hidden) {
    // Log it silently; can't truly prevent but flag to admin via poll
  }
});

function showLockToast(msg) {
  if (typeof showToast === 'function') { showToast(msg); return; }
  const t = document.createElement('div');
  t.textContent = msg;
  t.style.cssText='position:fixed;top:70px;left:50%;transform:translateX(-50%);z-index:10001;background:#ff8c42;color:#080b12;font-family:Space Mono,monospace;font-size:12px;font-weight:700;padding:8px 20px;border-radius:8px;box-shadow:0 4px 18px rgba(0,0,0,.4);pointer-events:none;white-space:nowrap';
  document.body.appendChild(t);
  setTimeout(()=>t.remove(), 2200);
}

function flashScreenshotWarning() {
  const el = document.getElementById('screenshotWarn');
  if (!el) return;
  el.style.display = 'block';
  setTimeout(()=>{ el.style.display='none'; }, 2800);
  // Briefly overlay the screen to obscure screenshot content
  const cover = document.createElement('div');
  cover.style.cssText='position:fixed;inset:0;z-index:9998;background:#080b12;pointer-events:none;';
  document.body.appendChild(cover);
  setTimeout(()=>cover.remove(), 180);
}

// Poll lock status every 4 seconds
async function pollArenaLock() {
  try {
    const r = await fetch('api.php?action=arena_lock_status&code='+ROOM_CODE);
    const d = await r.json();
    if (d.ok && d.locked !== ARENA_LOCKED) applyArenaLock(d.locked);
  } catch(e){}
}
setInterval(pollArenaLock, 4000);
if (ARENA_LOCKED) applyArenaLock(true);

// Admin quick-lock/unlock from within the arena
async function adminToggleArenaLock() {
  const action = ARENA_LOCKED ? 'arena_unlock' : 'arena_lock';
  const r = await fetch('api.php', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,code:ROOM_CODE})});
  const d = await r.json();
  if (d.ok) {
    applyArenaLock(d.locked);
    showToast(d.locked ? '🔒 Arena locked — copy/paste/screenshots blocked' : '🔓 Arena unlocked');
    const btn = document.getElementById('adminLockBtn');
    if (btn) {
      btn.textContent = d.locked ? '🔓 Unlock' : '🔒 Lock Arena';
      btn.style.background = d.locked ? 'rgba(255,45,111,.15)' : 'rgba(0,255,135,.08)';
      btn.style.color = d.locked ? '#ff2d6f' : '#00ff87';
      btn.style.borderColor = d.locked ? 'rgba(255,45,111,.3)' : 'rgba(0,255,135,.2)';
    }
  }
}
async function adminUnlockArena() {
  const r = await fetch('api.php', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'arena_unlock',code:ROOM_CODE})});
  const d = await r.json();
  if (d.ok) { applyArenaLock(false); showToast('🔓 Arena unlocked'); }
}



/* ── Scoring engine ──────────────────────────────────────────────
   CSS token comparison: extracts property:value pairs from the
   raw REF_CSS / REF_HTML source text and from the user's live
   iframe source. Works even when elements are off-screen or
   invisible (no getComputedStyle, no iframe layout required).
──────────────────────────────────────────────────────────────── */

/* Extract all prop:value tokens from a CSS string */
function _extractTokens(cssText) {
  var tokens = {};
  /* strip comments */
  var clean = cssText.replace(/\/\*[\s\S]*?\*\//g, '');
  /* match prop: value pairs */
  var re = /([\w-]+)\s*:\s*([^;}{]+)/g;
  var m;
  while ((m = re.exec(clean)) !== null) {
    var prop = m[1].trim().toLowerCase();
    var val  = m[2].trim().toLowerCase().replace(/\s+/g,' ');
    if (!prop || !val || val === 'inherit' || val === 'initial' || val === 'unset') continue;
    tokens[prop] = val; /* last-write wins — fine for scoring */
  }
  return tokens;
}

/* Numeric/color fuzzy match */
function _colorDist(a, b) {
  var ra = a.match(/[\d.]+/g), rb = b.match(/[\d.]+/g);
  if (!ra || !rb || ra.length < 3 || rb.length < 3) return 999;
  var d = 0;
  for (var i = 0; i < 3; i++) d += Math.abs(parseFloat(ra[i]) - parseFloat(rb[i]));
  return d;
}

function _valClose(va, vb) {
  if (!va || !vb) return false;
  if (va === vb) return true;
  /* color fuzzy */
  if ((va.includes('rgb') || va.includes('#')) && (vb.includes('rgb') || vb.includes('#'))) {
    return _colorDist(va, vb) < 60;
  }
  /* numeric within 20% */
  var fa = parseFloat(va), fb = parseFloat(vb);
  if (!isNaN(fa) && !isNaN(fb) && fa > 0 && fb > 0) {
    return Math.abs(fa - fb) / Math.max(fa, fb) < 0.20;
  }
  /* first keyword */
  return va.split(/[\s(]/)[0] === vb.split(/[\s(]/)[0];
}

/* Weighted properties — visual impact */
var VISUAL_W = {
  'background':3,'background-color':3,'background-image':3,
  'box-shadow':3,'animation-name':3,'animation':3,
  'border-radius':2,'color':2,'width':2,'height':2,
  'display':2,'position':2,'flex-direction':2,
  'justify-content':2,'align-items':2,'transform':2,
  'clip-path':2,'border':2,'border-color':2
};

function computeScore(userIframe) {
  /* Pull user CSS from the live preview iframe source */
  var userCSS = '';
  var userHTML = '';
  try {
    var ud = userIframe.contentDocument;
    if (ud) {
      /* Grab all <style> text */
      var styles = ud.querySelectorAll('style');
      styles.forEach(function(s){ userCSS += s.textContent + '\n'; });
      userHTML = ud.body ? ud.body.innerHTML : '';
    }
  } catch(e) {}

  /* Also grab raw typed value (faster, always available) */
  var editorVal = (document.getElementById('myCode') || {}).value || '';
  userCSS += '\n' + editorVal;

  var refCSS  = (REF_CSS  || '') + '\n' + (REF_HTML  || '');
  var userSrc = userCSS + '\n' + userHTML;

  var refTokens  = _extractTokens(refCSS);
  var userTokens = _extractTokens(userSrc);

  var refProps = Object.keys(refTokens);
  if (refProps.length === 0) {
    /* No reference tokens — fall back to keyword presence */
    var kw = ['background','color','border-radius','width','height','display',
              'position','flex','grid','animation','transform','box-shadow',
              'border','padding','margin','font-size'];
    var hits = kw.filter(function(k){ return userSrc.includes(k); }).length;
    return Math.min(90, Math.round(hits / kw.length * 100));
  }

  var totalW = 0, matchW = 0;
  refProps.forEach(function(prop) {
    var refVal  = refTokens[prop];
    var userVal = userTokens[prop];
    var w = VISUAL_W[prop] || 1;
    totalW += w;
    if (userVal && _valClose(refVal, userVal)) {
      matchW += w;
    } else if (userVal && _valClose(refVal, userVal)) {
      matchW += w * 0.75;
    }
  });

  return totalW === 0 ? 0 : Math.min(99, Math.round(matchW / totalW * 100));
}

function updateScoreDisplay(score) {
  myScore = score;
  var label = document.getElementById('myAccLabel');
  if (label) label.textContent = score + '%';
  var fill = document.getElementById('matchBarFill');
  if (fill) {
    fill.style.width = score + '%';
    if (score >= 80)      fill.style.background = 'linear-gradient(90deg,#007a40,#00cc66,#00ff87)';
    else if (score >= 50) fill.style.background = 'linear-gradient(90deg,#cc6600,#ff9900,#ffcc00)';
    else                  fill.style.background = 'linear-gradient(90deg,#cc2200,#ff5500,#ff8800)';
  }
}

/* Live preview */
var editor = document.getElementById('myCode');
var saveTimer, scoreDebounce;

editor.addEventListener('input', function() {
  var val = editor.value;
  /* detect if user wrote a full HTML doc, else wrap it */
  var isFullDoc = /^\s*<(!DOCTYPE|html)/i.test(val);
  var srcdoc = isFullDoc ? val
    : '<!DOCTYPE html><html><head><meta charset="utf-8"><style>*{margin:0;padding:0;box-sizing:border-box}body{background:#fff}</style></head><body>' + val + '</body></html>';

  var preview = document.getElementById('livePreview');
  preview.srcdoc = srcdoc;

  clearTimeout(scoreDebounce);
  scoreDebounce = setTimeout(function() {
    preview.onload = function() {
      preview.onload = null;
      var score = computeScore(preview);
      updateScoreDisplay(score);
      clearTimeout(saveTimer);
      saveTimer = setTimeout(function() {
        fetch('api.php', {method:'POST', headers:{'Content-Type':'application/json'},
          body: JSON.stringify({action:'save_code', code:ROOM_CODE, css:val, score:myScore})});
      }, 800);
    };
    /* if onload already fired (fast render), read now */
    if (preview.contentDocument && preview.contentDocument.readyState === 'complete') {
      preview.onload = null;
      var score = computeScore(preview);
      updateScoreDisplay(score);
    }
  }, 400);
});

/* Sync scoreboard */
function syncLobby(){
  if(finished)return;
  fetch('api.php?action=poll&code='+ROOM_CODE).then(function(r){return r.json()}).then(function(data){
    if(!data||data.status==='not_found')return;
    var strip=document.getElementById('livePodiumStrip');
    var board=document.getElementById('multiplayerScoreboard');
    strip.innerHTML='';board.innerHTML='';
    // Build versus battle bar: left player = first, right player = second
    var ps = data.players;
    ps.forEach(function(p){
      var me=p.user_id==MY_USER_ID;
      strip.innerHTML+='<div class="player-chip '+(me?'mine':'')+'">'+p.avatar+' '+p.username+' ('+p.score+'%)</div>';
    });
    if(ps.length>=2){
      var p1=ps[0], p2=ps[1];
      var me1=p1.user_id==MY_USER_ID, me2=p2.user_id==MY_USER_ID;
      var s1=p1.score||0, s2=p2.score||0;
      board.innerHTML=
        '<div class="vs-battle-bar">'+
          '<span class="vs-player-name">'+p1.avatar+' '+(p1.username.length>6?p1.username.slice(0,6)+'…':p1.username)+'</span>'+
          '<div class="vs-bars-center">'+
            '<div class="vs-bar-row">'+
              '<span class="vs-score-pct'+(me1?' me':'')+'">'+s1+'%</span>'+
              '<div class="vs-bar-track left-track">'+
                '<div class="vs-bar-fill left-fill'+(me1?' me-fill':'')+(p1.is_submitted?' submitted-fill':'')+'" style="width:'+s1+'%"></div>'+
              '</div>'+
              '<div class="vs-divider-line"></div>'+
              '<div class="vs-bar-track">'+
                '<div class="vs-bar-fill right-fill'+(me2?' me-fill':'')+(p2.is_submitted?' submitted-fill':'')+'" style="width:'+s2+'%"></div>'+
              '</div>'+
              '<span class="vs-score-pct'+(me2?' me':'')+'">'+s2+'%</span>'+
            '</div>'+
          '</div>'+
          '<span class="vs-player-name right">'+p2.avatar+' '+(p2.username.length>6?p2.username.slice(0,6)+'…':p2.username)+'</span>'+
        '</div>'+
        (p1.is_submitted||p2.is_submitted?
          '<div style="font-size:10px;font-family:var(--font-mono);color:var(--muted);text-align:center;margin-top:2px">'+
            (p1.is_submitted?'<span style="color:var(--green)">'+p1.username+' ✓</span> ':'')+
            (p2.is_submitted?'<span style="color:var(--green)">'+p2.username+' ✓</span>':'')+
          '</div>':'');
    } else if(ps.length===1){
      var p=ps[0], me=p.user_id==MY_USER_ID, s=p.score||0;
      board.innerHTML=
        '<div class="vs-battle-bar">'+
          '<span class="vs-player-name">'+p.avatar+' '+(p.username.length>6?p.username.slice(0,6)+'…':p.username)+'</span>'+
          '<div class="vs-bars-center">'+
            '<div class="vs-bar-row">'+
              '<span class="vs-score-pct'+(me?' me':'')+'">'+s+'%</span>'+
              '<div class="vs-bar-track left-track">'+
                '<div class="vs-bar-fill left-fill'+(me?' me-fill':'')+'" style="width:'+s+'%"></div>'+
              '</div>'+
              '<div class="vs-divider-line"></div>'+
              '<div class="vs-bar-track" style="opacity:.3"><div style="height:100%;width:0%"></div></div>'+
              '<span class="vs-score-pct" style="color:var(--muted)">?</span>'+
            '</div>'+
          '</div>'+
          '<span class="vs-player-name right" style="color:var(--muted)">Waiting…</span>'+
        '</div>';
    }
    syncSpectatorBar(data.players);
    if(data.status==='finished')endBattle(data.players);
  });
}
setInterval(syncLobby,2000);

/* Submit */
document.getElementById('submitBtn').onclick=function(){
  if(finished)return;
  var btn=document.getElementById('submitBtn');
  btn.disabled=true;btn.textContent='⏳ Submitting…';
  fetch('api.php',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({action:'finish',code:ROOM_CODE,score:myScore})})
    .then(function(r){return r.json()}).then(function(d){if(d.players)endBattle(d.players)});
};

/* ── Confetti ── */
function launchConfetti(){
  var canvas=document.getElementById('confettiCanvas');
  canvas.width=window.innerWidth;canvas.height=window.innerHeight;
  canvas.classList.add('active');
  var ctx=canvas.getContext('2d');
  var pieces=[];
  var colors=['#00ff87','#00c8ff','#ffbe00','#ff2d6f','#ffffff','#a855f7'];
  for(var i=0;i<160;i++){
    pieces.push({
      x:Math.random()*canvas.width,
      y:Math.random()*canvas.height-canvas.height,
      w:Math.random()*10+5,h:Math.random()*6+3,
      color:colors[Math.floor(Math.random()*colors.length)],
      rot:Math.random()*360,
      vx:(Math.random()-0.5)*4,
      vy:Math.random()*4+2,
      vr:(Math.random()-0.5)*6,
      opacity:1
    });
  }
  var frame=0;
  function draw(){
    ctx.clearRect(0,0,canvas.width,canvas.height);
    pieces.forEach(function(p){
      ctx.save();
      ctx.translate(p.x+p.w/2,p.y+p.h/2);
      ctx.rotate(p.rot*Math.PI/180);
      ctx.globalAlpha=p.opacity;
      ctx.fillStyle=p.color;
      ctx.fillRect(-p.w/2,-p.h/2,p.w,p.h);
      ctx.restore();
      p.x+=p.vx;p.y+=p.vy;p.rot+=p.vr;
      if(frame>120)p.opacity-=0.008;
    });
    frame++;
    if(frame<240)requestAnimationFrame(draw);
    else{canvas.classList.remove('active');ctx.clearRect(0,0,canvas.width,canvas.height);}
  }
  draw();
}

function endBattle(players){
  if(finished)return;finished=true;
  document.getElementById('spectatorBar').classList.remove('visible');
  players.sort(function(a,b){return b.score-a.score});
  var medals=['🥇','🥈','🥉'];
  var win=players[0]&&players[0].user_id==MY_USER_ID;

  // Winner spotlight
  if(players[0]){
    var ws=document.getElementById('winnerSpotlight');
    ws.style.display='flex';
    document.getElementById('winnerName').textContent=players[0].avatar+' '+players[0].username;
    document.getElementById('winnerScore').textContent=players[0].score+'%';
  }

  document.getElementById('podiumList').innerHTML=players.map(function(p,i){
    var isFirst=i===0;
    return '<div class="podium-item'+(isFirst?' first-place':'')+'"><span class="podium-rank">'+(medals[i]||'#'+(i+1))+'</span><span class="podium-name">'+p.avatar+' '+p.username+(p.user_id==MY_USER_ID?' <span style="color:var(--green);font-size:10px">(You)</span>':'')+'</span><span class="podium-score">'+p.score+'%</span></div>';
  }).join('');

  var titleEl=document.getElementById('resultTitle');
  titleEl.textContent=win?'🏆 You Win!':'⚡ Battle Over!';
  titleEl.className='result-title '+(win?'win':'lose');
  document.getElementById('resultSub').textContent=win?'Congratulations — highest score!':'Better luck next time!';
  document.getElementById('resultOverlay').classList.add('active');

  if(win) setTimeout(launchConfetti, 300);
}

/* ── Live spectator bar ── */
function syncSpectatorBar(players){
  var bar=document.getElementById('spectatorBar');
  var strip=document.getElementById('specPlayers');
  if(!players||players.length===0){bar.classList.remove('visible');return;}
  bar.classList.add('visible');
  strip.innerHTML=players.map(function(p){
    var me=p.user_id==MY_USER_ID;
    return '<div class="spec-chip">'+(me?'<span style="color:var(--green)">You</span>':'<span>'+p.avatar+' '+p.username+'</span>')+'<span class="spec-pct">'+p.score+'%</span></div>';
  }).join('');
}

/* ── Floating Chat ── */
var chatLastId=0,chatUnreadCount=0,chatIsOpen=false;
var chatWidget=document.getElementById('chatWidget');
var chatBubbleBtn=document.getElementById('chatBubbleBtn');
var chatUnreadEl=document.getElementById('chatUnread');
var chatMsgsEl=document.getElementById('chatMessages');

function toggleChat(force){
  chatIsOpen=force!==undefined?force:!chatIsOpen;
  chatWidget.classList.toggle('open',chatIsOpen);
  chatWidget.setAttribute('aria-hidden',String(!chatIsOpen));
  if(chatIsOpen){
    chatUnreadCount=0;chatUnreadEl.classList.remove('show');
    chatBubbleBtn.textContent='✕';chatBubbleBtn.appendChild(chatUnreadEl);
    chatMsgsEl.scrollTop=chatMsgsEl.scrollHeight;
    document.getElementById('chatInput').focus();
  } else {
    chatBubbleBtn.textContent='💬';chatBubbleBtn.appendChild(chatUnreadEl);
  }
}
chatBubbleBtn.addEventListener('click',function(){toggleChat()});
document.getElementById('chatWidgetClose').addEventListener('click',function(){toggleChat(false)});

function esc(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}

function appendMsg(m,isNew){
  var mine=m.user_id==MY_USER_ID;
  var t=new Date(m.sent_at.replace(' ','T'));
  var ts=t.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
  var wrap=document.createElement('div');
  wrap.className='cmsg '+(mine?'mine':'theirs');
  wrap.innerHTML='<div class="cmsg-author">'+esc(m.avatar)+' '+esc(m.username)+'</div><div class="cmsg-bubble">'+esc(m.message)+'</div><div class="cmsg-time">'+ts+'</div>';
  chatMsgsEl.appendChild(wrap);
  chatMsgsEl.scrollTop=chatMsgsEl.scrollHeight;
  if(isNew&&!mine&&!chatIsOpen){
    chatUnreadCount++;
    chatUnreadEl.textContent=chatUnreadCount>9?'9+':chatUnreadCount;
    chatUnreadEl.classList.add('show');
  }
}

function pollChat(){
  if(finished)return;
  fetch('api.php?action=poll_chat&code='+ROOM_CODE+'&after='+chatLastId)
    .then(function(r){return r.json()}).then(function(data){
      if(!data.messages||!data.messages.length)return;
      data.messages.forEach(function(m){chatLastId=Math.max(chatLastId,parseInt(m.id));appendMsg(m,true)});
    }).catch(function(){});
}
setInterval(pollChat,1500);pollChat();

function sendChat(){
  var inp=document.getElementById('chatInput');
  var msg=inp.value.trim();if(!msg)return;inp.value='';
  fetch('api.php',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({action:'send_chat',code:ROOM_CODE,message:msg})});
}
document.getElementById('chatSendBtn').addEventListener('click',sendChat);
document.getElementById('chatInput').addEventListener('keydown',function(e){
  if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendChat()}
});

/* Timer */
var timerEl=document.getElementById('timerBox');
var timerSec=300; /* 5:00 default — adjust to match your ch_time if needed */
setInterval(function(){
  if(finished)return;
  timerSec--;
  var m=String(Math.floor(timerSec/60)).padStart(2,'0');
  var s=String(timerSec%60).padStart(2,'0');
  timerEl.textContent=m+':'+s;
  if(timerSec<=60)timerEl.classList.add('urgent');
  if(timerSec<=0)document.getElementById('submitBtn').click();
},1000);

/* ── Heartbeat: tell server this user is online ── */
function sendHeartbeat(){
  fetch('api.php',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({action:'heartbeat'})});
}
sendHeartbeat();
setInterval(sendHeartbeat,20000);

/* ── Online presence: check if host is online ── */
function checkHostOnline(){
  if(!HOST_ID)return;
  fetch('api.php?action=get_online&ids[]='+HOST_ID)
    .then(function(r){return r.json();}).then(function(data){
      var dot=document.getElementById('hostOnlineDot');
      var label=document.getElementById('hostOnlineLabel');
      if(!dot)return;
      var isOnline=data.online&&data.online.map(Number).indexOf(HOST_ID)!==-1;
      dot.classList.toggle('online',isOnline);
      label.textContent=isOnline?'Host is online':'Host is offline';
    });
}
if(document.getElementById('hostOnlineDot')){checkHostOnline();setInterval(checkHostOnline,15000);}

/* ── Reactions ── */
var myReactions=[];
function loadReactions(){
  if(!CHALLENGE_ID)return;
  fetch('api.php?action=get_reactions&challenge_id='+CHALLENGE_ID)
    .then(function(r){return r.json();}).then(function(data){
      myReactions=data.mine||[];
      renderReactions(data.counts||{});
    });
}
function renderReactions(counts){
  document.querySelectorAll('.react-btn').forEach(function(btn){
    var emoji=btn.dataset.emoji;
    var cnt=counts[emoji]||0;
    btn.querySelector('.react-count').textContent=cnt||'';
    btn.classList.toggle('active',myReactions.indexOf(emoji)!==-1);
  });
}
function toggleReaction(emoji){
  if(!CHALLENGE_ID)return;
  fetch('api.php',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({action:'toggle_reaction',challenge_id:CHALLENGE_ID,emoji:emoji})})
    .then(function(r){return r.json();}).then(function(data){
      if(!data.ok)return;
      if(data.reacted){myReactions.push(emoji);}
      else{myReactions=myReactions.filter(function(e){return e!==emoji;});}
      renderReactions(data.counts||{});
    });
}
loadReactions();

/* ── Comments ── */
var commentLastId=0;
function loadComments(){
  if(!CHALLENGE_ID)return;
  fetch('api.php?action=get_comments&challenge_id='+CHALLENGE_ID+'&after='+commentLastId)
    .then(function(r){return r.json();}).then(function(data){
      if(!data.comments||!data.comments.length)return;
      var list=document.getElementById('commentsList');
      if(list&&list.querySelector('.no-comments'))list.innerHTML='';
      data.comments.forEach(function(c){
        commentLastId=Math.max(commentLastId,parseInt(c.id));
        var div=document.createElement('div');
        div.className='comment-item';
        var time=new Date(c.created_at.replace(' ','T')).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
        div.innerHTML='<div class="comment-meta">'+escHtml(c.avatar+' '+c.username)+' · '+time+'</div>'
                     +'<div class="comment-text">'+escHtml(c.comment)+'</div>';
        if(list)list.appendChild(div);
      });
      if(list)list.scrollTop=list.scrollHeight;
    });
}
function postComment(){
  if(!CHALLENGE_ID)return;
  var input=document.getElementById('commentInput');
  var text=input.value.trim();
  if(!text)return;
  input.value='';
  fetch('api.php',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({action:'add_comment',challenge_id:CHALLENGE_ID,comment:text})})
    .then(function(r){return r.json();}).then(function(d){if(d.ok)loadComments();});
}
var cInput=document.getElementById('commentInput');
if(cInput)cInput.addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();postComment();}});
if(CHALLENGE_ID){loadComments();setInterval(loadComments,5000);}

function escHtml(s){var d=document.createElement('div');d.textContent=s;return d.innerHTML;}

/* ══════════════════════════════════════════════════════════════
   IN-BATTLE LIVE VIDEO  — WebRTC peer-to-peer
   Uses battle_signals table in api.php for signaling.
   Both players see a small draggable video widget.
══════════════════════════════════════════════════════════════ */

var ICE_SERVERS = [
  {urls:'stun:stun.l.google.com:19302'},
  {urls:'stun:stun1.l.google.com:19302'}
];

var _bvLocalStream  = null;
var _bvPeers        = {};
var _bvLastSignalId = 0;
var _bvSignalTimer  = null;
var _bvWidgetOpen   = false;

async function bvSendSignal(type, payload, toUser) {
  var fd = new FormData();
  fd.append('action',  'battle_signal');
  fd.append('code',    ROOM_CODE);
  fd.append('type',    type);
  fd.append('payload', JSON.stringify(payload));
  fd.append('to_user', toUser || 0);
  await fetch('api.php', {method:'POST', body:fd}).catch(function(){});
}

async function bvPollSignals() {
  try {
    var fd = new FormData();
    fd.append('action',   'poll_battle_signals');
    fd.append('code',     ROOM_CODE);
    fd.append('since_id', _bvLastSignalId);
    var res  = await fetch('api.php', {method:'POST', body:fd});
    var data = await res.json();
    if (!data.ok) return;
    if (data.max_id > _bvLastSignalId) _bvLastSignalId = data.max_id;
    for (var i = 0; i < data.signals.length; i++) await bvHandleSignal(data.signals[i]);
  } catch(e) {}
}

function bvGetOrCreatePeer(remoteId) {
  if (_bvPeers[remoteId]) return _bvPeers[remoteId];
  var pc = new RTCPeerConnection({iceServers: ICE_SERVERS});
  _bvPeers[remoteId] = pc;
  if (_bvLocalStream) {
    _bvLocalStream.getTracks().forEach(function(t){ pc.addTrack(t, _bvLocalStream); });
  }
  pc.ontrack = function(e) { bvShowRemoteVideo(remoteId, e.streams[0]); };
  pc.onicecandidate = function(e) {
    if (e.candidate) bvSendSignal('ice', {candidate: e.candidate}, remoteId);
  };
  pc.onconnectionstatechange = function() {
    if (pc.connectionState === 'failed' || pc.connectionState === 'disconnected') {
      pc.close(); delete _bvPeers[remoteId]; bvHideRemoteVideo(remoteId);
    }
  };
  return pc;
}

async function bvHandleSignal(sig) {
  var fromId = parseInt(sig.from_user);
  var p; try { p = JSON.parse(sig.payload); } catch(e) { return; }

  if (sig.type === 'join') {
    var pc = bvGetOrCreatePeer(fromId);
    if (pc.signalingState !== 'stable') return;
    var offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    bvSendSignal('offer', {sdp: pc.localDescription}, fromId);
  }
  if (sig.type === 'offer') {
    var pc = bvGetOrCreatePeer(fromId);
    if (pc.signalingState !== 'stable') return;
    await pc.setRemoteDescription(new RTCSessionDescription(p.sdp)).catch(function(){});
    var answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    bvSendSignal('answer', {sdp: pc.localDescription}, fromId);
  }
  if (sig.type === 'answer') {
    var pc = _bvPeers[fromId];
    if (pc && pc.signalingState === 'have-local-offer') {
      await pc.setRemoteDescription(new RTCSessionDescription(p.sdp)).catch(function(){});
    }
  }
  if (sig.type === 'ice') {
    var pc = _bvPeers[fromId];
    if (pc && p.candidate) await pc.addIceCandidate(new RTCIceCandidate(p.candidate)).catch(function(){});
  }
}

function bvShowRemoteVideo(userId, stream) {
  var grid = document.getElementById('bv-remote-grid');
  if (!grid) return;
  var container = document.getElementById('bv-remote-' + userId);
  if (!container) {
    container = document.createElement('div');
    container.id = 'bv-remote-' + userId;
    container.style.cssText = 'position:relative;width:100%;aspect-ratio:4/3;background:#111;border-radius:6px;overflow:hidden';
    var vid = document.createElement('video');
    vid.autoplay = true; vid.playsInline = true;
    vid.style.cssText = 'width:100%;height:100%;object-fit:cover;display:block';
    container.appendChild(vid);
    grid.appendChild(container);
  }
  var vid = container.querySelector('video');
  if (vid) { vid.srcObject = stream; vid.play().catch(function(){}); }
  bvOpenWidget();
}

function bvHideRemoteVideo(userId) {
  var el = document.getElementById('bv-remote-' + userId);
  if (el) el.remove();
}

async function bvStartCamera() {
  var btn = document.getElementById('bv-cam-btn');
  if (btn) btn.disabled = true;
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    if (btn) { btn.disabled = false; btn.textContent = 'Not supported'; }
    return;
  }
  if (location.protocol !== 'https:' && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1') {
    showToast('Camera needs HTTPS');
    if (btn) { btn.disabled = false; }
    return;
  }
  try {
    _bvLocalStream = await navigator.mediaDevices.getUserMedia({video: true, audio: true});
  } catch(err) {
    if (btn) { btn.disabled = false; btn.textContent = '🎥 Retry'; }
    showToast('Camera denied or unavailable');
    return;
  }
  var localVid = document.getElementById('bv-local-video');
  if (localVid) { localVid.srcObject = _bvLocalStream; localVid.style.display = 'block'; localVid.play().catch(function(){}); }
  var placeholder = document.getElementById('bv-local-placeholder');
  if (placeholder) placeholder.style.display = 'none';
  if (btn) { btn.textContent = '🔴 Live'; btn.disabled = true; btn.style.cssText += ';color:#ff2d6f;border-color:#ff2d6f'; }
  Object.keys(_bvPeers).forEach(function(uid) {
    var pc = _bvPeers[uid];
    _bvLocalStream.getTracks().forEach(function(t){ pc.addTrack(t, _bvLocalStream); });
  });
  bvSendSignal('join', {}, 0);
  bvOpenWidget();
}

function bvStopCamera() {
  if (_bvLocalStream) { _bvLocalStream.getTracks().forEach(function(t){ t.stop(); }); _bvLocalStream = null; }
  var localVid = document.getElementById('bv-local-video');
  if (localVid) { localVid.srcObject = null; localVid.style.display = 'none'; }
  var placeholder = document.getElementById('bv-local-placeholder');
  if (placeholder) placeholder.style.display = 'flex';
  var btn = document.getElementById('bv-cam-btn');
  if (btn) { btn.textContent = '🎥 Camera'; btn.disabled = false; btn.style.cssText = btn.style.cssText.replace(/color:[^;]+;?/g,'').replace(/border-color:[^;]+;?/g,''); }
}

function bvOpenWidget() {
  var w = document.getElementById('bv-widget');
  if (w) { w.style.display = 'flex'; _bvWidgetOpen = true; }
}

function bvToggleWidget() {
  var w = document.getElementById('bv-widget');
  if (!w) return;
  _bvWidgetOpen = !_bvWidgetOpen;
  w.style.display = _bvWidgetOpen ? 'flex' : 'none';
}

/* Draggable widget */
(function(){
  var drag = false, ox = 0, oy = 0, startX = 0, startY = 0;
  document.addEventListener('DOMContentLoaded', function(){
    var widget = document.getElementById('bv-widget');
    var handle = document.getElementById('bv-handle');
    if (!widget || !handle) return;
    handle.addEventListener('mousedown', function(e){
      drag=true; startX=e.clientX; startY=e.clientY;
      var r=widget.getBoundingClientRect(); ox=r.left; oy=r.top; e.preventDefault();
    });
    document.addEventListener('mousemove', function(e){
      if(!drag)return;
      widget.style.left=(ox+e.clientX-startX)+'px'; widget.style.top=(oy+e.clientY-startY)+'px';
      widget.style.right='auto'; widget.style.bottom='auto';
    });
    document.addEventListener('mouseup', function(){ drag=false; });
    handle.addEventListener('touchstart',function(e){
      var t=e.touches[0]; drag=true; startX=t.clientX; startY=t.clientY;
      var r=widget.getBoundingClientRect(); ox=r.left; oy=r.top;
    },{passive:true});
    document.addEventListener('touchmove',function(e){
      if(!drag)return; var t=e.touches[0];
      widget.style.left=(ox+t.clientX-startX)+'px'; widget.style.top=(oy+t.clientY-startY)+'px';
      widget.style.right='auto'; widget.style.bottom='auto';
    },{passive:true});
    document.addEventListener('touchend',function(){ drag=false; });
  });
})();

/* Boot — announce presence, start polling */
if (!finished) {
  bvSendSignal('join', {}, 0);
  _bvSignalTimer = setInterval(bvPollSignals, 1200);
  bvPollSignals();
}

</script>

<!-- ── Battle Video Widget ── -->
<style>
#bv-fab{position:fixed;bottom:70px;right:16px;z-index:3000;width:44px;height:44px;border-radius:50%;background:#131820;border:1px solid rgba(0,255,135,.3);color:#00ff87;font-size:18px;cursor:pointer;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 16px rgba(0,0,0,.5);transition:transform .15s}
#bv-fab:hover{transform:scale(1.1)}
#bv-widget{display:none;position:fixed;bottom:120px;right:16px;z-index:2999;flex-direction:column;width:220px;background:#0d1117;border:1px solid rgba(0,255,135,.2);border-radius:12px;overflow:hidden;box-shadow:0 8px 32px rgba(0,0,0,.6)}
#bv-handle{padding:7px 10px;background:#131820;display:flex;align-items:center;justify-content:space-between;cursor:grab;user-select:none;font-size:11px;font-family:'Space Mono',monospace;color:rgba(255,255,255,.6);border-bottom:1px solid rgba(255,255,255,.06)}
#bv-handle:active{cursor:grabbing}
#bv-body{padding:8px;display:flex;flex-direction:column;gap:6px;max-height:340px;overflow-y:auto}
#bv-local-wrap{position:relative;width:100%;aspect-ratio:4/3;background:#111;border-radius:6px;overflow:hidden;flex-shrink:0}
#bv-local-video{width:100%;height:100%;object-fit:cover;display:none}
#bv-local-placeholder{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:28px;color:rgba(255,255,255,.15)}
#bv-remote-grid{display:flex;flex-direction:column;gap:6px}
#bv-footer{padding:7px 8px;border-top:1px solid rgba(255,255,255,.06);display:flex;gap:6px}
.bv-btn{flex:1;padding:5px 0;border-radius:6px;border:1px solid rgba(0,255,135,.25);background:rgba(0,255,135,.06);color:#00ff87;font-family:'Space Mono',monospace;font-size:10px;font-weight:700;cursor:pointer;transition:background .15s}
.bv-btn:hover{background:rgba(0,255,135,.14)}
.bv-btn:disabled{opacity:.45;cursor:default}
</style>

<button id="bv-fab" onclick="bvToggleWidget()" title="Battle Cam">🎥</button>

<div id="bv-widget">
  <div id="bv-handle">
    <span>🎥 Battle Cam</span>
    <span onclick="bvToggleWidget()" style="cursor:pointer;padding:0 4px;font-size:14px">✕</span>
  </div>
  <div id="bv-body">
    <div id="bv-local-wrap">
      <video id="bv-local-video" autoplay muted playsinline webkit-playsinline></video>
      <div id="bv-local-placeholder">🙂</div>
    </div>
    <div id="bv-remote-grid"></div>
  </div>
  <div id="bv-footer">
    <button class="bv-btn" id="bv-cam-btn" onclick="bvStartCamera()">🎥 Camera</button>
    <button class="bv-btn" onclick="bvStopCamera()">⏹ Stop</button>
  </div>
</div>
<script src="assets/security.js"></script>
<?php endif; ?>
<?php pageFooter(); ?>
