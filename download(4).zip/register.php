<?php
require_once 'includes/config.php';
require_once 'includes/layout.php';

if (auth()) { header('Location: index.php'); exit; }

$error = '';
$avatars = ['🧑','👩','🧙','🤖','👾','🦊','🐼','🐉'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = trim($_POST['username'] ?? '');
  $email    = trim($_POST['email']    ?? '');
  $password = $_POST['password']      ?? '';
  $avatar   = $_POST['avatar']        ?? '🧑';
  $confirm  = $_POST['confirm']       ?? '';

  if (strlen($username) < 3 || strlen($username) > 32) {
    $error = 'Username must be 3–32 characters.';
  } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $error = 'Invalid email address.';
  } elseif (strlen($password) < 6) {
    $error = 'Password must be at least 6 characters.';
  } elseif ($password !== $confirm) {
    $error = 'Passwords do not match.';
  } elseif (!in_array($avatar, $avatars)) {
    $avatar = '🧑';
  }

  if (!$error) {
    try {
      $hash = password_hash($password, PASSWORD_BCRYPT);
      $stmt = db()->prepare('INSERT INTO users (username,email,password,avatar) VALUES (?,?,?,?)');
      $stmt->execute([$username, $email, $hash, $avatar]);
      $id = (int)db()->lastInsertId();
      $_SESSION['user'] = ['id'=>$id,'username'=>$username,'avatar'=>$avatar];
      flash('success', 'Welcome, '.$username.'! 🎉');
      header('Location: index.php'); exit;
    } catch (PDOException $ex) {
      $error = str_contains($ex->getMessage(), 'username') ? 'Username already taken.' : 'Email already registered.';
    }
  }
}

pageHeader('Register');
?>
<div class="form-card">
  <h2>Create Account</h2>
  <p>Join codeMe and battle other developers.</p>
  <?php if ($error): ?>
    <div class="alert alert-error"><?= e($error) ?></div>
  <?php endif; ?>
  <form method="POST">
    <div class="field">
      <label>Username</label>
      <input type="text" name="username" value="<?= e($_POST['username'] ?? '') ?>" placeholder="cooldev42" required>
    </div>
    <div class="field">
      <label>Email</label>
      <input type="email" name="email" value="<?= e($_POST['email'] ?? '') ?>" placeholder="you@example.com" required>
    </div>
    <div class="field">
      <label>Password</label>
      <input type="password" name="password" placeholder="Min 6 characters" required>
    </div>
    <div class="field">
      <label>Confirm Password</label>
      <input type="password" name="confirm" placeholder="Repeat password" required>
    </div>
    <div class="field">
      <label>Pick Your Avatar</label>
      <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:4px">
        <?php foreach ($avatars as $av): ?>
          <label style="cursor:pointer;font-size:26px;opacity:<?= ($av === ($_POST['avatar'] ?? '🧑') ? '1' : '.4') ?>;transition:opacity .2s">
            <input type="radio" name="avatar" value="<?= $av ?>" <?= $av === ($_POST['avatar'] ?? '🧑') ? 'checked' : '' ?> style="display:none" onchange="document.querySelectorAll('.av-opt').forEach(x=>x.style.opacity='.4');this.parentNode.style.opacity='1'">
            <span class="av-opt"><?= $av ?></span>
          </label>
        <?php endforeach; ?>
      </div>
    </div>
    <button type="submit" class="btn-full">Create Account</button>
  </form>
  <div class="form-footer">Already have an account? <a href="login.php">Log in</a></div>
</div>
<script src="assets/security.js"></script>
<?php pageFooter(); ?>
