<?php
// api.php — Multiplayer JSON API
require_once 'includes/config.php';

header('Content-Type: application/json');

if (!auth()) { echo json_encode(['error'=>'not_logged_in']); exit; }
$user   = auth();
$action = $_GET['action'] ?? '';

$body = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $raw  = file_get_contents('php://input');
  $body = json_decode($raw, true) ?? [];
  $action = $body['action'] ?? $action;
}

// ── Helper: fetch room + players ──────────────────────────────────────
function getRoomData(string $code): ?array {
  $db = db();
  $s  = $db->prepare('SELECT * FROM rooms WHERE code=?');
  $s->execute([$code]);
  $room = $s->fetch();
  if (!$room) return null;

  $ps = $db->prepare('
    SELECT rp.user_id, rp.score, rp.is_submitted, u.username, u.avatar
    FROM room_players rp
    JOIN users u ON u.id=rp.user_id
    WHERE rp.room_id=? ORDER BY rp.joined_at ASC
  ');
  $ps->execute([$room['id']]);
  $room['players'] = $ps->fetchAll();
  return $room;
}

// ── room_status — Lobby polling ───────────────────────────────────────
if ($action === 'room_status') {
  $code = strtoupper(trim($_GET['code'] ?? ''));
  $room = getRoomData($code);
  if (!$room) { echo json_encode(['status'=>'not_found']); exit; }
  echo json_encode([
    'status'       => $room['status'],
    'player_count' => count($room['players']),
    'host_id'      => $room['host_id'],
    'players'      => $room['players'],
  ]);
  exit;
}

// ── start_room — Host manually starts an open room ────────────────────
if ($action === 'start_room') {
  $code = strtoupper(trim($body['code'] ?? ''));
  $room = getRoomData($code);

  if (!$room) { echo json_encode(['ok'=>false,'error'=>'not_found']); exit; }
  if ($room['host_id'] != $user['id']) { echo json_encode(['ok'=>false,'error'=>'not_host']); exit; }
  if ($room['status'] !== 'waiting') { echo json_encode(['ok'=>true]); exit; } // already started

  db()->prepare("UPDATE rooms SET status='active' WHERE id=?")->execute([$room['id']]);
  echo json_encode(['ok'=>true]);
  exit;
}

// ── poll — Live sync for active battle ───────────────────────────────
if ($action === 'poll') {
  $code = strtoupper(trim($_GET['code'] ?? ''));
  $room = getRoomData($code);
  if (!$room) { echo json_encode(['status'=>'not_found']); exit; }
  echo json_encode([
    'status'    => $room['status'],
    'winner_id' => $room['winner_id'],
    'players'   => $room['players'],
  ]);
  exit;
}

// ── track_view — Log when a player views the challenge reference ───────
if ($action === 'track_view') {
  $code = strtoupper(trim($body['code'] ?? ''));
  $room = getRoomData($code);
  if (!$room) { echo json_encode(['ok'=>false]); exit; }

  if ($room['challenge_id']) {
    $ch = db()->prepare('SELECT id, difficulty FROM challenges WHERE id=?');
    $ch->execute([$room['challenge_id']]);
    $challenge = $ch->fetch();
    if ($challenge) {
      db()->prepare('INSERT INTO target_views (user_id, challenge_id, difficulty) VALUES (?,?,?)')
        ->execute([$user['id'], $challenge['id'], $challenge['difficulty']]);
    }
  }
  echo json_encode(['ok'=>true]);
  exit;
}

// ── save_code — Persist typing progress + score ───────────────────────
if ($action === 'save_code') {
  $code  = strtoupper(trim($body['code'] ?? ''));
  $css   = substr($body['css'] ?? '', 0, 15000);
  $score = min(100, max(0, (int)($body['score'] ?? 0)));
  $room  = getRoomData($code);

  if (!$room || $room['status'] === 'finished') { echo json_encode(['ok'=>false]); exit; }

  db()->prepare('UPDATE room_players SET code_input=?, score=? WHERE room_id=? AND user_id=?')
    ->execute([$css, $score, $room['id'], $user['id']]);

  echo json_encode(['ok'=>true]);
  exit;
}

// ── finish — Player submits; evaluate standings ───────────────────────
if ($action === 'finish') {
  $code  = strtoupper(trim($body['code'] ?? ''));
  $score = min(100, max(0, (int)($body['score'] ?? 0)));
  $room  = getRoomData($code);

  if (!$room) { echo json_encode(['error'=>'not_found']); exit; }

  if ($room['status'] !== 'finished') {
    // Save final score + mark submitted
    db()->prepare('UPDATE room_players SET is_submitted=1, score=? WHERE room_id=? AND user_id=?')
      ->execute([$score, $room['id'], $user['id']]);

    $room = getRoomData($code);

    // Check if all players submitted (or host is finishing for open rooms)
    $allDone = true;
    foreach ($room['players'] as $p) {
      if (!$p['is_submitted']) { $allDone = false; break; }
    }

    if ($allDone || $room['host_id'] == $user['id']) {
      // Find winner
      $highestScore = -1;
      $winnerId     = $room['host_id'];
      foreach ($room['players'] as $p) {
        if ($p['score'] > $highestScore) {
          $highestScore = $p['score'];
          $winnerId     = $p['user_id'];
        }
      }

      db()->prepare("UPDATE rooms SET status='finished', winner_id=?, finished_at=NOW() WHERE id=?")
        ->execute([$winnerId, $room['id']]);

      foreach ($room['players'] as $p) {
        if ($p['user_id'] == $winnerId) {
          db()->prepare('UPDATE users SET wins=wins+1, total_score=total_score+? WHERE id=?')
            ->execute([$p['score'], $p['user_id']]);
        } else {
          db()->prepare('UPDATE users SET losses=losses+1, total_score=total_score+? WHERE id=?')
            ->execute([$p['score'], $p['user_id']]);
        }
      }
    }
  }

  $room = getRoomData($code);
  echo json_encode([
    'status'    => $room['status'],
    'winner_id' => $room['winner_id'],
    'players'   => $room['players'],
  ]);
  exit;
}


// ── Auto-create room_messages table if missing ───────────────────────
try {
  db()->exec("CREATE TABLE IF NOT EXISTS room_messages (
    id       INT AUTO_INCREMENT PRIMARY KEY,
    room_id  INT NOT NULL,
    user_id  INT NOT NULL,
    message  VARCHAR(300) NOT NULL,
    sent_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
} catch (Exception $e) {}

// ── send_chat — Post a chat message to a room ─────────────────────────
if ($action === 'send_chat') {
  $code    = strtoupper(trim($body['code'] ?? ''));
  $message = trim(substr($body['message'] ?? '', 0, 300));
  if (!$code || !$message) { echo json_encode(['ok'=>false,'error'=>'missing']); exit; }

  $room = getRoomData($code);
  if (!$room) { echo json_encode(['ok'=>false,'error'=>'not_found']); exit; }

  // Must be a player in this room
  $inRoom = false;
  foreach ($room['players'] as $p) {
    if ($p['user_id'] == $user['id']) { $inRoom = true; break; }
  }
  if (!$inRoom && $room['host_id'] != $user['id']) { echo json_encode(['ok'=>false,'error'=>'not_in_room']); exit; }

  db()->prepare('INSERT INTO room_messages (room_id, user_id, message) VALUES (?,?,?)')
    ->execute([$room['id'], $user['id'], $message]);

  echo json_encode(['ok'=>true, 'id'=>(int)db()->lastInsertId()]);
  exit;
}

// ── poll_chat — Fetch messages newer than a given id ─────────────────
if ($action === 'poll_chat') {
  $code   = strtoupper(trim($_GET['code'] ?? ''));
  $after  = (int)($_GET['after'] ?? 0);
  $room   = getRoomData($code);
  if (!$room) { echo json_encode(['messages'=>[]]); exit; }

  $msgs = db()->prepare('
    SELECT m.id, m.message, m.sent_at, u.username, u.avatar, u.id AS user_id
    FROM room_messages m JOIN users u ON u.id=m.user_id
    WHERE m.room_id=? AND m.id>?
    ORDER BY m.id ASC LIMIT 30
  ');
  $msgs->execute([$room['id'], $after]);
  echo json_encode(['messages' => $msgs->fetchAll()]);
  exit;
}

echo json_encode(['error'=>'unknown_action']);

// ── Auto-create presence + reference tables ───────────────────────────
try {
  db()->exec("CREATE TABLE IF NOT EXISTS user_presence (
    user_id   INT NOT NULL PRIMARY KEY,
    last_seen DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

  db()->exec("CREATE TABLE IF NOT EXISTS reference_comments (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    challenge_id INT NOT NULL,
    user_id      INT NOT NULL,
    comment      VARCHAR(500) NOT NULL,
    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (challenge_id) REFERENCES challenges(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id)      REFERENCES users(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

  db()->exec("CREATE TABLE IF NOT EXISTS reference_reactions (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    challenge_id INT NOT NULL,
    user_id      INT NOT NULL,
    emoji        VARCHAR(10) NOT NULL,
    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_react (challenge_id, user_id, emoji),
    FOREIGN KEY (challenge_id) REFERENCES challenges(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id)      REFERENCES users(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
} catch (Exception $e) {}

// ── heartbeat — Client pings to mark user as online ──────────────────
if ($action === 'heartbeat') {
  db()->prepare('INSERT INTO user_presence (user_id, last_seen) VALUES (?, NOW())
                 ON DUPLICATE KEY UPDATE last_seen=NOW()')
      ->execute([$user['id']]);
  echo json_encode(['ok' => true]);
  exit;
}

// ── get_online — Check if specific user ids are online (seen < 30s) ──
if ($action === 'get_online') {
  $ids = array_map('intval', (array)($_GET['ids'] ?? []));
  if (empty($ids)) { echo json_encode(['online' => []]); exit; }
  $placeholders = implode(',', array_fill(0, count($ids), '?'));
  $stmt = db()->prepare("SELECT user_id FROM user_presence
                          WHERE user_id IN ($placeholders)
                          AND last_seen >= NOW() - INTERVAL 30 SECOND");
  $stmt->execute($ids);
  $online = array_column($stmt->fetchAll(), 'user_id');
  echo json_encode(['online' => $online]);
  exit;
}

// ── add_comment — Post a comment on a challenge reference ─────────────
if ($action === 'add_comment') {
  $challenge_id = (int)($body['challenge_id'] ?? 0);
  $comment      = trim(substr($body['comment'] ?? '', 0, 500));
  if (!$challenge_id || !$comment) { echo json_encode(['ok'=>false,'error'=>'missing']); exit; }

  // Verify challenge exists
  $ch = db()->prepare('SELECT id FROM challenges WHERE id=?');
  $ch->execute([$challenge_id]);
  if (!$ch->fetch()) { echo json_encode(['ok'=>false,'error'=>'not_found']); exit; }

  db()->prepare('INSERT INTO reference_comments (challenge_id, user_id, comment) VALUES (?,?,?)')
     ->execute([$challenge_id, $user['id'], $comment]);

  echo json_encode(['ok'=>true, 'id'=>(int)db()->lastInsertId()]);
  exit;
}

// ── get_comments — Fetch comments for a challenge ─────────────────────
if ($action === 'get_comments') {
  $challenge_id = (int)($_GET['challenge_id'] ?? 0);
  $after        = (int)($_GET['after'] ?? 0);
  if (!$challenge_id) { echo json_encode(['comments'=>[]]); exit; }

  $stmt = db()->prepare('
    SELECT rc.id, rc.comment, rc.created_at,
           u.id AS user_id, u.username, u.avatar, u.avatar_img
    FROM reference_comments rc
    JOIN users u ON u.id = rc.user_id
    WHERE rc.challenge_id=? AND rc.id>?
    ORDER BY rc.id ASC LIMIT 50
  ');
  $stmt->execute([$challenge_id, $after]);
  echo json_encode(['comments' => $stmt->fetchAll()]);
  exit;
}

// ── toggle_reaction — Add or remove an emoji reaction ─────────────────
if ($action === 'toggle_reaction') {
  $challenge_id = (int)($body['challenge_id'] ?? 0);
  $emoji        = mb_substr(trim($body['emoji'] ?? ''), 0, 10);
  $allowed      = ['🔥','👏','😍','💡','🎯'];
  if (!$challenge_id || !$emoji || !in_array($emoji, $allowed)) {
    echo json_encode(['ok'=>false,'error'=>'invalid']); exit;
  }

  // Check if already reacted
  $existing = db()->prepare('SELECT id FROM reference_reactions WHERE challenge_id=? AND user_id=? AND emoji=?');
  $existing->execute([$challenge_id, $user['id'], $emoji]);

  if ($existing->fetch()) {
    // Un-react
    db()->prepare('DELETE FROM reference_reactions WHERE challenge_id=? AND user_id=? AND emoji=?')
       ->execute([$challenge_id, $user['id'], $emoji]);
    $reacted = false;
  } else {
    // React
    db()->prepare('INSERT IGNORE INTO reference_reactions (challenge_id, user_id, emoji) VALUES (?,?,?)')
       ->execute([$challenge_id, $user['id'], $emoji]);
    $reacted = true;
  }

  // Return updated counts
  $counts = db()->prepare('SELECT emoji, COUNT(*) AS cnt FROM reference_reactions WHERE challenge_id=? GROUP BY emoji');
  $counts->execute([$challenge_id]);
  $rows = $counts->fetchAll();
  $result = [];
  foreach ($rows as $r) $result[$r['emoji']] = (int)$r['cnt'];

  echo json_encode(['ok'=>true, 'reacted'=>$reacted, 'counts'=>$result]);
  exit;
}

// ── get_reactions — Fetch reaction counts + current user's picks ───────
if ($action === 'get_reactions') {
  $challenge_id = (int)($_GET['challenge_id'] ?? 0);
  if (!$challenge_id) { echo json_encode(['counts'=>[],'mine'=>[]]); exit; }

  $counts = db()->prepare('SELECT emoji, COUNT(*) AS cnt FROM reference_reactions WHERE challenge_id=? GROUP BY emoji');
  $counts->execute([$challenge_id]);
  $countRows = $counts->fetchAll();
  $result = [];
  foreach ($countRows as $r) $result[$r['emoji']] = (int)$r['cnt'];

  $mine = db()->prepare('SELECT emoji FROM reference_reactions WHERE challenge_id=? AND user_id=?');
  $mine->execute([$challenge_id, $user['id']]);
  $myEmojis = array_column($mine->fetchAll(), 'emoji');

  echo json_encode(['counts' => $result, 'mine' => $myEmojis]);
  exit;
}

// ── battle_signal — WebRTC signaling for in-battle video ─────────────────────
if ($action === 'battle_signal') {
  $room_code = trim($_POST['code'] ?? '');
  $type      = trim($_POST['type'] ?? '');
  $payload   = trim($_POST['payload'] ?? '');
  $to_user   = (int)($_POST['to_user'] ?? 0); // 0 = broadcast to all in room
  if (!$room_code || !$type) { echo json_encode(['ok'=>false]); exit; }

  // Auto-create table
  db()->exec("CREATE TABLE IF NOT EXISTS `battle_signals` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `room_code` VARCHAR(16) NOT NULL,
    `from_user` INT NOT NULL,
    `to_user` INT NOT NULL DEFAULT 0,
    `type` VARCHAR(32) NOT NULL,
    `payload` TEXT NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX(`room_code`,`created_at`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

  db()->prepare("INSERT INTO battle_signals (room_code,from_user,to_user,type,payload) VALUES (?,?,?,?,?)")
     ->execute([$room_code, $user['id'], $to_user, $type, $payload]);

  // Cleanup signals older than 60s
  db()->prepare("DELETE FROM battle_signals WHERE room_code=? AND created_at < DATE_SUB(NOW(), INTERVAL 60 SECOND)")
     ->execute([$room_code]);

  echo json_encode(['ok'=>true]); exit;
}

// ── poll_battle_signals — Poll WebRTC signals for battle video ────────────────
if ($action === 'poll_battle_signals') {
  $room_code = trim($_GET['code'] ?? $_POST['code'] ?? '');
  $since_id  = (int)($_GET['since_id'] ?? $_POST['since_id'] ?? 0);
  if (!$room_code) { echo json_encode(['ok'=>false,'signals'=>[]]); exit; }

  $stmt = db()->prepare("SELECT id,from_user,to_user,type,payload FROM battle_signals
    WHERE room_code=? AND id>? AND (to_user=0 OR to_user=?) AND from_user!=?
    ORDER BY id ASC LIMIT 30");
  $stmt->execute([$room_code, $since_id, $user['id'], $user['id']]);
  $sigs = $stmt->fetchAll();
  $maxId = $since_id;
  foreach ($sigs as $s) if ((int)$s['id'] > $maxId) $maxId = (int)$s['id'];
  echo json_encode(['ok'=>true,'signals'=>$sigs,'max_id'=>$maxId]); exit;
}
