<?php
session_start();
// If already logged in, skip landing and go to home
if (!empty($_SESSION['user_id'])) {
    header('Location: home.php');
    exit;
}

require_once 'includes/config.php';
require_once 'includes/layout.php';

$user    = auth();
$success = getFlash('success');

// Quick stats for logged-in user
$myStats = null;
if ($user) {
  $stmt = db()->prepare('SELECT wins,losses,total_score FROM users WHERE id=?');
  $stmt->execute([$user['id']]);
  $myStats = $stmt->fetch();
}

// Recent finished battles
$recent = db()->query(
  'SELECT r.*, u1.username AS host_name, u2.username AS guest_name, uw.username AS winner_name
   FROM rooms r
   JOIN users u1 ON u1.id = r.host_id
   LEFT JOIN users u2 ON u2.id = r.guest_id
   LEFT JOIN users uw ON uw.id = r.winner_id
   WHERE r.status = "finished"
   ORDER BY r.finished_at DESC LIMIT 6'
)->fetchAll();

pageHeader('Home');
?>


<style>
.hero{text-align:center;padding:80px 20px 60px}
.hero h1{font-size:56px;font-weight:800;letter-spacing:-3px;line-height:1}
.hero h1 .hi{color:var(--green)}
.hero p{color:var(--muted);font-family:var(--font-mono);font-size:13px;margin-top:16px;line-height:1.7}
.hero-btns{display:flex;gap:14px;justify-content:center;margin-top:32px;flex-wrap:wrap}
.big-btn{padding:14px 36px;border-radius:12px;font-size:15px;font-weight:700;cursor:pointer;border:none;letter-spacing:.5px;transition:transform .2s,filter .2s}
.big-btn:hover{transform:translateY(-2px);filter:brightness(1.1)}
.stats-bar{display:flex;gap:24px;justify-content:center;flex-wrap:wrap;margin:40px 0}
.stat-pill{background:var(--bg2);border:1px solid var(--border);border-radius:14px;padding:20px 32px;text-align:center}
.stat-pill .val{font-size:32px;font-weight:800;color:var(--green)}
.stat-pill .lbl{font-size:11px;color:var(--muted);font-family:var(--font-mono);letter-spacing:1px;margin-top:4px}
.match-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px;max-width:960px;margin:0 auto}
.match-card{background:var(--bg2);border:1px solid var(--border);border-radius:14px;padding:18px}
.match-vs{display:flex;align-items:center;justify-content:space-between;font-weight:700;font-size:14px}
.match-vs .winner{color:var(--green)}
.match-vs .vs-sep{font-family:var(--font-mono);font-size:11px;color:var(--muted)}
.match-time{font-size:11px;color:var(--muted);font-family:var(--font-mono);margin-top:8px}
</style>

<div class="hero">
  <h1>Code. <span class="hi">Battle.</span> Win.</h1>
  <p>Real-time 1v1 coding battles.<br>Write better CSS faster than your opponent.</p>
  <div class="hero-btns">
    <a href="versus.php" class="big-btn" style="background:var(--green);color:#080b12">⚔ Start Battle</a>
    <a href="leaderboard.php" class="big-btn" style="background:var(--bg2);color:#fff;border:1px solid var(--border)">🏆 Leaderboard</a>
  </div>
</div>

<?php if ($success): ?>
  <div style="max-width:440px;margin:0 auto 24px" class="alert alert-success"><?= e($success) ?></div>
<?php endif; ?>

<?php if ($myStats): ?>
<div class="stats-bar">
  <div class="stat-pill"><div class="val"><?= $myStats['wins'] ?></div><div class="lbl">Wins</div></div>
  <div class="stat-pill"><div class="val"><?= $myStats['losses'] ?></div><div class="lbl">Losses</div></div>
  <div class="stat-pill"><div class="val"><?= $myStats['total_score'] ?></div><div class="lbl">Score</div></div>
  <div class="stat-pill">
    <div class="val"><?= $myStats['wins'] + $myStats['losses'] > 0 ? round($myStats['wins'] / ($myStats['wins'] + $myStats['losses']) * 100) : 0 ?>%</div>
    <div class="lbl">Win Rate</div>
  </div>
</div>
<?php endif; ?>

<div class="page">
  <?php if ($recent): ?>
    <div class="sec-label">Recent Battles</div>
    <div class="match-grid">
      <?php foreach ($recent as $r): ?>
        <div class="match-card">
          <div class="match-vs">
            <span class="<?= $r['winner_id'] == $r['host_id'] ? 'winner' : '' ?>"><?= e($r['host_name']) ?></span>
            <span class="vs-sep">VS</span>
            <span class="<?= $r['winner_id'] == $r['guest_id'] ? 'winner' : '' ?>"><?= e($r['guest_name'] ?? '—') ?></span>
          </div>
          <div style="margin-top:6px;font-size:12px;color:var(--muted)">
            <?= $r['host_score'] ?> — <?= $r['guest_score'] ?> pts
            <?php if ($r['winner_name']): ?> · 🏆 <?= e($r['winner_name']) ?><?php endif; ?>
          </div>
          <div class="match-time"><?= date('M j, g:i a', strtotime($r['finished_at'])) ?></div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>
<script src="assets/security.js"></script>
<?php pageFooter(); ?>
