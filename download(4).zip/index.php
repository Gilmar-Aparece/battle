<?php
require_once 'includes/config.php';

// If already logged in → go straight to the app
if (auth()) {
    if (isAdmin()) {
        header('Location: admin/index.php');
        exit;
    }
    header('Location: versus.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#080b12">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="description" content="codeMe — Real-time 1v1 CSS coding battle game">
  <link rel="manifest" href="manifest.json">
  <link rel="apple-touch-icon" href="icon-192.png">
  <title>codeMe — Real-Time CSS Battle Game</title>
  <link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;600;700;800&display=swap" rel="stylesheet">
  <style>
    :root {
      --green:#00ff87; --pink:#ff2d6f; --blue:#00c8ff; --yellow:#ffe14d;
      --bg:#080b12; --bg2:#0e1320; --bg3:#141b2d;
      --border:rgba(255,255,255,0.07); --text:#e8eaf0; --muted:#5a6380;
      --font-head:'Syne',sans-serif; --font-mono:'Space Mono',monospace;
    }
    *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
    html{scroll-behavior:smooth}
    body{font-family:var(--font-head);background:var(--bg);color:var(--text);min-height:100vh;overflow-x:hidden}

    /* noise */
    body::after{content:'';position:fixed;inset:0;pointer-events:none;z-index:999;
      background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.035'/%3E%3C/svg%3E");
      opacity:.5}

    /* ── Navbar ── */
    nav{position:fixed;top:0;left:0;right:0;z-index:200;
      display:flex;align-items:center;justify-content:space-between;
      padding:0 40px;height:62px;
      background:rgba(8,11,18,0.88);backdrop-filter:blur(20px);
      border-bottom:1px solid var(--border)}
    .logo{display:flex;align-items:center;gap:10px;font-size:20px;font-weight:800;letter-spacing:-.5px;text-decoration:none;color:inherit}
    .logo-dot{width:10px;height:10px;border-radius:50%;background:var(--green);
      box-shadow:0 0 12px var(--green);animation:pulse 2s ease-in-out infinite}
    @keyframes pulse{0%,100%{box-shadow:0 0 8px var(--green)}50%{box-shadow:0 0 22px var(--green),0 0 40px rgba(0,255,135,.3)}}
    .logo em{color:var(--green);font-style:normal}
    .nav-right{display:flex;align-items:center;gap:10px}
    .btn{display:inline-flex;align-items:center;gap:8px;padding:9px 22px;border-radius:9px;
      font-size:13px;font-weight:700;cursor:pointer;border:none;letter-spacing:.3px;
      font-family:var(--font-head);text-decoration:none;transition:all .2s}
    .btn-outline{background:transparent;color:var(--muted);border:1px solid var(--border)}
    .btn-outline:hover{color:#fff;border-color:rgba(255,255,255,.2)}
    .btn-green{background:var(--green);color:#080b12}
    .btn-green:hover{filter:brightness(1.1);transform:translateY(-1px)}
    .btn-purple{background:linear-gradient(135deg,#7c3aed,#a855f7);color:#fff;
      box-shadow:0 4px 20px rgba(124,58,237,.35)}
    .btn-purple:hover{transform:translateY(-2px);box-shadow:0 8px 32px rgba(124,58,237,.5)}

    /* ── Hero ── */
    .hero{position:relative;padding:150px 40px 100px;text-align:center;overflow:hidden}
    .hero-grid{position:absolute;inset:0;pointer-events:none;
      background-image:linear-gradient(rgba(255,255,255,.025) 1px,transparent 1px),
                       linear-gradient(90deg,rgba(255,255,255,.025) 1px,transparent 1px);
      background-size:60px 60px;
      mask-image:radial-gradient(ellipse 80% 80% at 50% 50%,black 0%,transparent 100%)}
    .orb{position:absolute;border-radius:50%;filter:blur(70px);pointer-events:none}
    .orb1{width:600px;height:500px;top:-80px;left:50%;transform:translateX(-50%);
      background:radial-gradient(circle,rgba(0,255,135,.1) 0%,transparent 70%);
      animation:floatA 9s ease-in-out infinite}
    .orb2{width:320px;height:320px;top:80px;right:8%;
      background:radial-gradient(circle,rgba(255,45,111,.09) 0%,transparent 70%);
      animation:floatB 7s ease-in-out infinite}
    .orb3{width:260px;height:260px;top:120px;left:6%;
      background:radial-gradient(circle,rgba(0,200,255,.09) 0%,transparent 70%);
      animation:floatB 8s 2s ease-in-out infinite}
    @keyframes floatA{0%,100%{transform:translateX(-50%) translateY(0)}50%{transform:translateX(-50%) translateY(-28px)}}
    @keyframes floatB{0%,100%{transform:translateY(0)}50%{transform:translateY(-18px)}}

    .eyebrow{display:inline-flex;align-items:center;gap:8px;
      font-family:var(--font-mono);font-size:11px;color:var(--green);letter-spacing:2px;text-transform:uppercase;
      background:rgba(0,255,135,.07);border:1px solid rgba(0,255,135,.2);
      padding:6px 18px;border-radius:100px;margin-bottom:28px;
      animation:fadeUp .6s ease both}
    .eyebrow-dot{width:6px;height:6px;border-radius:50%;background:var(--green)}

    .hero h1{font-size:clamp(54px,10vw,104px);font-weight:800;line-height:.93;
      letter-spacing:-4px;animation:fadeUp .6s .1s ease both}
    .hero h1 .hi{color:var(--green)}
    .hero h1 .outline{-webkit-text-stroke:2px rgba(255,255,255,.25);color:transparent}
    .hero-sub{font-family:var(--font-mono);font-size:13px;color:var(--muted);
      line-height:1.8;margin:24px auto 0;max-width:460px;animation:fadeUp .6s .2s ease both}

    .cta-group{display:flex;gap:12px;justify-content:center;flex-wrap:wrap;
      margin-top:40px;animation:fadeUp .6s .3s ease both}
    .cta-main{padding:17px 40px;border-radius:13px;font-size:15px;font-weight:800;
      box-shadow:0 0 30px rgba(0,255,135,.25)}
    .cta-main:hover{box-shadow:0 8px 44px rgba(0,255,135,.45);transform:translateY(-3px) scale(1.02)}
    .cta-ghost{padding:17px 32px;border-radius:13px;font-size:15px;font-weight:700}
    .cta-apk{padding:15px 32px;border-radius:13px;font-size:14px;font-weight:700}

    /* stats */
    .stats-row{display:flex;justify-content:center;max-width:680px;margin:60px auto 0;
      background:var(--bg2);border:1px solid var(--border);border-radius:16px;overflow:hidden;
      animation:fadeUp .6s .4s ease both}
    .stat{flex:1;text-align:center;padding:22px 16px;border-right:1px solid var(--border)}
    .stat:last-child{border-right:none}
    .stat-val{font-size:26px;font-weight:800;color:var(--green);letter-spacing:-1px}
    .stat-lbl{font-family:var(--font-mono);font-size:10px;color:var(--muted);
      letter-spacing:1.5px;text-transform:uppercase;margin-top:4px}

    @keyframes fadeUp{from{opacity:0;transform:translateY(22px)}to{opacity:1;transform:none}}

    /* ── Battle mockup ── */
    .mockup-wrap{max-width:960px;margin:0 auto;padding:0 40px 80px}
    .window{background:var(--bg2);border:1px solid var(--border);border-radius:16px;overflow:hidden}
    .titlebar{display:flex;align-items:center;gap:7px;padding:13px 18px;
      background:var(--bg3);border-bottom:1px solid var(--border)}
    .tb-dot{width:11px;height:11px;border-radius:50%}
    .tb-label{font-family:var(--font-mono);font-size:11px;color:var(--muted);margin-left:8px}
    .battle-bar{display:grid;grid-template-columns:1fr auto 1fr;gap:16px;
      padding:20px;align-items:center}
    .p-card{background:var(--bg3);border-radius:12px;padding:14px;border:1px solid var(--border)}
    .p-head{display:flex;align-items:center;gap:10px;margin-bottom:12px}
    .p-av{width:30px;height:30px;border-radius:50%;display:flex;align-items:center;
      justify-content:center;font-size:13px;font-weight:800;color:#080b12}
    .p-name{font-size:13px;font-weight:700}
    .p-pts{margin-left:auto;font-family:var(--font-mono);font-size:17px;font-weight:700}
    .prog{height:4px;background:var(--bg);border-radius:2px;overflow:hidden}
    .prog-fill{height:100%;border-radius:2px}
    .vs-txt{text-align:center;font-family:var(--font-mono);font-size:11px;
      color:var(--pink);font-weight:700;letter-spacing:2px}
    .code-cols{display:grid;grid-template-columns:1fr 1fr;border-top:1px solid var(--border)}
    .code-col{padding:22px;font-family:var(--font-mono);font-size:12px;line-height:1.9;
      border-right:1px solid var(--border)}
    .code-col:last-child{border-right:none}
    .col-label{font-size:10px;color:var(--muted);letter-spacing:1.5px;text-transform:uppercase;margin-bottom:12px}
    .cg{color:var(--green)}.cp{color:var(--pink)}.cb{color:var(--blue)}.cy{color:var(--yellow)}.cm{color:var(--muted)}
    .cursor{display:inline-block;width:7px;height:13px;background:var(--green);
      margin-left:2px;vertical-align:middle;animation:blink 1s step-end infinite}
    @keyframes blink{0%,100%{opacity:1}50%{opacity:0}}

    /* ── Sections ── */
    .section{max-width:1060px;margin:0 auto;padding:60px 40px}
    .sec-label{font-family:var(--font-mono);font-size:11px;color:var(--green);
      letter-spacing:3px;text-transform:uppercase;margin-bottom:14px}
    .sec-title{font-size:clamp(28px,5vw,46px);font-weight:800;letter-spacing:-2px;
      line-height:1.1;margin-bottom:44px}

    .feat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(290px,1fr));gap:14px}
    .feat-card{background:var(--bg2);border:1px solid var(--border);border-radius:15px;
      padding:26px;transition:border-color .3s,transform .3s;position:relative;overflow:hidden}
    .feat-card::after{content:'';position:absolute;top:0;left:0;right:0;height:2px;
      background:linear-gradient(90deg,transparent,var(--c),transparent);
      opacity:0;transition:opacity .3s}
    .feat-card:hover{border-color:rgba(255,255,255,.12);transform:translateY(-3px)}
    .feat-card:hover::after{opacity:1}
    .feat-icon{font-size:26px;margin-bottom:14px}
    .feat-title{font-size:15px;font-weight:700;margin-bottom:7px}
    .feat-desc{font-family:var(--font-mono);font-size:11px;color:var(--muted);line-height:1.75}

    /* steps */
    .steps{display:grid;grid-template-columns:repeat(4,1fr);border:1px solid var(--border);
      border-radius:16px;overflow:hidden;background:var(--bg2)}
    .step{padding:28px 24px;border-right:1px solid var(--border);position:relative}
    .step:last-child{border-right:none}
    .step-num{font-family:var(--font-mono);font-size:10px;color:var(--muted);
      letter-spacing:2px;margin-bottom:14px}
    .step-title{font-size:15px;font-weight:700;margin-bottom:7px}
    .step-desc{font-family:var(--font-mono);font-size:11px;color:var(--muted);line-height:1.7}
    .step-arrow{position:absolute;right:-11px;top:50%;transform:translateY(-50%);
      width:20px;height:20px;background:var(--bg3);border:1px solid var(--border);
      border-radius:50%;display:flex;align-items:center;justify-content:center;
      font-size:9px;color:var(--green);z-index:1}

    /* ── APK download ── */
    .dl-section{margin:0 40px 80px;
      background:linear-gradient(135deg,#0c1020 0%,#12092a 50%,#0c1020 100%);
      border:1px solid rgba(120,50,220,.2);border-radius:22px;padding:60px 48px;
      text-align:center;position:relative;overflow:hidden}
    .dl-section::before{content:'';position:absolute;inset:0;
      background:radial-gradient(ellipse 70% 60% at 50% 0%,rgba(124,58,237,.13) 0%,transparent 70%);
      pointer-events:none}
    .dl-label{font-family:var(--font-mono);font-size:11px;color:#a855f7;
      letter-spacing:3px;text-transform:uppercase;margin-bottom:14px}
    .dl-title{font-size:clamp(28px,5vw,46px);font-weight:800;letter-spacing:-2px;margin-bottom:12px}
    .dl-sub{font-family:var(--font-mono);font-size:12px;color:var(--muted);
      line-height:1.8;margin-bottom:38px}
    .apk-btn{display:inline-flex;align-items:center;gap:14px;padding:20px 50px;
      border-radius:14px;background:linear-gradient(135deg,#7c3aed,#a855f7);
      color:#fff;font-size:16px;font-weight:800;text-decoration:none;cursor:pointer;
      border:none;font-family:var(--font-head);letter-spacing:.3px;
      transition:all .25s cubic-bezier(.34,1.56,.64,1);
      box-shadow:0 8px 40px rgba(124,58,237,.4);position:relative}
    .apk-btn:hover{transform:translateY(-4px) scale(1.03);
      box-shadow:0 16px 60px rgba(124,58,237,.6)}
    .apk-btn:active{transform:scale(.97)}
    .apk-btn-sub{font-family:var(--font-mono);font-size:10px;font-weight:400;
      letter-spacing:1px;opacity:.75;display:block;margin-top:2px}
    .dl-chips{display:flex;gap:20px;justify-content:center;flex-wrap:wrap;margin-top:28px}
    .chip{display:flex;align-items:center;gap:6px;font-family:var(--font-mono);
      font-size:11px;color:var(--muted)}
    .chip-dot{color:#a855f7}
    .dl-note{margin-top:20px;font-family:var(--font-mono);font-size:10px;
      color:var(--muted);opacity:.55;line-height:1.6}
    .dl-note a{color:inherit;text-decoration:underline}

    /* ── footer ── */
    footer{border-top:1px solid var(--border);padding:36px 40px;
      display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:16px}
    .foot-logo{font-size:16px;font-weight:800}
    .foot-logo em{color:var(--green);font-style:normal}
    .foot-links{display:flex;gap:22px}
    .foot-link{font-family:var(--font-mono);font-size:11px;color:var(--muted);
      text-decoration:none;transition:color .2s}
    .foot-link:hover{color:#fff}
    .foot-copy{font-family:var(--font-mono);font-size:10px;color:var(--muted);opacity:.4}

    /* reveal */
    .reveal{opacity:0;transform:translateY(28px);transition:opacity .65s ease,transform .65s ease}
    .reveal.on{opacity:1;transform:none}

    /* responsive */
    @media(max-width:768px){
      nav{padding:0 20px}
      .hero{padding:120px 20px 80px}
      .hero h1{letter-spacing:-2px}
      .stats-row{flex-wrap:wrap}
      .stat{min-width:50%;border-bottom:1px solid var(--border)}
      .mockup-wrap,.section{padding-left:20px;padding-right:20px}
      .code-cols{grid-template-columns:1fr}
      .code-col{border-right:none;border-bottom:1px solid var(--border)}
      .steps{grid-template-columns:1fr 1fr}
      .step-arrow{display:none}
      .dl-section{margin:0 20px 60px;padding:40px 24px}
      footer{padding:28px 20px;flex-direction:column;align-items:flex-start}
      .battle-bar{grid-template-columns:1fr}
    }
    @media(max-width:480px){
      .steps{grid-template-columns:1fr}
      .step{border-right:none;border-bottom:1px solid var(--border)}
      .step:last-child{border-bottom:none}
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav>
  <a class="logo" href="index.php">
    <div class="logo-dot"></div>
    code<em>Me</em>
  </a>
  <div class="nav-right">
    <a href="login.php"    class="btn btn-outline">Log in</a>
    <a href="register.php" class="btn btn-green">Register</a>
  </div>
</nav>

<!-- Hero -->
<section class="hero">
  <div class="hero-grid"></div>
  <div class="orb orb1"></div>
  <div class="orb orb2"></div>
  <div class="orb orb3"></div>

  <div class="eyebrow"><div class="eyebrow-dot"></div>Real-time 1v1 CSS battle game</div>

  <h1>Code.<br><span class="hi">Battle.</span><br><span class="outline">Win.</span></h1>

  <p class="hero-sub">
    Challenge opponents to live coding duels.<br>
    Write better CSS faster. Climb the ranks.
  </p>

  <div class="cta-group">
    <a href="register.php" class="btn btn-green cta-main">⚔&nbsp; Start Battling</a>
    <a href="leaderboard.php" class="btn btn-outline cta-ghost">🏆&nbsp; Leaderboard</a>
    <a href="codeMe.apk" download class="btn btn-purple cta-apk">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="white">
        <path d="M17.523 15.341a.696.696 0 110-1.392.696.696 0 010 1.392zm-11.046 0a.696.696 0 110-1.392.696.696 0 010 1.392zm11.405-6.354l1.397-2.42a.29.29 0 10-.502-.292l-1.416 2.452A8.456 8.456 0 0012 8.14a8.456 8.456 0 00-5.361 1.588L5.22 7.275a.29.29 0 10-.502.291l1.397 2.42C3.916 11.35 2.625 13.373 2.625 15.7H21.375c0-2.327-1.29-4.35-3.493-5.713z"/>
      </svg>
      Download APK
    </a>
  </div>

  <div class="stats-row">
    <div class="stat"><div class="stat-val">1v1</div><div class="stat-lbl">Live Battles</div></div>
    <div class="stat"><div class="stat-val">CSS</div><div class="stat-lbl">Challenge Type</div></div>
    <div class="stat"><div class="stat-val">100%</div><div class="stat-lbl">Real-time</div></div>
    <div class="stat"><div class="stat-val">Free</div><div class="stat-lbl">Always</div></div>
  </div>
</section>

<!-- Battle mockup -->
<div class="mockup-wrap reveal">
  <div class="window">
    <div class="titlebar">
      <div class="tb-dot" style="background:#ff5f57"></div>
      <div class="tb-dot" style="background:#ffbd2e"></div>
      <div class="tb-dot" style="background:#28c840"></div>
      <div class="tb-label">Battle Arena — Room #4F9A2C · 01:24 remaining</div>
    </div>
    <div class="battle-bar">
      <div class="p-card">
        <div class="p-head">
          <div class="p-av" style="background:linear-gradient(135deg,var(--green),var(--blue))">A</div>
          <div class="p-name">you</div>
          <div class="p-pts" style="color:var(--green)">87<span style="font-size:11px;opacity:.5"> pts</span></div>
        </div>
        <div class="prog"><div class="prog-fill" style="width:87%;background:var(--green)"></div></div>
      </div>
      <div class="vs-txt">VS</div>
      <div class="p-card">
        <div class="p-head">
          <div class="p-av" style="background:linear-gradient(135deg,var(--pink),#ff8c00)">R</div>
          <div class="p-name">rival_x</div>
          <div class="p-pts" style="color:var(--pink)">64<span style="font-size:11px;opacity:.5"> pts</span></div>
        </div>
        <div class="prog"><div class="prog-fill" style="width:64%;background:var(--pink)"></div></div>
      </div>
    </div>
    <div class="code-cols">
      <div class="code-col">
        <div class="col-label">Your editor</div>
        <span class="cm">/* style the button */</span><br>
        <span class="cp">.btn</span> {<br>
        &nbsp;&nbsp;<span class="cb">background</span>: <span class="cg">#00ff87</span>;<br>
        &nbsp;&nbsp;<span class="cb">border-radius</span>: <span class="cy">12px</span>;<br>
        &nbsp;&nbsp;<span class="cb">padding</span>: <span class="cy">14px 32px</span>;<br>
        &nbsp;&nbsp;<span class="cb">font-weight</span>: <span class="cy">700</span>;<br>
        &nbsp;&nbsp;<span class="cb">color</span>: <span class="cg">#080b12</span>;<span class="cursor"></span><br>
        }
      </div>
      <div class="code-col">
        <div class="col-label">Live preview</div>
        <div style="padding:18px;background:#070a11;border-radius:10px;text-align:center;margin-top:4px">
          <div style="display:inline-block;background:#00ff87;border-radius:12px;padding:14px 32px;font-weight:700;color:#080b12;font-size:13px;font-family:'Syne',sans-serif">
            Submit ✓
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Features -->
<section class="section reveal">
  <div class="sec-label">// features</div>
  <div class="sec-title">Built for competitors.</div>
  <div class="feat-grid">
    <div class="feat-card" style="--c:var(--green)">
      <div class="feat-icon">⚡</div>
      <div class="feat-title">Real-time Battles</div>
      <div class="feat-desc">Live 1v1 matches synced every 2 seconds. No WebSockets — pure efficient polling.</div>
    </div>
    <div class="feat-card" style="--c:var(--blue)">
      <div class="feat-icon">🎯</div>
      <div class="feat-title">CSS Challenges</div>
      <div class="feat-desc">Recreate a target design using CSS. Score based on accuracy and code efficiency.</div>
    </div>
    <div class="feat-card" style="--c:var(--pink)">
      <div class="feat-icon">🏆</div>
      <div class="feat-title">Live Leaderboard</div>
      <div class="feat-desc">Global rankings powered by SQL RANK(). Every win pushes you higher up the board.</div>
    </div>
    <div class="feat-card" style="--c:#a855f7">
      <div class="feat-icon">📱</div>
      <div class="feat-title">PWA + APK</div>
      <div class="feat-desc">Install as a Progressive Web App or download the Android APK for native feel.</div>
    </div>
    <div class="feat-card" style="--c:var(--yellow)">
      <div class="feat-icon">👤</div>
      <div class="feat-title">Player Profiles</div>
      <div class="feat-desc">Track wins, losses, score, and win rate. Watch your stats climb after every battle.</div>
    </div>
    <div class="feat-card" style="--c:var(--green)">
      <div class="feat-icon">🔐</div>
      <div class="feat-title">Instant Rooms</div>
      <div class="feat-desc">Create a room, share a 6-char code. Your opponent joins in seconds — no setup needed.</div>
    </div>
  </div>
</section>

<!-- How it works -->
<section class="section reveal" style="padding-top:0">
  <div class="sec-label">// how to play</div>
  <div class="sec-title">Ready in 4 steps.</div>
  <div class="steps">
    <div class="step">
      <div class="step-num">01 /</div>
      <div class="step-title">Register</div>
      <div class="step-desc">Create your account. Pick a username and join the arena.</div>
      <div class="step-arrow">→</div>
    </div>
    <div class="step">
      <div class="step-num">02 /</div>
      <div class="step-title">Create Room</div>
      <div class="step-desc">Hit Versus, create a room, share your 6-char code with a friend.</div>
      <div class="step-arrow">→</div>
    </div>
    <div class="step">
      <div class="step-num">03 /</div>
      <div class="step-title">Battle Live</div>
      <div class="step-desc">Both players enter the arena. Write CSS to match the challenge.</div>
      <div class="step-arrow">→</div>
    </div>
    <div class="step">
      <div class="step-num">04 /</div>
      <div class="step-title">Climb Ranks</div>
      <div class="step-desc">Win, earn score, and watch your name rise on the leaderboard.</div>
    </div>
  </div>
</section>

<!-- APK Download -->
<div class="dl-section reveal">
  <div class="dl-label">// android app</div>
  <div class="dl-title">Take battles with you.</div>
  <p class="dl-sub">
    Download the codeMe APK and battle anywhere.<br>
    No app store needed — just enable Unknown Sources and install.
  </p>
  <a href="codeMe.apk" download class="apk-btn">
    <svg width="32" height="32" viewBox="0 0 24 24" fill="white">
      <path d="M17.523 15.341a.696.696 0 110-1.392.696.696 0 010 1.392zm-11.046 0a.696.696 0 110-1.392.696.696 0 010 1.392zm11.405-6.354l1.397-2.42a.29.29 0 10-.502-.292l-1.416 2.452A8.456 8.456 0 0012 8.14a8.456 8.456 0 00-5.361 1.588L5.22 7.275a.29.29 0 10-.502.291l1.397 2.42C3.916 11.35 2.625 13.373 2.625 15.7H21.375c0-2.327-1.29-4.35-3.493-5.713z"/>
    </svg>
    <div>
      <div>Download APK</div>
      <span class="apk-btn-sub">Android · 1.1MB · Free</span>
    </div>
  </a>
  <div class="dl-chips">
    <div class="chip"><span class="chip-dot">✓</span> No Play Store required</div>
    <div class="chip"><span class="chip-dot">✓</span> Enable Unknown Sources to install</div>
    <div class="chip"><span class="chip-dot">✓</span> Same features as web version</div>
    <div class="chip"><span class="chip-dot">✓</span> Offline-capable PWA</div>
  </div>
  <div class="dl-note">
    By downloading you agree to our <a href="#">Terms of Use</a>.
    Also available as a <a href="manifest.json">PWA</a> — tap "Add to Home Screen" in your browser.
  </div>
</div>

<!-- Footer -->
<footer>
  <div class="foot-logo">code<em>Me</em></div>
  <div class="foot-links">
    <a href="login.php"      class="foot-link">Login</a>
    <a href="register.php"   class="foot-link">Register</a>
    <a href="leaderboard.php" class="foot-link">Leaderboard</a>
  </div>
  <div class="foot-copy">© 2026 codeMe · CSS Battle Arena</div>
</footer>

<script>
  const obs = new IntersectionObserver(els => {
    els.forEach(e => { if (e.isIntersecting) { e.target.classList.add('on'); obs.unobserve(e.target); } });
  }, { threshold: 0.08 });
  document.querySelectorAll('.reveal').forEach(el => obs.observe(el));
</script>
</body>
</html>
