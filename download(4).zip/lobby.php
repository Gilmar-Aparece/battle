<?php
require_once 'includes/config.php';
require_once 'includes/layout.php';
requireLogin();

$user = auth();

// ── Safe column check helper ──────────────────────────────────────────
function columnExists(string $table, string $col): bool {
  try {
    $r = db()->query("SHOW COLUMNS FROM `{$table}` LIKE '{$col}'")->fetch();
    return (bool)$r;
  } catch (Exception $e) { return false; }
}

// ── Auto-migration ────────────────────────────────────────────────────
if (!columnExists('rooms', 'room_mode')) {
  try { db()->exec("ALTER TABLE `rooms` ADD COLUMN `room_mode` enum('1v1','open') NOT NULL DEFAULT '1v1'"); }
  catch (Exception $e) {}
}
if (!columnExists('rooms', 'max_players')) {
  try { db()->exec("ALTER TABLE `rooms` ADD COLUMN `max_players` tinyint(1) NOT NULL DEFAULT 4"); }
  catch (Exception $e) {}
}

$hasRoomMode   = columnExists('rooms', 'room_mode');
$hasMaxPlayers = columnExists('rooms', 'max_players');

// ── Handle: host creates open lobby room ──────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'create_lobby') {
  $isPublic    = true; // lobby rooms are always public
  $maxPlayers  = max(2, min(8, (int)($_POST['max_players'] ?? 4)));
  $challengeId = (int)($_POST['challenge_id'] ?? 0);

  $selectedChallenge = null;
  if ($challengeId > 0) {
    $chStmt = db()->prepare('SELECT * FROM challenges WHERE id=?');
    $chStmt->execute([$challengeId]);
    $selectedChallenge = $chStmt->fetch() ?: null;
  }
  if (!$selectedChallenge) {
    $rnd = db()->query('SELECT * FROM challenges ORDER BY RAND() LIMIT 1')->fetch();
    $selectedChallenge = $rnd ?: ['id'=>null,'title'=>'CSS Freestyle','description'=>'Create any CSS artwork!','target_html'=>'','target_css'=>'','target_image'=>null];
  }

  do {
    $code = strtoupper(substr(md5(uniqid()), 0, 6));
    $exists = db()->prepare('SELECT id FROM rooms WHERE code=?');
    $exists->execute([$code]);
  } while ($exists->fetch());

  if ($hasRoomMode && $hasMaxPlayers) {
    $ins = db()->prepare('INSERT INTO rooms (code, host_id, challenge_id, challenge, is_public, room_mode, max_players) VALUES (?,?,?,?,1,?,?)');
    $ins->execute([$code, $user['id'], $selectedChallenge['id'], $selectedChallenge['description'], 'open', $maxPlayers]);
  } else {
    $ins = db()->prepare('INSERT INTO rooms (code, host_id, challenge_id, challenge, is_public) VALUES (?,?,?,?,1)');
    $ins->execute([$code, $user['id'], $selectedChallenge['id'], $selectedChallenge['description']]);
  }

  header('Location: battle.php?code='.$code); exit;
}

// ── Load open waiting rooms ───────────────────────────────────────────
$waitingRooms = db()->query(
  'SELECT r.*, u.username AS host_name, u.avatar AS host_avatar,
          c.title AS ch_title, c.difficulty AS ch_diff,
          (SELECT COUNT(*) FROM room_players rp WHERE rp.room_id=r.id) AS player_count
   FROM rooms r JOIN users u ON u.id=r.host_id
   LEFT JOIN challenges c ON c.id=r.challenge_id
   WHERE r.status="waiting" AND r.is_public=1
   ORDER BY r.created_at DESC LIMIT 20'
)->fetchAll();

// ── Load all challenges ───────────────────────────────────────────────
$allChallenges = db()->query(
  'SELECT c.*, u.username AS creator_name, u.avatar AS creator_avatar
   FROM challenges c JOIN users u ON u.id=c.created_by
   ORDER BY c.id DESC'
)->fetchAll();

pageHeader('Game Lobby');
?>
<style>
/* ── Layout ── */
.lobby-page{max-width:1100px;margin:0 auto;padding:48px 28px}
.lobby-hero{margin-bottom:40px}
.lobby-hero h1{font-size:40px;font-weight:800;letter-spacing:-2px;line-height:1}
.lobby-hero h1 .hi{color:var(--green)}
.lobby-hero p{margin-top:10px;color:var(--muted);font-size:13px;font-family:var(--font-mono);line-height:1.7;max-width:440px}

/* ── Two-column layout ── */
.lobby-layout{display:grid;grid-template-columns:360px 1fr;gap:28px;align-items:start}

/* ── Host Panel ── */
.host-panel{background:var(--bg2);border:1px solid var(--border);border-radius:20px;padding:28px;position:sticky;top:80px}
.host-panel-title{font-size:16px;font-weight:800;margin-bottom:4px;display:flex;align-items:center;gap:8px}
.host-panel-sub{font-size:12px;color:var(--muted);font-family:var(--font-mono);margin-bottom:22px}
.lfield{margin-bottom:14px}
.lfield label{display:block;font-size:10px;font-family:var(--font-mono);letter-spacing:1.5px;text-transform:uppercase;color:var(--muted);margin-bottom:6px}
.lfield select,.lfield input[type=number]{width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:10px;padding:11px 14px;color:var(--text);font-size:13px;font-family:var(--font-mono);outline:none;transition:border-color .2s;appearance:none}
.lfield select:focus,.lfield input:focus{border-color:rgba(0,255,135,.4)}
.ch-scroll{max-height:220px;overflow-y:auto;display:flex;flex-direction:column;gap:7px;margin-top:6px;padding-right:2px}
.ch-scroll::-webkit-scrollbar{width:4px}
.ch-scroll::-webkit-scrollbar-thumb{background:var(--border);border-radius:4px}
.lch-item{display:flex;align-items:center;gap:9px;padding:8px 10px;background:var(--bg3);border:2px solid var(--border);border-radius:9px;cursor:pointer;transition:border-color .2s}
.lch-item:hover{border-color:rgba(0,255,135,.25)}
.lch-item.selected{border-color:var(--green);background:rgba(0,255,135,.05)}
.lch-item input[type=radio]{accent-color:var(--green);flex-shrink:0}
.lch-title{font-size:12px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.lch-by{font-size:10px;color:var(--muted);font-family:var(--font-mono)}
.diff-badge{font-size:10px;font-family:var(--font-mono);padding:2px 6px;border-radius:4px;font-weight:700;flex-shrink:0;white-space:nowrap}
.diff-badge.easy{background:rgba(0,255,135,.15);color:var(--green)}
.diff-badge.medium{background:rgba(255,190,0,.15);color:#ffbe00}
.diff-badge.hard{background:rgba(255,45,111,.15);color:var(--pink)}
.thumb-sm{width:36px;height:24px;object-fit:cover;border-radius:4px;border:1px solid var(--border);flex-shrink:0}
.thumb-sm-ph{width:36px;height:24px;background:var(--bg);border:1px dashed var(--border);border-radius:4px;flex-shrink:0}
.max-players-row{display:flex;align-items:center;gap:10px}
.mp-btn{width:36px;height:36px;border-radius:8px;border:1px solid var(--border);background:var(--bg3);color:var(--text);font-size:18px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:border-color .2s,background .2s;flex-shrink:0}
.mp-btn:hover{border-color:rgba(0,255,135,.4);background:rgba(0,255,135,.06)}
.mp-display{font-family:var(--font-mono);font-size:20px;font-weight:700;color:var(--green);text-align:center;flex:1}
.launch-btn{width:100%;padding:13px;border-radius:12px;font-size:14px;font-weight:700;cursor:pointer;border:none;background:var(--green);color:#080b12;letter-spacing:.5px;transition:filter .2s,transform .2s;margin-top:18px}
.launch-btn:hover{filter:brightness(1.1);transform:scale(1.01)}

/* ── Rooms list ── */
.rooms-side{}
.rooms-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;gap:10px;flex-wrap:wrap}
.rooms-count{font-size:11px;font-family:var(--font-mono);color:var(--muted);letter-spacing:2px;text-transform:uppercase}
.rooms-search{padding:7px 12px;background:var(--bg3);border:1px solid var(--border);border-radius:8px;color:var(--text);font-size:12px;font-family:var(--font-mono);outline:none;width:180px;transition:border-color .2s}
.rooms-search:focus{border-color:rgba(0,200,255,.4)}
.rooms-list{display:flex;flex-direction:column;gap:10px}
.rcard{background:var(--bg2);border:1px solid var(--border);border-radius:14px;padding:16px 18px;display:flex;align-items:center;gap:14px;transition:border-color .2s,transform .2s;position:relative;overflow:hidden}
.rcard:hover{border-color:rgba(0,200,255,.3);transform:translateX(3px)}
.rcard-glow{position:absolute;left:-40px;top:50%;transform:translateY(-50%);width:80px;height:80px;border-radius:50%;background:var(--blue);opacity:.04;pointer-events:none}
.rcard-code{font-family:var(--font-mono);font-size:16px;font-weight:700;color:var(--green);letter-spacing:2px;flex-shrink:0;min-width:72px}
.rcard-body{flex:1;min-width:0}
.rcard-top{display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-bottom:3px}
.rcard-host{font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.rcard-ch{font-size:11px;color:var(--muted);font-family:var(--font-mono);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.rbadge{font-size:10px;font-family:var(--font-mono);padding:2px 8px;border-radius:4px;font-weight:700}
.rbadge.waiting{color:#f0a500;background:rgba(240,165,0,.1);border:1px solid rgba(240,165,0,.2)}
.rbadge.neutral{background:var(--bg3);color:var(--muted);border:1px solid var(--border)}
.rcard-actions{display:flex;flex-direction:column;gap:6px;flex-shrink:0}
.rjoin-btn{padding:8px 16px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;background:rgba(0,200,255,.1);color:var(--blue);border:1px solid rgba(0,200,255,.2);font-family:var(--font-mono);transition:background .2s;text-align:center;text-decoration:none;white-space:nowrap}
.rjoin-btn:hover{background:rgba(0,200,255,.25)}
.rjoin-btn.mine{background:rgba(0,255,135,.1);color:var(--green);border-color:rgba(0,255,135,.2)}
.rjoin-btn.mine:hover{background:rgba(0,255,135,.2)}
.empty-state{text-align:center;padding:60px 20px;color:var(--muted);font-family:var(--font-mono);font-size:13px}
.empty-state .em-icon{font-size:40px;margin-bottom:12px;opacity:.4}

/* ── Players bar inside card ── */
.players-bar{display:flex;gap:3px;align-items:center;margin-top:4px}
.pslot{width:20px;height:20px;border-radius:50%;background:var(--bg3);border:1px solid var(--border);display:flex;align-items:center;justify-content:center;font-size:10px}
.pslot.filled{border-color:rgba(0,200,255,.4);background:rgba(0,200,255,.08)}
.pslot.empty{opacity:.35}
.players-label{font-size:10px;font-family:var(--font-mono);color:var(--muted);margin-left:4px}

/* ── Responsive ── */
@media(max-width:760px){
  .lobby-layout{grid-template-columns:1fr}
  .host-panel{position:static}
  .lobby-page{padding:28px 16px}
  .lobby-hero h1{font-size:30px}
  .rcard{flex-wrap:wrap;gap:10px}
  .rcard-actions{flex-direction:row;width:100%}
  .rjoin-btn{flex:1;text-align:center}
}
@media(max-width:420px){
  .lobby-hero h1{font-size:26px}
  .rcard-code{font-size:14px;min-width:60px}
}
</style>

<div class="lobby-page">
  <div class="lobby-hero">
    <h1>Game <span class="hi">Lobby</span></h1>
    <p>Host a room anyone can join, or jump into an open room waiting for players.</p>
  </div>

  <div class="lobby-layout">

    <!-- ── Host Panel ── -->
    <aside class="host-panel">
      <div class="host-panel-title">⚡ Create Open Room</div>
      <div class="host-panel-sub">Set player limit, pick a challenge, launch.</div>

      <form method="POST" id="lobbyForm">
        <input type="hidden" name="action" value="create_lobby">
        <input type="hidden" name="challenge_id" id="lchallengeId" value="0">

        <div class="lfield">
          <label>Max Players</label>
          <div class="max-players-row">
            <button type="button" class="mp-btn" id="mpMinus">−</button>
            <div class="mp-display" id="mpDisplay">4</div>
            <button type="button" class="mp-btn" id="mpPlus">+</button>
          </div>
          <input type="hidden" name="max_players" id="mpValue" value="4">
        </div>

        <div class="lfield">
          <label>Pick a Challenge <span style="color:var(--muted)">(optional — random if skipped)</span></label>
          <?php if (empty($allChallenges)): ?>
            <p style="font-size:12px;color:var(--muted);font-family:var(--font-mono);margin-top:4px">No challenges yet. Go to <a href="versus.php" style="color:var(--green)">Versus</a> to create one.</p>
          <?php else: ?>
          <div class="ch-scroll" id="lchList">
            <label class="lch-item selected" data-id="0">
              <input type="radio" name="lch_pick" value="0" checked>
              <div style="flex:1">
                <div class="lch-title">🎲 Random Challenge</div>
                <div class="lch-by">Surprise me!</div>
              </div>
            </label>
            <?php foreach ($allChallenges as $ch): ?>
            <label class="lch-item" data-id="<?= $ch['id'] ?>">
              <input type="radio" name="lch_pick" value="<?= $ch['id'] ?>">
              <?php if ($ch['target_image']): ?>
                <img src="<?= e($ch['target_image']) ?>" class="thumb-sm" alt="">
              <?php else: ?>
                <div class="thumb-sm-ph"></div>
              <?php endif; ?>
              <div style="flex:1;min-width:0">
                <div class="lch-title"><?= e($ch['title']) ?></div>
                <div class="lch-by"><?= e($ch['creator_avatar'].' '.$ch['creator_name']) ?></div>
              </div>
              <span class="diff-badge <?= $ch['difficulty'] ?>"><?= strtoupper($ch['difficulty']) ?></span>
            </label>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>
        </div>

        <button type="submit" class="launch-btn">⚡ Open Lobby Room</button>
      </form>
    </aside>

    <!-- ── Rooms List ── -->
    <section class="rooms-side">
      <div class="rooms-header">
        <div class="rooms-count"><?= count($waitingRooms) ?> open room<?= count($waitingRooms) !== 1 ? 's' : '' ?></div>
        <input type="text" class="rooms-search" id="roomSearch" placeholder="Search host or code…">
      </div>

      <?php if (empty($waitingRooms)): ?>
        <div class="empty-state">
          <div class="em-icon">🏟️</div>
          <div>No rooms open right now.</div>
          <div style="margin-top:6px;font-size:12px">Be the first — create one on the left!</div>
        </div>
      <?php else: ?>
      <div class="rooms-list" id="roomsList">
        <?php foreach ($waitingRooms as $r):
          $mode  = $hasRoomMode   ? ($r['room_mode']   ?? 'open') : 'open';
          $maxP  = $hasMaxPlayers ? ($r['max_players'] ?? 4)      : 4;
          $curP  = (int)($r['player_count'] ?? 1);
          $full  = $curP >= $maxP;
          $isMe  = ($r['host_id'] == $user['id']);
        ?>
        <div class="rcard" data-search="<?= e(strtolower($r['host_name'].' '.$r['code'])) ?>">
          <div class="rcard-glow"></div>
          <div class="rcard-code"><?= e($r['code']) ?></div>
          <div class="rcard-body">
            <div class="rcard-top">
              <span class="rcard-host"><?= e($r['host_avatar'].' '.$r['host_name']) ?></span>
              <span class="rbadge waiting">WAITING</span>
              <?php if ($full): ?><span class="rbadge neutral">FULL</span><?php endif; ?>
            </div>
            <?php if (!empty($r['ch_title'])): ?>
              <div class="rcard-ch">📋 <?= e($r['ch_title']) ?>
                <?php if (!empty($r['ch_diff'])): ?>&nbsp;<span class="diff-badge <?= $r['ch_diff'] ?>" style="font-size:9px"><?= strtoupper($r['ch_diff']) ?></span><?php endif; ?>
              </div>
            <?php endif; ?>
            <div class="players-bar">
              <?php for ($i = 0; $i < $maxP; $i++): ?>
                <div class="pslot <?= $i < $curP ? 'filled' : 'empty' ?>"><?= $i < $curP ? '●' : '○' ?></div>
              <?php endfor; ?>
              <span class="players-label"><?= $curP ?>/<?= $maxP ?> players</span>
            </div>
          </div>
          <div class="rcard-actions">
            <?php if ($isMe): ?>
              <a href="battle.php?code=<?= e($r['code']) ?>" class="rjoin-btn mine">Re-enter →</a>
            <?php elseif (!$full): ?>
              <a href="battle.php?code=<?= e($r['code']) ?>" class="rjoin-btn">Join →</a>
            <?php else: ?>
              <span class="rjoin-btn" style="opacity:.4;cursor:default">Full</span>
            <?php endif; ?>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </section>

  </div>
</div>
<script src="assets/security.js"></script>
<script>
// ── Max players stepper ──
let mpVal = 4;
function updateMp() {
  document.getElementById('mpDisplay').textContent = mpVal;
  document.getElementById('mpValue').value = mpVal;
}
document.getElementById('mpMinus').onclick = () => { if (mpVal > 2) { mpVal--; updateMp(); } };
document.getElementById('mpPlus').onclick  = () => { if (mpVal < 8) { mpVal++; updateMp(); } };

// ── Challenge picker ──
document.querySelectorAll('#lchList .lch-item').forEach(item => {
  item.addEventListener('click', () => {
    document.querySelectorAll('#lchList .lch-item').forEach(i => i.classList.remove('selected'));
    item.classList.add('selected');
    document.getElementById('lchallengeId').value = item.dataset.id;
    item.querySelector('input[type=radio]').checked = true;
  });
});

// ── Room search ──
document.getElementById('roomSearch')?.addEventListener('input', e => {
  const q = e.target.value.toLowerCase().trim();
  document.querySelectorAll('#roomsList .rcard').forEach(card => {
    card.style.display = card.dataset.search.includes(q) ? '' : 'none';
  });
});
</script>

<?php pageFooter(); ?>
