<?php
// ─── includes/footer.php ───────────────────────────────────────────────
function pageFooter(): void { ?>
<script src="../assets/js/notifications-badge.js"></script>
</body></html>
<?php }
