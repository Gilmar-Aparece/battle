<?php
// ── includes/notifications_helper.php ────────────────────────────────
// Lightweight include — only provides pushNotification().
// Does NOT render any HTML or enforce login.

if (!function_exists('pushNotification')) {
  /**
   * Insert a notification row for $userId, deduplicated within 10 min.
   */
  function pushNotification(int $userId, int $actorId, string $type, ?int $refId = null, ?string $refLabel = null): void {
    if ($userId === $actorId) return;
    try {
      // Auto-create table if it doesn't exist yet.
      // NOTE: No FOREIGN KEY constraints — shared hosts (InfinityFree etc.)
      // reject FK creation from PHP and the silent failure means the table
      // never gets created, breaking all notifications.
      db()->exec("CREATE TABLE IF NOT EXISTS `notifications` (
        `id`         INT(11)      NOT NULL AUTO_INCREMENT,
        `user_id`    INT(11)      NOT NULL,
        `actor_id`   INT(11)      NOT NULL,
        `type`       ENUM('follow','showcase_like','showcase_comment','arena_join','arena_invite') NOT NULL,
        `ref_id`     INT(11)      DEFAULT NULL,
        `ref_label`  VARCHAR(120) DEFAULT NULL,
        `is_read`    TINYINT(1)   NOT NULL DEFAULT 0,
        `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `idx_user_id`  (`user_id`),
        KEY `idx_actor_id` (`actor_id`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

      // Deduplicate within 10 minutes
      $dup = db()->prepare("
        SELECT id FROM notifications
        WHERE user_id=? AND actor_id=? AND type=? AND ref_id<=>?
          AND created_at >= NOW() - INTERVAL 10 MINUTE
        LIMIT 1
      ");
      $dup->execute([$userId, $actorId, $type, $refId]);
      if ($dup->fetch()) return;

      db()->prepare("INSERT INTO notifications (user_id, actor_id, type, ref_id, ref_label) VALUES (?,?,?,?,?)")
         ->execute([$userId, $actorId, $type, $refId, $refLabel]);
    } catch (Exception $e) {
      // Fail silently — notifications are non-critical
    }
  }
}
