<?php
// ─── includes/header.php ───────────────────────────────────────────────
function pageHeader(string $title = SITE_NAME, string $extra = ''): void {
  $user = auth();
  $cur  = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($title) ?> — <?= SITE_NAME ?></title>
  <link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;600;800&display=swap" rel="stylesheet">
  <?= $extra ?>
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>

<nav class="navbar">

  <!-- Logo -->
  <a href="index.php" class="nav-logo">
    <div class="logo-dot"></div>
    <span class="logo-text">code<span>Me</span></span>
  </a>

  <!-- Desktop nav links -->
  <div class="nav-links">

    <div class="nav-item">
      <a href="home.php" class="nav-link <?= $cur==='home.php'?'active':'' ?>">Home</a>
    </div>

    <!-- ⚔️ Play dropdown -->
    <div class="nav-item">
      <span class="nav-link <?= in_array($cur,['versus.php','lobby.php','battle.php'])?'active':'' ?>">
        ⚔️ Play <span class="nav-chev">▾</span>
      </span>
      <div class="nav-dd">
        <a href="versus.php" class="dd-row">
          <span class="dd-icon">⚔️</span>
          <div>
            <div class="dd-title">Versus <span class="badge badge-red">1v1</span></div>
            <div class="dd-desc">Challenge a coder, match CSS to target</div>
          </div>
        </a>
        <a href="lobby.php" class="dd-row">
          <span class="dd-icon">🏟️</span>
          <div>
            <div class="dd-title">Lobby <span class="badge badge-blue">up to 8</span></div>
            <div class="dd-desc">Host or join a room — up to 8 players</div>
          </div>
        </a>
      </div>
    </div>

    <!-- 📡 Watch dropdown -->
    <div class="nav-item">
      <span class="nav-link <?= in_array($cur,['live.php','leaderboard.php'])?'active':'' ?>">
        Watch <span class="nav-chev">▾</span>
      </span>
      <div class="nav-dd">
        <a href="live.php" class="dd-row">
          <span class="dd-icon">📡</span>
          <div>
            <div class="dd-title">Live <span class="badge badge-live">● LIVE</span></div>
            <div class="dd-desc">Watch ongoing battles in real time</div>
          </div>
        </a>
        <a href="leaderboard.php" class="dd-row">
          <span class="dd-icon">🏆</span>
          <div>
            <div class="dd-title">Rankings</div>
            <div class="dd-desc">Top coders ranked by wins &amp; score</div>
          </div>
        </a>
      </div>
    </div>

    <!-- ✨ Create dropdown -->
    <div class="nav-item">
      <span class="nav-link <?= in_array($cur,['menu_builder.php','showcase.php','autopost.php'])?'active':'' ?>">
        ✨ Create <span class="nav-chev">▾</span>
      </span>
      <div class="nav-dd">
        <a href="menu_builder.php" class="dd-row">
          <span class="dd-icon">🎨</span>
          <div>
            <div class="dd-title">UI Builder</div>
            <div class="dd-desc">Design UI components with live preview</div>
          </div>
        </a>
        <a href="showcase.php" class="dd-row">
          <span class="dd-icon">🖼️</span>
          <div>
            <div class="dd-title">Showcase</div>
            <div class="dd-desc">Browse &amp; share community creations</div>
          </div>
        </a>
        <div class="dd-sep"></div>
        <a href="autopost.php" class="dd-row">
          <span class="dd-icon">🗓️</span>
          <div>
            <div class="dd-title">Schedule</div>
            <div class="dd-desc">Auto-post &amp; schedule your content</div>
          </div>
        </a>
      </div>
    </div>

    <!-- Messages (logged in only) -->
    <?php if ($user): ?>
    <div class="nav-item">
      <a href="messages.php" class="nav-link <?= $cur==='messages.php'?'active':'' ?>">
        💬 Messages
      </a>
    </div>
    <?php endif; ?>

  </div><!-- /nav-links -->

  <div class="nav-spacer"></div>

  <!-- Desktop right -->
  <div class="nav-right">
    <?php if ($user): ?>
      <a href="notifications.php" class="notif-bell" id="navNotifBell" title="Notifications">
        🔔<span class="notif-bell-badge" id="navNotifBadge"></span>
      </a>
      <a href="profile.php" class="nav-chip">
        <span class="nav-av"><?= e($user['avatar']) ?></span>
        <span><?= e($user['username']) ?></span>
      </a>
      <?php if(isAdmin()): ?>
      <a href="admin/index.php" class="btn-sm btn-admin">⚡ Admin</a>
      <?php endif; ?>
      <a href="logout.php" class="btn-sm btn-danger">Logout</a>
    <?php else: ?>
      <a href="login.php"    class="btn-sm btn-outline">Login</a>
      <a href="register.php" class="btn-sm btn-primary">🎮 Play Now</a>
    <?php endif; ?>
  </div>

  <!-- Hamburger -->
  <button class="nav-toggle" id="navToggle" aria-label="Toggle menu">
    <span></span><span></span><span></span>
  </button>

</nav>

<!-- ══ Mobile Drawer ══ -->
<div class="mobile-menu" id="mobileMenu">

  <!-- ⚔️ Play -->
  <div class="drawer-section">⚔️ Play</div>
  <a href="versus.php" class="nav-link <?= $cur==='versus.php'?'active':'' ?>">
    <span class="nav-link-icon">⚔️</span>Versus <span class="badge badge-red" style="margin-left:auto">1v1</span>
  </a>
  <div class="drawer-hint">Challenge a player — match your CSS to a target design</div>

  <a href="lobby.php" class="nav-link <?= $cur==='lobby.php'?'active':'' ?>">
    <span class="nav-link-icon">🏟️</span>Lobby <span class="badge badge-blue" style="margin-left:auto">up to 8</span>
  </a>
  <div class="drawer-hint">Host or join an open room with multiple players</div>

  <!-- 📡 Watch -->
  <div class="nav-divider"></div>
  <div class="drawer-section">📡 Watch</div>
  <a href="live.php" class="nav-link <?= $cur==='live.php'?'active':'' ?>">
    <span class="nav-link-icon">📡</span>Live <span class="badge badge-live" style="margin-left:auto">● LIVE</span>
  </a>
  <div class="drawer-hint">Watch active battles happening right now</div>

  <a href="leaderboard.php" class="nav-link <?= $cur==='leaderboard.php'?'active':'' ?>">
    <span class="nav-link-icon">🏆</span>Rankings
  </a>
  <div class="drawer-hint">Top coders ranked by wins, score &amp; streaks</div>

  <!-- ✨ Create -->
  <div class="nav-divider"></div>
  <div class="drawer-section">✨ Create</div>
  <a href="menu_builder.php" class="nav-link <?= $cur==='menu_builder.php'?'active':'' ?>">
    <span class="nav-link-icon">🎨</span>UI Builder
  </a>
  <div class="drawer-hint">Design menus &amp; components visually with live preview</div>

  <a href="showcase.php" class="nav-link <?= $cur==='showcase.php'?'active':'' ?>">
    <span class="nav-link-icon">🖼️</span>Showcase
  </a>
  <div class="drawer-hint">Browse &amp; share community creations</div>

  <a href="autopost.php" class="nav-link <?= $cur==='autopost.php'?'active':'' ?>">
    <span class="nav-link-icon">🗓️</span>Schedule
  </a>
  <div class="drawer-hint">Auto-post &amp; schedule your content</div>

  <!-- Messages -->
  <?php if ($user): ?>
  <div class="nav-divider"></div>
  <a href="messages.php" class="nav-link <?= $cur==='messages.php'?'active':'' ?>">
    <span class="nav-link-icon">💬</span>Messages
  </a>
  <a href="notifications.php" class="nav-link <?= $cur==='notifications.php'?'active':'' ?>">
    <span class="nav-link-icon">🔔</span>Notifications
    <span id="mobileNotifBadge" style="background:var(--pink);color:#fff;font-size:10px;font-weight:800;font-family:var(--font-mono);min-width:17px;height:17px;border-radius:9px;display:none;align-items:center;justify-content:center;padding:0 3px;margin-left:auto"></span>
  </a>
  <?php endif; ?>

  <div class="nav-divider"></div>

  <?php if ($user): ?>
    <div class="mobile-user">
      <span style="font-size:24px"><?= e($user['avatar']) ?></span>
      <span><?= e($user['username']) ?></span>
    </div>
    <a href="profile.php" class="drawer-btn" style="background:var(--bg3);border:1px solid var(--border);color:var(--text)">👤 My Profile</a>
    <a href="home.php"    class="drawer-btn" style="background:var(--bg3);border:1px solid var(--border);color:var(--muted)">🏠 Home</a>
    <a href="logout.php"  class="drawer-btn" style="background:rgba(255,45,111,.1);border:1px solid rgba(255,45,111,.3);color:var(--pink)">🚪 Logout</a>
  <?php else: ?>
    <a href="login.php"    class="drawer-btn" style="background:var(--bg3);border:1px solid var(--border);color:var(--muted)">🔑 Login</a>
    <a href="register.php" class="drawer-btn" style="background:var(--green);color:#080b12">🎮 Play Now — it's free</a>
  <?php endif; ?>

</div>

<script src="../assets/js/nav-toggle.js"></script>

<div id="toast"></div>
<?php
}

