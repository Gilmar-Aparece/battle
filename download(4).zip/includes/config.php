<?php
// ─── includes/config.php ───────────────────────────────────────────────
// Edit these to match your phpMyAdmin / MySQL setup
define('DB_HOST', 'sql307.byetcluster.com');            // From your screenshot server info
define('DB_NAME', 'if0_41970567_codeme_versus');       // From your screenshot database info
define('DB_USER', 'if0_41970567');                     // Your hosting account username
define('DB_PASS', 'xfzpS214IR7ijd');   // ⚠️ Replace this with your actual MySQL/vPanel password
define('DB_CHARSET', 'utf8mb4');

define('SITE_NAME', 'codeMe Versus');
define('BASE_URL',  'https://battlewithme.free.nf');

// ─── PDO Connection ───────────────────────────────────────────────────
function db(): PDO {
  static $pdo = null;
  if ($pdo === null) {
    $dsn = 'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset='.DB_CHARSET;
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
      PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
      PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
  }
  return $pdo;
}

// ─── Session bootstrap ────────────────────────────────────────────────
if (session_status() === PHP_SESSION_NONE) session_start();

function auth(): ?array {
  return $_SESSION['user'] ?? null;
}

function requireLogin(): void {
  if (!auth()) {
    header('Location: login.php');
    exit;
  }
}

function e(string $s): string {
  return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

// ─── Flash messages ───────────────────────────────────────────────────
function flash(string $key, string $msg): void {
  $_SESSION['flash'][$key] = $msg;
}

function getFlash(string $key): ?string {
  $msg = $_SESSION['flash'][$key] ?? null;
  unset($_SESSION['flash'][$key]);
  return $msg;
}

// ─── Admin check ──────────────────────────────────────────
function isAdmin(): bool {
  $user = auth();
  if (!$user) return false;
  static $role = null;
  if ($role === null) {
    $stmt = db()->prepare('SELECT role FROM users WHERE id=?');
    $stmt->execute([$user['id']]);
    $role = (int)($stmt->fetchColumn() ?? 0);
  }
  return $role === 1;
}
