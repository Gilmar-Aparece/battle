// codeMe Service Worker — PWA offline support + call/live notifications
const CACHE = 'codeme-v2';
const PRECACHE = [
  '/index.php',
  '/leaderboard.php',
  '/login.php',
  '/register.php'
];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(c => c.addAll(PRECACHE)).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  if (e.request.url.includes('api.php') || e.request.url.includes('messages.php') || e.request.url.includes('live.php')) return;

  e.respondWith(
    fetch(e.request)
      .then(res => {
        if (res && res.status === 200) {
          const clone = res.clone();
          caches.open(CACHE).then(c => c.put(e.request, clone));
        }
        return res;
      })
      .catch(() => caches.match(e.request))
  );
});

// ── Handle messages from page (for triggering notifications) ─────────────────
self.addEventListener('message', e => {
  if (e.data && e.data.type === 'INCOMING_CALL') {
    const { callerName, callType, sessionId } = e.data;
    const icon = callType === 'video' ? '📹' : '📞';
    self.registration.showNotification(`${icon} Incoming ${callType} call`, {
      body: `${callerName} is calling you`,
      icon: '/icon-192.png',
      badge: '/icon-192.png',
      tag: 'incoming-call-' + sessionId,
      requireInteraction: true,
      data: { url: self.location.origin + '/messages.php' }
    }).catch(() => {});
  }

  if (e.data && e.data.type === 'LIVE_STARTED') {
    const { streamerName, sessionId, title } = e.data;
    self.registration.showNotification('🔴 Live Stream Started', {
      body: `${streamerName} is now live: ${title}`,
      icon: '/icon-192.png',
      badge: '/icon-192.png',
      tag: 'live-' + sessionId,
      data: { url: self.location.origin + '/live.php?id=' + sessionId }
    }).catch(() => {});
  }
});

// ── Notification click → open the right page ─────────────────────────────────
self.addEventListener('notificationclick', e => {
  e.notification.close();
  const url = (e.notification.data && e.notification.data.url) || '/messages.php';
  e.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then(list => {
      for (const c of list) {
        if (c.url.includes(self.location.origin)) {
          c.focus();
          c.postMessage({ type: 'FOCUS_AND_NAVIGATE', url });
          return;
        }
      }
      return clients.openWindow(url);
    })
  );
});
