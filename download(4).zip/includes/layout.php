<?php
// ─── includes/layout.php ──────────────────────────────────────────────
function pageHeader(string $title = SITE_NAME, string $extra = ''): void {
  $user = auth();
  $cur  = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($title) ?> — <?= SITE_NAME ?></title>
  <link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;600;800&display=swap" rel="stylesheet">
  <style>
    :root{
      --green:#00ff87;--pink:#ff2d6f;--blue:#00c8ff;--purple:#b14fff;
      --bg:#080b12;--bg2:#0e1320;--bg3:#141b2d;
      --border:rgba(255,255,255,0.07);--text:#e8eaf0;--muted:#5a6380;
      --font-head:'Syne',sans-serif;--font-mono:'Space Mono',monospace;
      --nav-h:60px;
    }
    *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
    html,body{min-height:100%;font-family:var(--font-head);background:var(--bg);color:var(--text)}
    a{color:inherit;text-decoration:none}
    input,button,textarea,select{font-family:inherit}

    /* ══ NAVBAR ══ */
    .navbar{
      background:var(--bg2);border-bottom:1px solid var(--border);
      display:flex;align-items:center;padding:0 22px;height:var(--nav-h);
      position:sticky;top:0;z-index:300;gap:0;
    }

    /* Logo */
    .nav-logo{display:flex;align-items:center;gap:8px;flex-shrink:0;margin-right:20px}
    .logo-dot{width:9px;height:9px;border-radius:50%;background:var(--green);box-shadow:0 0 10px var(--green)}
    .logo-text{font-size:17px;font-weight:800;letter-spacing:-.5px;color:#fff;white-space:nowrap}
    .logo-text span{color:var(--green)}

    /* Nav links row */
    .nav-links{display:flex;align-items:center;gap:1px}
    .nav-spacer{flex:1}

    /* Nav item (plain link or dropdown trigger) */
    .nav-item{position:relative}
    .nav-link{
      display:flex;align-items:center;gap:4px;
      padding:7px 11px;border-radius:8px;
      font-size:13px;font-weight:600;color:var(--muted);
      transition:color .15s,background .15s;white-space:nowrap;
      cursor:pointer;border:none;background:transparent;
    }
    .nav-link:hover,.nav-link.active{color:#fff;background:rgba(255,255,255,0.06)}
    .nav-link.active{color:var(--green)}
    .nav-chev{font-size:9px;opacity:.4;transition:transform .2s,opacity .2s;display:inline-block;margin-left:1px}
    .nav-item:hover .nav-chev,.nav-item.open .nav-chev{transform:rotate(180deg);opacity:.9}

    /* ── Dropdown panel ── */
    .nav-dd{
      display:none;position:absolute;top:calc(100% + 7px);left:0;
      min-width:240px;background:var(--bg3);
      border:1px solid rgba(255,255,255,0.09);border-radius:13px;
      padding:7px;box-shadow:0 16px 44px rgba(0,0,0,.65);
      z-index:400;animation:ddIn .14s ease-out;
    }
    @keyframes ddIn{from{opacity:0;transform:translateY(-5px)}to{opacity:1;transform:none}}
    .nav-item:hover .nav-dd{display:block}

    .dd-row{
      display:flex;align-items:flex-start;gap:10px;
      padding:9px 10px;border-radius:8px;
      transition:background .12s;text-decoration:none;
    }
    .dd-row:hover{background:rgba(255,255,255,0.05)}
    .dd-icon{font-size:17px;flex-shrink:0;line-height:1.25;margin-top:1px}
    .dd-title{font-size:13px;font-weight:700;color:var(--text);line-height:1.2}
    .dd-desc{font-size:11px;color:var(--muted);font-family:var(--font-mono);margin-top:2px;line-height:1.4;white-space:nowrap}
    .dd-sep{height:1px;background:var(--border);margin:5px 4px}

    /* Inline badges */
    .badge{
      display:inline-block;font-size:10px;font-weight:700;
      padding:1px 6px;border-radius:4px;vertical-align:middle;margin-left:4px;letter-spacing:.2px;
    }
    .badge-red {background:rgba(255,45,111,.16);color:var(--pink)}
    .badge-blue{background:rgba(0,200,255,.13);color:var(--blue)}
    .badge-grn {background:rgba(0,255,135,.12);color:var(--green)}
    .badge-live{background:rgba(255,45,111,.18);color:var(--pink);animation:livePulse 1.5s ease-in-out infinite}
    @keyframes livePulse{0%,100%{opacity:1}50%{opacity:.5}}

    /* Right area */
    .nav-right{display:flex;align-items:center;gap:7px;flex-shrink:0}

    /* Notification bell */
    .notif-bell{
      position:relative;display:flex;align-items:center;justify-content:center;
      width:36px;height:36px;border-radius:9px;
      background:var(--bg3);border:1px solid var(--border);
      cursor:pointer;transition:border-color .2s,background .2s;font-size:17px;
    }
    .notif-bell:hover{border-color:rgba(255,255,255,.2);background:rgba(255,255,255,.06)}
    .notif-bell-badge{
      position:absolute;top:-5px;right:-5px;
      min-width:17px;height:17px;border-radius:9px;
      background:var(--pink);color:#fff;font-size:9px;font-weight:800;
      font-family:var(--font-mono);
      align-items:center;justify-content:center;padding:0 3px;
      box-shadow:0 0 7px var(--pink);display:none;
    }

    /* User chip */
    .nav-chip{
      display:flex;align-items:center;gap:7px;
      padding:5px 11px 5px 7px;border-radius:9px;
      border:1px solid var(--border);font-size:13px;font-weight:600;
      transition:background .15s,border-color .15s;
    }
    .nav-chip:hover{background:rgba(255,255,255,.04);border-color:rgba(255,255,255,.14)}
    .nav-av{font-size:18px;line-height:1}

    .btn-sm{
      padding:7px 14px;border-radius:8px;font-size:12px;font-weight:700;
      cursor:pointer;border:none;letter-spacing:.4px;
      transition:filter .18s,transform .15s;white-space:nowrap;display:inline-block;
    }
    .btn-sm:hover{filter:brightness(1.12);transform:scale(1.03)}
    .btn-primary{background:var(--green);color:#080b12}
    .btn-outline{background:transparent;border:1px solid var(--border);color:var(--muted)}
    .btn-outline:hover{color:#fff;border-color:rgba(255,255,255,.2)}
    .btn-danger{background:transparent;border:1px solid rgba(255,45,111,.4);color:var(--pink)}
    .btn-danger:hover{background:rgba(255,45,111,.1)}
    .btn-admin{background:rgba(177,79,255,.15);color:var(--purple);border:1px solid rgba(177,79,255,.3)}

    /* ── Hamburger ── */
    .nav-toggle{
      display:none;flex-direction:column;justify-content:center;gap:5px;
      width:40px;height:40px;padding:8px;border-radius:10px;
      border:1px solid var(--border);background:rgba(255,255,255,.03);
      cursor:pointer;flex-shrink:0;margin-left:auto;
      transition:background .2s,border-color .2s;
    }
    .nav-toggle:hover{background:rgba(255,255,255,.07);border-color:rgba(255,255,255,.15)}
    .nav-toggle span{
      display:block;height:2px;width:100%;border-radius:2px;background:var(--text);
      transition:transform .3s cubic-bezier(.68,-.6,.32,1.6),opacity .25s;
    }
    .nav-toggle.open{border-color:rgba(0,255,135,.4);background:rgba(0,255,135,.06)}
    .nav-toggle.open span{background:var(--green)}
    .nav-toggle.open span:nth-child(1){transform:translateY(7px) rotate(45deg)}
    .nav-toggle.open span:nth-child(2){opacity:0;transform:scaleX(0)}
    .nav-toggle.open span:nth-child(3){transform:translateY(-7px) rotate(-45deg)}

    /* ── Mobile drawer ── */
    .mobile-menu{
      display:none;position:fixed;
      top:var(--nav-h);left:0;right:0;bottom:0;
      background:rgba(8,11,18,0.98);border-top:1px solid var(--border);
      z-index:299;flex-direction:column;padding:14px;gap:2px;overflow-y:auto;
    }
    .mobile-menu.open{display:flex;animation:drawerIn .2s ease-out}
    @keyframes drawerIn{from{opacity:0;transform:translateY(-7px)}to{opacity:1;transform:none}}

    /* Drawer section labels */
    .drawer-section{
      font-size:10px;font-family:var(--font-mono);letter-spacing:1.8px;
      text-transform:uppercase;color:var(--muted);
      padding:12px 16px 4px;
    }
    .mobile-menu .nav-link{
      padding:12px 16px;border-radius:11px;font-size:14px;font-weight:600;
      border:1px solid transparent;display:flex;align-items:center;gap:11px;
      color:var(--text);transition:background .15s,border-color .15s;
    }
    .mobile-menu .nav-link:hover{background:rgba(255,255,255,.05);border-color:var(--border)}
    .mobile-menu .nav-link.active{color:var(--green);border-color:rgba(0,255,135,.25);background:rgba(0,255,135,.06)}
    .mobile-menu .nav-link .nav-link-icon{font-size:18px;width:24px;text-align:center;flex-shrink:0}
    .drawer-hint{
      font-size:10.5px;font-family:var(--font-mono);color:var(--muted);
      padding:0 16px 5px 52px;line-height:1.45;margin-top:-2px;
    }
    .nav-divider{height:1px;background:var(--border);margin:8px 0}
    .mobile-user{
      display:flex;align-items:center;gap:12px;
      padding:12px 16px;font-size:14px;font-weight:600;
      color:var(--muted);border-radius:12px;background:var(--bg3);margin-bottom:6px;
    }
    .drawer-btn{
      padding:13px 16px;border-radius:12px;font-size:14px;font-weight:700;
      cursor:pointer;border:none;letter-spacing:.3px;text-align:center;
      text-decoration:none;display:block;margin-bottom:6px;
      transition:filter .2s,transform .15s;
    }
    .drawer-btn:active{transform:scale(.98)}

    /* ── Responsive ── */
    @media(max-width:768px){
      .nav-links,.nav-right{display:none}
      .nav-toggle{display:flex}
    }
    @media(min-width:769px){
      .mobile-menu,.mobile-menu.open{display:none}
      .nav-toggle{display:none}
    }

    /* ── Page wrapper ── */
    .page{max-width:1100px;margin:0 auto;padding:40px 20px}
    .page-hero{margin-bottom:36px}
    .page-hero h1{font-size:clamp(28px,8vw,44px);font-weight:800;line-height:1;letter-spacing:-2px}
    .page-hero h1 .hi{color:var(--green)}
    .page-hero p{margin-top:12px;color:var(--muted);font-size:13px;max-width:420px;line-height:1.7;font-family:var(--font-mono)}

    @media(max-width:768px){
      .page{padding:28px 16px}
      .page-hero h1{letter-spacing:-1px}
      .form-card{padding:28px 20px;margin:32px auto;border-radius:16px}
    }

    /* ── Forms ── */
    .form-card{background:var(--bg2);border:1px solid var(--border);border-radius:20px;padding:40px;max-width:440px;margin:60px auto}
    .form-card h2{font-size:26px;font-weight:800;letter-spacing:-1px;margin-bottom:6px}
    .form-card p{color:var(--muted);font-size:13px;font-family:var(--font-mono);margin-bottom:28px}
    .field{margin-bottom:18px}
    .field label{display:block;font-size:11px;font-family:var(--font-mono);letter-spacing:1.5px;text-transform:uppercase;color:var(--muted);margin-bottom:8px}
    .field input,.field select{width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:10px;padding:12px 16px;color:var(--text);font-size:14px;font-family:var(--font-mono);outline:none;transition:border-color .2s}
    .field input:focus,.field select:focus{border-color:rgba(0,255,135,.4)}
    .btn-full{width:100%;padding:13px;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;border:none;background:var(--green);color:#080b12;letter-spacing:.5px;transition:filter .2s}
    .btn-full:hover{filter:brightness(1.1)}
    .form-footer{text-align:center;margin-top:20px;font-size:13px;color:var(--muted);font-family:var(--font-mono)}
    .form-footer a{color:var(--green)}
    .alert{padding:12px 16px;border-radius:10px;font-size:13px;font-family:var(--font-mono);margin-bottom:20px}
    .alert-error{background:rgba(255,45,111,.1);border:1px solid rgba(255,45,111,.3);color:var(--pink)}
    .alert-success{background:rgba(0,255,135,.08);border:1px solid rgba(0,255,135,.3);color:var(--green)}

    /* ── Toast ── */
    #toast{position:fixed;bottom:28px;right:28px;background:var(--bg3);border:1px solid var(--green);color:var(--green);padding:12px 22px;border-radius:10px;font-family:var(--font-mono);font-size:13px;opacity:0;pointer-events:none;transition:opacity .3s;z-index:9999}
    #toast.show{opacity:1}

    /* ── Section label ── */
    .sec-label{font-size:11px;font-family:var(--font-mono);color:var(--muted);letter-spacing:2px;text-transform:uppercase;margin-bottom:14px;margin-top:40px}
  </style>
  <?= $extra ?>
</head>
<body>

<nav class="navbar">

  <!-- Logo -->
  <a href="index.php" class="nav-logo">
    <div class="logo-dot"></div>
    <span class="logo-text">code<span>Me</span></span>
  </a>

  <!-- Desktop nav links -->
  <div class="nav-links">

    <div class="nav-item">
      <a href="home.php" class="nav-link <?= $cur==='home.php'?'active':'' ?>">Home</a>
    </div>

    <!-- ⚔️ Play dropdown -->
    <div class="nav-item">
      <span class="nav-link <?= in_array($cur,['versus.php','lobby.php','battle.php'])?'active':'' ?>">
        ⚔️ Play <span class="nav-chev">▾</span>
      </span>
      <div class="nav-dd">
        <a href="versus.php" class="dd-row">
          <span class="dd-icon">⚔️</span>
          <div>
            <div class="dd-title">Versus <span class="badge badge-red">1v1</span></div>
            <div class="dd-desc">Challenge a coder, match CSS to target</div>
          </div>
        </a>
        <a href="lobby.php" class="dd-row">
          <span class="dd-icon">🏟️</span>
          <div>
            <div class="dd-title">Lobby <span class="badge badge-blue">up to 8</span></div>
            <div class="dd-desc">Host or join a room — up to 8 players</div>
          </div>
        </a>
      </div>
    </div>

    <!-- 📡 Watch dropdown -->
    <div class="nav-item">
      <span class="nav-link <?= in_array($cur,['live.php','leaderboard.php'])?'active':'' ?>">
        Watch <span class="nav-chev">▾</span>
      </span>
      <div class="nav-dd">
        <a href="live.php" class="dd-row">
          <span class="dd-icon">📡</span>
          <div>
            <div class="dd-title">Live <span class="badge badge-live">● LIVE</span></div>
            <div class="dd-desc">Watch ongoing battles in real time</div>
          </div>
        </a>
        <a href="leaderboard.php" class="dd-row">
          <span class="dd-icon">🏆</span>
          <div>
            <div class="dd-title">Rankings</div>
            <div class="dd-desc">Top coders ranked by wins &amp; score</div>
          </div>
        </a>
      </div>
    </div>

    <!-- ✨ Create dropdown -->
    <div class="nav-item">
      <span class="nav-link <?= in_array($cur,['menu_builder.php','showcase.php','autopost.php'])?'active':'' ?>">
        ✨ Create <span class="nav-chev">▾</span>
      </span>
      <div class="nav-dd">
        <a href="menu_builder.php" class="dd-row">
          <span class="dd-icon">🎨</span>
          <div>
            <div class="dd-title">UI Builder</div>
            <div class="dd-desc">Design UI components with live preview</div>
          </div>
        </a>
        <a href="showcase.php" class="dd-row">
          <span class="dd-icon">🖼️</span>
          <div>
            <div class="dd-title">Showcase</div>
            <div class="dd-desc">Browse &amp; share community creations</div>
          </div>
        </a>
        <div class="dd-sep"></div>
        <a href="autopost.php" class="dd-row">
          <span class="dd-icon">🗓️</span>
          <div>
            <div class="dd-title">Schedule</div>
            <div class="dd-desc">Auto-post &amp; schedule your content</div>
          </div>
        </a>
      </div>
    </div>

    <!-- Messages (logged in only) -->
    <?php if ($user): ?>
    <div class="nav-item">
      <a href="messages.php" class="nav-link <?= $cur==='messages.php'?'active':'' ?>">
        💬 Messages
      </a>
    </div>
    <?php endif; ?>

  </div><!-- /nav-links -->

  <div class="nav-spacer"></div>

  <!-- Desktop right -->
  <div class="nav-right">
    <?php if ($user): ?>
      <a href="notifications.php" class="notif-bell" id="navNotifBell" title="Notifications">
        🔔<span class="notif-bell-badge" id="navNotifBadge"></span>
      </a>
      <a href="profile.php" class="nav-chip">
        <span class="nav-av"><?= e($user['avatar']) ?></span>
        <span><?= e($user['username']) ?></span>
      </a>
      <?php if(isAdmin()): ?>
      <a href="admin/index.php" class="btn-sm btn-admin">⚡ Admin</a>
      <?php endif; ?>
      <a href="logout.php" class="btn-sm btn-danger">Logout</a>
    <?php else: ?>
      <a href="login.php"    class="btn-sm btn-outline">Login</a>
      <a href="register.php" class="btn-sm btn-primary">🎮 Play Now</a>
    <?php endif; ?>
  </div>

  <!-- Hamburger -->
  <button class="nav-toggle" id="navToggle" aria-label="Toggle menu">
    <span></span><span></span><span></span>
  </button>

</nav>

<!-- ══ Mobile Drawer ══ -->
<div class="mobile-menu" id="mobileMenu">

  <!-- ⚔️ Play -->
  <div class="drawer-section">⚔️ Play</div>
  <a href="versus.php" class="nav-link <?= $cur==='versus.php'?'active':'' ?>">
    <span class="nav-link-icon">⚔️</span>Versus <span class="badge badge-red" style="margin-left:auto">1v1</span>
  </a>
  <div class="drawer-hint">Challenge a player — match your CSS to a target design</div>

  <a href="lobby.php" class="nav-link <?= $cur==='lobby.php'?'active':'' ?>">
    <span class="nav-link-icon">🏟️</span>Lobby <span class="badge badge-blue" style="margin-left:auto">up to 8</span>
  </a>
  <div class="drawer-hint">Host or join an open room with multiple players</div>

  <!-- 📡 Watch -->
  <div class="nav-divider"></div>
  <div class="drawer-section">📡 Watch</div>
  <a href="live.php" class="nav-link <?= $cur==='live.php'?'active':'' ?>">
    <span class="nav-link-icon">📡</span>Live <span class="badge badge-live" style="margin-left:auto">● LIVE</span>
  </a>
  <div class="drawer-hint">Watch active battles happening right now</div>

  <a href="leaderboard.php" class="nav-link <?= $cur==='leaderboard.php'?'active':'' ?>">
    <span class="nav-link-icon">🏆</span>Rankings
  </a>
  <div class="drawer-hint">Top coders ranked by wins, score &amp; streaks</div>

  <!-- ✨ Create -->
  <div class="nav-divider"></div>
  <div class="drawer-section">✨ Create</div>
  <a href="menu_builder.php" class="nav-link <?= $cur==='menu_builder.php'?'active':'' ?>">
    <span class="nav-link-icon">🎨</span>UI Builder
  </a>
  <div class="drawer-hint">Design menus &amp; components visually with live preview</div>

  <a href="showcase.php" class="nav-link <?= $cur==='showcase.php'?'active':'' ?>">
    <span class="nav-link-icon">🖼️</span>Showcase
  </a>
  <div class="drawer-hint">Browse &amp; share community creations</div>

  <a href="autopost.php" class="nav-link <?= $cur==='autopost.php'?'active':'' ?>">
    <span class="nav-link-icon">🗓️</span>Schedule
  </a>
  <div class="drawer-hint">Auto-post &amp; schedule your content</div>

  <!-- Messages -->
  <?php if ($user): ?>
  <div class="nav-divider"></div>
  <a href="messages.php" class="nav-link <?= $cur==='messages.php'?'active':'' ?>">
    <span class="nav-link-icon">💬</span>Messages
  </a>
  <a href="notifications.php" class="nav-link <?= $cur==='notifications.php'?'active':'' ?>">
    <span class="nav-link-icon">🔔</span>Notifications
    <span id="mobileNotifBadge" style="background:var(--pink);color:#fff;font-size:10px;font-weight:800;font-family:var(--font-mono);min-width:17px;height:17px;border-radius:9px;display:none;align-items:center;justify-content:center;padding:0 3px;margin-left:auto"></span>
  </a>
  <?php endif; ?>

  <div class="nav-divider"></div>

  <?php if ($user): ?>
    <div class="mobile-user">
      <span style="font-size:24px"><?= e($user['avatar']) ?></span>
      <span><?= e($user['username']) ?></span>
    </div>
    <a href="profile.php" class="drawer-btn" style="background:var(--bg3);border:1px solid var(--border);color:var(--text)">👤 My Profile</a>
    <a href="home.php"    class="drawer-btn" style="background:var(--bg3);border:1px solid var(--border);color:var(--muted)">🏠 Home</a>
    <a href="logout.php"  class="drawer-btn" style="background:rgba(255,45,111,.1);border:1px solid rgba(255,45,111,.3);color:var(--pink)">🚪 Logout</a>
  <?php else: ?>
    <a href="login.php"    class="drawer-btn" style="background:var(--bg3);border:1px solid var(--border);color:var(--muted)">🔑 Login</a>
    <a href="register.php" class="drawer-btn" style="background:var(--green);color:#080b12">🎮 Play Now — it's free</a>
  <?php endif; ?>

</div>

<script>
(function(){
  var toggle = document.getElementById('navToggle');
  var menu   = document.getElementById('mobileMenu');
  if(toggle && menu){
    toggle.addEventListener('click', function(){
      toggle.classList.toggle('open');
      menu.classList.toggle('open');
      document.body.style.overflow = menu.classList.contains('open') ? 'hidden' : '';
    });
    document.addEventListener('click', function(e){
      if(!toggle.contains(e.target) && !menu.contains(e.target)){
        toggle.classList.remove('open');
        menu.classList.remove('open');
        document.body.style.overflow = '';
      }
    });
    document.addEventListener('keydown', function(e){ if(e.key==='Escape'){ toggle.classList.remove('open'); menu.classList.remove('open'); document.body.style.overflow=''; } });
    menu.querySelectorAll('a').forEach(function(a){ a.addEventListener('click', function(){ toggle.classList.remove('open'); menu.classList.remove('open'); document.body.style.overflow=''; }); });
  }
})();
</script>

<div id="toast"></div>
<?php
}

function pageFooter(): void { ?>
<script>
function showToast(msg){const t=document.getElementById('toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2500)}
// ── Notification badge auto-poll ──
(function(){
  const badge       = document.getElementById('navNotifBadge');
  const mobileBadge = document.getElementById('mobileNotifBadge');
  function pollBadge(){
    fetch('notifications.php?action=unread_count')
      .then(r=>r.json())
      .then(d=>{
        const n = d.unread || 0;
        const label = n > 99 ? '99+' : (n || '');
        if(badge){ badge.textContent=label; badge.style.display=n>0?'flex':'none'; }
        if(mobileBadge){ mobileBadge.textContent=label; mobileBadge.style.display=n>0?'flex':'none'; }
      }).catch(()=>{});
  }
  window.refreshNotifBadge = pollBadge;
  if(badge || mobileBadge){ pollBadge(); setInterval(pollBadge, 10000); }
})();
</script>
</body></html>
<?php }
