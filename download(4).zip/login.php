<?php
require_once 'includes/config.php';
require_once 'includes/layout.php';

if (auth()) { header('Location: index.php'); exit; }

$error   = '';
$success = getFlash('success');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $login    = trim($_POST['login']    ?? '');
  $password = $_POST['password']      ?? '';

  $stmt = db()->prepare('SELECT * FROM users WHERE username=? OR email=? LIMIT 1');
  $stmt->execute([$login, $login]);
  $user = $stmt->fetch();

  if ($user && password_verify($password, $user['password'])) {
    $_SESSION['user'] = ['id'=>$user['id'],'username'=>$user['username'],'avatar'=>$user['avatar']];
    header('Location: index.php'); exit;
  } else {
    $error = 'Invalid username/email or password.';
  }
}

pageHeader('Login');
?>
<style>
.social-divider{display:flex;align-items:center;gap:12px;margin:20px 0;color:var(--muted);font-size:11px;font-family:var(--font-mono);letter-spacing:1px}
.social-divider::before,.social-divider::after{content:'';flex:1;height:1px;background:var(--border)}
.social-btns{display:flex;flex-direction:column;gap:10px;margin-bottom:4px}
.social-btn{display:flex;align-items:center;gap:12px;padding:11px 16px;border-radius:12px;border:1px solid var(--border);background:var(--bg3);color:var(--text);font-size:13px;font-weight:600;text-decoration:none;transition:border-color .2s,background .2s,transform .15s;font-family:var(--font-head);cursor:pointer}
.social-btn:hover{background:rgba(255,255,255,0.05);border-color:rgba(255,255,255,0.18);transform:translateY(-1px)}
.social-btn svg{width:20px;height:20px;flex-shrink:0}
.social-btn-label{flex:1;text-align:center}
.social-btn.google:hover{border-color:rgba(66,133,244,0.5)}
.social-btn.github:hover{border-color:rgba(255,255,255,0.35)}
.social-btn.facebook:hover{border-color:rgba(24,119,242,0.5)}
</style>

<div class="form-card">
  <h2>Welcome back</h2>
  <p>Log in to continue battling.</p>

  <!-- ── Social Login Buttons ── -->
  <div class="social-btns">

    <a href="auth_social.php?provider=google" class="social-btn google">
      <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M43.611 20.083H42V20H24v8h11.303c-1.649 4.657-6.08 8-11.303 8-6.627 0-12-5.373-12-12s5.373-12 12-12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4 12.955 4 4 12.955 4 24s8.955 20 20 20 20-8.955 20-20c0-1.341-.138-2.65-.389-3.917z" fill="#FFC107"/>
        <path d="M6.306 14.691l6.571 4.819C14.655 15.108 19.001 12 24 12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4 16.318 4 9.656 8.337 6.306 14.691z" fill="#FF3D00"/>
        <path d="M24 44c5.166 0 9.86-1.977 13.409-5.192l-6.19-5.238A11.91 11.91 0 0124 36c-5.202 0-9.619-3.317-11.283-7.946l-6.522 5.025C9.505 39.556 16.227 44 24 44z" fill="#4CAF50"/>
        <path d="M43.611 20.083H42V20H24v8h11.303a12.04 12.04 0 01-4.087 5.571l6.19 5.238C36.971 39.205 44 34 44 24c0-1.341-.138-2.65-.389-3.917z" fill="#1976D2"/>
      </svg>
      <span class="social-btn-label">Continue with Google</span>
    </a>

    <a href="auth_social.php?provider=github" class="social-btn github">
      <svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"/>
      </svg>
      <span class="social-btn-label">Continue with GitHub</span>
    </a>

    <a href="auth_social.php?provider=facebook" class="social-btn facebook">
      <svg viewBox="0 0 24 24" fill="#1877F2" xmlns="http://www.w3.org/2000/svg">
        <path d="M24 12.073C24 5.404 18.627 0 12 0S0 5.404 0 12.073C0 18.1 4.388 23.094 10.125 24v-8.437H7.078v-3.49h3.047V9.41c0-3.025 1.792-4.697 4.533-4.697 1.312 0 2.686.236 2.686.236v2.97h-1.513c-1.491 0-1.956.93-1.956 1.886v2.267h3.328l-.532 3.49h-2.796V24C19.612 23.094 24 18.1 24 12.073z"/>
      </svg>
      <span class="social-btn-label">Continue with Facebook</span>
    </a>

  </div>

  <div class="social-divider">OR LOGIN WITH EMAIL</div>

  <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
  <?php if ($success): ?><div class="alert alert-success"><?= e($success) ?></div><?php endif; ?>

  <form method="POST">
    <div class="field">
      <label>Username or Email</label>
      <input type="text" name="login" value="<?= e($_POST['login'] ?? '') ?>" placeholder="yourname or email" required autofocus>
    </div>
    <div class="field">
      <label>Password</label>
      <input type="password" name="password" placeholder="Your password" required>
    </div>
    <button type="submit" class="btn-full">Log In</button>
  </form>
  <div class="form-footer">No account? <a href="register.php">Register free</a></div>
</div>
<script src="assets/security.js"></script>
<?php pageFooter(); ?>
