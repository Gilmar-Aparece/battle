// ─── assets/security.js ──────────────────────────────────────────────────────
// Disables common client-side snooping shortcuts.
// NOTE: This is a UX deterrent — a determined developer can always bypass
// client-side protection. Pair it with server-side access control.

(function () {
  'use strict';

  // ── 1. Block right-click context menu ────────────────────────────────────
  document.addEventListener('contextmenu', function (e) {
    e.preventDefault();
    showWarning('Right-click is disabled.');
  });

  // ── 2. Block keyboard shortcuts ───────────────────────────────────────────
  document.addEventListener('keydown', function (e) {
    const key = e.key.toUpperCase();
    const ctrl = e.ctrlKey || e.metaKey; // Cmd on Mac

    // Ctrl+U  → view source
    if (ctrl && key === 'U') { e.preventDefault(); showWarning('View Source is disabled.'); return; }

    // Ctrl+S  → save page
    if (ctrl && key === 'S') { e.preventDefault(); showWarning('Saving is disabled.'); return; }

    // Ctrl+A  → select all
    if (ctrl && key === 'A') { e.preventDefault(); return; }

    // Ctrl+C / Ctrl+X  → copy / cut
    if (ctrl && (key === 'C' || key === 'X')) { e.preventDefault(); return; }

    // F12 → DevTools
    if (e.key === 'F12') { e.preventDefault(); showWarning('DevTools is disabled.'); return; }

    // Ctrl+Shift+I / Ctrl+Shift+J / Ctrl+Shift+C → DevTools panels
    if (ctrl && e.shiftKey && (key === 'I' || key === 'J' || key === 'C')) {
      e.preventDefault(); showWarning('DevTools is disabled.'); return;
    }

    // Ctrl+Shift+U → view-source in Firefox
    if (ctrl && e.shiftKey && key === 'U') { e.preventDefault(); showWarning('View Source is disabled.'); return; }

    // Ctrl+P → print (can expose source via "Save as PDF")
    if (ctrl && key === 'P') { e.preventDefault(); showWarning('Printing is disabled.'); return; }
  });

  // ── 3. Disable text selection via CSS ────────────────────────────────────
  document.documentElement.style.userSelect        = 'none';
  document.documentElement.style.webkitUserSelect  = 'none';
  document.documentElement.style.msUserSelect      = 'none';

  // ── 4. Block drag-and-drop (another way to grab assets) ──────────────────
  document.addEventListener('dragstart', function (e) { e.preventDefault(); });

  // ── 5. DevTools open detection (size heuristic) ──────────────────────────
  var devtoolsOpen = false;
  function checkDevTools() {
    var threshold = 160;
    if (
      window.outerWidth  - window.innerWidth  > threshold ||
      window.outerHeight - window.innerHeight > threshold
    ) {
      if (!devtoolsOpen) {
        devtoolsOpen = true;
        document.body.innerHTML =
          '<div style="display:flex;align-items:center;justify-content:center;' +
          'height:100vh;background:#0d0f12;color:#f75f5f;font-family:monospace;' +
          'font-size:20px;text-align:center;padding:40px">' +
          '🚫 DevTools detected.<br>Please close DevTools and refresh.' +
          '</div>';
      }
    } else {
      devtoolsOpen = false;
    }
  }
  setInterval(checkDevTools, 1000);

  // ── 6. Toast warning UI ───────────────────────────────────────────────────
  function showWarning(msg) {
    var existing = document.getElementById('__sec_toast');
    if (existing) existing.remove();

    var toast = document.createElement('div');
    toast.id = '__sec_toast';
    toast.textContent = '🔒 ' + msg;
    toast.style.cssText =
      'position:fixed;bottom:28px;left:50%;transform:translateX(-50%);' +
      'background:#1c2130;border:1px solid #f75f5f;color:#f75f5f;' +
      'font-family:monospace;font-size:13px;padding:10px 22px;' +
      'border-radius:8px;z-index:99999;opacity:1;transition:opacity 0.4s;' +
      'box-shadow:0 4px 20px rgba(0,0,0,0.6);pointer-events:none';
    document.body.appendChild(toast);

    setTimeout(function () {
      toast.style.opacity = '0';
      setTimeout(function () { toast.remove(); }, 400);
    }, 2200);
  }
})();
