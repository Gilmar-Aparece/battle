// ── Ban modal ─────────────────────────────────────────────────────────────────
function openBan(id, name) {
  document.getElementById('banUserId').value = id;
  document.getElementById('banTarget').textContent = name;
  document.getElementById('banModal').classList.add('open');
}
function closeBan() {
  document.getElementById('banModal').classList.remove('open');
}
document.getElementById('banModal').addEventListener('click', function(e) {
  if (e.target === this) closeBan();
});

// ── Bulk selection ────────────────────────────────────────────────────────────
function toggleAll(master) {
  var checked = master.checked;
  // sync both checkboxes (header + bar)
  document.getElementById('selectAll').checked   = checked;
  document.getElementById('selectAllTh').checked = checked;
  document.querySelectorAll('.row-cb').forEach(function(cb) { cb.checked = checked; });
  updateBulkCount();
}

function updateBulkCount() {
  var checkboxes = document.querySelectorAll('.row-cb');
  var checked    = document.querySelectorAll('.row-cb:checked');
  var count      = checked.length;
  var total      = checkboxes.length;

  // Update count badge
  document.getElementById('bulkCount').textContent = count;

  // Enable / disable buttons
  var allBtns = document.querySelectorAll('.bulk-btn');
  allBtns.forEach(function(b) {
    b.classList.toggle('enabled', count > 0);
  });

  // Highlight the bar
  document.getElementById('bulkBar').classList.toggle('has-selection', count > 0);

  // Update hint text
  var hint = document.getElementById('bulkHint');
  hint.textContent = count > 0
    ? count + ' user' + (count > 1 ? 's' : '') + ' selected — choose an action above'
    : 'Select rows to enable bulk actions';

  // Indeterminate state for master checkboxes
  ['selectAll', 'selectAllTh'].forEach(function(id) {
    var el = document.getElementById(id);
    if (!el) return;
    el.indeterminate = count > 0 && count < total;
    el.checked = total > 0 && count === total;
  });

  // Highlight selected rows
  checkboxes.forEach(function(cb) {
    var row = cb.closest('tr');
    if (row) row.classList.toggle('row-selected', cb.checked);
  });
}

function bulkDo(op, confirmMsg) {
  var count = document.querySelectorAll('.row-cb:checked').length;
  if (count === 0) { alert('No users selected.'); return; }
  if (!confirm(confirmMsg + '\n\n' + count + ' user(s) will be affected.')) return;
  document.getElementById('bulkOp').value = op;
  document.getElementById('bulkForm').submit();
}

// ── Sidebar hamburger ─────────────────────────────────────────────────────────
(function(){
  var btn     = document.querySelector('.hamburger');
  var sidebar = document.querySelector('.sidebar');
  var overlay = document.querySelector('.sidebar-overlay');
  if (!btn) return;
  function open()  { sidebar.classList.add('open');    overlay.classList.add('visible');    document.body.style.overflow='hidden'; }
  function close() { sidebar.classList.remove('open'); overlay.classList.remove('visible'); document.body.style.overflow=''; }
  btn.addEventListener('click',   function() { sidebar.classList.contains('open') ? close() : open(); });
  overlay.addEventListener('click', close);
  document.addEventListener('keydown', function(e) { if (e.key === 'Escape') close(); });
})();
