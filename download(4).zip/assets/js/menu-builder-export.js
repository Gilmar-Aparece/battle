// Wrapper that calls existing downloadCode logic then routes to approval
function downloadCode_submit(exportName) {
  // Re-use existing fullCode build logic from downloadCode() but skip the direct download
  // We call the original function then intercept — here we just call the export builder:
  openExportAndSubmit(exportName);
}

function openExportAndSubmit(exportName) {
  exportName = (exportName || 'my-website').replace(/\.html$/i,'').trim() || 'my-website';
  const fileName = exportName + '.html';

  const frame = document.getElementById('import-preview-frame');
  if (frame && frame.style.display !== 'none' && frame.srcdoc) {
    submitExportForApproval(exportName, frame.srcdoc);
    return;
  }

  // Builder mode — clone and clean the canvas
  const preview       = document.getElementById('preview');
  const cssCode       = document.getElementById('cssCode');
  const jsCode        = document.getElementById('jsCode');
  const exportClone   = preview.cloneNode(true);

  exportClone.querySelectorAll('.section-controls, .plus-btn, .widget-actions, .top-plus-btn').forEach(el => el.remove());
  exportClone.querySelectorAll('.widget-wrapper').forEach(wrapper => {
    while (wrapper.firstChild) wrapper.parentNode.insertBefore(wrapper.firstChild, wrapper);
    wrapper.remove();
  });
  exportClone.querySelectorAll('*').forEach(el => {
    el.removeAttribute('contenteditable');
    el.removeAttribute('draggable');
    el.classList.remove('dragging-section', 'selected', 'selected-global');
    if (el.getAttribute('class') === '') el.removeAttribute('class');
  });
  exportClone.querySelectorAll('.section, .container, .container-advanced, .column').forEach(el => {
    const s = el.getAttribute('style') || '';
    el.setAttribute('style', s.replace(/border:\s*1px dashed[^;]*;?/g, '').trim());
  });

  /* ── Pretty-print the cloned HTML ── */
  function prettyNode(node, level) {
    const pad = '  '.repeat(level);
    let   out = '';
    const INLINE = new Set(['a','abbr','b','bdi','bdo','br','cite','code','data','dfn',
                             'em','i','kbd','mark','q','s','samp','small','span','strong',
                             'sub','sup','time','u','var','wbr']);
    node.childNodes.forEach(child => {
      if (child.nodeType === 3) {
        const t = child.textContent.replace(/\s+/g, ' ').trim();
        if (t) out += pad + t + '\n';
      } else if (child.nodeType === 1) {
        const tag   = child.tagName.toLowerCase();
        const attrs = Array.from(child.attributes)
          .filter(a => !['contenteditable','draggable'].includes(a.name))
          .map(a => ' ' + a.name + '="' + a.value + '"')
          .join('');
        const VOID = new Set(['area','base','br','col','embed','hr','img','input',
                               'link','meta','param','source','track','wbr']);
        if (VOID.has(tag)) {
          out += pad + '<' + tag + attrs + '>\n';
        } else {
          const inner = prettyNode(child, level + 1);
          if (!inner.trim()) {
            out += pad + '<' + tag + attrs + '></' + tag + '>\n';
          } else if (INLINE.has(tag) && !inner.includes('\n')) {
            out += pad + '<' + tag + attrs + '>' + inner.trim() + '</' + tag + '>\n';
          } else {
            out += pad + '<' + tag + attrs + '>\n' + inner + pad + '</' + tag + '>\n';
          }
        }
      }
    });
    return out;
  }

  const prettyBody = prettyNode(exportClone, 1);

  const fullCode = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${exportName}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
</head>
<body>

${prettyBody}

<script>
/* ── Custom Scripts ── */
${(jsCode ? jsCode.value : '')}
<\/script>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"><\/script>
</body>
</html>`;

  submitExportForApproval(exportName, fullCode);
}

// Load exports list when modal opens
document.addEventListener('DOMContentLoaded', function() {
  var modal = document.getElementById('exportModal');
  if (modal) {
    var observer = new MutationObserver(function(mutations) {
      mutations.forEach(function(m) {
        if (m.target.style.display === 'flex') refreshMyExports();
      });
    });
    observer.observe(modal, { attributes: true, attributeFilter: ['style'] });
  }
});
