/* ═══════════════════════════════════════════════════════
   FOLIO ONE LIVE EDITOR
   Communicates with the FolioOne iframe via contentDocument
   ═══════════════════════════════════════════════════════ */

// Get the FolioOne iframe document safely
function getFolioDoc() {
  const frame = document.getElementById('import-preview-frame');
  if (!frame || frame.style.display === 'none') return null;
  try { return frame.contentDocument || frame.contentWindow.document; } catch(e) { return null; }
}

// Re-serialize the iframe HTML back into projectFiles and show editor
function folioSync() {
  const doc = getFolioDoc();
  if (!doc) return;
  const html = '<!DOCTYPE html>\n' + doc.documentElement.outerHTML;
  projectFiles['index.html'] = { raw: html, selfContained: html };
  const frame = document.getElementById('import-preview-frame');
  if (frame) frame.srcdoc = html; // re-render to persist
}

// Open the FolioOne editor panel and populate tabs
function openFolioEditor() {
  const doc = getFolioDoc();
  if (!doc) {
    alert('Load the FolioOne template first (it should be the default when you open the builder).');
    return;
  }
  document.getElementById('widgetSettings').style.display   = 'none';
  document.getElementById('folioEditorPanel').style.display = 'block';
  buildFolioTabs(doc);
}

function buildFolioTabs(doc) {
  const bar     = document.getElementById('folioTabBar');
  const content = document.getElementById('folioTabContent');
  bar.innerHTML = '';
  const tabs = [
    { id:'nav',       label:'🔗 Navbar'   },
    { id:'hero',      label:'🏠 Hero'     },
    { id:'services',  label:'🛠 Services' },
    { id:'portfolio', label:'🖼 Portfolio'},
    { id:'about',     label:'👤 About'    },
    { id:'contact',   label:'✉ Contact'  },
    { id:'footer',    label:'📋 Footer'  },
  ];
  tabs.forEach((t, i) => {
    const btn = document.createElement('button');
    btn.className = 'editor-btn';
    btn.style = 'padding:4px 8px;font-size:10px;flex-shrink:0;' + (i===0?'background:var(--accent);color:#fff;':'');
    btn.textContent = t.label;
    btn.onclick = () => {
      bar.querySelectorAll('button').forEach(b => { b.style.background=''; b.style.color=''; });
      btn.style.background = 'var(--accent)'; btn.style.color = '#fff';
      renderFolioTab(t.id, doc);
    };
    bar.appendChild(btn);
  });
  renderFolioTab('nav', doc);
}

function renderFolioTab(tab, doc) {
  const el = document.getElementById('folioTabContent');
  el.innerHTML = '';

  if (tab === 'nav')      renderFolioNavEditor(doc, el);
  if (tab === 'hero')     renderFolioSectionEditor(doc, el, '#folio-hero',      folioHeroFields);
  if (tab === 'services') renderFolioServicesEditor(doc, el);
  if (tab === 'portfolio')renderFolioPortfolioEditor(doc, el);
  if (tab === 'about')    renderFolioSectionEditor(doc, el, '#folio-about',     folioAboutFields);
  if (tab === 'contact')  renderFolioSectionEditor(doc, el, '#folio-contact',   folioContactFields);
  if (tab === 'footer')   renderFolioFooterEditor(doc, el);
}

/* ── Shared helpers ── */
function folioMakeInput(label, value, onChange) {
  const wrap = document.createElement('div');
  wrap.style = 'margin-bottom:8px;';
  wrap.innerHTML = `<label style="font-size:10px;color:var(--text-muted);display:block;margin-bottom:3px;text-transform:uppercase;letter-spacing:.06em;">${label}</label>
    <input type="text" value="${(value||'').replace(/"/g,'&quot;')}"
      style="width:100%;background:var(--surface3);border:1px solid var(--border);color:var(--text);
             padding:6px 8px;border-radius:4px;font-size:12px;outline:none;box-sizing:border-box;">`;
  wrap.querySelector('input').oninput = e => onChange(e.target.value);
  return wrap;
}
function folioMakeColor(label, value, onChange) {
  const wrap = document.createElement('div');
  wrap.style = 'margin-bottom:8px;display:flex;align-items:center;gap:8px;';
  wrap.innerHTML = `<label style="font-size:10px;color:var(--text-muted);flex:1;text-transform:uppercase;letter-spacing:.06em;">${label}</label>
    <input type="color" value="${value||'#6366f1'}" style="width:32px;height:28px;border:none;background:none;cursor:pointer;border-radius:4px;">`;
  wrap.querySelector('input').oninput = e => onChange(e.target.value);
  return wrap;
}
function folioMakeTextarea(label, value, onChange) {
  const wrap = document.createElement('div');
  wrap.style = 'margin-bottom:8px;';
  wrap.innerHTML = `<label style="font-size:10px;color:var(--text-muted);display:block;margin-bottom:3px;text-transform:uppercase;letter-spacing:.06em;">${label}</label>
    <textarea style="width:100%;background:var(--surface3);border:1px solid var(--border);color:var(--text);
             padding:6px 8px;border-radius:4px;font-size:12px;outline:none;box-sizing:border-box;resize:vertical;min-height:60px;">${(value||'').replace(/</g,'&lt;')}</textarea>`;
  wrap.querySelector('textarea').oninput = e => onChange(e.target.value);
  return wrap;
}
function folioMakeSelect(label, options, current, onChange) {
  const wrap = document.createElement('div');
  wrap.style = 'margin-bottom:8px;';
  const opts = options.map(o => `<option value="${o.v}" ${o.v===current?'selected':''}>${o.l}</option>`).join('');
  wrap.innerHTML = `<label style="font-size:10px;color:var(--text-muted);display:block;margin-bottom:3px;text-transform:uppercase;letter-spacing:.06em;">${label}</label>
    <select style="width:100%;background:var(--surface3);border:1px solid var(--border);color:var(--text);
             padding:6px 8px;border-radius:4px;font-size:12px;outline:none;box-sizing:border-box;">${opts}</select>`;
  wrap.querySelector('select').onchange = e => onChange(e.target.value);
  return wrap;
}
function folioLabel(text) {
  const d = document.createElement('div');
  d.style = 'font-size:11px;font-weight:700;color:var(--text);text-transform:uppercase;letter-spacing:.08em;margin:12px 0 6px;border-bottom:1px solid var(--border);padding-bottom:4px;';
  d.textContent = text;
  return d;
}
function folioSaveThenRefresh(doc, tab) {
  // Persist changes to srcdoc then re-render the tab
  const html = '<!DOCTYPE html>\n' + doc.documentElement.outerHTML;
  projectFiles['index.html'] = { raw: html, selfContained: html };
  renderFolioTab(tab, doc);
}

/* ══════════════════════════════════════════════
   NAVBAR EDITOR — full add/edit/delete + sub-dropdown
   ══════════════════════════════════════════════ */
function renderFolioNavEditor(doc, el) {
  const nav      = doc.getElementById('folio-nav-component');
  const mainNav  = doc.getElementById('folio-main-nav');
  if (!nav || !mainNav) { el.innerHTML='<p style="color:var(--text-muted);font-size:12px;">Navbar not found.</p>'; return; }

  // ── Logo ──
  el.appendChild(folioLabel('Logo'));
  const logoEl = nav.querySelector('.folio-nav-logo');
  if (logoEl) {
    el.appendChild(folioMakeInput('Logo Text', logoEl.textContent, v => { logoEl.textContent = v; folioSaveThenRefresh(doc,'nav'); }));
    el.appendChild(folioMakeColor('Logo Color', rgbToHex(getComputedStyle(logoEl).color) || '#6366f1', v => { logoEl.style.color = v; folioSaveThenRefresh(doc,'nav'); }));
  }

  // ── Navbar background ──
  el.appendChild(folioLabel('Navbar Style'));
  el.appendChild(folioMakeColor('Background', rgbToHex(getComputedStyle(nav).backgroundColor)||'#0b0e14', v => { nav.style.background = v; folioSaveThenRefresh(doc,'nav'); }));
  el.appendChild(folioMakeSelect('Position', [
    {v:'sticky',l:'Sticky (follows scroll)'},{v:'fixed',l:'Fixed'},{v:'relative',l:'Static'}
  ], nav.style.position||'sticky', v => { nav.style.position = v; folioSaveThenRefresh(doc,'nav'); }));

  // ── Nav Links ──
  el.appendChild(folioLabel('Navigation Links'));

  // Get only top-level <li> items (exclude the drawer-socials li)
  const items = [...mainNav.querySelectorAll(':scope > li')].filter(li => !li.classList.contains('folio-drawer-socials-li'));

  items.forEach((li, idx) => {
    const linkEl    = li.querySelector('a') || li;
    const linkText  = linkEl.tagName === 'A' ? linkEl.textContent.trim() : li.childNodes[0]?.textContent?.trim() || '';
    const linkHref  = linkEl.tagName === 'A' ? linkEl.getAttribute('href') || '#' : '#';
    const hasDrop   = !!li.querySelector('.folio-dropdown');

    const card = document.createElement('div');
    card.style = 'background:var(--surface3);border:1px solid var(--border);border-radius:6px;padding:8px;margin-bottom:6px;';

    // Link row
    const linkRow = document.createElement('div');
    linkRow.style = 'display:flex;align-items:center;gap:5px;margin-bottom:6px;';
    linkRow.innerHTML = `
      <span style="background:var(--accent);color:#fff;font-size:8px;font-weight:700;padding:2px 5px;border-radius:3px;flex-shrink:0;">LINK</span>
      <input type="text" value="${linkText.replace(/"/g,'&quot;')}" placeholder="Label"
        style="flex:1;min-width:0;background:var(--bg);border:1px solid var(--border);color:var(--text);
               padding:5px 7px;border-radius:4px;font-size:12px;outline:none;">
      <input type="text" value="${linkHref.replace(/"/g,'&quot;')}" placeholder="href"
        style="flex:1;min-width:0;background:var(--bg);border:1px solid var(--border);color:var(--text);
               padding:5px 7px;border-radius:4px;font-size:12px;outline:none;">
      <button class="nb-del" style="background:#f43f5e22;border:1px solid #f43f5e55;color:#f43f5e;
               border-radius:3px;padding:2px 8px;font-size:14px;font-weight:700;cursor:pointer;line-height:1;">×</button>
    `;
    const [labelIn, hrefIn] = linkRow.querySelectorAll('input');
    labelIn.oninput = e => {
      if (linkEl.tagName === 'A') linkEl.textContent = e.target.value;
      else if (li.childNodes[0]) li.childNodes[0].textContent = e.target.value;
    };
    hrefIn.oninput = e => { if (linkEl.tagName === 'A') linkEl.setAttribute('href', e.target.value); };
    const delBtn = linkRow.querySelector('.nb-del');
    delBtn.onclick = () => { li.remove(); folioSaveThenRefresh(doc,'nav'); };
    card.appendChild(linkRow);

    // Sub-dropdown section
    const dropList = li.querySelector('.folio-dropdown');
    if (dropList) {
      const subItems = dropList.querySelectorAll(':scope > li');
      subItems.forEach(subLi => {
        const subA    = subLi.querySelector('a') || subLi;
        const subText = subA.tagName === 'A' ? subA.textContent.trim() : subLi.textContent.trim();
        const subHref = subA.tagName === 'A' ? subA.getAttribute('href') || '#' : '#';
        const subRow  = document.createElement('div');
        subRow.style  = 'display:flex;align-items:center;gap:5px;margin-bottom:4px;margin-left:14px;';
        subRow.innerHTML = `
          <span style="width:2px;height:20px;background:var(--accent);border-radius:2px;flex-shrink:0;"></span>
          <span style="background:#6366f1;color:#fff;font-size:7px;font-weight:700;padding:2px 4px;border-radius:2px;flex-shrink:0;">SUB</span>
          <input type="text" value="${subText.replace(/"/g,'&quot;')}" placeholder="Label"
            style="flex:1;min-width:0;background:var(--bg);border:1px solid var(--border);color:var(--text);
                   padding:4px 6px;border-radius:4px;font-size:11px;outline:none;">
          <input type="text" value="${subHref.replace(/"/g,'&quot;')}" placeholder="href"
            style="flex:1;min-width:0;background:var(--bg);border:1px solid var(--border);color:var(--text);
                   padding:4px 6px;border-radius:4px;font-size:11px;outline:none;">
          <button style="background:#f43f5e22;border:1px solid #f43f5e55;color:#f43f5e;
                   border-radius:3px;padding:2px 7px;font-size:13px;font-weight:700;cursor:pointer;line-height:1;">×</button>
        `;
        const [sl, sh] = subRow.querySelectorAll('input');
        sl.oninput = e => { if (subA.tagName==='A') subA.textContent=e.target.value; else subLi.textContent=e.target.value; };
        sh.oninput = e => { if (subA.tagName==='A') subA.setAttribute('href',e.target.value); };
        subRow.querySelector('button').onclick = () => {
          subLi.remove();
          if (!dropList.querySelector('li')) {
            dropList.remove();
            li.classList.remove('folio-has-dropdown');
          }
          folioSaveThenRefresh(doc,'nav');
        };
        card.appendChild(subRow);
      });
    }

    // Add sub-item + move up/down buttons
    const actRow = document.createElement('div');
    actRow.style = 'display:flex;gap:5px;margin-top:4px;';
    actRow.innerHTML = `
      <button class="add-sub-btn" style="flex:1;background:var(--surface2);border:1px solid var(--border);color:var(--text-muted);
              border-radius:4px;padding:4px 6px;font-size:10px;cursor:pointer;">+ Sub-item</button>
      <button class="move-up-btn" style="background:var(--surface2);border:1px solid var(--border);color:var(--text-muted);
              border-radius:4px;padding:4px 8px;font-size:10px;cursor:pointer;" title="Move up">↑</button>
      <button class="move-dn-btn" style="background:var(--surface2);border:1px solid var(--border);color:var(--text-muted);
              border-radius:4px;padding:4px 8px;font-size:10px;cursor:pointer;" title="Move down">↓</button>
    `;
    actRow.querySelector('.add-sub-btn').onclick = () => {
      let dd = li.querySelector('.folio-dropdown');
      if (!dd) {
        li.classList.add('folio-has-dropdown');
        dd = doc.createElement('ul');
        dd.className = 'folio-dropdown';
        li.appendChild(dd);
      }
      const newSub  = doc.createElement('li');
      const newSubA = doc.createElement('a');
      newSubA.href  = '#'; newSubA.textContent = 'Sub Item';
      newSub.appendChild(newSubA);
      dd.appendChild(newSub);
      folioSaveThenRefresh(doc,'nav');
    };
    actRow.querySelector('.move-up-btn').onclick = () => {
      const prev = li.previousElementSibling;
      if (prev && !prev.classList.contains('folio-drawer-socials-li')) { mainNav.insertBefore(li, prev); folioSaveThenRefresh(doc,'nav'); }
    };
    actRow.querySelector('.move-dn-btn').onclick = () => {
      const next = li.nextElementSibling;
      if (next && !next.classList.contains('folio-drawer-socials-li')) { mainNav.insertBefore(next, li); folioSaveThenRefresh(doc,'nav'); }
    };
    card.appendChild(actRow);
    el.appendChild(card);
  });

  // Add link button
  const addBtn = document.createElement('button');
  addBtn.className = 'btn btn-primary';
  addBtn.style     = 'width:100%;margin-top:4px;font-size:11px;';
  addBtn.textContent = '+ Add Nav Link';
  addBtn.onclick = () => {
    const newLi = doc.createElement('li');
    const newA  = doc.createElement('a');
    newA.href = '#'; newA.textContent = 'New Link';
    newA.setAttribute('onclick','folioCloseNav()');
    newLi.appendChild(newA);
    // Insert before the drawer socials li if present
    const drawerSocials = mainNav.querySelector('.folio-drawer-socials-li');
    if (drawerSocials) mainNav.insertBefore(newLi, drawerSocials);
    else mainNav.appendChild(newLi);
    folioSaveThenRefresh(doc,'nav');
  };
  el.appendChild(addBtn);

  // Ensure dropdown CSS exists in doc
  ensureFolioDropdownCSS(doc);
}

// Inject dropdown CSS into the FolioOne document if missing
function ensureFolioDropdownCSS(doc) {
  if (doc.getElementById('folio-dropdown-css')) return;
  const s = doc.createElement('style');
  s.id = 'folio-dropdown-css';
  s.textContent = `
    /* ── Folio Dropdown Menus ── */
    .folio-has-dropdown { position: relative; }
    .folio-dropdown {
      list-style: none; margin: 0; padding: 6px 0;
      position: absolute; top: 100%; left: 0;
      min-width: 180px;
      background: #0b0e14;
      border: 1px solid rgba(255,255,255,.1);
      border-radius: 8px;
      box-shadow: 0 12px 32px rgba(0,0,0,.5);
      opacity: 0; visibility: hidden; transform: translateY(6px);
      transition: opacity .18s, transform .18s, visibility .18s;
      z-index: 2000;
    }
    .folio-has-dropdown:hover > .folio-dropdown { opacity:1; visibility:visible; transform:translateY(0); }
    .folio-dropdown li a {
      display: block; padding: 9px 18px;
      color: #d1d5db; font-size: 13px; text-decoration: none;
      transition: background .15s, color .15s;
      white-space: nowrap;
    }
    .folio-dropdown li a:hover { background: rgba(99,102,241,.15); color: #fff; padding-left: 22px; }
    /* Mobile: show sub-items inline in drawer */
    @media(max-width:900px){
      .folio-dropdown { position:static; opacity:1; visibility:visible; transform:none; box-shadow:none; border:none; background:transparent; padding:0; }
      .folio-dropdown li a { padding:10px 28px 10px 42px; font-size:13px; border-bottom:1px solid rgba(255,255,255,.04); color:#9ca3af; }
    }
  `;
  doc.head.appendChild(s);
}

/* ══════════════════════════════════════════════
   HERO SECTION EDITOR
   ══════════════════════════════════════════════ */
function folioHeroFields(doc, section, el) {
  const h1   = section.querySelector('h1');
  const span = h1 ? h1.querySelector('span') : null;
  const lead = section.querySelector('p.lead');
  const btn1 = section.querySelector('.btn-folio-primary');
  const btn2 = section.querySelector('.btn-folio-outline');

  if (h1) el.appendChild(folioMakeInput('Headline "Hello, I\'m"', h1.childNodes[0]?.textContent?.trim()||'Hello, I\'m', v => {
    if (h1.childNodes[0]) h1.childNodes[0].textContent = v + ' ';
  }));
  if (span) el.appendChild(folioMakeInput('Name / Highlight', span.textContent, v => { span.textContent = v; }));
  if (lead) el.appendChild(folioMakeTextarea('Subtitle / Bio', lead.textContent, v => { lead.textContent = v; }));
  if (btn1) el.appendChild(folioMakeInput('Button 1 Text', btn1.textContent, v => { btn1.textContent = v; }));
  if (btn1) el.appendChild(folioMakeInput('Button 1 Link', btn1.getAttribute('href')||'#', v => { btn1.setAttribute('href',v); }));
  if (btn2) el.appendChild(folioMakeInput('Button 2 Text', btn2.textContent, v => { btn2.textContent = v; }));
  if (btn2) el.appendChild(folioMakeInput('Button 2 Link', btn2.getAttribute('href')||'#', v => { btn2.setAttribute('href',v); }));

  el.appendChild(folioLabel('Hero Colors'));
  el.appendChild(folioMakeColor('Accent Color', '#6366f1', v => {
    section.querySelectorAll('[style*="#6366f1"]').forEach(n => { n.style.cssText = n.style.cssText.replace(/#6366f1/g,v); });
    if (span) span.style.color = v;
  }));
  el.appendChild(folioLabel('Hero Background'));
  const bgBtns = document.createElement('div');
  bgBtns.style = 'display:grid;grid-template-columns:1fr 1fr;gap:4px;';
  [
    ['Light','linear-gradient(135deg,#f8fafc,#f1f5f9)'],
    ['Dark','#0b0e14'],
    ['Purple','linear-gradient(135deg,#6366f1,#8b5cf6)'],
    ['Blue','linear-gradient(135deg,#0ea5e9,#6366f1)'],
    ['Green','linear-gradient(135deg,#22c55e,#0ea5e9)'],
    ['Custom',''],
  ].forEach(([l,bg]) => {
    const b = document.createElement('button');
    b.className = 'editor-btn'; b.style='font-size:10px;'; b.textContent = l;
    b.onclick = () => {
      if (bg) section.style.background = bg;
      else {
        const c = prompt('CSS background:', section.style.background);
        if (c) section.style.background = c;
      }
    };
    bgBtns.appendChild(b);
  });
  el.appendChild(bgBtns);
}

/* ══════════════════════════════════════════════
   SERVICES EDITOR
   ══════════════════════════════════════════════ */
function renderFolioServicesEditor(doc, el) {
  const section = doc.getElementById('folio-services');
  if (!section) { el.innerHTML='<p style="color:var(--text-muted);font-size:12px;">Services section not found.</p>'; return; }

  el.appendChild(folioLabel('Section Title'));
  const title = section.querySelector('.section-title');
  const sub   = section.querySelector('.section-sub');
  if (title) el.appendChild(folioMakeInput('Title', title.textContent, v => { title.textContent = v; }));
  if (sub)   el.appendChild(folioMakeInput('Subtitle', sub.textContent, v => { sub.textContent = v; }));

  el.appendChild(folioLabel('Service Cards'));
  const cards = section.querySelectorAll('.service-card');
  cards.forEach((card, i) => {
    const h5   = card.querySelector('h5');
    const desc = card.querySelector('p');
    const icon = card.querySelector('.service-icon');
    const cardWrap = document.createElement('div');
    cardWrap.style = 'background:var(--surface3);border:1px solid var(--border);border-radius:6px;padding:8px;margin-bottom:8px;';
    cardWrap.appendChild(folioLabel(`Card ${i+1}`));
    if (icon) cardWrap.appendChild(folioMakeInput('Icon (emoji)', icon.textContent.trim(), v => { icon.textContent = v; }));
    if (h5)   cardWrap.appendChild(folioMakeInput('Title', h5.textContent, v => { h5.textContent = v; }));
    if (desc) cardWrap.appendChild(folioMakeTextarea('Description', desc.textContent, v => { desc.textContent = v; }));
    el.appendChild(cardWrap);
  });

  // Add/remove service card
  const addBtn = document.createElement('button');
  addBtn.className = 'btn btn-primary';
  addBtn.style = 'width:100%;font-size:11px;margin-top:4px;';
  addBtn.textContent = '+ Add Service Card';
  addBtn.onclick = () => {
    const grid = section.querySelector('.row.g-4');
    if (!grid) return;
    const col  = doc.createElement('div'); col.className='col-lg-4 col-md-6';
    col.innerHTML = `<div class="service-card"><div class="service-icon">⭐</div><h5 class="fw-bold mb-2" contenteditable="true">New Service</h5><p class="text-muted" contenteditable="true">Service description here.</p></div>`;
    grid.appendChild(col);
    folioSaveThenRefresh(doc,'services');
  };
  el.appendChild(addBtn);
}

/* ══════════════════════════════════════════════
   PORTFOLIO EDITOR
   ══════════════════════════════════════════════ */
function renderFolioPortfolioEditor(doc, el) {
  const section = doc.getElementById('folio-portfolio');
  if (!section) { el.innerHTML='<p style="color:var(--text-muted);font-size:12px;">Portfolio section not found.</p>'; return; }

  el.appendChild(folioLabel('Section Title'));
  const title = section.querySelector('h2');
  const sub   = section.querySelector('p.text-muted');
  if (title) el.appendChild(folioMakeInput('Title', title.textContent, v => { title.textContent = v; }));
  if (sub)   el.appendChild(folioMakeInput('Subtitle', sub.textContent, v => { sub.textContent = v; }));

  el.appendChild(folioLabel('Portfolio Cards'));
  const cards = section.querySelectorAll('.portfolio-card');
  cards.forEach((card, i) => {
    const cardWrap = document.createElement('div');
    cardWrap.style = 'background:var(--surface3);border:1px solid var(--border);border-radius:6px;padding:8px;margin-bottom:6px;display:flex;align-items:center;gap:6px;';
    const label = document.createElement('span');
    label.style = 'font-size:11px;color:var(--text-muted);flex:1;';
    label.textContent = `Card ${i+1}: ${card.textContent.trim()}`;

    const colorIn = document.createElement('input');
    colorIn.type  = 'color'; colorIn.title = 'Background color';
    colorIn.style = 'width:28px;height:28px;border:none;background:none;cursor:pointer;';
    colorIn.oninput = e => { card.style.background = e.target.value; };

    const imgBtn = document.createElement('button');
    imgBtn.style = 'background:var(--surface2);border:1px solid var(--border);color:var(--text-muted);border-radius:4px;padding:3px 7px;font-size:10px;cursor:pointer;';
    imgBtn.textContent = '🖼 Img';
    const fileIn = document.createElement('input'); fileIn.type='file'; fileIn.accept='image/*'; fileIn.style='display:none;';
    imgBtn.onclick = () => fileIn.click();
    fileIn.onchange = e => {
      const r = new FileReader(); r.onload = ev => {
        let img = card.querySelector('img');
        if (!img) { img = doc.createElement('img'); img.style='width:100%;height:100%;object-fit:cover;position:absolute;inset:0;border-radius:12px;'; card.style.position='relative'; card.prepend(img); }
        img.src = ev.target.result;
      };
      if (e.target.files[0]) r.readAsDataURL(e.target.files[0]);
    };

    const labelIn = document.createElement('input');
    labelIn.type='text'; labelIn.value=card.textContent.trim(); labelIn.placeholder='Label';
    labelIn.style='flex:1;background:var(--bg);border:1px solid var(--border);color:var(--text);padding:4px 6px;border-radius:4px;font-size:11px;outline:none;';
    labelIn.oninput = e => {
      const txt = [...card.childNodes].find(n=>n.nodeType===3);
      if (txt) txt.textContent = e.target.value; else card.prepend(doc.createTextNode(e.target.value));
    };

    const delBtn = document.createElement('button');
    delBtn.style='background:#f43f5e22;border:1px solid #f43f5e55;color:#f43f5e;border-radius:3px;padding:2px 7px;font-size:13px;cursor:pointer;';
    delBtn.textContent='×';
    delBtn.onclick = () => { card.closest('.col-lg-4, .col-md-6')?.remove(); folioSaveThenRefresh(doc,'portfolio'); };

    cardWrap.append(labelIn, colorIn, imgBtn, fileIn, delBtn);
    el.appendChild(cardWrap);
  });

  const addBtn = document.createElement('button');
  addBtn.className='btn btn-primary'; addBtn.style='width:100%;font-size:11px;margin-top:4px;'; addBtn.textContent='+ Add Portfolio Card';
  addBtn.onclick = () => {
    const grid = section.querySelector('.row.g-4'); if (!grid) return;
    const col = doc.createElement('div'); col.className='col-lg-4 col-md-6';
    col.innerHTML=`<div class="portfolio-card" style="background:linear-gradient(135deg,#6366f1,#8b5cf6);">New Project</div>`;
    grid.appendChild(col);
    folioSaveThenRefresh(doc,'portfolio');
  };
  el.appendChild(addBtn);
}

/* ══════════════════════════════════════════════
   ABOUT SECTION — field definitions
   ══════════════════════════════════════════════ */
function folioAboutFields(doc, section, el) {
  const h2   = section.querySelector('h2');
  const para = section.querySelector('p.text-muted');
  if (h2)   el.appendChild(folioMakeInput('Heading', h2.textContent, v => { h2.textContent = v; }));
  if (para) el.appendChild(folioMakeTextarea('Bio', para.textContent, v => { para.textContent = v; }));

  el.appendChild(folioLabel('Stats'));
  section.querySelectorAll('.col-6 [style*="1.8rem"]').forEach((stat, i) => {
    el.appendChild(folioMakeInput(`Stat ${i+1} Number`, stat.textContent, v => { stat.textContent = v; }));
    const lbl = stat.nextElementSibling;
    if (lbl) el.appendChild(folioMakeInput(`Stat ${i+1} Label`, lbl.textContent, v => { lbl.textContent = v; }));
  });

  el.appendChild(folioLabel('Skill Bars'));
  section.querySelectorAll('.skill-bar').forEach((bar, i) => {
    const fill  = bar.querySelector('.skill-bar-fill');
    const label = bar.previousElementSibling?.querySelector('.fw-semibold');
    const pct   = bar.previousElementSibling?.querySelector('[style*="color:#6b7280"]');
    if (label) el.appendChild(folioMakeInput(`Skill ${i+1} Name`, label.textContent, v => { label.textContent = v; }));
    if (fill) {
      const wrap = document.createElement('div');
      wrap.style = 'margin-bottom:8px;';
      wrap.innerHTML = `<label style="font-size:10px;color:var(--text-muted);display:block;margin-bottom:3px;text-transform:uppercase;">Skill ${i+1} %</label>
        <input type="range" min="0" max="100" value="${parseInt(fill.style.width)||80}"
          style="width:100%;accent-color:var(--accent);">
        <span style="font-size:10px;color:var(--text-muted);">${parseInt(fill.style.width)||80}%</span>`;
      const range = wrap.querySelector('input'); const pctSpan = wrap.querySelector('span');
      range.oninput = e => {
        fill.style.width = e.target.value + '%';
        if (pct) pct.textContent = e.target.value + '%';
        pctSpan.textContent = e.target.value + '%';
      };
      el.appendChild(wrap);
    }
  });
}

/* ══════════════════════════════════════════════
   CONTACT SECTION — field definitions
   ══════════════════════════════════════════════ */
function folioContactFields(doc, section, el) {
  const h2   = section.querySelector('h2');
  const para = section.querySelector('p.text-muted');
  const btn  = section.querySelector('button');
  if (h2)   el.appendChild(folioMakeInput('Heading', h2.textContent, v => { h2.textContent = v; }));
  if (para) el.appendChild(folioMakeInput('Subheading', para.textContent, v => { para.textContent = v; }));
  if (btn)  el.appendChild(folioMakeInput('Button Text', btn.textContent, v => { btn.textContent = v; }));
  el.appendChild(folioMakeColor('Button Color', '#6366f1', v => { if(btn) btn.style.background = v; }));
}

/* ══════════════════════════════════════════════
   FOOTER EDITOR
   ══════════════════════════════════════════════ */
function renderFolioFooterEditor(doc, el) {
  const footer = doc.getElementById('folio-footer');
  if (!footer) { el.innerHTML='<p style="color:var(--text-muted);font-size:12px;">Footer not found.</p>'; return; }

  const brand     = footer.querySelector('.footer-brand h3');
  const brandDesc = footer.querySelector('.footer-brand p');
  const copyright = footer.querySelector('.footer-bottom span');

  el.appendChild(folioLabel('Brand'));
  if (brand)     el.appendChild(folioMakeInput('Brand Name', brand.textContent, v => { brand.textContent = v; }));
  if (brandDesc) el.appendChild(folioMakeTextarea('Brand Description', brandDesc.textContent, v => { brandDesc.textContent = v; }));
  if (copyright) el.appendChild(folioMakeInput('Copyright Text', copyright.textContent, v => { copyright.textContent = v; }));

  el.appendChild(folioLabel('Footer Columns'));
  footer.querySelectorAll('h5').forEach((h5, i) => {
    const colWrap = document.createElement('div');
    colWrap.style = 'background:var(--surface3);border:1px solid var(--border);border-radius:6px;padding:8px;margin-bottom:6px;';
    colWrap.appendChild(folioMakeInput(`Column ${i+1} Title`, h5.textContent, v => { h5.textContent = v; }));
    const ul = h5.nextElementSibling;
    if (ul && ul.tagName === 'UL') {
      ul.querySelectorAll('li a').forEach((a, j) => {
        colWrap.appendChild(folioMakeInput(`  Link ${j+1}`, a.textContent, v => { a.textContent = v; }));
      });
    }
    el.appendChild(colWrap);
  });

  el.appendChild(folioMakeColor('Footer Background', '#0b0e14', v => { footer.style.background = v; }));
}

/* ══════════════════════════════════════════════
   Generic section editor — uses field-def fn
   ══════════════════════════════════════════════ */
function renderFolioSectionEditor(doc, el, selector, fieldsFn) {
  const section = doc.querySelector(selector);
  if (!section) { el.innerHTML=`<p style="color:var(--text-muted);font-size:12px;">Section "${selector}" not found.</p>`; return; }
  fieldsFn(doc, section, el);

  // Auto-save on any input change
  el.querySelectorAll('input,textarea,select').forEach(inp => {
    inp.addEventListener('change', () => {
      const html = '<!DOCTYPE html>\n' + doc.documentElement.outerHTML;
      projectFiles['index.html'] = { raw: html, selfContained: html };
    });
  });
}

/* ── RGB → Hex helper ── */
function rgbToHex(rgb) {
  if (!rgb) return '#000000';
  const m = rgb.match(/\d+/g);
  if (!m || m.length < 3) return '#000000';
  return '#' + m.slice(0,3).map(x => (+x).toString(16).padStart(2,'0')).join('');
}

/* ── Show the FolioOne editor button when in import-preview mode ── */
(function watchFolioMode() {
  const frame   = document.getElementById('import-preview-frame');
  const btn     = document.getElementById('folioEditorBtn');
  if (!frame) return;
  const mo = new MutationObserver(() => {
    const vis = frame.style.display !== 'none';
    if (btn) btn.style.display = vis ? 'flex' : 'none';
  });
  mo.observe(frame, { attributes: true, attributeFilter: ['style'] });
})();

/* ── Override export to capture live iframe DOM ── */
const _origOpenExportAndSubmit = typeof openExportAndSubmit === 'function' ? openExportAndSubmit : null;
function openExportAndSubmit(exportName) {
  exportName = (exportName || 'my-website').replace(/\.html$/i,'').trim() || 'my-website';
  const frame = document.getElementById('import-preview-frame');
  // If FolioOne is active in iframe, export the live DOM
  if (frame && frame.style.display !== 'none') {
    try {
      const doc  = frame.contentDocument || frame.contentWindow.document;
      if (doc) {
        // Clean up editor artifacts
        const clone = doc.documentElement.cloneNode(true);
        clone.querySelectorAll('[contenteditable]').forEach(el => el.removeAttribute('contenteditable'));
        clone.querySelectorAll('#folio-dropdown-css').forEach(el => {}); // keep the CSS
        const fullCode = '<!DOCTYPE html>\n' + clone.outerHTML;
        submitExportForApproval(exportName, fullCode);
        return;
      }
    } catch(e) {}
    // Fall back to srcdoc
    if (frame.srcdoc) { submitExportForApproval(exportName, frame.srcdoc); return; }
  }
  // Otherwise fall through to original builder export
  if (_origOpenExportAndSubmit) _origOpenExportAndSubmit(exportName);
}

/* ══════════════════════════════════════════════
   FOLIO ONE DEFAULT PREVIEW — wire up editor button
   ══════════════════════════════════════════════ */

/* ══════════════════════════════════════════════
   SOURCE PROTECTION
// ══════════════════════════════════════════════════════
//  SOURCE PROTECTION — blocks DevTools, right-click,
//  view-source, and text selection so other users
//  cannot inspect or copy the builder code.
// ══════════════════════════════════════════════════════
(function () {
  'use strict';

  /* 1. Block DevTools keyboard shortcuts */
  document.addEventListener('keydown', function (e) {
    // F12
    if (e.keyCode === 123) { e.preventDefault(); e.stopImmediatePropagation(); return false; }
    // Ctrl+Shift+I  (DevTools)
    if (e.ctrlKey && e.shiftKey && e.keyCode === 73) { e.preventDefault(); e.stopImmediatePropagation(); return false; }
    // Ctrl+Shift+J  (Console)
    if (e.ctrlKey && e.shiftKey && e.keyCode === 74) { e.preventDefault(); e.stopImmediatePropagation(); return false; }
    // Ctrl+Shift+C  (Inspector)
    if (e.ctrlKey && e.shiftKey && e.keyCode === 67) { e.preventDefault(); e.stopImmediatePropagation(); return false; }
    // Ctrl+U  (View Source)
    if (e.ctrlKey && e.keyCode === 85) { e.preventDefault(); e.stopImmediatePropagation(); return false; }
    // Ctrl+S  (Save page)
    if (e.ctrlKey && e.keyCode === 83) { e.preventDefault(); return false; }
  }, true);

  /* 2. Block right-click context menu */
  document.addEventListener('contextmenu', function (e) {
    e.preventDefault();
    return false;
  }, true);

  /* 3. Block text selection outside inputs/textareas */
  document.addEventListener('selectstart', function (e) {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
    e.preventDefault();
  });

  /* 4. DevTools detection via debugger timing trick */
  (function devToolsDetect() {
    var threshold = 160;
    var blocked   = false;
    var check = function () {
      if (blocked) return;
      var start = performance.now();
      // eslint-disable-next-line no-debugger
      debugger;
      var delta = performance.now() - start;
      if (delta > threshold) {
        blocked = true;
        document.body.innerHTML =
          '<div style="display:flex;align-items:center;justify-content:center;' +
          'height:100vh;background:#080b12;color:#ff2d6f;font-family:sans-serif;' +
          'font-size:1.1rem;text-align:center;padding:20px;">' +
          '⛔ Developer tools are not allowed in the Menu Builder.</div>';
      }
    };
    setInterval(check, 2000);
  })();

})();
