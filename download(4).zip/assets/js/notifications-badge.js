function showToast(msg){const t=document.getElementById('toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2500)}
// ── Notification badge auto-poll ──
(function(){
  const badge       = document.getElementById('navNotifBadge');
  const mobileBadge = document.getElementById('mobileNotifBadge');
  function pollBadge(){
    fetch('notifications.php?action=unread_count')
      .then(r=>r.json())
      .then(d=>{
        const n = d.unread || 0;
        const label = n > 99 ? '99+' : (n || '');
        if(badge){ badge.textContent=label; badge.style.display=n>0?'flex':'none'; }
        if(mobileBadge){ mobileBadge.textContent=label; mobileBadge.style.display=n>0?'flex':'none'; }
      }).catch(()=>{});
  }
  window.refreshNotifBadge = pollBadge;
  if(badge || mobileBadge){ pollBadge(); setInterval(pollBadge, 10000); }
})();
