(function(){
  var toggle = document.getElementById('navToggle');
  var menu   = document.getElementById('mobileMenu');
  if(toggle && menu){
    toggle.addEventListener('click', function(){
      toggle.classList.toggle('open');
      menu.classList.toggle('open');
      document.body.style.overflow = menu.classList.contains('open') ? 'hidden' : '';
    });
    document.addEventListener('click', function(e){
      if(!toggle.contains(e.target) && !menu.contains(e.target)){
        toggle.classList.remove('open');
        menu.classList.remove('open');
        document.body.style.overflow = '';
      }
    });
    document.addEventListener('keydown', function(e){ if(e.key==='Escape'){ toggle.classList.remove('open'); menu.classList.remove('open'); document.body.style.overflow=''; } });
    menu.querySelectorAll('a').forEach(function(a){ a.addEventListener('click', function(){ toggle.classList.remove('open'); menu.classList.remove('open'); document.body.style.overflow=''; }); });
  }
})();
