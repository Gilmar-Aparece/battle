function openGoLiveModal(){ document.getElementById('goLiveModal').classList.add('open'); }
function closeGoLiveModal(){ document.getElementById('goLiveModal').classList.remove('open'); }
document.getElementById('goLiveModal').addEventListener('click', function(e){ if(e.target===this) closeGoLiveModal(); });

async function startLive(){
  const title=document.getElementById('liveTitle').value.trim();
  if(!title){showToast('Please enter a stream title');return;}
  const fd=new FormData();
  fd.append('action','start_live');
  fd.append('title',title);
  fd.append('description',document.getElementById('liveDesc').value.trim());
  const res=await fetch('live.php',{method:'POST',body:fd});
  const data=await res.json();
  if(data.ok){
    window.location.href='live.php?id='+data.session_id;
  } else {
    showToast(data.msg||'Error');
  }
}
