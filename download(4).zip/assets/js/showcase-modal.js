/* ── Modal ────────────────────────────────────────────────────────── */
function openPostModal(){ document.getElementById('postModal').classList.add('open'); }
function closePostModal(){ document.getElementById('postModal').classList.remove('open'); }

let activeTab = 'html';
function switchTab(tab,btn){
  document.querySelectorAll('[id^="code-"]').forEach(el=>el.style.display='none');
  document.getElementById('code-'+tab).style.display='block';
  document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  activeTab=tab;
}
function copyActiveTab(btn){
  const txt = document.getElementById('code-'+activeTab)?.value || '';
  navigator.clipboard.writeText(txt).then(()=>{
    btn.textContent='✓ Copied!'; btn.classList.add('copied');
    setTimeout(()=>{ btn.textContent='⎘ Copy'; btn.classList.remove('copied'); },2000);
  });
}
function buildSrcdoc(){
  const html=document.getElementById('code-html').value;
  const css=document.getElementById('code-css').value;
  const js=document.getElementById('code-js').value;
  return `<!DOCTYPE html><html><head><meta charset="UTF-8"><style>${css}</style></head><body>${html}<script>${js}<\/script></body></html>`;
}
function refreshModalPreview(){
  document.getElementById('modalPreview').srcdoc=buildSrcdoc();
}
let previewTimer;
['code-html','code-css','code-js'].forEach(id=>{
  document.getElementById(id).addEventListener('input',()=>{
    clearTimeout(previewTimer);
    previewTimer=setTimeout(refreshModalPreview,800);
  });
});
document.getElementById('postModal').addEventListener('click',function(e){
  if(e.target===this) closePostModal();
});
async function submitPost(){
  const title=document.getElementById('postTitle').value.trim();
  if(!title){showToast('Please enter a title');return;}
  const fd=new FormData();
  fd.append('action','submit_post');
  fd.append('title',title);
  fd.append('description',document.getElementById('postDesc').value.trim());
  fd.append('html_code',document.getElementById('code-html').value);
  fd.append('css_code',document.getElementById('code-css').value);
  fd.append('js_code',document.getElementById('code-js').value);
  if(document.getElementById('chkVersus').checked) fd.append('allow_versus','1');
  const res=await fetch('showcase.php',{method:'POST',body:fd});
  const data=await res.json();
  if(data.ok){
    showToast('Posted! ✦');
    setTimeout(()=>window.location.href='showcase.php?id='+data.id,800);
  } else {
    showToast(data.msg||'Error');
  }
}

/* ── Share dropdown ───────────────────────────────────────────────── */
function getPostUrl(id){ return location.origin+location.pathname+'?id='+id; }

function toggleShare(e,id){
  e.stopPropagation();
  const dd=document.getElementById('sd-'+id);
  const wasOpen=dd.classList.contains('open');
  document.querySelectorAll('.share-dropdown').forEach(d=>d.classList.remove('open'));
  if(!wasOpen) dd.classList.add('open');
}
document.addEventListener('click',()=>
  document.querySelectorAll('.share-dropdown').forEach(d=>d.classList.remove('open'))
);
function shareToFacebook(id){
  const url='https://www.facebook.com/sharer/sharer.php?u='+encodeURIComponent(getPostUrl(id));
  window.open(url,'_blank','width=626,height=436');
  document.querySelectorAll('.share-dropdown').forEach(d=>d.classList.remove('open'));
}
async function shareNative(id,title){
  document.querySelectorAll('.share-dropdown').forEach(d=>d.classList.remove('open'));
  if(navigator.share){
    try{ await navigator.share({title,url:getPostUrl(id)}); return; }catch(e){}
  }
  copyLink(id);
}
function copyLink(id){
  document.querySelectorAll('.share-dropdown').forEach(d=>d.classList.remove('open'));
  const url=getPostUrl(id);
  navigator.clipboard.writeText(url)
    .then(()=>showToast('Link copied!'))
    .catch(()=>prompt('Copy this link:',url));
}
