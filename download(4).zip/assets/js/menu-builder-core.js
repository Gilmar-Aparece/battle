'use strict';

/* ═══════════════════════════════════════════════════════
   STATE & DOM REFERENCES
   ═══════════════════════════════════════════════════════ */

const preview        = document.getElementById('preview');
const previewContent = document.getElementById('preview-content');
const htmlCode       = document.getElementById('htmlCode');
const cssCode        = document.getElementById('cssCode');
const jsCode         = document.getElementById('jsCode');
const cssInput       = document.getElementById('cssInput');
const activeLabel    = document.getElementById('activeLabel');
const layoutModal    = document.getElementById('layoutModal');

let selected           = previewContent;
let modalTargetSection = null;
let activeNavbar       = null;

const counts = { section: 0, container: 0, column: 0, widget: 0 };

const widgetScripts   = new Map();
const widgetJSModes   = new Map();
const pseudoStyles    = new Map();
let   projectFiles    = {};


/* ═══════════════════════════════════════════════════════
   DRAG — Init widget drag from panel
   ═══════════════════════════════════════════════════════ */

document.querySelectorAll('.draggable').forEach(el => {
  el.addEventListener('dragstart', e => {
    e.dataTransfer.setData('html', el.dataset.html);
    e.dataTransfer.setData('type', el.dataset.type || 'generic');
  });

  // ── TOUCH DRAG (mobile) ─────────────────────────────────
  let touchClone = null, touchHtml = null, touchType = null;

  el.addEventListener('touchstart', e => {
    touchHtml = el.dataset.html;
    touchType = el.dataset.type || 'generic';

    // Create a ghost clone to follow the finger
    touchClone = el.cloneNode(true);
    touchClone.style.cssText = `
      position:fixed;z-index:99999;opacity:0.85;pointer-events:none;
      width:${el.offsetWidth}px;transform:scale(1.08);
      box-shadow:0 8px 24px rgba(99,102,241,0.5);
      border:2px solid #6366f1;border-radius:6px;background:#1e2230;
    `;
    document.body.appendChild(touchClone);

    const t = e.touches[0];
    touchClone.style.left = (t.clientX - el.offsetWidth / 2) + 'px';
    touchClone.style.top  = (t.clientY - el.offsetHeight / 2) + 'px';
  }, { passive: true });

  el.addEventListener('touchmove', e => {
    if (!touchClone) return;
    e.preventDefault();
    const t = e.touches[0];
    touchClone.style.left = (t.clientX - el.offsetWidth / 2) + 'px';
    touchClone.style.top  = (t.clientY - el.offsetHeight / 2) + 'px';

    // Highlight the column under the finger
    touchClone.style.display = 'none';
    const under = document.elementFromPoint(t.clientX, t.clientY);
    touchClone.style.display = '';
    document.querySelectorAll('.column.touch-over').forEach(c => c.classList.remove('touch-over'));
    if (under) {
      const col = under.closest('.column');
      if (col) col.classList.add('touch-over');
    }
  }, { passive: false });

  el.addEventListener('touchend', e => {
    if (!touchClone) return;
    const t = e.changedTouches[0];

    // Find drop target
    touchClone.style.display = 'none';
    const under = document.elementFromPoint(t.clientX, t.clientY);
    touchClone.style.display = '';
    document.body.removeChild(touchClone);
    touchClone = null;
    document.querySelectorAll('.column.touch-over').forEach(c => c.classList.remove('touch-over'));

    if (!under) return;
    const dropCol = under.closest('.column');
    if (dropCol && touchHtml) {
      dropWidget(dropCol, touchHtml, touchType);
    }
  }, { passive: true });
});


/* ═══════════════════════════════════════════════════════
   VIEWPORT TOGGLE
   ═══════════════════════════════════════════════════════ */

function setViewport(device) {
  previewContent.classList.remove('view-mobile', 'view-tablet', 'view-desktop');
  ['desktop', 'tablet', 'mobile'].forEach(d => {
    const btn = document.getElementById('vp-' + d);
    if (btn) btn.classList.remove('vp-active');
  });

  if (device === 'mobile')      previewContent.classList.add('view-mobile');
  else if (device === 'tablet') previewContent.classList.add('view-tablet');
  else                          previewContent.classList.add('view-desktop');

  const activeBtn = document.getElementById('vp-' + device);
  if (activeBtn) activeBtn.classList.add('vp-active');
}


/* ═══════════════════════════════════════════════════════
   TAB SWITCHER
   ═══════════════════════════════════════════════════════ */

function switchTab(type, event) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  event.currentTarget.classList.add('active');

  const allViews = ['explorerView', 'htmlCode', 'cssCode', 'jsCode'];
  allViews.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = 'none';
  });

  if (type === 'explorer') {
    document.getElementById('explorerView').style.display = 'block';
  } else {
    document.getElementById(type + 'Code').style.display = 'block';
  }
}


/* ═══════════════════════════════════════════════════════
   IMPORT — Open folder, load files, preview index.html
   ═══════════════════════════════════════════════════════ */

async function importProjectFolder(files) {
  if (!files || files.length === 0) return;

  let firstHTML = '', firstCSS = '', firstJS = '';
  let indexFound = false;
  projectFiles = {};

  const fileItemsContainer = document.getElementById('fileItems');
  fileItemsContainer.innerHTML = '';
  document.getElementById('fileList').style.display = 'block';

  const fileTree = document.getElementById('fileTree');
  fileTree.innerHTML = '';

  // Collect all file contents first (CSS/JS needed for HTML preview)
  const rawFiles = {};
  const readPromises = Array.from(files).map(file => {
    return file.text().then(content => { rawFiles[file.name] = content; });
  });
  await Promise.all(readPromises);

  // Build combined CSS and JS for pages that link external files
  let combinedCSS = '', combinedJS = '';
  for (const [name, content] of Object.entries(rawFiles)) {
    if (name.endsWith('.css')) combinedCSS += content + '\n';
    if (name.endsWith('.js'))  combinedJS  += content + '\n';
  }

  for (const [name, content] of Object.entries(rawFiles)) {
    if (name.endsWith('.html')) {
      // Build a self-contained version by inlining external refs
      const selfContained = inlineExternalRefs(content, rawFiles);
      projectFiles[name] = { raw: content, selfContained };

      if (name === 'index.html' || !indexFound) {
        firstHTML  = selfContained;
        indexFound = (name === 'index.html');
      }

      // File list entry
      const item = document.createElement('div');
      item.style = 'padding:5px 8px;font-size:11px;color:var(--text-dim);cursor:pointer;border-radius:3px;transition:background .15s;display:flex;align-items:center;gap:6px;';
      item.innerHTML = '<span style="color:#e34c26;font-size:9px;font-weight:700;">HTML</span> ' + name;
      item.onclick   = () => loadFileToEditor(name);
      item.onmouseover = () => item.style.background = 'var(--surface3)';
      item.onmouseout  = () => item.style.background = 'transparent';
      fileItemsContainer.appendChild(item);

      // Tree entry
      const treeItem = document.createElement('div');
      treeItem.className = 'tree-item';
      treeItem.innerHTML = '<span style="color:#e34c26;font-size:9px;font-weight:700;margin-right:4px;">HTML</span>' + name;
      treeItem.onclick   = () => loadFileToEditor(name);
      fileTree.appendChild(treeItem);

    } else if (name.endsWith('.css')) {
      projectFiles[name] = { raw: content };
      const treeItem = document.createElement('div');
      treeItem.className = 'tree-item';
      treeItem.innerHTML = '<span style="color:#264de4;font-size:9px;font-weight:700;margin-right:4px;">CSS</span>' + name;
      fileTree.appendChild(treeItem);

    } else if (name.endsWith('.js')) {
      projectFiles[name] = { raw: content };
      const treeItem = document.createElement('div');
      treeItem.className = 'tree-item';
      treeItem.innerHTML = '<span style="color:#f7df1e;font-size:9px;font-weight:700;margin-right:4px;">JS</span>' + name;
      fileTree.appendChild(treeItem);
    }
  }

  // Show raw source in code editor tabs
  const parser = new DOMParser();
  const doc = parser.parseFromString(firstHTML, 'text/html');
  let css = '', js = '';
  doc.querySelectorAll('style').forEach(s => { css += s.textContent + '\n'; });
  doc.querySelectorAll('script').forEach(s => { if (!s.src) js += s.textContent + '\n'; });
  htmlCode.value = doc.body ? doc.body.innerHTML.trim() : '';
  cssCode.value  = css.trim();
  jsCode.value   = js.trim();

  // Show in live preview via iframe
  syncImportToPreview(firstHTML);

  // Switch to explorer tab
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.tab')[0].classList.add('active');
  document.getElementById('explorerView').style.display = 'block';
  document.getElementById('htmlCode').style.display     = 'none';
  document.getElementById('cssCode').style.display      = 'none';
  document.getElementById('jsCode').style.display       = 'none';

  // Reset the file input so re-importing works
  document.getElementById('folderInput').value = '';
}

/* Inline <link rel="stylesheet"> and <script src=""> references if we have those files */
function inlineExternalRefs(htmlContent, rawFiles) {
  const parser = new DOMParser();
  const doc    = parser.parseFromString(htmlContent, 'text/html');

  // Inline linked stylesheets
  doc.querySelectorAll('link[rel="stylesheet"]').forEach(link => {
    const href = link.getAttribute('href');
    const fname = href ? href.split('/').pop() : '';
    if (fname && rawFiles[fname]) {
      const style = document.createElement('style');
      style.textContent = rawFiles[fname];
      link.replaceWith(style);
    }
  });

  // Inline external scripts
  doc.querySelectorAll('script[src]').forEach(script => {
    const src   = script.getAttribute('src');
    const fname = src ? src.split('/').pop() : '';
    if (fname && rawFiles[fname]) {
      const newScript = document.createElement('script');
      newScript.textContent = rawFiles[fname];
      script.replaceWith(newScript);
    }
  });

  return '<!DOCTYPE html>' + doc.documentElement.outerHTML;
}

/* Load a specific imported file into the editor and preview */
function loadFileToEditor(fileName) {
  const data = projectFiles[fileName];
  if (!data) return;

  // Highlight active file in file list
  document.querySelectorAll('#fileItems div').forEach(div => {
    const isActive = div.innerText.includes(fileName);
    div.style.color      = isActive ? 'var(--accent)' : 'var(--text-dim)';
    div.style.background = isActive ? 'var(--surface2)' : 'transparent';
  });

  // Show raw source in code tabs
  if (data.raw) {
    const parser = new DOMParser();
    const doc    = parser.parseFromString(data.raw, 'text/html');
    let css = '', js = '';
    doc.querySelectorAll('style').forEach(s  => { css += s.textContent + '\n'; });
    doc.querySelectorAll('script').forEach(s => { if (!s.src) js += s.textContent + '\n'; });
    htmlCode.value = doc.body ? doc.body.innerHTML.trim() : '';
    cssCode.value  = css.trim();
    jsCode.value   = js.trim();
  } else {
    htmlCode.value = '';
    cssCode.value  = data.css || '';
    jsCode.value   = data.js  || '';
  }

  if (data.selfContained) syncImportToPreview(data.selfContained);
}

/* Render a full HTML page into the live preview iframe */
function syncImportToPreview(fullHTML) {
  const frame       = document.getElementById('import-preview-frame');
  const wrapper     = document.getElementById('preview-wrapper');
  const backBtn     = document.getElementById('back-to-builder-btn');

  // Show iframe, hide the builder canvas
  frame.style.display   = 'block';
  wrapper.style.display = 'none';
  if (backBtn) backBtn.style.display = 'block';

  // Write the full HTML document into the iframe
  frame.srcdoc = fullHTML;
}

/* Return to the drag-and-drop builder canvas */
function backToBuilder() {
  const frame   = document.getElementById('import-preview-frame');
  const wrapper = document.getElementById('preview-wrapper');
  const backBtn = document.getElementById('back-to-builder-btn');
  frame.style.display   = 'none';
  wrapper.style.display = 'flex';
  if (backBtn) backBtn.style.display = 'none';
}

/* Re-bind click handlers on imported elements */
function rebindImportedElements() {
  const previewDiv = document.getElementById('preview');
  if (!previewDiv || document.getElementById('preview-wrapper').style.display === 'none') return;

  previewDiv.querySelectorAll('section').forEach(sec => {
    counts.section++;
    sec.onclick = e => selectItem(sec, `Imported Section ${counts.section}`, e);
  });

  previewDiv.querySelectorAll('*').forEach(el => {
    if (!el.onclick) {
      el.onclick = e => { e.stopPropagation(); selectItem(el, `Element: ${el.tagName.toLowerCase()}`, e); };
    }
  });
}

/* File tree helpers */
function addNewFile() {
  const fileName = prompt('Enter file name (e.g. about.html):', 'page.html');
  if (!fileName) return;
  projectFiles[fileName] = { html: '', css: '', js: '' };

  const fileTree = document.getElementById('fileTree');
  const emptyMsg = fileTree.querySelector('div[style]');
  if (emptyMsg) emptyMsg.remove();

  const item = document.createElement('div');
  item.className = 'tree-item';
  item.innerHTML = '📄 ' + fileName;
  item.onclick   = () => loadFileToEditor(fileName);
  fileTree.appendChild(item);
  loadFileToEditor(fileName);
}

function addNewFolder() {
  const name = prompt('Enter folder name:', 'New Folder');
  if (!name) return;
  const fileTree = document.getElementById('fileTree');
  const item = document.createElement('div');
  item.className = 'tree-item';
  item.innerHTML = '📁 <span contenteditable="true">' + name + '</span>';
  item.style.color = '#dcb67a';
  fileTree.appendChild(item);
}

function toggleNewMenu() {
  document.getElementById('newDropdown').classList.toggle('show');
}

window.addEventListener('click', e => {
  if (!e.target.matches('.new-btn')) {
    document.querySelectorAll('.dropdown-content.show').forEach(d => d.classList.remove('show'));
  }
});


/* ═══════════════════════════════════════════════════════
   EXPORT — Download complete HTML file
   ═══════════════════════════════════════════════════════ */

function downloadCode() {
  // Ask user for custom filename
  let exportName = prompt('Enter a filename for the export:', 'my-website') || 'my-website';
  exportName = exportName.replace(/\.html$/i, '').trim() || 'my-website';
  const fileName = exportName + '.html';

  // If we're in import-preview mode, export the currently loaded file
  const frame = document.getElementById('import-preview-frame');
  if (frame.style.display !== 'none' && frame.srcdoc) {
    const blob = new Blob([frame.srcdoc], { type: 'text/html' });
    const a    = document.createElement('a');
    a.href     = URL.createObjectURL(blob);
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { document.body.removeChild(a); URL.revokeObjectURL(a.href); }, 0);
    return;
  }

  // Builder mode export
  const exportClone = preview.cloneNode(true);

  // Strip builder UI elements
  exportClone.querySelectorAll('.section-controls, .plus-btn, .widget-actions, .top-plus-btn').forEach(el => el.remove());
  // Unwrap widget-wrapper divs (builder containers) keeping their inner content
  exportClone.querySelectorAll('.widget-wrapper').forEach(wrapper => {
    while (wrapper.firstChild) wrapper.parentNode.insertBefore(wrapper.firstChild, wrapper);
    wrapper.remove();
  });
  exportClone.querySelectorAll('*').forEach(el => {
    el.removeAttribute('contenteditable');
    el.removeAttribute('draggable');
    el.classList.remove('dragging-section', 'selected', 'selected-global');
    if (el.getAttribute('class') === '') el.removeAttribute('class');
  });

  // Remove builder-only dashed borders from sections and columns
  exportClone.querySelectorAll('.section, .container, .container-advanced, .column').forEach(el => {
    const s = el.getAttribute('style') || '';
    // Remove dashed border that is builder UI
    el.setAttribute('style', s.replace(/border:\s*1px dashed[^;]*;?/g, '').trim());
  });

  // Detect which widgets are actually on the canvas
  const exportHasNavbar   = !!exportClone.querySelector('.pb-navbar');
  const exportHasCarousel = !!exportClone.querySelector('.pb-carousel');
  const exportHasForm     = !!exportClone.querySelector('.pb-reg-form');
  const exportHasFooter   = !!exportClone.querySelector('.pb-footer');

  const navbarCSS = exportHasNavbar ? `
/* Navbar */
.pb-navbar         { display: flex; align-items: center; justify-content: space-between; padding: 0 32px; height: 64px; background: #0b0e14; position: relative; z-index: 1000; }
.pb-logo-container { display: flex; align-items: center; }
.pb-nav-text-logo  { font-weight: 700; font-size: 1.25rem; color: #6366f1; }
.pb-nav-list       { list-style: none; display: flex; align-items: center; gap: 4px; margin: 0; padding: 0; }
.pb-nav-list > li  { position: relative; padding: 8px 14px; font-size: 14px; color: #d1d5db; border-radius: 6px; cursor: pointer; transition: all .18s; }
.pb-nav-list > li:hover { color: white; background: rgba(255,255,255,.05); }
.pb-nav-cta        { background: #22c55e !important; color: white !important; border-radius: 20px !important; padding: 8px 18px !important; font-weight: 600 !important; }
.pb-nav-cta:hover  { background: #16a34a !important; }
.pb-has-dropdown::after { content: ' ▾'; font-size: 10px; opacity: 0.6; }
.pb-dropdown       { display: none; position: absolute; top: calc(100% + 6px); left: 0; background: rgba(13,17,23,.97); min-width: 200px; padding: 6px; border-radius: 10px; border: 1px solid rgba(255,255,255,.08); list-style: none; box-shadow: 0 20px 40px rgba(0,0,0,.5); z-index: 9999; }
.pb-nav-list > li:hover > .pb-dropdown { display: block; }
.pb-dropdown li    { padding: 9px 14px; color: #9ca3af; font-size: 13px; border-radius: 6px; cursor: pointer; transition: all .15s; }
.pb-dropdown li:hover { background: rgba(99,102,241,.15); color: #a5b4fc; }
.pb-nav-toggle     { display: none; background: rgba(255,255,255,.06); border: 1px solid rgba(255,255,255,.1); color: white; padding: 8px 12px; border-radius: 6px; cursor: pointer; font-size: 18px; }
.pb-mobile-drawer  { display: none; position: fixed; top: 0; right: -100%; width: 280px; height: 100vh; background: #0b0e14; flex-direction: column; padding: 24px 24px 40px; transition: right .35s cubic-bezier(.4,0,.2,1); box-shadow: -10px 0 40px rgba(0,0,0,.6); z-index: 99999; overflow-y: auto; }
.pb-mobile-drawer.open { right: 0; display: flex; }
.pb-drawer-close   { align-self: flex-end; background: transparent; border: none; color: #9ca3af; font-size: 22px; cursor: pointer; margin-bottom: 24px; }
.pb-mobile-nav-list { list-style: none; display: flex; flex-direction: column; gap: 2px; padding: 0; margin: 0; }
.pb-mobile-nav-list > li { padding: 12px 16px; color: #d1d5db; font-size: 15px; border-radius: 6px; cursor: pointer; }
.pb-mobile-nav-list > li:hover { background: rgba(255,255,255,.06); }
.pb-mobile-dropdown { list-style: none; padding: 4px 0 4px 16px; display: none; border-left: 2px solid rgba(99,102,241,.3); margin-top: 4px; }
.pb-mobile-dropdown.open { display: block; }
.pb-drawer-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,.6); z-index: 99998; }
.pb-drawer-overlay.open { display: block; }
@media (max-width: 768px) {
  .pb-nav-toggle { display: block; }
  .pb-nav-list   { display: none !important; }
}` : '';

  const carouselCSS = exportHasCarousel ? `
/* Carousel */
.pb-carousel  { position: relative; width: 100%; overflow: hidden; min-height: 240px; background: #1a1a2e; }
.pb-slides img { width: 100%; display: none; object-fit: cover; }
.pb-slides img.active { display: block; animation: slideIn .4s ease; }
@keyframes slideIn { from { opacity:0; transform:scale(1.02); } to { opacity:1; transform:scale(1); } }
.pb-prev, .pb-next { position:absolute; top:50%; transform:translateY(-50%); background:rgba(0,0,0,.5); border:1px solid rgba(255,255,255,.1); color:white; width:40px; height:40px; border-radius:50%; display:flex; align-items:center; justify-content:center; cursor:pointer; z-index:10; font-size:16px; transition:all .2s; margin:0 10px; }
.pb-next { right:0; }
.pb-prev:hover, .pb-next:hover { background:#6366f1; border-color:#6366f1; }` : '';

  const formCSS = exportHasForm ? `
/* Registration Form */
.pb-reg-form         { display:flex; flex-direction:column; gap:12px; padding:28px; border:1px solid #e5e7eb; border-radius:12px; max-width:360px; background:#fff; box-shadow:0 4px 24px rgba(0,0,0,.06); }
.pb-reg-form h3      { margin:0 0 4px; font-size:1.2rem; color:#111; }
.pb-reg-form input   { padding:11px 14px; border:1px solid #d1d5db; border-radius:6px; font-size:14px; outline:none; width:100%; box-sizing:border-box; }
.pb-reg-form input:focus { border-color:#6366f1; }
.pb-reg-form button  { padding:12px; background:#6366f1; color:white; border:none; border-radius:8px; cursor:pointer; font-weight:600; font-size:14px; }
.pb-reg-form button:hover { background:#4f46e5; }` : '';

  const footerCSS = exportHasFooter ? `
/* Footer */
.pb-footer { background:#0b0e14; color:#9ca3af; padding:60px 40px 30px; }
.pb-footer-grid { display:grid; grid-template-columns:2fr 1fr 1fr 1fr; gap:40px; margin-bottom:40px; }
.pb-footer-brand h3 { color:#6366f1; font-size:1.3rem; font-weight:700; margin-bottom:12px; }
.pb-footer-brand p { font-size:13px; line-height:1.7; color:#6b7280; max-width:240px; }
.pb-footer-col h4 { color:#e2e4f0; font-size:13px; font-weight:600; margin-bottom:14px; text-transform:uppercase; letter-spacing:.06em; }
.pb-footer-col ul { list-style:none; display:flex; flex-direction:column; gap:8px; padding:0; margin:0; }
.pb-footer-col ul li { font-size:13px; color:#6b7280; cursor:pointer; transition:color .15s; }
.pb-footer-col ul li:hover { color:#a5b4fc; }
.pb-footer-bottom { display:flex; align-items:center; justify-content:space-between; padding-top:24px; border-top:1px solid rgba(255,255,255,.06); font-size:12px; color:#4b5563; }
.pb-footer-socials { display:flex; gap:12px; }
.pb-footer-socials a { color:#6b7280; font-size:18px; transition:color .15s; cursor:pointer; }
.pb-footer-socials a:hover { color:#a5b4fc; }
@media (max-width:768px) { .pb-footer-grid { grid-template-columns:1fr; } }` : '';

  const fullCode = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${exportName}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
</head>
<body>
${exportClone.innerHTML}

<script>
// Mobile menu (drawer-based)
function pbToggleMobile(btn) {
  var drawer  = document.getElementById('pb-drawer');
  var overlay = document.querySelector('.pb-drawer-overlay');
  if (!drawer) return;
  var isOpen = drawer.classList.toggle('open');
  btn.textContent = isOpen ? '\u2715' : '\u2630';
  if (overlay) overlay.classList.toggle('open', isOpen);
}
function pbCloseMobile() {
  var drawer  = document.getElementById('pb-drawer');
  var overlay = document.querySelector('.pb-drawer-overlay');
  if (drawer)  drawer.classList.remove('open');
  if (overlay) overlay.classList.remove('open');
  document.querySelectorAll('.pb-nav-toggle').forEach(function(b){ b.textContent = '\u2630'; });
}
function pbToggleSubMenu(li) {
  var sub = li.querySelector('.pb-mobile-dropdown');
  if (sub) sub.classList.toggle('open');
}
document.addEventListener('keydown', function(e){ if(e.key==='Escape') pbCloseMobile(); });
// Carousel
function pbMoveSlide(btn, dir) {
  var carousel = btn.closest('.pb-carousel');
  var slides   = carousel.querySelectorAll('.pb-slides img');
  if (slides.length <= 1) return;
  var idx = Array.from(slides).findIndex(function(i){ return i.classList.contains('active'); });
  slides[idx].classList.remove('active');
  idx = (idx + dir + slides.length) % slides.length;
  slides[idx].classList.add('active');
}
${jsCode.value}
<\/script>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"><\/script>
<!-- AOS -->
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"><\/script>
<script>if(typeof AOS!=='undefined') AOS.init({duration:800,once:true});<\/script>
</body>
</html>`;

  // ── Submit to approval queue instead of direct download ──────────────
  submitExportForApproval(exportName, fullCode);
}

/* ═══════════════════════════════════════════════════════
   EXPORT APPROVAL SYSTEM
   ═══════════════════════════════════════════════════════ */

// Open modal to confirm submission
function openExportModal() {
  document.getElementById('exportModal').style.display = 'flex';
  document.getElementById('exportFilename').value = 'my-website';
  document.getElementById('exportStatus').textContent = '';
  document.getElementById('exportStatus').className = 'export-status';
}
function closeExportModal() {
  document.getElementById('exportModal').style.display = 'none';
}

// Submit HTML to server for admin approval
async function submitExportForApproval(exportName, htmlContent) {
  const statusEl = document.getElementById('exportStatus');
  const btn      = document.getElementById('exportSubmitBtn');
  if (btn) { btn.disabled = true; btn.textContent = '⏳ Submitting…'; }
  if (statusEl) { statusEl.textContent = 'Uploading to server…'; statusEl.className = 'export-status info'; }

  try {
    const fd = new FormData();
    fd.append('action',   'submit_export');
    fd.append('filename', exportName);
    fd.append('content',  htmlContent);

    const res  = await fetch('menu_builder_api.php', { method: 'POST', body: fd });
    const data = await res.json();

    if (data.ok) {
      if (statusEl) {
        statusEl.textContent = '✅ ' + data.message;
        statusEl.className   = 'export-status success';
      }
      // Store export_id so user can check status later
      localStorage.setItem('last_export_id', data.export_id);
      refreshMyExports();
    } else {
      if (statusEl) {
        statusEl.textContent = '❌ ' + (data.error || 'Submission failed.');
        statusEl.className   = 'export-status error';
      }
    }
  } catch (err) {
    if (statusEl) {
      statusEl.textContent = '❌ Network error: ' + err.message;
      statusEl.className   = 'export-status error';
    }
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = '📤 Submit for Approval'; }
  }
}

// Download an already-approved export
async function downloadApprovedExport(exportId, filename) {
  const url = `menu_builder_api.php?action=download_export&id=${exportId}`;
  const a   = document.createElement('a');
  a.href    = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => document.body.removeChild(a), 0);
}

// Import an approved export directly into the builder
async function importApprovedExport(exportId, filename) {
  try {
    const res  = await fetch(`menu_builder_api.php?action=import_approved&id=${exportId}`);
    const data = await res.json();
    if (!data.ok) {
      alert('Could not load approved file: ' + (data.error || 'Unknown error'));
      return;
    }
    // Close export modal, load into builder
    closeExportModal();
    const frame = document.getElementById('import-preview-frame');
    if (frame) {
      frame.srcdoc       = data.content;
      frame.style.display = 'block';
      document.getElementById('back-to-builder-btn').style.display = 'inline-flex';
      document.getElementById('preview-wrapper').style.display     = 'none';
    }
    // Store in project files so export re-uses it
    projectFiles[data.filename] = { raw: data.content, selfContained: data.content };
    // Update file tree
    const fileTree = document.getElementById('fileTree');
    fileTree.innerHTML = '';
    const item       = document.createElement('div');
    item.className   = 'tree-item';
    item.style.color = 'var(--accent)';
    item.innerHTML   = `<span style="color:#e34c26;font-size:9px;font-weight:700;margin-right:4px;">HTML</span> ${data.filename} ✅`;
    item.onclick     = () => loadFileToEditor(data.filename);
    fileTree.appendChild(item);
    document.getElementById('fileList').style.display = 'block';
  } catch (err) {
    alert('Import failed: ' + err.message);
  }
}

// Fetch and display user's own export history
async function refreshMyExports() {
  const listEl = document.getElementById('myExportsList');
  if (!listEl) return;
  try {
    const res  = await fetch('menu_builder_api.php?action=list_exports');
    const data = await res.json();
    if (!data.ok || !data.exports.length) {
      listEl.innerHTML = '<div style="color:#5a6380;font-size:11px;padding:8px 0">No exports yet.</div>';
      return;
    }
    listEl.innerHTML = data.exports.map(exp => {
      const statusColors = { pending: '#ff8c42', approved: '#00ff87', rejected: '#ff2d6f' };
      const color = statusColors[exp.status] || '#fff';
      const dl = exp.status === 'approved'
        ? `<button onclick="downloadApprovedExport(${exp.id},'${exp.filename}')"
                  style="font-size:10px;padding:3px 8px;border-radius:5px;border:1px solid ${color};
                         background:transparent;color:${color};cursor:pointer;margin-left:6px;">
             ⬇ Download
           </button>
           <button onclick="importApprovedExport(${exp.id},'${exp.filename}')"
                  style="font-size:10px;padding:3px 8px;border-radius:5px;border:1px solid #00c8ff;
                         background:transparent;color:#00c8ff;cursor:pointer;margin-left:4px;">
             📥 Import into Builder
           </button>` : '';
      const note = exp.admin_note
        ? `<div style="font-size:10px;color:#5a6380;margin-top:3px">Note: ${exp.admin_note}</div>` : '';
      return `
        <div style="padding:8px 0;border-bottom:1px solid rgba(255,255,255,.05);font-size:12px">
          <div style="display:flex;align-items:center;justify-content:space-between">
            <span style="font-family:monospace">${exp.filename}</span>
            <span style="color:${color};font-size:10px;font-weight:700;text-transform:uppercase">${exp.status}${dl}</span>
          </div>
          <div style="color:#5a6380;font-size:10px;margin-top:2px">
            Submitted: ${new Date(exp.created_at).toLocaleDateString()}
          </div>
          ${note}
        </div>`;
    }).join('');
  } catch (e) {
    listEl.innerHTML = '<div style="color:#ff2d6f;font-size:11px">Failed to load exports.</div>';
  }
}

/* ═══════════════════════════════════════════════════════
   SECTION MANAGEMENT
   ═══════════════════════════════════════════════════════ */

function openLayoutModal(targetSection = null) {
  modalTargetSection  = targetSection;
  layoutModal.style.display = 'flex';
}

function closeModal() {
  layoutModal.style.display = 'none';
  modalTargetSection = null;
}

window.addEventListener('click', e => {
  if (e.target === layoutModal) closeModal();
});

function createNewSection() {
  counts.section++;
  const sec = document.createElement('section');
  sec.className = `section-${counts.section} section`;
  sec.setAttribute('draggable', 'true');
  sec.onclick = e => selectItem(sec, `Section ${counts.section}`, e);

  const controls   = document.createElement('div');
  controls.className = 'section-controls';
  controls.innerHTML = `
    <div class="drag-handle" title="Drag to reorder">⋮⋮</div>
    <button class="section-del-btn" title="Delete Section">×</button>
  `;
  controls.querySelector('.section-del-btn').onclick = e => {
    e.stopPropagation();
    if (confirm('Delete this entire section?')) { sec.remove(); updateCode(); }
  };

  const plusBtn     = document.createElement('button');
  plusBtn.className = 'plus-btn top-plus-btn';
  plusBtn.innerText = '+';
  plusBtn.title     = 'Add column layout';
  plusBtn.onclick   = e => { e.stopPropagation(); openLayoutModal(sec); };

  sec.appendChild(controls);
  sec.appendChild(plusBtn);
  preview.appendChild(sec);
  return sec;
}

function applyStructure(type) {
  const targetSec = modalTargetSection || createNewSection();
  targetSec.querySelectorAll('.layout-menu, .top-plus-btn').forEach(n => n.remove());

  counts.container++;
  const row = document.createElement('div');
  row.onclick = e => selectItem(row, `Container ${counts.container}`, e);

  let numCols = 1, gridMap = '', isGrid = false;
  switch (type) {
    case '1-col':   numCols = 1; break;
    case '2-col':   numCols = 2; break;
    case '3-col':   numCols = 3; break;
    case 'stack':   numCols = 2; gridMap = 'grid-template-rows:1fr 1fr;';             isGrid = true; break;
    case 'split':   numCols = 2; gridMap = 'grid-template-columns:2fr 1fr;';           isGrid = true; break;
    case 'complex': numCols = 4; gridMap = 'grid-template-columns:1fr 1fr;grid-template-rows:1fr 1fr;'; isGrid = true; break;
  }

  row.className = `container-${counts.container} ${isGrid ? 'container-advanced' : 'container'}`;
  if (gridMap) row.setAttribute('style', gridMap);

  for (let i = 0; i < numCols; i++) {
    counts.column++;
    const col    = document.createElement('div');
    col.className = `column-${counts.column} column`;
    if (type === 'complex' && i === 2) col.style.gridColumn = 'span 2';
    col.onclick   = e => selectItem(col, `Column ${counts.column}`, e);
    setupDropZone(col);
    row.appendChild(col);
  }

  targetSec.appendChild(row);

  const plusBtn     = document.createElement('button');
  plusBtn.className = 'plus-btn top-plus-btn';
  plusBtn.innerText = '+';
  plusBtn.onclick   = e => { e.stopPropagation(); openLayoutModal(targetSec); };
  targetSec.appendChild(plusBtn);

  closeModal();
  updateCode();
}


/* ═══════════════════════════════════════════════════════
   SECTION SORTING (drag to reorder)
   ═══════════════════════════════════════════════════════ */

function initSectionSorting() {
  preview.addEventListener('dragstart', e => {
    if (e.target.tagName === 'SECTION') { e.target.classList.add('dragging-section'); e.dataTransfer.effectAllowed = 'move'; }
  });
  preview.addEventListener('dragend', e => {
    if (e.target.tagName === 'SECTION') { e.target.classList.remove('dragging-section'); updateCode(); }
  });
  preview.addEventListener('dragover', e => {
    e.preventDefault();
    const dragging = document.querySelector('.dragging-section');
    if (!dragging) return;
    const after = getDragAfterElement(preview, e.clientY);
    if (after == null) preview.appendChild(dragging);
    else preview.insertBefore(dragging, after);
  });
}

function getDragAfterElement(container, y) {
  const els = [...container.querySelectorAll('section:not(.dragging-section)')];
  return els.reduce((closest, child) => {
    const box    = child.getBoundingClientRect();
    const offset = y - box.top - box.height / 2;
    if (offset < 0 && offset > closest.offset) return { offset, element: child };
    return closest;
  }, { offset: Number.NEGATIVE_INFINITY }).element;
}

initSectionSorting();


/* ═══════════════════════════════════════════════════════
   WIDGET DROP ZONES
   ═══════════════════════════════════════════════════════ */

function setupDropZone(zone) {
  zone.addEventListener('dragover', e => e.preventDefault());
  zone.addEventListener('drop', e => {
    e.preventDefault();
    e.stopPropagation();
    dropWidget(zone, e.dataTransfer.getData('html'), e.dataTransfer.getData('type'));
  });
}

/* Shared drop logic — called by both mouse drop and touch end */
function dropWidget(zone, html, type) {
  if (!html) return;
  counts.widget++;
  createWidget(zone, html, type);
}

function createWidget(parent, htmlContent, type) {
  const wrapper     = document.createElement('div');
  wrapper.className = `widget-wrapper codeme-${counts.widget}`;

  const overlay       = document.createElement('div');
  overlay.className   = 'widget-actions';
  overlay.innerHTML   = `
    <span class="action-btn pencil" title="Duplicate">❐</span>
    <span class="action-btn trash"  title="Delete">×</span>
  `;

  const content = document.createElement('div');
  content.innerHTML = htmlContent;
  const actualWidget  = content.firstChild;

  if (actualWidget && actualWidget.nodeType === 1) {
    // Only set contentEditable on text-container elements, not media/form/component elements
    const nonEditable = ['IMG','INPUT','SELECT','TEXTAREA','NAV','FORM'];
    const isComponent = actualWidget.classList.contains('pb-navbar') ||
                        actualWidget.classList.contains('pb-carousel') ||
                        actualWidget.classList.contains('pb-footer') ||
                        actualWidget.classList.contains('pb-reg-form') ||
                        actualWidget.classList.contains('pb-mobile-drawer') ||
                        actualWidget.classList.contains('pb-drawer-overlay');
    if (!nonEditable.includes(actualWidget.tagName) && !isComponent) {
      actualWidget.contentEditable = 'true';
    }
    actualWidget.onclick = e => { e.stopPropagation(); selectItem(actualWidget, `Element: ${actualWidget.tagName.toLowerCase()}`, e); };
  }

  wrapper.appendChild(overlay);
  if (actualWidget) wrapper.appendChild(actualWidget);
  parent.appendChild(wrapper);

  overlay.querySelector('.pencil').onclick = e => {
    e.stopPropagation();
    counts.widget++;
    createWidget(parent, actualWidget.outerHTML);
  };
  overlay.querySelector('.trash').onclick = e => {
    e.stopPropagation();
    wrapper.remove();
    updateCode();
  };

  wrapper.onclick = e => selectItem(wrapper, `Widget ${counts.widget}`, e);
  updateCode();
}


/* ═══════════════════════════════════════════════════════
   SELECTION SYSTEM
   ═══════════════════════════════════════════════════════ */

function selectItem(el, label, event) {
  if (event) event.stopPropagation();
  if (selected) selected.classList.remove('selected', 'selected-global');

  selected = el;
  el.classList.add(el === previewContent ? 'selected-global' : 'selected');
  activeLabel.innerText = label;

  document.getElementById('pseudoSelector').value = 'main';
  loadCurrentCSS();

  // Load inline CSS into editor
  const s = el.getAttribute('style') || '';
  cssInput.value = s.split(';').map(x => x.trim()).filter(x => x).join(';\n') + (s ? ';' : '');

  // Load widget JS
  const jsInput  = document.getElementById('jsInput');
  const uid      = findUID(el);
  jsInput.value  = (uid && widgetScripts.has(uid)) ? widgetScripts.get(uid) : '';

  // Widget-specific editor panel — detect which component was clicked
  const find = (cls) => el.classList.contains(cls) ? el : el.querySelector('.' + cls) || el.closest('.' + cls);
  const nav      = find('pb-navbar');
  const carousel = find('pb-carousel');
  const form     = find('pb-reg-form');
  const footer   = find('pb-footer');
  const img      = (el.tagName === 'IMG' && el.classList.contains('pb-image-widget')) ? el : el.querySelector('.pb-image-widget');
  const card     = el.classList.contains('pb-card') ? el : (el.closest('.pb-card') || (el.querySelector('.pb-card')));
  const hero     = find('pb-folio-hero');
  const alert    = find('pb-alert');
  const badge    = find('pb-badge');
  const heading  = ['H1','H2','H3','H4','H5','H6'].includes(el.tagName) ? el : el.querySelector('h1,h2,h3,h4,h5,h6');
  const para     = el.tagName === 'P' ? el : (!heading && el.querySelector('p') ? el.querySelector('p') : null);
  const btn      = el.tagName === 'BUTTON' ? el : el.querySelector('button:not(.widget-actions button):not(.plus-btn):not(.section-del-btn)');
  const list     = ['UL','OL'].includes(el.tagName) ? el : el.querySelector('ul,ol');
  const quote    = el.tagName === 'BLOCKQUOTE' ? el : el.querySelector('blockquote');
  const table    = el.tagName === 'TABLE' ? el : el.querySelector('table');
  const progress = el.tagName === 'PROGRESS' ? el : el.querySelector('progress');
  const meter    = el.tagName === 'METER'    ? el : el.querySelector('meter');
  const details  = el.tagName === 'DETAILS'  ? el : el.querySelector('details');
  const hr       = el.tagName === 'HR'       ? el : el.querySelector('hr');
  const video    = el.querySelector('iframe[src*="youtube"], iframe[src*="vimeo"], video');
  const settingsPanel = document.getElementById('widgetSettings');

  if (nav) {
    settingsPanel.style.display = 'block';
    activeNavbar = nav;
    refreshNavbarEditor();
  } else if (carousel) {
    settingsPanel.style.display = 'block';
    refreshCarouselEditor(el);
  } else if (hero) {
    refreshHeroEditor(hero);
  } else if (footer) {
    refreshFooterEditor(footer);
  } else if (form) {
    refreshFormEditor(el);
  } else if (img) {
    refreshImageEditor(img);
  } else if (card) {
    refreshCardEditor(card);
  } else if (alert) {
    refreshAlertEditor(alert);
  } else if (badge) {
    refreshBadgeEditor(badge);
  } else if (video) {
    refreshVideoEditor(video);
  } else if (table) {
    refreshTableEditor(table);
  } else if (progress) {
    refreshProgressEditor(progress);
  } else if (meter) {
    refreshMeterEditor(meter);
  } else if (details) {
    refreshDetailsEditor(details);
  } else if (hr) {
    refreshDividerEditor(hr);
  } else if (quote) {
    refreshQuoteEditor(quote);
  } else if (list) {
    refreshListEditor(list);
  } else if (heading) {
    refreshHeadingEditor(heading);
  } else if (btn) {
    refreshButtonEditor(btn);
  } else if (para) {
    refreshParaEditor(para);
  } else {
    settingsPanel.style.display = 'none';
    activeNavbar = null;
  }
}

function findUID(el) {
  return Array.from(el.classList).find(c => c.startsWith('codeme-')) ||
         (el.closest('.widget-wrapper') ? Array.from(el.closest('.widget-wrapper').classList).find(c => c.startsWith('codeme-')) : null);
}


/* ═══════════════════════════════════════════════════════
   NAVBAR MOBILE TOGGLE (in-preview functions)
   ═══════════════════════════════════════════════════════ */

function pbToggleMobile(btn) {
  // Search inside the preview div first, then fall back to document
  const ctx = btn.closest('#preview') || document;
  const drawer  = ctx.querySelector('#pb-drawer') || document.getElementById('pb-drawer');
  const overlay = ctx.querySelector('.pb-drawer-overlay') || document.querySelector('.pb-drawer-overlay');
  if (!drawer) return;
  const isOpen = drawer.classList.toggle('open');
  btn.textContent = isOpen ? '✕' : '☰';
  if (overlay) overlay.classList.toggle('open', isOpen);
}

function pbCloseMobile() {
  const ctx = document;
  const drawer  = ctx.getElementById ? ctx.getElementById('pb-drawer') : ctx.querySelector('#pb-drawer');
  const overlay = ctx.querySelector ? ctx.querySelector('.pb-drawer-overlay') : null;
  if (drawer)  { drawer.classList.remove('open'); }
  if (overlay) { overlay.classList.remove('open'); }
  // reset all hamburger buttons
  document.querySelectorAll('.pb-nav-toggle').forEach(b => b.textContent = '☰');
}

function pbToggleSubMenu(li) {
  const sub = li.querySelector('.pb-mobile-dropdown');
  if (sub) sub.classList.toggle('open');
}


/* ═══════════════════════════════════════════════════════
   CAROUSEL LOGIC
   ═══════════════════════════════════════════════════════ */

function pbMoveSlide(btn, dir) {
  const carousel = btn.closest('.pb-carousel');
  const slides   = carousel.querySelectorAll('.pb-slides img');
  if (slides.length <= 1) return;

  let idx = Array.from(slides).findIndex(img => img.classList.contains('active'));
  slides[idx].classList.remove('active');
  idx = (idx + dir + slides.length) % slides.length;
  slides[idx].classList.add('active');

  carousel.querySelectorAll('.pb-dot').forEach((d, i) => {
    d.classList.toggle('pb-dot-active', i === idx);
    d.style.background = i === idx ? 'white' : 'rgba(255,255,255,0.4)';
  });
}

function refreshCarouselEditor(el) {
  const settingsPanel     = document.getElementById('widgetSettings');
  const navStructContainer = document.getElementById('navbarStructure');
  const carousel = el.querySelector('.pb-carousel') || (el.classList.contains('pb-carousel') ? el : null);
  if (!carousel) return;

  settingsPanel.style.display = 'block';
  navStructContainer.innerHTML = '';

  const label        = createEditorLabel('Carousel Slides');
  navStructContainer.appendChild(label);

  const slidesContainer = carousel.querySelector('.pb-slides');
  const images          = slidesContainer.querySelectorAll('img');

  images.forEach((img, index) => {
    const row = document.createElement('div');
    row.style = 'display:flex;align-items:center;gap:8px;margin-bottom:6px;background:var(--surface3);padding:8px;border-radius:var(--radius-sm);cursor:pointer;border:1px solid var(--border);transition:border-color .15s;';
    row.innerHTML = `
      <img src="${img.src}" style="width:32px;height:32px;object-fit:cover;border-radius:3px;flex-shrink:0;">
      <span style="flex:1;font-size:11px;color:var(--text-muted);">Slide ${index + 1}</span>
      <button class="change-img-btn editor-btn">Change</button>
      <input type="file" accept="image/*" style="display:none;">
      <span class="del-slide remove-btn">×</span>
    `;

    row.querySelector('.change-img-btn').onclick = e => { e.stopPropagation(); row.querySelector('input[type=file]').click(); };
    row.querySelector('input[type=file]').onchange = e => {
      const reader = new FileReader();
      reader.onload = ev => { img.src = ev.target.result; row.querySelector('img').src = ev.target.result; updateCode(); };
      reader.readAsDataURL(e.target.files[0]);
    };
    row.querySelector('.del-slide').onclick = e => {
      e.stopPropagation();
      img.remove(); row.remove();
      const remaining = slidesContainer.querySelectorAll('img');
      if (remaining.length > 0 && !slidesContainer.querySelector('.active')) remaining[0].classList.add('active');
      rebuildCarouselDots(carousel);
      updateCode();
    };

    navStructContainer.appendChild(row);
  });

  const addBtn       = document.createElement('button');
  addBtn.className   = 'btn btn-primary';
  addBtn.style       = 'width:100%;margin-top:6px;';
  addBtn.innerText   = '+ Add New Slide';
  addBtn.onclick     = () => {
    const newImg = document.createElement('img');
    newImg.src   = 'img/banner.png';
    newImg.alt   = 'Slide';
    if (slidesContainer.children.length === 0) newImg.className = 'active';
    slidesContainer.appendChild(newImg);
    rebuildCarouselDots(carousel);
    refreshCarouselEditor(el);
    updateCode();
  };
  navStructContainer.appendChild(addBtn);
  rebuildCarouselDots(carousel);
}

function rebuildCarouselDots(carousel) {
  let dotsContainer = carousel.querySelector('.pb-dots');
  if (!dotsContainer) {
    dotsContainer           = document.createElement('div');
    dotsContainer.className = 'pb-dots';
    dotsContainer.style     = 'position:absolute;bottom:12px;left:50%;transform:translateX(-50%);display:flex;gap:6px;z-index:10;';
    carousel.appendChild(dotsContainer);
  }
  dotsContainer.innerHTML = '';

  carousel.querySelectorAll('.pb-slides img').forEach((img, i) => {
    const dot     = document.createElement('span');
    dot.className = 'pb-dot' + (img.classList.contains('active') ? ' pb-dot-active' : '');
    dot.style     = `width:8px;height:8px;border-radius:50%;background:${img.classList.contains('active') ? 'white' : 'rgba(255,255,255,0.4)'};cursor:pointer;transition:all .2s;`;
    dot.onclick   = () => { pbMoveSlide({ closest: () => carousel }, i - (i * 2)); };
    dotsContainer.appendChild(dot);
  });
}


/* ═══════════════════════════════════════════════════════
   IMAGE EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshImageEditor(img) {
  const settingsPanel      = document.getElementById('widgetSettings');
  const navStructContainer = document.getElementById('navbarStructure');
  settingsPanel.style.display  = 'block';

  navStructContainer.innerHTML = `
    <div style="padding:2px 0 8px;">
      ${createEditorLabel('Image Settings').outerHTML}
      <div style="background:var(--surface3);padding:10px;border-radius:var(--radius-sm);">
        <label style="font-size:9px;color:var(--text-muted);display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.06em;">Image URL</label>
        <input type="text" id="imgSrcInput" value="${img.src}"
          style="width:100%;background:var(--surface2);color:var(--text);border:1px solid var(--border);padding:6px 8px;font-size:11px;border-radius:3px;box-sizing:border-box;font-family:inherit;outline:none;margin-bottom:8px;">
        <button id="uploadImgBtn" class="btn btn-primary" style="width:100%;font-size:10px;">Upload Local File</button>
        <input type="file" id="hiddenFileIn" accept="image/*" style="display:none;">
        <p class="help-text" style="margin-top:8px;">Use CSS below to adjust width, border-radius, etc.</p>
      </div>
    </div>
  `;

  document.getElementById('imgSrcInput').oninput  = e => { img.src = e.target.value; updateCode(); };
  document.getElementById('uploadImgBtn').onclick  = () => document.getElementById('hiddenFileIn').click();
  document.getElementById('hiddenFileIn').onchange = e => {
    const reader = new FileReader();
    reader.onload = ev => { img.src = ev.target.result; document.getElementById('imgSrcInput').value = ev.target.result; updateCode(); };
    reader.readAsDataURL(e.target.files[0]);
  };
}


/* ═══════════════════════════════════════════════════════
   FORM EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshFormEditor(el) {
  const settingsPanel      = document.getElementById('widgetSettings');
  const navStructContainer = document.getElementById('navbarStructure');
  const form = el.querySelector('.pb-reg-form') || (el.classList.contains('pb-reg-form') ? el : el.closest('.pb-reg-form'));
  if (!form) return;

  settingsPanel.style.display = 'block';
  navStructContainer.innerHTML = '';
  navStructContainer.appendChild(createEditorLabel('Form Fields'));

  const title = form.querySelector('h3');
  if (title) {
    const row = makeEditorRow('Title', title.innerText, false);
    row.querySelector('input').oninput = e => { title.innerText = e.target.value; updateCode(); };
    navStructContainer.appendChild(row);
  }

  form.querySelectorAll('input').forEach((input) => {
    const row = document.createElement('div');
    row.style = 'display:flex;align-items:center;gap:5px;background:var(--surface3);padding:6px 8px;margin-bottom:4px;border-radius:3px;';
    row.innerHTML = `
      <select style="background:var(--surface2);color:var(--text);border:1px solid var(--border);font-size:10px;padding:3px 5px;border-radius:3px;font-family:inherit;outline:none;">
        <option value="text"     ${input.type==='text'     ?'selected':''}>Text</option>
        <option value="email"    ${input.type==='email'    ?'selected':''}>Email</option>
        <option value="password" ${input.type==='password' ?'selected':''}>Pass</option>
        <option value="number"   ${input.type==='number'   ?'selected':''}>Number</option>
      </select>
      <input type="text" value="${input.placeholder || ''}"
        style="flex:1;background:transparent;border:none;color:var(--text);font-size:11px;font-family:inherit;outline:none;"
        placeholder="Placeholder">
      <span style="color:var(--danger);cursor:pointer;font-weight:700;font-size:14px;line-height:1;" class="del-field">×</span>
    `;
    row.querySelector('select').onchange  = e => { input.type = e.target.value; updateCode(); };
    row.querySelector('input').oninput    = e => { input.placeholder = e.target.value; updateCode(); };
    row.querySelector('.del-field').onclick = () => { input.remove(); row.remove(); updateCode(); };
    navStructContainer.appendChild(row);
  });

  const addBtn     = document.createElement('button');
  addBtn.className = 'btn btn-primary';
  addBtn.style     = 'width:100%;margin-top:6px;font-size:10px;';
  addBtn.innerText = '+ Add Input Field';
  addBtn.onclick   = () => {
    const newInput       = document.createElement('input');
    newInput.type        = 'text';
    newInput.placeholder = 'New Field';
    form.insertBefore(newInput, form.querySelector('button'));
    refreshFormEditor(el);
    updateCode();
  };
  navStructContainer.appendChild(addBtn);
}


/* ═══════════════════════════════════════════════════════
   NAVBAR EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshNavbarEditor() {
  const settingsPanel      = document.getElementById('widgetSettings');
  const navStructContainer = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  if (!activeNavbar || !navStructContainer) return;
  navStructContainer.innerHTML = '';

  let logoWrap = activeNavbar.querySelector('.pb-logo-container');
  if (!logoWrap) {
    logoWrap           = document.createElement('div');
    logoWrap.className = 'pb-logo-container';
    activeNavbar.prepend(logoWrap);
  }

  // Logo type switcher
  const typeRow       = document.createElement('div');
  typeRow.style       = 'display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-bottom:8px;';
  typeRow.innerHTML   = `
    <button id="btn-text-mode" class="editor-btn">TEXT LOGO</button>
    <button id="btn-img-mode"  class="editor-btn">IMAGE LOGO</button>
  `;
  navStructContainer.appendChild(typeRow);

  const logoRow = document.createElement('div');
  logoRow.style = 'background:var(--surface3);padding:8px;margin-bottom:12px;border-radius:3px;border:1px solid var(--border);';
  navStructContainer.appendChild(logoRow);

  const switchToText  = () => {
    logoWrap.innerHTML = `<div class="pb-nav-text-logo" contenteditable="true" style="font-weight:700;">MyBrand</div>`;
    renderLogoUI(); updateCode();
  };
  const switchToImage = () => {
    logoWrap.innerHTML = `<img class="pb-nav-logo" src="img/logo.svg" style="height:30px;width:auto;">`;
    renderLogoUI(); updateCode();
  };

  function renderLogoUI() {
    const logoImg  = logoWrap.querySelector('.pb-nav-logo');
    const logoText = logoWrap.querySelector('.pb-nav-text-logo');
    logoRow.innerHTML = '';

    if (logoText) {
      logoRow.innerHTML = `
        <div style="display:flex;align-items:center;gap:8px;">
          <span class="badge blue">TEXT</span>
          <input type="text" value="${logoText.innerText}"
            style="flex:1;background:transparent;border:none;color:var(--text);outline:none;font-size:12px;font-family:inherit;">
        </div>
      `;
      logoRow.querySelector('input').oninput = e => { logoText.innerText = e.target.value; updateCode(); };

    } else if (logoImg) {
      logoRow.innerHTML = `
        <div style="display:flex;align-items:center;gap:8px;">
          <span class="badge blue">IMG</span>
          <button id="logo-upload-trigger" class="editor-btn" style="flex:1;">Upload File</button>
          <input type="file" id="logo-hidden-file" accept="image/*" style="display:none;">
        </div>
      `;
      const fileIn = logoRow.querySelector('#logo-hidden-file');
      logoRow.querySelector('#logo-upload-trigger').onclick = () => fileIn.click();
      fileIn.onchange = e => {
        const reader = new FileReader();
        reader.onload = ev => { logoImg.src = ev.target.result; updateCode(); };
        if (e.target.files[0]) reader.readAsDataURL(e.target.files[0]);
      };
    }
  }

  typeRow.querySelector('#btn-text-mode').onclick = switchToText;
  typeRow.querySelector('#btn-img-mode').onclick  = switchToImage;
  renderLogoUI();

  // Nav Links editor — with real drag-to-reorder
  const navList = activeNavbar.querySelector('.pb-nav-list');
  if (navList) {
    navStructContainer.appendChild(createEditorLabel('Navigation Links'));

    // Drag state for sidebar rows
    let dragSrcLi = null;

    navList.querySelectorAll(':scope > li').forEach(li => {
      const linkText = li.childNodes[0] ? li.childNodes[0].textContent.trim() : 'Link';

      /* ── Row ── */
      const row = document.createElement('div');
      row.dataset.navRow = '1';
      row.style = [
        'display:flex','align-items:center','gap:5px',
        'background:var(--surface3)','padding:6px 8px',
        'margin-bottom:4px','border-radius:4px',
        'border:1px solid var(--border)','cursor:default',
        'transition:border-color .15s,background .15s'
      ].join(';');

      row.innerHTML = `
        <span class="nav-drag-grip" draggable="true"
          title="Drag to reorder"
          style="cursor:grab;color:var(--text-muted);font-size:13px;padding:0 3px;
                 flex-shrink:0;line-height:1;user-select:none;letter-spacing:-1px;">⠿</span>
        <span style="background:var(--accent);color:#fff;font-size:8px;font-weight:700;
                     padding:2px 5px;border-radius:3px;flex-shrink:0;letter-spacing:.04em;">LINK</span>
        <input type="text" value="${linkText.replace(/"/g,'&quot;')}"
          style="flex:1;min-width:0;background:transparent;border:none;color:var(--text);
                 font-size:12px;outline:none;font-family:inherit;">
        <button class="nb-add-sub" title="Add sub-item"
          style="background:var(--surface2);border:1px solid var(--border);color:var(--text-muted);
                 border-radius:3px;padding:2px 6px;font-size:11px;cursor:pointer;flex-shrink:0;
                 font-family:inherit;transition:all .15s;">+sub</button>
        <button class="nb-del" title="Delete link"
          style="background:#f43f5e22;border:1px solid #f43f5e55;color:#f43f5e;
                 border-radius:3px;padding:2px 7px;font-size:14px;font-weight:700;
                 cursor:pointer;flex-shrink:0;font-family:inherit;line-height:1;
                 transition:all .15s;">×</button>
      `;

      /* Rename */
      row.querySelector('input').oninput = e => {
        if (li.childNodes[0] && li.childNodes[0].nodeType === 3)
          li.childNodes[0].textContent = e.target.value;
        else li.prepend(document.createTextNode(e.target.value));
        updateCode();
      };

      /* Delete */
      const delBtn = row.querySelector('.nb-del');
      delBtn.onmouseenter = () => { delBtn.style.background='#f43f5e'; delBtn.style.color='#fff'; };
      delBtn.onmouseleave = () => { delBtn.style.background='#f43f5e22'; delBtn.style.color='#f43f5e'; };
      delBtn.onclick = () => { li.remove(); refreshNavbarEditor(); updateCode(); };

      /* Add sub */
      row.querySelector('.nb-add-sub').onclick = () => {
        let dd = li.querySelector('.pb-dropdown');
        if (!dd) {
          li.classList.add('pb-has-dropdown');
          dd = document.createElement('ul');
          dd.className = 'pb-dropdown';
          li.appendChild(dd);
        }
        const s = document.createElement('li');
        s.innerText = 'Sub Item';
        dd.appendChild(s);
        refreshNavbarEditor();
        updateCode();
      };

      /* ── Drag-to-reorder on the grip ── */
      const grip = row.querySelector('.nav-drag-grip');

      grip.addEventListener('dragstart', e => {
        dragSrcLi = li;
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', '');   // required for Firefox
        setTimeout(() => { row.style.opacity = '0.45'; }, 0);
      });

      grip.addEventListener('dragend', () => {
        row.style.opacity = '1';
        // Remove all drag-over highlights
        navStructContainer.querySelectorAll('[data-nav-row]').forEach(r => {
          r.style.borderColor = 'var(--border)';
          r.style.background  = 'var(--surface3)';
        });
        dragSrcLi = null;
        updateCode();
      });

      row.addEventListener('dragover', e => {
        if (!dragSrcLi || dragSrcLi === li) return;
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        row.style.borderColor = 'var(--accent)';
        row.style.background  = 'rgba(99,102,241,0.12)';
      });

      row.addEventListener('dragleave', () => {
        row.style.borderColor = 'var(--border)';
        row.style.background  = 'var(--surface3)';
      });

      row.addEventListener('drop', e => {
        e.preventDefault();
        if (!dragSrcLi || dragSrcLi === li) return;
        row.style.borderColor = 'var(--border)';
        row.style.background  = 'var(--surface3)';

        // Insert dragSrcLi before the current li in the real navList
        const srcIdx = [...navList.children].indexOf(dragSrcLi);
        const tgtIdx = [...navList.children].indexOf(li);
        if (srcIdx < tgtIdx) navList.insertBefore(dragSrcLi, li.nextElementSibling);
        else                  navList.insertBefore(dragSrcLi, li);

        refreshNavbarEditor();
        updateCode();
      });

      navStructContainer.appendChild(row);

      /* ── Sub-items ── */
      const dropdown = li.querySelector('.pb-dropdown');
      if (dropdown) {
        dropdown.querySelectorAll(':scope > li').forEach(subLi => {
          const subRow = document.createElement('div');
          subRow.style = [
            'display:flex','align-items:center','gap:5px',
            'background:var(--bg)','padding:5px 8px',
            'margin-bottom:3px','margin-left:18px',
            'border-radius:3px','border-left:2px solid var(--accent)'
          ].join(';');
          subRow.innerHTML = `
            <span style="background:#6366f1;color:#fff;font-size:7px;font-weight:700;
                         padding:2px 4px;border-radius:2px;flex-shrink:0;">SUB</span>
            <input type="text" value="${subLi.innerText.replace(/"/g,'&quot;')}"
              style="flex:1;min-width:0;background:transparent;border:none;color:var(--text);
                     font-size:11px;outline:none;font-family:inherit;">
            <button class="nb-del-sub"
              style="background:#f43f5e22;border:1px solid #f43f5e55;color:#f43f5e;
                     border-radius:3px;padding:1px 6px;font-size:13px;font-weight:700;
                     cursor:pointer;flex-shrink:0;font-family:inherit;line-height:1;
                     transition:all .15s;">×</button>
          `;
          subRow.querySelector('input').oninput = e => { subLi.innerText = e.target.value; updateCode(); };
          const dBtn = subRow.querySelector('.nb-del-sub');
          dBtn.onmouseenter = () => { dBtn.style.background='#f43f5e'; dBtn.style.color='#fff'; };
          dBtn.onmouseleave = () => { dBtn.style.background='#f43f5e22'; dBtn.style.color='#f43f5e'; };
          dBtn.onclick = () => {
            subLi.remove();
            if (!dropdown.querySelector('li')) { dropdown.remove(); li.classList.remove('pb-has-dropdown'); }
            refreshNavbarEditor();
            updateCode();
          };
          navStructContainer.appendChild(subRow);
        });
      }
    });
  }

  /* ── Add Nav Link button ── */
  const addMainBtn = document.createElement('button');
  addMainBtn.className = 'btn btn-primary';
  addMainBtn.style = 'width:100%;margin-top:10px;font-size:10px;';
  addMainBtn.innerText = '+ Add Nav Link';
  addMainBtn.onclick = () => {
    const newLi = document.createElement('li');
    newLi.innerText = 'New Link';
    if (navList) navList.appendChild(newLi);
    refreshNavbarEditor();
    updateCode();
  };
  navStructContainer.appendChild(addMainBtn);
}

function addNavLink() {
  if (!activeNavbar) return;
  const list      = activeNavbar.querySelector('.pb-nav-list');
  const newItem   = document.createElement('li');
  newItem.contentEditable = 'true';
  newItem.innerText = 'New Link';
  if (list) list.appendChild(newItem);
  refreshNavbarEditor();
  updateCode();
}

/* ═══════════════════════════════════════════════════════
   FOOTER EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshFooterEditor(footer) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Footer Brand'));

  const brandH3 = footer.querySelector('.pb-footer-brand h3');
  const brandP  = footer.querySelector('.pb-footer-brand p');

  if (brandH3) {
    const r = makeEditorRow('Brand', brandH3.innerText, false);
    r.querySelector('input').oninput = e => { brandH3.innerText = e.target.value; updateCode(); };
    container.appendChild(r);
  }
  if (brandP) {
    const r2 = makeEditorRow('Tagline', brandP.innerText, false);
    r2.querySelector('input').oninput = e => { brandP.innerText = e.target.value; updateCode(); };
    container.appendChild(r2);
  }

  container.appendChild(createEditorLabel('Footer Columns'));
  footer.querySelectorAll('.pb-footer-col').forEach((col, ci) => {
    const h4 = col.querySelector('h4');
    if (h4) {
      const hRow = makeEditorRow('Col '+(ci+1), h4.innerText, false);
      hRow.querySelector('input').oninput = e => { h4.innerText = e.target.value; updateCode(); };
      container.appendChild(hRow);
    }
    col.querySelectorAll('li').forEach((li, li_i) => {
      const lRow = document.createElement('div');
      lRow.style = 'display:flex;align-items:center;gap:5px;padding:4px 8px 4px 18px;margin-bottom:3px;background:var(--bg);border-radius:3px;';
      lRow.innerHTML = `<span style="font-size:9px;color:var(--text-muted);">↳</span><input type="text" value="${li.innerText}" style="flex:1;background:transparent;border:none;color:var(--text);font-size:11px;outline:none;font-family:inherit;"><span class="remove-btn" style="font-size:12px;">×</span>`;
      lRow.querySelector('input').oninput = e => { li.innerText = e.target.value; updateCode(); };
      lRow.querySelector('.remove-btn').onclick = () => { li.remove(); lRow.remove(); updateCode(); };
      container.appendChild(lRow);
    });
    const addLi = document.createElement('button');
    addLi.className = 'btn btn-ghost'; addLi.style = 'width:100%;font-size:9px;margin-bottom:8px;';
    addLi.innerText = '+ Add Link to Col '+(ci+1);
    addLi.onclick = () => {
      const newLi = document.createElement('li'); newLi.innerText = 'New Link';
      col.querySelector('ul').appendChild(newLi);
      refreshFooterEditor(footer); updateCode();
    };
    container.appendChild(addLi);
  });

  container.appendChild(createEditorLabel('Copyright'));
  const copy = footer.querySelector('.pb-footer-bottom span');
  if (copy) {
    const cr = makeEditorRow('©', copy.innerText, false);
    cr.querySelector('input').oninput = e => { copy.innerText = e.target.value; updateCode(); };
    container.appendChild(cr);
  }
}


/* ═══════════════════════════════════════════════════════
   CARD EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshCardEditor(card) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Card'));

  // Find card inner elements — support both pb-card and generic card divs
  const root    = card;
  const titleEl = root.querySelector('h1,h2,h3,h4,h5,h6');
  const descEl  = root.querySelector('p');
  const btnEl   = root.querySelector('button,a.btn');
  const imgEl   = root.querySelector('img');
  const bannerEl = root.querySelector('div[style*="background"]');

  if (titleEl) {
    const r = makeEditorRow('Title', titleEl.innerText, false);
    r.querySelector('input').oninput = e => { titleEl.innerText = e.target.value; updateCode(); };
    container.appendChild(r);
  }
  if (descEl) {
    const r = makeEditorRow('Desc', descEl.innerText, false);
    r.querySelector('input').oninput = e => { descEl.innerText = e.target.value; updateCode(); };
    container.appendChild(r);
  }
  if (btnEl) {
    const r = makeEditorRow('Btn', btnEl.innerText, false);
    r.querySelector('input').oninput = e => { btnEl.innerText = e.target.value; updateCode(); };
    container.appendChild(r);
  }
  if (bannerEl && !imgEl) {
    container.appendChild(createEditorLabel('Banner Color'));
    const colorRow = document.createElement('div');
    colorRow.style = 'display:flex;align-items:center;gap:8px;margin-bottom:6px;';
    colorRow.innerHTML = `<input type="color" value="#6366f1" style="width:36px;height:28px;border:none;border-radius:3px;cursor:pointer;background:none;"><span style="font-size:11px;color:var(--text-muted);">Banner background</span>`;
    colorRow.querySelector('input[type=color]').oninput = e => {
      bannerEl.style.background = e.target.value; updateCode();
    };
    container.appendChild(colorRow);
  }
  if (imgEl) {
    container.appendChild(createEditorLabel('Card Image'));
    const uploadRow = document.createElement('div');
    uploadRow.innerHTML = `<button class="btn btn-primary" style="width:100%;font-size:10px;margin-bottom:4px;">Upload Image</button><input type="file" accept="image/*" style="display:none;">`;
    uploadRow.querySelector('button').onclick = () => uploadRow.querySelector('input[type=file]').click();
    uploadRow.querySelector('input[type=file]').onchange = e => {
      const r = new FileReader(); r.onload = ev => { imgEl.src = ev.target.result; updateCode(); };
      if (e.target.files[0]) r.readAsDataURL(e.target.files[0]);
    };
    container.appendChild(uploadRow);
  }
}


/* ═══════════════════════════════════════════════════════
   ALERT EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshAlertEditor(alert) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Alert'));

  const titleEl = alert.querySelector('strong');
  const msgEl   = alert.querySelector('p');
  const iconEl  = alert.querySelector('span:first-child');

  if (titleEl) {
    const r = makeEditorRow('Title', titleEl.innerText, false);
    r.querySelector('input').oninput = e => { titleEl.innerText = e.target.value; updateCode(); };
    container.appendChild(r);
  }
  if (msgEl) {
    const r = makeEditorRow('Message', msgEl.innerText, false);
    r.querySelector('input').oninput = e => { msgEl.innerText = e.target.value; updateCode(); };
    container.appendChild(r);
  }

  container.appendChild(createEditorLabel('Alert Type'));
  const types = [
    { label: 'Info',    bg: '#eff6ff', border: '#bfdbfe', left: '#3b82f6', color: '#1e40af', icon: 'ℹ️' },
    { label: 'Success', bg: '#f0fdf4', border: '#bbf7d0', left: '#22c55e', color: '#15803d', icon: '✅' },
    { label: 'Warning', bg: '#fffbeb', border: '#fde68a', left: '#f59e0b', color: '#b45309', icon: '⚠️' },
    { label: 'Error',   bg: '#fff1f2', border: '#fecdd3', left: '#f43f5e', color: '#be123c', icon: '🚫' },
  ];
  const typeGrid = document.createElement('div');
  typeGrid.style = 'display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-bottom:8px;';
  types.forEach(t => {
    const b = document.createElement('button');
    b.className = 'editor-btn'; b.innerText = t.label;
    b.onclick = () => {
      alert.style.background   = t.bg;
      alert.style.border       = `1px solid ${t.border}`;
      alert.style.borderLeft   = `4px solid ${t.left}`;
      if (titleEl) titleEl.style.color = t.color;
      if (msgEl)   msgEl.style.color   = t.color;
      if (iconEl)  iconEl.innerText    = t.icon;
      updateCode();
    };
    typeGrid.appendChild(b);
  });
  container.appendChild(typeGrid);
}


/* ═══════════════════════════════════════════════════════
   BADGE EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshBadgeEditor(badge) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Badge'));

  const r = makeEditorRow('Text', badge.innerText, false);
  r.querySelector('input').oninput = e => { badge.innerText = e.target.value; updateCode(); };
  container.appendChild(r);

  container.appendChild(createEditorLabel('Color'));
  const colors = ['#6366f1','#22c55e','#f59e0b','#f43f5e','#0ea5e9','#8b5cf6','#64748b'];
  const colorRow = document.createElement('div');
  colorRow.style = 'display:flex;gap:5px;flex-wrap:wrap;margin-bottom:8px;';
  colors.forEach(c => {
    const swatch = document.createElement('span');
    swatch.style = `width:20px;height:20px;border-radius:50%;background:${c};cursor:pointer;border:2px solid transparent;transition:border-color .15s;`;
    swatch.onclick = () => { badge.style.background = c; updateCode(); };
    swatch.onmouseover = () => swatch.style.borderColor = 'white';
    swatch.onmouseout  = () => swatch.style.borderColor = 'transparent';
    colorRow.appendChild(swatch);
  });
  container.appendChild(colorRow);

  container.appendChild(createEditorLabel('Shape'));
  const shapeRow = document.createElement('div');
  shapeRow.style = 'display:grid;grid-template-columns:1fr 1fr;gap:5px;';
  const shapes = [{ label: 'Pill', r: '20px' }, { label: 'Square', r: '4px' }];
  shapes.forEach(s => {
    const b = document.createElement('button');
    b.className = 'editor-btn'; b.innerText = s.label;
    b.onclick = () => { badge.style.borderRadius = s.r; updateCode(); };
    shapeRow.appendChild(b);
  });
  container.appendChild(shapeRow);
}


/* ═══════════════════════════════════════════════════════
   VIDEO EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshVideoEditor(videoEl) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Video Embed'));

  const curSrc = videoEl.src || videoEl.getAttribute('src') || '';
  const row = document.createElement('div');
  row.style = 'margin-bottom:8px;';
  row.innerHTML = `
    <label style="font-size:9px;color:var(--text-muted);display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.06em;">YouTube / Vimeo URL</label>
    <input type="text" value="${curSrc}" placeholder="https://youtube.com/embed/..." style="width:100%;background:var(--surface2);color:var(--text);border:1px solid var(--border);padding:6px 8px;font-size:11px;border-radius:3px;box-sizing:border-box;font-family:inherit;outline:none;">
  `;
  row.querySelector('input').oninput = e => {
    let url = e.target.value.trim();
    // Auto-convert watch URLs to embed
    url = url.replace('watch?v=', 'embed/').replace('youtu.be/', 'youtube.com/embed/');
    videoEl.src = url; updateCode();
  };
  container.appendChild(row);

  container.appendChild(createEditorLabel('Aspect Ratio'));
  const wrapper = videoEl.closest('div[style]');
  const ratioRow = document.createElement('div');
  ratioRow.style = 'display:grid;grid-template-columns:1fr 1fr 1fr;gap:5px;';
  [['16:9','56.25%'],['4:3','75%'],['1:1','100%']].forEach(([label, pb]) => {
    const b = document.createElement('button');
    b.className = 'editor-btn'; b.innerText = label;
    b.onclick = () => { if (wrapper) { wrapper.style.paddingBottom = pb; updateCode(); } };
    ratioRow.appendChild(b);
  });
  container.appendChild(ratioRow);
}


/* ═══════════════════════════════════════════════════════
   HEADING EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshHeadingEditor(el) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Heading'));

  const r = makeEditorRow('Text', el.innerText, false);
  r.querySelector('input').oninput = e => { el.innerText = e.target.value; updateCode(); };
  container.appendChild(r);

  container.appendChild(createEditorLabel('Tag'));
  const tagRow = document.createElement('div');
  tagRow.style = 'display:grid;grid-template-columns:repeat(3,1fr);gap:5px;margin-bottom:8px;';
  ['H1','H2','H3','H4','H5','H6'].forEach(tag => {
    const b = document.createElement('button');
    b.className = 'editor-btn' + (el.tagName === tag ? ' active' : '');
    b.innerText = tag;
    b.onclick = () => {
      const newEl = document.createElement(tag);
      newEl.innerHTML = el.innerHTML;
      Array.from(el.attributes).forEach(a => newEl.setAttribute(a.name, a.value));
      el.replaceWith(newEl);
      el = newEl;
      refreshHeadingEditor(newEl); updateCode();
    };
    tagRow.appendChild(b);
  });
  container.appendChild(tagRow);

  container.appendChild(createEditorLabel('Align'));
  const alignRow = document.createElement('div');
  alignRow.style = 'display:grid;grid-template-columns:1fr 1fr 1fr;gap:5px;';
  ['left','center','right'].forEach(a => {
    const b = document.createElement('button');
    b.className = 'editor-btn'; b.innerText = a[0].toUpperCase()+a.slice(1);
    b.onclick = () => { el.style.textAlign = a; updateCode(); };
    alignRow.appendChild(b);
  });
  container.appendChild(alignRow);
}


/* ═══════════════════════════════════════════════════════
   PARAGRAPH EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshParaEditor(el) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Text'));

  const textarea = document.createElement('textarea');
  textarea.className = 'custom-css-area';
  textarea.style.color = 'var(--text)';
  textarea.style.height = '80px';
  textarea.value = el.innerText;
  textarea.oninput = e => { el.innerText = e.target.value; updateCode(); };
  container.appendChild(textarea);

  container.appendChild(createEditorLabel('Align'));
  const alignRow = document.createElement('div');
  alignRow.style = 'display:grid;grid-template-columns:1fr 1fr 1fr;gap:5px;';
  ['left','center','right'].forEach(a => {
    const b = document.createElement('button'); b.className = 'editor-btn'; b.innerText = a[0].toUpperCase()+a.slice(1);
    b.onclick = () => { el.style.textAlign = a; updateCode(); };
    alignRow.appendChild(b);
  });
  container.appendChild(alignRow);
}


/* ═══════════════════════════════════════════════════════
   BUTTON EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshButtonEditor(btn) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Button'));

  const r = makeEditorRow('Label', btn.innerText, false);
  r.querySelector('input').oninput = e => { btn.innerText = e.target.value; updateCode(); };
  container.appendChild(r);

  const linkRow = makeEditorRow('Link', btn.getAttribute('onclick') || btn.getAttribute('href') || '', false);
  linkRow.querySelector('input').placeholder = 'https://... or #id';
  linkRow.querySelector('input').oninput = e => {
    const v = e.target.value;
    if (v.startsWith('http') || v.startsWith('#')) { btn.setAttribute('onclick', `window.location='${v}'`); }
    updateCode();
  };
  container.appendChild(linkRow);

  container.appendChild(createEditorLabel('Style'));
  const styleRow = document.createElement('div');
  styleRow.style = 'display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-bottom:8px;';
  [
    { label: 'Primary',   bg: '#6366f1', color: '#fff', border: 'none' },
    { label: 'Success',   bg: '#22c55e', color: '#fff', border: 'none' },
    { label: 'Danger',    bg: '#f43f5e', color: '#fff', border: 'none' },
    { label: 'Outline',   bg: 'transparent', color: '#6366f1', border: '2px solid #6366f1' },
    { label: 'Dark',      bg: '#0b0e14', color: '#fff', border: 'none' },
    { label: 'Light',     bg: '#f8fafc', color: '#111', border: '1px solid #e5e7eb' },
  ].forEach(s => {
    const b = document.createElement('button'); b.className = 'editor-btn'; b.innerText = s.label;
    b.onclick = () => {
      btn.style.background = s.bg; btn.style.color = s.color;
      btn.style.border = s.border; btn.style.padding = '10px 20px';
      btn.style.borderRadius = '6px'; btn.style.cursor = 'pointer';
      btn.style.fontWeight = '600'; btn.style.fontSize = '14px';
      updateCode();
    };
    styleRow.appendChild(b);
  });
  container.appendChild(styleRow);

  container.appendChild(createEditorLabel('Shape'));
  const shapeRow = document.createElement('div');
  shapeRow.style = 'display:grid;grid-template-columns:1fr 1fr 1fr;gap:5px;';
  [['Sharp','2px'],['Rounded','8px'],['Pill','50px']].forEach(([l,r]) => {
    const b = document.createElement('button'); b.className = 'editor-btn'; b.innerText = l;
    b.onclick = () => { btn.style.borderRadius = r; updateCode(); };
    shapeRow.appendChild(b);
  });
  container.appendChild(shapeRow);
}


/* ═══════════════════════════════════════════════════════
   LIST EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshListEditor(list) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('List Items'));

  list.querySelectorAll('li').forEach((li, i) => {
    const row = document.createElement('div');
    row.style = 'display:flex;align-items:center;gap:5px;background:var(--surface3);padding:5px 8px;margin-bottom:4px;border-radius:3px;';
    row.innerHTML = `<span style="font-size:9px;color:var(--text-muted);width:14px;">${i+1}</span><input type="text" value="${li.innerText}" style="flex:1;background:transparent;border:none;color:var(--text);font-size:12px;outline:none;font-family:inherit;"><span class="remove-btn" style="font-size:13px;">×</span>`;
    row.querySelector('input').oninput = e => { li.innerText = e.target.value; updateCode(); };
    row.querySelector('.remove-btn').onclick = () => { li.remove(); refreshListEditor(list); updateCode(); };
    container.appendChild(row);
  });

  const addBtn = document.createElement('button');
  addBtn.className = 'btn btn-primary'; addBtn.style = 'width:100%;margin-top:6px;font-size:10px;';
  addBtn.innerText = '+ Add Item';
  addBtn.onclick = () => {
    const li = document.createElement('li'); li.innerText = 'New Item';
    li.style.marginBottom = '10px'; list.appendChild(li);
    refreshListEditor(list); updateCode();
  };
  container.appendChild(addBtn);

  container.appendChild(createEditorLabel('List Style'));
  const styleRow = document.createElement('div');
  styleRow.style = 'display:grid;grid-template-columns:1fr 1fr 1fr;gap:5px;';
  [['None','none'],['Disc','disc'],['Decimal','decimal']].forEach(([l,s]) => {
    const b = document.createElement('button'); b.className = 'editor-btn'; b.innerText = l;
    b.onclick = () => { list.style.listStyle = s; list.style.paddingLeft = s === 'none' ? '0' : '20px'; updateCode(); };
    styleRow.appendChild(b);
  });
  container.appendChild(styleRow);
}


/* ═══════════════════════════════════════════════════════
   BLOCKQUOTE EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshQuoteEditor(el) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Blockquote'));

  const textarea = document.createElement('textarea');
  textarea.className = 'custom-css-area';
  textarea.style.color = 'var(--text)'; textarea.style.height = '80px';
  textarea.value = el.innerText.replace(/[""]/g, '');
  textarea.oninput = e => { el.innerHTML = `&ldquo;${e.target.value}&rdquo;`; updateCode(); };
  container.appendChild(textarea);

  container.appendChild(createEditorLabel('Accent Color'));
  const colorRow = document.createElement('div');
  colorRow.style = 'display:flex;gap:5px;flex-wrap:wrap;';
  ['#6366f1','#22c55e','#f59e0b','#f43f5e','#0ea5e9','#64748b'].forEach(c => {
    const swatch = document.createElement('span');
    swatch.style = `width:20px;height:20px;border-radius:50%;background:${c};cursor:pointer;border:2px solid transparent;`;
    swatch.onclick = () => { el.style.borderLeftColor = c; updateCode(); };
    colorRow.appendChild(swatch);
  });
  container.appendChild(colorRow);
}


/* ═══════════════════════════════════════════════════════
   TABLE EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshTableEditor(table) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Table'));

  const heads = table.querySelectorAll('th');
  const rows  = table.querySelectorAll('tbody tr');

  container.appendChild(createEditorLabel('Headers'));
  heads.forEach((th, i) => {
    const r = makeEditorRow('H'+(i+1), th.innerText, false);
    r.querySelector('input').oninput = e => { th.innerText = e.target.value; updateCode(); };
    container.appendChild(r);
  });

  const addColBtn = document.createElement('button');
  addColBtn.className = 'btn btn-ghost'; addColBtn.style = 'width:100%;font-size:9px;margin-bottom:8px;';
  addColBtn.innerText = '+ Add Column';
  addColBtn.onclick = () => {
    const th = document.createElement('th'); th.innerText = 'Header'; th.style = 'padding:10px;border:1px solid #e5e7eb;text-align:left;';
    table.querySelector('thead tr').appendChild(th);
    table.querySelectorAll('tbody tr').forEach(row => {
      const td = document.createElement('td'); td.innerText = 'Cell'; td.style = 'padding:10px;border:1px solid #e5e7eb;';
      row.appendChild(td);
    });
    refreshTableEditor(table); updateCode();
  };
  container.appendChild(addColBtn);

  const addRowBtn = document.createElement('button');
  addRowBtn.className = 'btn btn-ghost'; addRowBtn.style = 'width:100%;font-size:9px;margin-bottom:8px;';
  addRowBtn.innerText = '+ Add Row';
  addRowBtn.onclick = () => {
    const tr = document.createElement('tr');
    heads.forEach(() => {
      const td = document.createElement('td'); td.innerText = 'Cell'; td.style = 'padding:10px;border:1px solid #e5e7eb;';
      tr.appendChild(td);
    });
    table.querySelector('tbody').appendChild(tr);
    refreshTableEditor(table); updateCode();
  };
  container.appendChild(addRowBtn);

  container.appendChild(createEditorLabel('Style'));
  const styleRow = document.createElement('div');
  styleRow.style = 'display:grid;grid-template-columns:1fr 1fr;gap:5px;';
  [['Striped', () => {
      table.querySelectorAll('tbody tr:nth-child(even)').forEach(r => r.style.background = '#f8fafc');
   }], ['Bordered', () => {
      table.style.border = '2px solid #e5e7eb';
   }]].forEach(([l, fn]) => {
    const b = document.createElement('button'); b.className = 'editor-btn'; b.innerText = l;
    b.onclick = () => { fn(); updateCode(); };
    styleRow.appendChild(b);
  });
  container.appendChild(styleRow);
}


/* ═══════════════════════════════════════════════════════
   PROGRESS EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshProgressEditor(el) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Progress Bar'));

  const valRow = document.createElement('div');
  valRow.style = 'margin-bottom:10px;';
  valRow.innerHTML = `
    <label style="font-size:9px;color:var(--text-muted);display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.06em;">Value: <span id="progVal">${el.value}</span>%</label>
    <input type="range" min="0" max="100" value="${el.value}" style="width:100%;">
  `;
  valRow.querySelector('input[type=range]').oninput = e => {
    el.value = e.target.value;
    const label = el.parentElement.querySelector('span');
    if (label) label.innerText = e.target.value + '%';
    valRow.querySelector('#progVal').innerText = e.target.value;
    updateCode();
  };
  container.appendChild(valRow);

  const maxRow = makeEditorRow('Max', el.max || '100', false);
  maxRow.querySelector('input').oninput = e => { el.max = e.target.value; updateCode(); };
  container.appendChild(maxRow);
}


/* ═══════════════════════════════════════════════════════
   METER EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshMeterEditor(el) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Meter'));

  const valRow = document.createElement('div');
  valRow.style = 'margin-bottom:10px;';
  valRow.innerHTML = `
    <label style="font-size:9px;color:var(--text-muted);display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.06em;">Value: <span id="meterVal">${el.value}</span></label>
    <input type="range" min="0" max="1" step="0.05" value="${el.value}" style="width:100%;">
  `;
  valRow.querySelector('input[type=range]').oninput = e => {
    el.value = e.target.value;
    valRow.querySelector('#meterVal').innerText = e.target.value;
    updateCode();
  };
  container.appendChild(valRow);
}


/* ═══════════════════════════════════════════════════════
   DETAILS / ACCORDION EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshDetailsEditor(el) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Accordion'));

  const summary = el.querySelector('summary');
  const body    = el.querySelector('p');

  if (summary) {
    const r = makeEditorRow('Title', summary.innerText, false);
    r.querySelector('input').oninput = e => { summary.innerText = e.target.value; updateCode(); };
    container.appendChild(r);
  }
  if (body) {
    const textarea = document.createElement('textarea');
    textarea.className = 'custom-css-area';
    textarea.style.color = 'var(--text)'; textarea.style.height = '70px';
    textarea.style.marginBottom = '8px';
    textarea.value = body.innerText;
    textarea.oninput = e => { body.innerText = e.target.value; updateCode(); };
    container.appendChild(createEditorLabel('Body'));
    container.appendChild(textarea);
  }

  const openRow = document.createElement('div');
  openRow.style = 'display:flex;align-items:center;gap:8px;';
  openRow.innerHTML = `<input type="checkbox" ${el.open ? 'checked' : ''} style="cursor:pointer;"><span style="font-size:11px;color:var(--text-muted);">Open by default</span>`;
  openRow.querySelector('input').onchange = e => { e.target.checked ? el.setAttribute('open','') : el.removeAttribute('open'); updateCode(); };
  container.appendChild(openRow);
}


/* ═══════════════════════════════════════════════════════
   DIVIDER EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshDividerEditor(el) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Divider'));

  container.appendChild(createEditorLabel('Style'));
  const styleRow = document.createElement('div');
  styleRow.style = 'display:grid;grid-template-columns:1fr 1fr 1fr;gap:5px;margin-bottom:8px;';
  [['Solid','solid'],['Dashed','dashed'],['Dotted','dotted']].forEach(([l,s]) => {
    const b = document.createElement('button'); b.className = 'editor-btn'; b.innerText = l;
    b.onclick = () => { el.style.borderTop = `1px ${s} currentColor`; updateCode(); };
    styleRow.appendChild(b);
  });
  container.appendChild(styleRow);

  container.appendChild(createEditorLabel('Color'));
  const colorRow = document.createElement('div');
  colorRow.style = 'display:flex;gap:5px;flex-wrap:wrap;';
  ['#e5e7eb','#6366f1','#f43f5e','#22c55e','#f59e0b','#0b0e14'].forEach(c => {
    const swatch = document.createElement('span');
    swatch.style = `width:20px;height:20px;border-radius:50%;background:${c};cursor:pointer;border:2px solid rgba(255,255,255,.15);`;
    swatch.onclick = () => { el.style.borderTopColor = c; el.style.color = c; updateCode(); };
    colorRow.appendChild(swatch);
  });
  container.appendChild(colorRow);

  container.appendChild(createEditorLabel('Thickness'));
  const thickRow = document.createElement('div');
  thickRow.style = 'display:grid;grid-template-columns:1fr 1fr 1fr;gap:5px;';
  [['Thin','1px'],['Medium','2px'],['Thick','4px']].forEach(([l,t]) => {
    const b = document.createElement('button'); b.className = 'editor-btn'; b.innerText = l;
    b.onclick = () => {
      const cur = el.style.borderTop || 'solid #e5e7eb';
      const parts = cur.split(' ');
      el.style.borderTop = `${t} ${parts[1] || 'solid'} ${parts[2] || '#e5e7eb'}`;
      updateCode();
    };
    thickRow.appendChild(b);
  });
  container.appendChild(thickRow);
}

/* Helper: create a styled section label in the editor panel */
function createEditorLabel(text) {
  const label   = document.createElement('label');
  label.style   = 'font-size:9px;color:var(--accent);font-weight:700;display:block;margin-bottom:8px;text-transform:uppercase;letter-spacing:.1em;';
  label.innerText = text;
  return label;
}

function makeEditorRow(badgeText, value, canDelete) {
  const row = document.createElement('div');
  row.style = 'display:flex;align-items:center;gap:8px;background:var(--surface3);padding:6px 8px;margin-bottom:5px;border-radius:3px;';
  row.innerHTML = `
    <span class="badge blue">${badgeText}</span>
    <input type="text" value="${value}"
      style="flex:1;background:transparent;border:none;color:var(--text);outline:none;font-size:12px;font-family:inherit;">
    ${canDelete ? '<span class="del-btn remove-btn" style="font-size:12px;">×</span>' : ''}
  `;
  return row;
}


/* ═══════════════════════════════════════════════════════
   CSS ENGINE
   ═══════════════════════════════════════════════════════ */

function applyCSS() {
  if (!selected) return;
  const pseudo = document.getElementById('pseudoSelector').value;
  const val    = cssInput.value.trim();

  if (pseudo === 'main') {
    selected.setAttribute('style', val);
  } else {
    const cls = findUID(selected) || Array.from(selected.classList).find(c => c.startsWith('section-')) || selected.tagName.toLowerCase();
    if (!pseudoStyles.has(cls)) pseudoStyles.set(cls, {});
    pseudoStyles.get(cls)[pseudo] = val;
    renderRuntimeStyles();
  }
  updateCode();
}

function renderRuntimeStyles() {
  let sheet = document.getElementById('runtime-hover-sheet');
  if (!sheet) {
    sheet    = document.createElement('style');
    sheet.id = 'runtime-hover-sheet';
    document.head.appendChild(sheet);
  }
  let css = '';
  pseudoStyles.forEach((states, selector) => {
    for (const state in states) {
      const imp = states[state].split(';').map(s => s.trim() ? s + ' !important' : '').filter(Boolean).join('; ');
      css += `.${selector}:${state} { ${imp} }\n`;
    }
  });
  sheet.innerHTML = css;
}

function loadCurrentCSS() {
  if (!selected) return;
  const pseudo = document.getElementById('pseudoSelector').value;
  const cls    = findUID(selected) || selected.tagName.toLowerCase();

  if (pseudo === 'main') {
    const s = selected.getAttribute('style') || '';
    cssInput.value = s.split(';').map(x => x.trim()).filter(x => x).join(';\n') + (s ? ';' : '');
  } else {
    cssInput.value = (pseudoStyles.get(cls) || {})[pseudo] || '';
  }
}


/* ═══════════════════════════════════════════════════════
   JS ENGINE
   ═══════════════════════════════════════════════════════ */

function applyJS() {
  if (!selected) return;
  const wrapper    = selected.closest('.widget-wrapper') || selected;
  const uid        = Array.from(wrapper.classList).find(c => c.startsWith('codeme-'));
  if (!uid) return;

  const codeValue  = document.getElementById('jsInput').value;
  const mode       = document.getElementById('jsModeSelector').value;
  const hint       = document.getElementById('jsHint');

  widgetScripts.set(uid, codeValue);
  widgetJSModes.set(uid, mode);

  if (mode === 'click') {
    hint.innerText = "Code runs when clicked. 'this' refers to the element.";
    selected.onclick = e => {
      e.stopPropagation();
      try { new Function(codeValue).call(selected); } catch (err) { console.error(err); }
    };
  } else {
    hint.innerText   = 'Raw script mode. Use for global functions or data.';
    selected.onclick = null;
  }
  updateCode();
}


/* ═══════════════════════════════════════════════════════
   CODE GENERATION (HTML prettifier)
   ═══════════════════════════════════════════════════════ */

function prettifyHTML(node, level = 0) {
  const indent = '  '.repeat(level);
  let html = '';

  node.childNodes.forEach(child => {
    if (child.nodeType === 1) {
      // Skip builder-only UI elements
      if (child.classList.contains('plus-btn') || child.classList.contains('widget-actions')) return;

      const tag   = child.tagName.toLowerCase();
      const attrs = Array.from(child.attributes)
        .filter(a => !['contenteditable', 'selected'].includes(a.name))
        .map(a => ` ${a.name}="${a.value}"`)
        .join('');

      const inner = prettifyHTML(child, level + 1);
      if (inner.trim()) {
        html += `${indent}<${tag}${attrs}>\n${inner}${indent}</${tag}>\n`;
      } else {
        html += `${indent}<${tag}${attrs}></${tag}>\n`;
      }
    } else if (child.nodeType === 3 && child.textContent.trim()) {
      html += `${indent}  ${child.textContent.trim()}\n`;
    }
  });

  return html;
}

function updateCode() {
  const hasCarousel = !!preview.querySelector('.pb-carousel');
  const hasForm     = !!preview.querySelector('.pb-reg-form');
  const hasNavbar   = !!preview.querySelector('.pb-navbar');

  htmlCode.value = prettifyHTML(preview, 1);

  /* --- Build CSS output --- */
  const bodyStyles = previewContent.getAttribute('style') || '';
  let finalCSS = '';

  // Body styles - only if user added any
  if (bodyStyles.trim()) {
    finalCSS += `/* Body */\nbody {\n  ${bodyStyles.split(';').map(s => s.trim()).filter(Boolean).join(';\n  ')};\n}\n\n`;
  }

  // Per-element inline styles - only what user added
  preview.querySelectorAll('*').forEach(el => {
    const styleAttr = el.getAttribute('style');
    if (!styleAttr || styleAttr.trim() === '' || el.classList.contains('widget-actions')) return;

    const cls = Array.from(el.classList).find(c =>
      c.startsWith('section-') || c.startsWith('container-') ||
      c.startsWith('column-')  || c.startsWith('codeme-')    || c.startsWith('pb-')
    );
    const sel   = cls ? '.' + cls : el.tagName.toLowerCase();
    const props = styleAttr.split(';').map(p => p.trim()).filter(Boolean).join(';\n  ');
    finalCSS   += `${sel} {\n  ${props};\n}\n\n`;
  });

  if (hasNavbar) {
    finalCSS += `
/* Navbar */
.pb-navbar         { display: flex; align-items: center; justify-content: space-between; padding: 0 32px; height: 64px; background: #0b0e14; position: relative; z-index: 1000; }
.pb-nav-text-logo  { font-weight: 700; font-size: 1.25rem; color: #6366f1; }
.pb-nav-list       { list-style: none; display: flex; align-items: center; gap: 4px; margin: 0; padding: 0; }
.pb-nav-list > li  { position: relative; padding: 8px 14px; font-size: 14px; color: #d1d5db; border-radius: 6px; cursor: pointer; transition: all .18s; }
.pb-nav-list > li:hover { color: white; background: rgba(255,255,255,.05); }
.pb-nav-cta        { background: #22c55e !important; color: white !important; border-radius: 20px !important; padding: 8px 18px !important; font-weight: 600; }

/* Dropdown */
.pb-dropdown       { display: none; position: absolute; top: calc(100% + 6px); left: 0; background: rgba(13,17,23,.97); min-width: 200px; padding: 6px; border-radius: 10px; border: 1px solid rgba(255,255,255,.08); list-style: none; box-shadow: 0 20px 40px rgba(0,0,0,.5); z-index: 9999; }
.pb-nav-list > li:hover > .pb-dropdown { display: block; }
.pb-dropdown li    { padding: 9px 14px; color: #9ca3af; font-size: 13px; border-radius: 6px; transition: all .15s; }
.pb-dropdown li:hover { background: rgba(99,102,241,.15); color: #a5b4fc; }

/* Mobile */
.pb-nav-toggle     { display: none; background: rgba(255,255,255,.06); border: 1px solid rgba(255,255,255,.1); color: white; padding: 8px 12px; border-radius: 6px; cursor: pointer; font-size: 18px; }
@keyframes fadeIn  { from { opacity:0; transform:translateY(8px); } to { opacity:1; transform:translateY(0); } }
@media (max-width: 768px) {
  .pb-nav-toggle   { display: block; }
  .pb-nav-list     { display: none; position: fixed; top:0; right:-100%; width:280px; height:100vh; background:#0b0e14; flex-direction:column; padding:80px 30px 40px; transition:.35s cubic-bezier(.4,0,.2,1); box-shadow:-10px 0 40px rgba(0,0,0,.6); z-index:9999; }
  .pb-nav-list.active { display: flex; right: 0; }
}
`;
  }

  if (hasCarousel) {
    finalCSS += `
/* Carousel */
.pb-carousel  { position: relative; width: 100%; overflow: hidden; min-height: 240px; background: #1a1a2e; }
.pb-slides img { width: 100%; display: none; object-fit: cover; }
.pb-slides img.active { display: block; animation: slideIn .4s ease; }
@keyframes slideIn { from { opacity:0; transform:scale(1.02); } to { opacity:1; transform:scale(1); } }
.pb-prev, .pb-next { position:absolute; top:50%; transform:translateY(-50%); background:rgba(0,0,0,.5); border:1px solid rgba(255,255,255,.1); color:white; width:40px; height:40px; border-radius:50%; display:flex; align-items:center; justify-content:center; cursor:pointer; z-index:10; font-size:16px; transition:all .2s; margin:0 10px; }
.pb-next { right:0; }
.pb-prev:hover, .pb-next:hover { background:#6366f1; border-color:#6366f1; }
`;
  }

  if (hasForm) {
    finalCSS += `
/* Registration Form */
.pb-reg-form         { display:flex; flex-direction:column; gap:12px; padding:28px; border:1px solid #e5e7eb; border-radius:12px; max-width:360px; background:#fff; box-shadow:0 4px 24px rgba(0,0,0,.06); }
.pb-reg-form h3      { margin:0 0 4px; font-size:1.2rem; color:#111; }
.pb-reg-form input   { padding:11px 14px; border:1px solid #d1d5db; border-radius:6px; font-size:14px; outline:none; width:100%; box-sizing:border-box; }
.pb-reg-form input:focus { border-color:#6366f1; }
.pb-reg-form button  { padding:12px; background:#6366f1; color:white; border:none; border-radius:8px; cursor:pointer; font-weight:600; font-size:14px; }
.pb-reg-form button:hover { background:#4f46e5; }
`;
  }

  // Pseudo/hover states
  if (pseudoStyles.size > 0) {
    finalCSS += '\n/* State Styles */\n';
    pseudoStyles.forEach((states, selector) => {
      for (const state in states) {
        const props = states[state].split(';').map(s => s.trim()).filter(Boolean).join(';\n  ');
        finalCSS += `.${selector}:${state} {\n  ${props};\n}\n\n`;
      }
    });
  }

  cssCode.value = finalCSS.trim();

  /* --- Build JS output --- */
  let finalJS = '';

  if (hasCarousel) {
    finalJS += `// Carousel controls
function pbMoveSlide(btn, dir) {
  var carousel = btn.closest('.pb-carousel');
  var slides   = carousel.querySelectorAll('.pb-slides img');
  if (slides.length <= 1) return;
  var idx = Array.from(slides).findIndex(function(i){ return i.classList.contains('active'); });
  slides[idx].classList.remove('active');
  idx = (idx + dir + slides.length) % slides.length;
  slides[idx].classList.add('active');
}\n\n`;
  }

  if (hasNavbar) {
    finalJS += `// Mobile menu (drawer-based)
function pbToggleMobile(btn) {
  var drawer  = document.getElementById('pb-drawer');
  var overlay = document.querySelector('.pb-drawer-overlay');
  if (!drawer) return;
  var isOpen = drawer.classList.toggle('open');
  btn.textContent = isOpen ? '\u2715' : '\u2630';
  if (overlay) overlay.classList.toggle('open', isOpen);
}
function pbCloseMobile() {
  var drawer  = document.getElementById('pb-drawer');
  var overlay = document.querySelector('.pb-drawer-overlay');
  if (drawer)  drawer.classList.remove('open');
  if (overlay) overlay.classList.remove('open');
  document.querySelectorAll('.pb-nav-toggle').forEach(function(b){ b.textContent = '\u2630'; });
}
function pbToggleSubMenu(li) {
  var sub = li.querySelector('.pb-mobile-dropdown');
  if (sub) sub.classList.toggle('open');
}
document.addEventListener('keydown', function(e){ if(e.key==='Escape') pbCloseMobile(); });\n\n`;
  }

  widgetScripts.forEach((code, uid) => {
    const mode = widgetJSModes.get(uid) || 'click';
    if (mode === 'click') {
      finalJS += `// Widget: ${uid}\ndocument.querySelector('.${uid}').addEventListener('click', function() {\n  ${code}\n});\n\n`;
    } else {
      finalJS += `// Raw: ${uid}\n${code}\n\n`;
    }
  });

  jsCode.value = finalJS.trim();
}


/* ═══════════════════════════════════════════════════════
   FACEBOOK FOLLOW MODAL — blocks app, detects tab return
   ═══════════════════════════════════════════════════════ */

// ── CONFIG: set your Facebook page URL here ──────────────
const FB_PAGE_URL = 'https://www.facebook.com/share/1JR8DCb9Hm/';   // ← your Facebook page
// ─────────────────────────────────────────────────────────

let fbPageURL       = FB_PAGE_URL;
let fbTabOpened     = false;
let fbVisibilityFn  = null;

function fbInit() {
  // ── If user already followed before, skip the modal immediately ──
  if (localStorage.getItem('fb_followed') === '1') {
    const modal = document.getElementById('fbFollowModal');
    if (modal) modal.style.display = 'none';
    return;
  }

  // ── On mobile: show a friendly notice instead of the full modal ──
  const isMobile = window.innerWidth < 768 || ('ontouchstart' in window && window.innerWidth < 1024);
  if (isMobile) {
    const desktopCard = document.getElementById('fb-desktop-card');
    const mobileNote  = document.getElementById('fb-mobile-notice');
    if (desktopCard) desktopCard.style.display = 'none';
    if (mobileNote)  mobileNote.style.display  = 'block';
    return;
  }

  // Update the page name / handle display from URL
  const nameEl   = document.getElementById('fb-page-name');
  const handleEl = document.getElementById('fb-page-handle');
  if (fbPageURL && fbPageURL !== 'https://www.facebook.com/') {
    const parts  = fbPageURL.replace(/\/$/, '').split('/');
    const handle = parts[parts.length - 1] || '';
    if (nameEl)   nameEl.innerText   = handle ? handle.charAt(0).toUpperCase() + handle.slice(1) : 'My Page';
    if (handleEl) handleEl.innerText = 'facebook.com/' + (handle || '');
  }
}

function fbOpenPage() {
  // Open the Facebook page in a new tab
  window.open(fbPageURL || 'https://www.facebook.com/', '_blank');
  fbTabOpened = true;

  // Update the step message
  const msg = document.getElementById('fb-step-msg');
  if (msg) msg.innerHTML = '🔵 Facebook opened in a new tab.<br>Follow the page, then return here.';

  // Change button to a "waiting" state
  const btn = document.getElementById('fb-main-btn');
  if (btn) {
    btn.innerHTML = `<span style="display:inline-block;width:16px;height:16px;border:2px solid rgba(255,255,255,.4);border-top-color:white;border-radius:50%;animation:fbSpin 0.8s linear infinite;margin-right:8px;"></span> Waiting for you to follow…`;
    btn.style.background = 'rgba(24,119,242,0.5)';
    btn.style.cursor     = 'default';
    btn.onclick          = null;
  }

  // Show the "already followed" fallback button
  const alreadyRow = document.getElementById('fb-already-row');
  if (alreadyRow) alreadyRow.style.display = 'block';

  // Listen for the user returning to this tab (visibilitychange)
  if (fbVisibilityFn) document.removeEventListener('visibilitychange', fbVisibilityFn);
  fbVisibilityFn = function() {
    if (document.visibilityState === 'visible' && fbTabOpened) {
      // Small delay so it feels natural
      setTimeout(fbConfirmFollowed, 600);
      document.removeEventListener('visibilitychange', fbVisibilityFn);
    }
  };
  document.addEventListener('visibilitychange', fbVisibilityFn);
}

function fbConfirmFollowed() {
  const modal = document.getElementById('fbFollowModal');
  if (!modal) return;

  // Remember that this user has followed — won't see modal again
  try { localStorage.setItem('fb_followed', '1'); } catch(e) {}

  // Green success flash before dismiss
  const card = modal.querySelector('div[style*="max-width:400px"]') || modal.firstElementChild;
  if (card) {
    card.style.transition = 'transform .2s, opacity .35s';
    card.style.transform  = 'scale(1.03)';
    setTimeout(() => {
      card.style.transform = 'scale(1)';
      card.style.opacity   = '0';
    }, 180);
  }

  modal.style.transition = 'opacity .4s';
  modal.style.opacity    = '0';
  setTimeout(() => {
    modal.style.display = 'none';
    // Remove visibility listener in case it's still there
    if (fbVisibilityFn) document.removeEventListener('visibilitychange', fbVisibilityFn);
  }, 420);
}

// Inject the spinner keyframe into the page
(function() {
  const s = document.createElement('style');
  s.textContent = '@keyframes fbSpin { to { transform: rotate(360deg); } }';
  document.head.appendChild(s);
})();

// Kept for backward-compat (old calls in HTML attributes)
function updateFBPreview(val) { fbPageURL = val || FB_PAGE_URL; fbInit(); }
function openFBAndClose()     { fbOpenPage(); }
function dismissFBModal()     { fbConfirmFollowed(); }

// Show FB modal immediately on load (blocks app)
window.addEventListener('DOMContentLoaded', () => {
  fbInit();
  const modal = document.getElementById('fbFollowModal');
  if (modal) {
    modal.style.opacity    = '0';
    modal.style.transition = 'opacity .4s';
    requestAnimationFrame(() => requestAnimationFrame(() => { modal.style.opacity = '1'; }));
  }

  // Load FolioOne default in background while modal is showing
  loadFolioOneDefault();

  // ── Check FolioOne edit permission ──────────────────────────────────────
  (async function checkFolioPermission() {
    try {
      const res  = await fetch('menu_builder_api.php?action=check_folio_permission');
      const data = await res.json();
      if (!data.ok || !data.folio_edit_allowed) {
        // Lock direct editing of FolioOne elements in the import preview
        const style       = document.createElement('style');
        style.textContent = '#import-preview-frame { pointer-events: none; opacity: 0.85; }';
        document.head.appendChild(style);
        // Show a notice in the file tree
        const notice       = document.createElement('div');
        notice.style.cssText = 'font-size:10px;color:#ff8c42;padding:8px 10px;border:1px solid rgba(255,140,66,.2);border-radius:6px;margin:6px;line-height:1.5;';
        notice.textContent   = '🔒 FolioOne editing is locked. Submit your work for admin approval to unlock customisation.';
        const fileTree = document.getElementById('fileTree');
        if (fileTree) fileTree.prepend(notice);
      }
    } catch (e) { /* silent fail — don't block the builder */ }
  })();
});


/* ═══════════════════════════════════════════════════════
   FOLIO ONE DEFAULT PREVIEW
   Loads the FolioOne Bootstrap template as the
   default starting point in live preview
   ═══════════════════════════════════════════════════════ */

function loadFolioOneDefault() {
  const folioHTML = getFolioOneHTML();
  syncImportToPreview(folioHTML);
  htmlCode.value = '<!-- FolioOne Bootstrap Template loaded. Use Export to download. -->';
  cssCode.value  = '/* FolioOne styles loaded via CDN */';
  jsCode.value   = '/* FolioOne scripts loaded via CDN */';

  // Add to project files
  projectFiles['index.html'] = { raw: folioHTML, selfContained: folioHTML };

  // Update file tree
  const fileTree = document.getElementById('fileTree');
  fileTree.innerHTML = '';
  const item = document.createElement('div');
  item.className = 'tree-item';
  item.style.color = 'var(--accent)';
  item.innerHTML = '<span style="color:#e34c26;font-size:9px;font-weight:700;margin-right:4px;">HTML</span> index.html ⭐';
  item.onclick = () => loadFileToEditor('index.html');
  fileTree.appendChild(item);
  document.getElementById('fileList').style.display = 'block';

  // Show the FolioOne editor button
  const feb = document.getElementById('folioEditorBtn');
  if (feb) feb.style.display = 'flex';
}

function getFolioOneHTML() {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>FolioOne — My Portfolio</title>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
</head>
<body>

  <!-- NAVBAR -->
  <nav class="folio-navbar" id="folio-nav-component">
    <a href="#" class="folio-nav-logo" contenteditable="true">FolioOne</a>

    <!-- Desktop nav links (inline) -->
    <ul class="folio-nav-list" id="folio-main-nav">
      <li><a href="#folio-hero" class="active" onclick="folioCloseNav()">Home</a></li>
      <li><a href="#folio-about" onclick="folioCloseNav()">About</a></li>
      <li><a href="#folio-services" onclick="folioCloseNav()">Services</a></li>
      <li><a href="#folio-portfolio" onclick="folioCloseNav()">Portfolio</a></li>
      <li><a href="#folio-contact" onclick="folioCloseNav()">Contact</a></li>
      <li class="folio-nav-cta"><a href="#folio-contact" onclick="folioCloseNav()">Get Started</a></li>
      <!-- Mobile-only socials row inside drawer -->
      <li class="folio-drawer-socials-li" style="padding:0;border:none;">
        <div class="folio-nav-socials-row">
          <a class="folio-nav-social" href="https://www.facebook.com/share/1JR8DCb9Hm/" target="_blank" onmouseover="this.style.color='#1877f2';this.style.background='rgba(24,119,242,.12)'" onmouseout="this.style.color='#9ca3af';this.style.background='transparent'"><i class="bi bi-facebook"></i></a>
          <a class="folio-nav-social" href="#" onmouseover="this.style.color='#e1306c';this.style.background='rgba(225,48,108,.12)'" onmouseout="this.style.color='#9ca3af';this.style.background='transparent'"><i class="bi bi-instagram"></i></a>
          <a class="folio-nav-social" href="#" onmouseover="this.style.color='#0077b5';this.style.background='rgba(0,119,181,.12)'" onmouseout="this.style.color='#9ca3af';this.style.background='transparent'"><i class="bi bi-linkedin"></i></a>
          <a class="folio-nav-social" href="#" onmouseover="this.style.color='white';this.style.background='rgba(255,255,255,.1)'" onmouseout="this.style.color='#9ca3af';this.style.background='transparent'"><i class="bi bi-github"></i></a>
        </div>
      </li>
    </ul>

    <!-- Desktop social icons (outside the drawer list) -->
    <div class="folio-desktop-socials">
      <a class="folio-nav-social" href="https://www.facebook.com/share/1JR8DCb9Hm/" target="_blank" onmouseover="this.style.color='#1877f2';this.style.background='rgba(24,119,242,.12)'" onmouseout="this.style.color='#9ca3af';this.style.background='transparent'"><i class="bi bi-facebook"></i></a>
      <a class="folio-nav-social" href="#" onmouseover="this.style.color='#e1306c';this.style.background='rgba(225,48,108,.12)'" onmouseout="this.style.color='#9ca3af';this.style.background='transparent'"><i class="bi bi-instagram"></i></a>
      <a class="folio-nav-social" href="#" onmouseover="this.style.color='#0077b5';this.style.background='rgba(0,119,181,.12)'" onmouseout="this.style.color='#9ca3af';this.style.background='transparent'"><i class="bi bi-linkedin"></i></a>
      <a class="folio-nav-social" href="#" onmouseover="this.style.color='white';this.style.background='rgba(255,255,255,.1)'" onmouseout="this.style.color='#9ca3af';this.style.background='transparent'"><i class="bi bi-github"></i></a>
    </div>

    <!-- Hamburger (mobile only — hidden on desktop via CSS) -->
    <button class="folio-hamburger" id="folio-hamburger-btn" onclick="folioToggleNav(this)">☰</button>

    <div id="folio-nav-overlay" onclick="folioCloseNav()"></div>
  </nav>

  <!-- HERO SECTION -->
  <section id="folio-hero">
    <div class="container-xxl">
      <div class="row align-items-center gy-5">
        <div class="col-lg-6 order-lg-1 order-2">
          <h1>Hello, I'm <span contenteditable="true">CodeMe</span></h1>
          <p class="lead mb-4" contenteditable="true">Creative UI/UX Designer &amp; Web Developer building amazing digital experiences with passion and modern tools.</p>
          <div class="d-flex gap-3 flex-wrap mb-4">
            <a href="#folio-portfolio" class="btn-folio-primary">View My Work</a>
            <a href="#folio-contact" class="btn-folio-outline">Get In Touch</a>
          </div>
          <div class="d-flex gap-3">
            <a href="https://www.facebook.com/share/1JR8DCb9Hm/" target="_blank" style="color:#6b7280;font-size:20px;transition:color .15s;" onmouseover="this.style.color='#1877f2'" onmouseout="this.style.color='#6b7280'"><i class="bi bi-facebook"></i></a>
            <a href="#" style="color:#6b7280;font-size:20px;transition:color .15s;" onmouseover="this.style.color='#e1306c'" onmouseout="this.style.color='#6b7280'"><i class="bi bi-instagram"></i></a>
            <a href="#" style="color:#6b7280;font-size:20px;transition:color .15s;" onmouseover="this.style.color='#0077b5'" onmouseout="this.style.color='#6b7280'"><i class="bi bi-linkedin"></i></a>
            <a href="#" style="color:#6b7280;font-size:20px;transition:color .15s;" onmouseover="this.style.color='#111'" onmouseout="this.style.color='#6b7280'"><i class="bi bi-github"></i></a>
          </div>
        </div>
        <div class="col-lg-6 order-lg-2 order-1 text-center">
          <div class="hero-img-wrap mx-auto" id="folio-hero-img-wrap">
            <img src="" alt="" id="folio-hero-img">
            <span>👤</span>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- SERVICES SECTION -->
  <section id="folio-services">
    <div class="container-xxl">
      <div class="text-center">
        <h2 class="section-title" contenteditable="true">My Services</h2>
        <p class="section-sub text-center" contenteditable="true">Professional services tailored to bring your vision to life</p>
      </div>
      <div class="row g-4">
        <div class="col-lg-4 col-md-6">
          <div class="service-card">
            <div class="service-icon">🎨</div>
            <h5 class="fw-bold mb-2" contenteditable="true">UI/UX Design</h5>
            <p class="text-muted" contenteditable="true">Creating beautiful, intuitive interfaces that users love to interact with.</p>
          </div>
        </div>
        <div class="col-lg-4 col-md-6">
          <div class="service-card">
            <div class="service-icon">💻</div>
            <h5 class="fw-bold mb-2" contenteditable="true">Web Development</h5>
            <p class="text-muted" contenteditable="true">Building fast, responsive websites using modern technologies and best practices.</p>
          </div>
        </div>
        <div class="col-lg-4 col-md-6">
          <div class="service-card">
            <div class="service-icon">📱</div>
            <h5 class="fw-bold mb-2" contenteditable="true">Mobile Development</h5>
            <p class="text-muted" contenteditable="true">Creating cross-platform mobile applications for iOS and Android.</p>
          </div>
        </div>
        <div class="col-lg-4 col-md-6">
          <div class="service-card">
            <div class="service-icon">🚀</div>
            <h5 class="fw-bold mb-2" contenteditable="true">SEO Optimization</h5>
            <p class="text-muted" contenteditable="true">Boosting your online visibility with proven SEO strategies and techniques.</p>
          </div>
        </div>
        <div class="col-lg-4 col-md-6">
          <div class="service-card">
            <div class="service-icon">🎯</div>
            <h5 class="fw-bold mb-2" contenteditable="true">Digital Marketing</h5>
            <p class="text-muted" contenteditable="true">Reaching your target audience through effective digital marketing campaigns.</p>
          </div>
        </div>
        <div class="col-lg-4 col-md-6">
          <div class="service-card">
            <div class="service-icon">☁️</div>
            <h5 class="fw-bold mb-2" contenteditable="true">Cloud Solutions</h5>
            <p class="text-muted" contenteditable="true">Scalable cloud infrastructure and deployment solutions for your business.</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- PORTFOLIO SECTION -->
  <section id="folio-portfolio">
    <div class="container-xxl">
      <div class="text-center mb-5">
        <h2 class="fw-bold" style="font-size:2rem;color:#111;" contenteditable="true">My Portfolio</h2>
        <p class="text-muted" contenteditable="true">A selection of my recent work and projects</p>
      </div>
      <div class="row g-4">
        <div class="col-lg-4 col-md-6"><div class="portfolio-card" style="background:linear-gradient(135deg,#6366f1,#8b5cf6);">Project 1</div></div>
        <div class="col-lg-4 col-md-6"><div class="portfolio-card" style="background:linear-gradient(135deg,#0ea5e9,#6366f1);">Project 2</div></div>
        <div class="col-lg-4 col-md-6"><div class="portfolio-card" style="background:linear-gradient(135deg,#22c55e,#0ea5e9);">Project 3</div></div>
        <div class="col-lg-4 col-md-6"><div class="portfolio-card" style="background:linear-gradient(135deg,#f59e0b,#ef4444);">Project 4</div></div>
        <div class="col-lg-4 col-md-6"><div class="portfolio-card" style="background:linear-gradient(135deg,#ec4899,#8b5cf6);">Project 5</div></div>
        <div class="col-lg-4 col-md-6"><div class="portfolio-card" style="background:linear-gradient(135deg,#0b0e14,#6366f1);">Project 6</div></div>
      </div>
    </div>
  </section>

  <!-- ABOUT SECTION -->
  <section id="folio-about">
    <div class="container-xxl">
      <div class="row align-items-center gy-5">
        <div class="col-lg-5">
          <div class="about-img" id="folio-about-img">
            <img src="" alt="" id="folio-about-photo">
            <span>🧑‍💻</span>
          </div>
        </div>
        <div class="col-lg-7 ps-lg-5">
          <h2 class="fw-bold mb-3" style="font-size:2rem;" contenteditable="true">About Me</h2>
          <p class="text-muted mb-4" contenteditable="true">I'm a passionate creative professional with 5+ years of experience in design and development. I love building beautiful, functional products that make people's lives easier.</p>
          <div class="row g-3 mb-4">
            <div class="col-6"><div style="background:#f8fafc;border-radius:10px;padding:16px;text-align:center;"><div style="font-size:1.8rem;font-weight:700;color:var(--accent);" contenteditable="true">50+</div><div style="font-size:13px;color:#6b7280;" contenteditable="true">Projects Done</div></div></div>
            <div class="col-6"><div style="background:#f8fafc;border-radius:10px;padding:16px;text-align:center;"><div style="font-size:1.8rem;font-weight:700;color:var(--accent);" contenteditable="true">30+</div><div style="font-size:13px;color:#6b7280;" contenteditable="true">Happy Clients</div></div></div>
          </div>
          <div class="mb-2 d-flex justify-content-between"><span class="fw-semibold" style="font-size:13px;" contenteditable="true">Web Design</span><span style="font-size:13px;color:#6b7280;">90%</span></div>
          <div class="skill-bar mb-3"><div class="skill-bar-fill" style="width:90%;"></div></div>
          <div class="mb-2 d-flex justify-content-between"><span class="fw-semibold" style="font-size:13px;" contenteditable="true">Development</span><span style="font-size:13px;color:#6b7280;">85%</span></div>
          <div class="skill-bar mb-3"><div class="skill-bar-fill" style="width:85%;"></div></div>
          <div class="mb-2 d-flex justify-content-between"><span class="fw-semibold" style="font-size:13px;" contenteditable="true">SEO & Marketing</span><span style="font-size:13px;color:#6b7280;">70%</span></div>
          <div class="skill-bar"><div class="skill-bar-fill" style="width:70%;"></div></div>
        </div>
      </div>
    </div>
  </section>

  <!-- CONTACT SECTION -->
  <section id="folio-contact" style="padding:80px 40px;background:#f8fafc;">
    <div class="container-xxl">
      <div class="row justify-content-center">
        <div class="col-lg-6 text-center">
          <h2 class="fw-bold mb-2" style="font-size:2rem;" contenteditable="true">Get In Touch</h2>
          <p class="text-muted mb-5" contenteditable="true">Have a project in mind? Let's work together!</p>
          <div style="background:white;border-radius:16px;padding:36px;box-shadow:0 4px 24px rgba(0,0,0,.08);text-align:left;">
            <div class="mb-3">
              <input type="text" placeholder="Your Name" style="width:100%;padding:12px 16px;border:1px solid #e5e7eb;border-radius:8px;font-size:14px;outline:none;box-sizing:border-box;">
            </div>
            <div class="mb-3">
              <input type="email" placeholder="Your Email" style="width:100%;padding:12px 16px;border:1px solid #e5e7eb;border-radius:8px;font-size:14px;outline:none;box-sizing:border-box;">
            </div>
            <div class="mb-3">
              <textarea placeholder="Your Message" rows="4" style="width:100%;padding:12px 16px;border:1px solid #e5e7eb;border-radius:8px;font-size:14px;outline:none;box-sizing:border-box;resize:vertical;"></textarea>
            </div>
            <button style="width:100%;padding:14px;background:var(--accent);color:white;border:none;border-radius:8px;font-size:15px;font-weight:600;cursor:pointer;" onmouseover="this.style.background='#4f46e5'" onmouseout="this.style.background='var(--accent)'">Send Message</button>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- FOOTER -->
  <footer id="folio-footer">
    <div class="container-xxl">
      <div class="row g-5 mb-4">
        <div class="col-lg-4 footer-brand">
          <h3 contenteditable="true">FolioOne</h3>
          <p contenteditable="true">Building amazing digital experiences with modern tools and passionate teams.</p>
          <div class="social-links mt-3">
            <a href="https://www.facebook.com/share/1JR8DCb9Hm/" target="_blank"><i class="bi bi-facebook"></i></a>
            <a href="#"><i class="bi bi-instagram"></i></a>
            <a href="#"><i class="bi bi-twitter-x"></i></a>
            <a href="#"><i class="bi bi-linkedin"></i></a>
          </div>
        </div>
        <div class="col-lg-2 col-6">
          <h5>Company</h5>
          <ul>
            <li><a href="#">Home</a></li>
            <li><a href="#">About Us</a></li>
            <li><a href="#">Services</a></li>
            <li><a href="#">Contact</a></li>
          </ul>
        </div>
        <div class="col-lg-2 col-6">
          <h5>Services</h5>
          <ul>
            <li><a href="#">Web Design</a></li>
            <li><a href="#">Development</a></li>
            <li><a href="#">Marketing</a></li>
            <li><a href="#">SEO</a></li>
          </ul>
        </div>
        <div class="col-lg-4">
          <h5>Newsletter</h5>
          <p style="font-size:13px;line-height:1.7;" contenteditable="true">Subscribe to get the latest updates and news.</p>
          <div style="display:flex;gap:8px;margin-top:12px;">
            <input type="email" placeholder="Your email" style="flex:1;padding:10px 14px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:6px;color:white;font-size:13px;outline:none;">
            <button style="padding:10px 18px;background:var(--accent);color:white;border:none;border-radius:6px;cursor:pointer;font-weight:600;font-size:13px;">Subscribe</button>
          </div>
        </div>
      </div>
      <div class="footer-bottom d-flex justify-content-between align-items-center flex-wrap gap-2">
        <span contenteditable="true">© 2025 FolioOne. All Rights Reserved.</span>
        <div class="social-links">
          <a href="#"><i class="bi bi-twitter-x"></i></a>
          <a href="#"><i class="bi bi-linkedin"></i></a>
          <a href="#"><i class="bi bi-github"></i></a>
        </div>
      </div>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"><\/script>
  <script>
    function folioToggleNav(btn) {
      var nav     = document.getElementById('folio-main-nav');
      var overlay = document.getElementById('folio-nav-overlay');
      var isOpen  = nav.classList.toggle('open');
      btn.textContent = isOpen ? '✕' : '☰';
      btn.style.background = isOpen ? 'rgba(239,68,68,.15)' : 'rgba(255,255,255,.06)';
      btn.style.borderColor = isOpen ? 'rgba(239,68,68,.3)' : 'rgba(255,255,255,.1)';
      if (overlay) overlay.style.display = isOpen ? 'block' : 'none';
    }
    function folioCloseNav() {
      var nav     = document.getElementById('folio-main-nav');
      var btn     = document.getElementById('folio-hamburger-btn');
      var overlay = document.getElementById('folio-nav-overlay');
      if (nav)     nav.classList.remove('open');
      if (btn)     { btn.textContent = '☰'; btn.style.background = 'rgba(255,255,255,.06)'; btn.style.borderColor = 'rgba(255,255,255,.1)'; }
      if (overlay) overlay.style.display = 'none';
    }
    // Close drawer with Escape key
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape') folioCloseNav();
    });
  <\/script>
</html>`;
}


/* ═══════════════════════════════════════════════════════
   HERO BANNER EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshHeroEditor(hero) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Hero Banner'));

  const h1    = hero.querySelector('h1');
  const para  = hero.querySelector('p');
  const img   = hero.querySelector('.pb-hero-img');
  const ph    = hero.querySelector('.pb-hero-placeholder');

  if (h1) {
    const r = makeEditorRow('Headline', h1.innerText, false);
    r.querySelector('input').oninput = e => { h1.innerHTML = e.target.value; updateCode(); };
    container.appendChild(r);
  }
  if (para) {
    const r = makeEditorRow('Subtitle', para.innerText, false);
    r.querySelector('input').oninput = e => { para.innerText = e.target.value; updateCode(); };
    container.appendChild(r);
  }

  if (img) {
    container.appendChild(createEditorLabel('Profile Photo'));
    const uploadRow = document.createElement('div');
    uploadRow.innerHTML = `<button class="btn btn-primary" style="width:100%;font-size:10px;margin-bottom:4px;">Upload Photo</button><input type="file" accept="image/*" style="display:none;">`;
    uploadRow.querySelector('button').onclick = () => uploadRow.querySelector('input[type=file]').click();
    uploadRow.querySelector('input[type=file]').onchange = e => {
      const r = new FileReader();
      r.onload = ev => {
        img.src = ev.target.result;
        img.style.display = 'block';
        if (ph) ph.style.display = 'none';
        updateCode();
      };
      if (e.target.files[0]) r.readAsDataURL(e.target.files[0]);
    };
    container.appendChild(uploadRow);
  }

  container.appendChild(createEditorLabel('Background'));
  const bgRow = document.createElement('div');
  bgRow.style = 'display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-bottom:8px;';
  [['Light Gray','linear-gradient(135deg,#f8f9fa 0%,#e9ecef 100%)'],['White','#ffffff'],['Dark','#0b0e14'],['Purple','linear-gradient(135deg,#6366f1,#8b5cf6)'],['Blue','linear-gradient(135deg,#0ea5e9,#6366f1)'],['Custom','']].forEach(([label, bg]) => {
    const b = document.createElement('button');
    b.className = 'editor-btn'; b.innerText = label;
    if (bg) b.onclick = () => { hero.style.background = bg; updateCode(); };
    else b.onclick = () => {
      const c = prompt('Enter CSS background (color, gradient, etc):', hero.style.background);
      if (c) { hero.style.background = c; updateCode(); }
    };
    bgRow.appendChild(b);
  });
  container.appendChild(bgRow);
}


