// ── Max players stepper ──
let mpVal = 4;
function updateMp() {
  document.getElementById('mpDisplay').textContent = mpVal;
  document.getElementById('mpValue').value = mpVal;
}
document.getElementById('mpMinus').onclick = () => { if (mpVal > 2) { mpVal--; updateMp(); } };
document.getElementById('mpPlus').onclick  = () => { if (mpVal < 8) { mpVal++; updateMp(); } };

// ── Challenge picker ──
document.querySelectorAll('#lchList .lch-item').forEach(item => {
  item.addEventListener('click', () => {
    document.querySelectorAll('#lchList .lch-item').forEach(i => i.classList.remove('selected'));
    item.classList.add('selected');
    document.getElementById('lchallengeId').value = item.dataset.id;
    item.querySelector('input[type=radio]').checked = true;
  });
});

// ── Room search ──
document.getElementById('roomSearch')?.addEventListener('input', e => {
  const q = e.target.value.toLowerCase().trim();
  document.querySelectorAll('#roomsList .rcard').forEach(card => {
    card.style.display = card.dataset.search.includes(q) ? '' : 'none';
  });
});
