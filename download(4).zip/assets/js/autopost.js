// Set minimum datetime-local to now + 1 min
(function(){
  const inp=document.getElementById('schedAt');
  const now=new Date(Date.now()+60000);
  inp.min=now.toISOString().slice(0,16);
  inp.value='';
})();

function openScheduleModal(){ document.getElementById('scheduleModal').classList.add('open'); }
function closeScheduleModal(){ document.getElementById('scheduleModal').classList.remove('open'); }
document.getElementById('scheduleModal').addEventListener('click',function(e){if(e.target===this)closeScheduleModal();});

let schedActiveTab='html';
function schedSwitchTab(tab,btn){
  ['html','css','js'].forEach(t=>{document.getElementById('sched-'+t).style.display=t===tab?'block':'none';});
  document.querySelectorAll('#scheduleModal .tab-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  schedActiveTab=tab;
}

async function submitScheduled(){
  const title=document.getElementById('schedTitle').value.trim();
  const schedAt=document.getElementById('schedAt').value;
  if(!title){showToast('Please enter a title');return;}
  if(!schedAt){showToast('Please pick a publish time');return;}
  if(new Date(schedAt)<=new Date()){showToast('Time must be in the future');return;}
  const fd=new FormData();
  fd.append('action','schedule_post');
  fd.append('title',title);
  fd.append('description',document.getElementById('schedDesc').value.trim());
  fd.append('scheduled_at',schedAt);
  fd.append('html_code',document.getElementById('sched-html').value);
  fd.append('css_code',document.getElementById('sched-css').value);
  fd.append('js_code',document.getElementById('sched-js').value);
  if(document.getElementById('schedVersus').checked) fd.append('allow_versus','1');
  const res=await fetch('autopost.php',{method:'POST',body:fd});
  const data=await res.json();
  if(data.ok){
    showToast('Scheduled! ✦');
    setTimeout(()=>window.location.reload(),900);
  } else {
    showToast(data.msg||'Error');
  }
}

async function cancelScheduled(id, btn){
  if(!confirm('Cancel this scheduled post?'))return;
  btn.disabled=true;btn.textContent='Cancelling…';
  const fd=new FormData();
  fd.append('action','cancel_scheduled');
  fd.append('id',id);
  const res=await fetch('autopost.php',{method:'POST',body:fd});
  const data=await res.json();
  if(data.ok){
    showToast('Cancelled');
    const row=btn.closest('tr');
    if(row) row.style.opacity='0.3';
    setTimeout(()=>window.location.reload(),700);
  } else {
    btn.disabled=false;btn.textContent='Cancel';
    showToast(data.msg||'Error');
  }
}

// Countdown timers
function updateCountdowns(){
  document.querySelectorAll('[id^="cd-"],[id^="cvs-cd-"]').forEach(el=>{
    const ts=parseInt(el.dataset.ts,10)*1000;
    const diff=ts-Date.now();
    if(diff<=0){el.textContent='Publishing soon…';return;}
    const h=Math.floor(diff/3600000);
    const m=Math.floor((diff%3600000)/60000);
    const s=Math.floor((diff%60000)/1000);
    el.textContent=`in ${h?h+'h ':''} ${m?m+'m ':''} ${s}s`;
  });
}
updateCountdowns();
setInterval(updateCountdowns,1000);
