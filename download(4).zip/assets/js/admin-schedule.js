// ── Sidebar toggle ────────────────────────────────────────────────────────────
(function(){
  var btn = document.querySelector('.hamburger');
  var sidebar = document.querySelector('.sidebar');
  var overlay = document.querySelector('.sidebar-overlay');
  if (!btn) return;
  function open(){ sidebar.classList.add('open'); overlay.classList.add('visible'); document.body.style.overflow='hidden'; }
  function close(){ sidebar.classList.remove('open'); overlay.classList.remove('visible'); document.body.style.overflow=''; }
  btn.addEventListener('click', function(){ sidebar.classList.contains('open') ? close() : open(); });
  overlay.addEventListener('click', close);
  document.addEventListener('keydown', function(e){ if(e.key==='Escape') close(); });
})();

// ── Checkbox / select-all ─────────────────────────────────────────────────────
function toggleAll(master) {
  document.querySelectorAll('.row-cb').forEach(function(cb){ cb.checked = master.checked; });
  updateBulkCount();
}

function updateBulkCount() {
  var checked = document.querySelectorAll('.row-cb:checked').length;
  document.getElementById('bulkCount').textContent = checked + ' selected';
  var hasChecked = checked > 0;
  var btnApprove = document.getElementById('btnBulkApprove');
  var btnDelete  = document.getElementById('btnBulkDelete');
  if (btnApprove) btnApprove.disabled = !hasChecked;
  if (btnDelete)  btnDelete.disabled  = !hasChecked;
  // Sync master checkbox indeterminate state
  var total = document.querySelectorAll('.row-cb').length;
  var master = document.getElementById('selectAll');
  if (master) {
    master.indeterminate = (checked > 0 && checked < total);
    master.checked = (total > 0 && checked === total);
  }
}

function bulkSubmit(action) {
  var checked = document.querySelectorAll('.row-cb:checked').length;
  if (checked === 0) { alert('No posts selected.'); return; }
  var confirmMsg = action === 'bulk_approve'
    ? 'Approve and publish ' + checked + ' post(s) now?'
    : 'Permanently delete ' + checked + ' post(s)? This cannot be undone.';
  if (!confirm(confirmMsg)) return;
  document.getElementById('bulkAction').value = action;
  document.getElementById('bulkForm').submit();
}
