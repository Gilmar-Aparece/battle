<?php
// ─────────────────────────────────────────────────────────────────────────────
// PATCH: Add these POST action handlers to showcase.php (before the final echo)
// Place them inside the existing POST action block.
// ─────────────────────────────────────────────────────────────────────────────

// ── toggle_like ───────────────────────────────────────────────────────────────
if ($action === 'toggle_like') {
  header('Content-Type: application/json');
  $post_id = (int)($_POST['post_id'] ?? 0);
  if (!$post_id) { echo json_encode(['ok'=>false,'error'=>'missing']); exit; }

  // Check if post exists
  $chk = db()->prepare('SELECT id FROM showcase_posts WHERE id=?');
  $chk->execute([$post_id]);
  if (!$chk->fetch()) { echo json_encode(['ok'=>false,'error'=>'not_found']); exit; }

  // Toggle
  $existing = db()->prepare('SELECT id FROM showcase_likes WHERE post_id=? AND user_id=?');
  $existing->execute([$post_id, $user['id']]);
  if ($existing->fetch()) {
    db()->prepare('DELETE FROM showcase_likes WHERE post_id=? AND user_id=?')->execute([$post_id, $user['id']]);
    $liked = false;
  } else {
    db()->prepare('INSERT IGNORE INTO showcase_likes (post_id, user_id) VALUES (?,?)')->execute([$post_id, $user['id']]);
    $liked = true;
  }

  $count = (int)db()->query("SELECT COUNT(*) FROM showcase_likes WHERE post_id={$post_id}")->fetchColumn();
  echo json_encode(['ok'=>true, 'liked'=>$liked, 'like_count'=>$count]);
  exit;
}

// ── toggle_follow ─────────────────────────────────────────────────────────────
// Can also be placed in api.php or a standalone follow.php
if ($action === 'toggle_follow') {
  header('Content-Type: application/json');
  $target_id = (int)($_POST['target_id'] ?? 0);
  if (!$target_id || $target_id === (int)$user['id']) {
    echo json_encode(['ok'=>false,'error'=>'invalid']); exit;
  }

  // Check target exists
  $chk = db()->prepare('SELECT id FROM users WHERE id=?');
  $chk->execute([$target_id]);
  if (!$chk->fetch()) { echo json_encode(['ok'=>false,'error'=>'not_found']); exit; }

  $existing = db()->prepare('SELECT id FROM user_follows WHERE follower_id=? AND following_id=?');
  $existing->execute([$user['id'], $target_id]);
  if ($existing->fetch()) {
    db()->prepare('DELETE FROM user_follows WHERE follower_id=? AND following_id=?')->execute([$user['id'], $target_id]);
    $following = false;
  } else {
    db()->prepare('INSERT IGNORE INTO user_follows (follower_id, following_id) VALUES (?,?)')->execute([$user['id'], $target_id]);
    $following = true;
  }

  $followerCount = (int)db()->query("SELECT COUNT(*) FROM user_follows WHERE following_id={$target_id}")->fetchColumn();
  echo json_encode(['ok'=>true, 'following'=>$following, 'follower_count'=>$followerCount]);
  exit;
}
