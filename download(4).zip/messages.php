<?php
require_once 'includes/config.php';
require_once 'includes/layout.php';
require_once 'includes/notifications_helper.php';
requireLogin();

$me = auth();

// ── Auto-create tables ─────────────────────────────────────────────────────
try {
  db()->exec("CREATE TABLE IF NOT EXISTS direct_messages (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    sender_id   INT NOT NULL,
    receiver_id INT NOT NULL,
    message     TEXT NOT NULL,
    is_read     TINYINT(1) NOT NULL DEFAULT 0,
    sent_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_sender   (sender_id),
    KEY idx_receiver (receiver_id),
    KEY idx_convo    (sender_id, receiver_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
} catch (Exception $e) {}

// Typing indicator table
try {
  db()->exec("CREATE TABLE IF NOT EXISTS typing_indicators (
    user_id     INT NOT NULL,
    to_user_id  INT NOT NULL,
    updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, to_user_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Exception $e) {}

// WebRTC signaling table
try {
  db()->exec("CREATE TABLE IF NOT EXISTS call_signals (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    from_id     INT NOT NULL,
    to_id       INT NOT NULL,
    type        VARCHAR(32) NOT NULL,
    payload     MEDIUMTEXT NOT NULL,
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_to  (to_id),
    KEY idx_from (from_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
} catch (Exception $e) {}

// ── JSON API ───────────────────────────────────────────────────────────────
if (isset($_GET['action'])) {
  header('Content-Type: application/json');
  $action = $_GET['action'];

  // Send a chat message
  if ($action === 'send' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $to  = (int)($_POST['to'] ?? 0);
    $msg = trim($_POST['message'] ?? '');
    if (!$to || !$msg || strlen($msg) > 1000) { echo json_encode(['ok'=>false,'msg'=>'Invalid']); exit; }
    $chk = db()->prepare('SELECT id FROM users WHERE id=?'); $chk->execute([$to]);
    if (!$chk->fetch()) { echo json_encode(['ok'=>false,'msg'=>'User not found']); exit; }
    db()->prepare('INSERT INTO direct_messages (sender_id, receiver_id, message) VALUES (?,?,?)')
        ->execute([$me['id'], $to, $msg]);
    $newId = db()->lastInsertId();
    $row = db()->prepare('SELECT * FROM direct_messages WHERE id=?'); $row->execute([$newId]);
    $row = $row->fetch();
    echo json_encode(['ok'=>true, 'message'=>$row]);
    exit;
  }

  // Get messages for a conversation
  if ($action === 'messages') {
    $with = (int)($_GET['with'] ?? 0);
    if (!$with) { echo json_encode(['ok'=>false]); exit; }
    db()->prepare('UPDATE direct_messages SET is_read=1 WHERE receiver_id=? AND sender_id=?')
        ->execute([$me['id'], $with]);
    $stmt = db()->prepare('
      SELECT * FROM direct_messages
      WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?)
      ORDER BY sent_at ASC LIMIT 200
    ');
    $stmt->execute([$me['id'], $with, $with, $me['id']]);
    echo json_encode(['ok'=>true, 'messages'=>$stmt->fetchAll()]);
    exit;
  }

  // Poll new messages
  if ($action === 'poll') {
    $with    = (int)($_GET['with'] ?? 0);
    $sinceId = (int)($_GET['since'] ?? 0);
    if (!$with) { echo json_encode(['ok'=>false]); exit; }
    db()->prepare('UPDATE direct_messages SET is_read=1 WHERE receiver_id=? AND sender_id=?')
        ->execute([$me['id'], $with]);
    $stmt = db()->prepare('
      SELECT * FROM direct_messages
      WHERE id > ? AND ((sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?))
      ORDER BY sent_at ASC
    ');
    $stmt->execute([$sinceId, $me['id'], $with, $with, $me['id']]);
    echo json_encode(['ok'=>true, 'messages'=>$stmt->fetchAll()]);
    exit;
  }

  // Get conversation list
  if ($action === 'conversations') {
    $stmt = db()->query("
      SELECT u.id, u.username, u.avatar, u.avatar_img,
             dm.message AS last_message, dm.sent_at AS last_at,
             dm.sender_id AS last_sender,
             (SELECT COUNT(*) FROM direct_messages WHERE receiver_id={$me['id']} AND sender_id=u.id AND is_read=0) AS unread
      FROM users u
      JOIN (
        SELECT CASE WHEN sender_id={$me['id']} THEN receiver_id ELSE sender_id END AS other_id,
               MAX(id) AS max_id
        FROM direct_messages
        WHERE sender_id={$me['id']} OR receiver_id={$me['id']}
        GROUP BY other_id
      ) latest ON latest.other_id = u.id
      JOIN direct_messages dm ON dm.id = latest.max_id
      WHERE u.id != {$me['id']}
      ORDER BY dm.sent_at DESC
    ");
    echo json_encode(['ok'=>true, 'conversations'=>$stmt->fetchAll()]);
    exit;
  }

  // Unread count
  if ($action === 'unread_count') {
    $cnt = db()->query("SELECT COUNT(*) FROM direct_messages WHERE receiver_id={$me['id']} AND is_read=0")->fetchColumn();
    echo json_encode(['ok'=>true,'count'=>(int)$cnt]);
    exit;
  }

  // ── Typing indicator ───────────────────────────────────────────────────────
  if ($action === 'typing' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $to = (int)($_POST['to'] ?? 0);
    if ($to) {
      db()->prepare('INSERT INTO typing_indicators (user_id, to_user_id, updated_at) VALUES (?,?,NOW())
        ON DUPLICATE KEY UPDATE updated_at=NOW()')->execute([$me['id'], $to]);
    }
    echo json_encode(['ok'=>true]); exit;
  }

  if ($action === 'check_typing') {
    $with = (int)($_GET['with'] ?? 0);
    if (!$with) { echo json_encode(['ok'=>false]); exit; }
    $stmt = db()->prepare('SELECT COUNT(*) FROM typing_indicators WHERE user_id=? AND to_user_id=? AND updated_at > DATE_SUB(NOW(), INTERVAL 4 SECOND)');
    $stmt->execute([$with, $me['id']]);
    echo json_encode(['ok'=>true,'typing'=>(bool)$stmt->fetchColumn()]); exit;
  }

  // ── WebRTC Signaling API ────────────────────────────────────────────────

  // Send a signal (offer, answer, ice-candidate, call-request, call-end, call-reject, call-busy)
  if ($action === 'signal' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw  = file_get_contents('php://input');
    $body = json_decode($raw, true);
    $to      = (int)($body['to'] ?? 0);
    $type    = preg_replace('/[^a-z\-]/', '', strtolower($body['type'] ?? ''));
    $payload = $body['payload'] ?? '';
    if (!$to || !$type) { echo json_encode(['ok'=>false,'msg'=>'Invalid']); exit; }
    // Clean up stale signals older than 2 minutes for this pair
    db()->prepare('DELETE FROM call_signals WHERE created_at < DATE_SUB(NOW(), INTERVAL 2 MINUTE)')->execute();
    db()->prepare('INSERT INTO call_signals (from_id, to_id, type, payload) VALUES (?,?,?,?)')
        ->execute([$me['id'], $to, $type, is_string($payload) ? $payload : json_encode($payload)]);
    echo json_encode(['ok'=>true]);
    exit;
  }

  // Poll for incoming signals addressed to me
  if ($action === 'poll_signals') {
    $sinceId = (int)($_GET['since'] ?? 0);
    $stmt = db()->prepare('
      SELECT cs.*, u.username, u.avatar, u.avatar_img
      FROM call_signals cs
      JOIN users u ON u.id = cs.from_id
      WHERE cs.to_id = ? AND cs.id > ?
      ORDER BY cs.id ASC
      LIMIT 20
    ');
    $stmt->execute([$me['id'], $sinceId]);
    $signals = $stmt->fetchAll();
    // Delete signals we've consumed (except offer — keep for late joiners for 30s)
    if ($signals) {
      $ids = array_column($signals, 'id');
      $ph  = implode(',', array_fill(0, count($ids), '?'));
      db()->prepare("DELETE FROM call_signals WHERE id IN ($ph) AND type NOT IN ('call-request')")->execute($ids);
    }
    $maxId = $signals ? max(array_column($signals, 'id')) : $sinceId;
    echo json_encode(['ok'=>true,'signals'=>$signals,'max_id'=>$maxId]);
    exit;
  }

  echo json_encode(['ok'=>false,'msg'=>'unknown action']); exit;
}

// ── Determine if opening a specific conversation ───────────────────────────
$withId     = (int)($_GET['with'] ?? 0);
$incomingCall = isset($_GET['incoming']) && $_GET['incoming'] === '1';
$withUser   = null;
if ($withId) {
  $s = db()->prepare('SELECT id, username, avatar, avatar_img FROM users WHERE id=?');
  $s->execute([$withId]);
  $withUser = $s->fetch();
}

pageHeader('Messages');
?>
<style>
/* ── Messages Layout ─────────────────────────────────────────────────────── */
.msg-wrap{display:flex;height:calc(100vh - 58px);overflow:hidden;max-width:1200px;margin:0 auto}

/* Sidebar */
.msg-sidebar{width:300px;flex-shrink:0;border-right:1px solid var(--border);display:flex;flex-direction:column;background:var(--bg2)}
.msg-sidebar-head{padding:20px 16px 14px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}
.msg-sidebar-head h2{font-size:16px;font-weight:800;letter-spacing:-.5px}
.msg-search{padding:10px 12px;border-bottom:1px solid var(--border)}
.msg-search input{width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;padding:7px 12px;color:var(--text);font-size:12px;font-family:var(--font-mono);outline:none;transition:border-color .2s}
.msg-search input:focus{border-color:rgba(0,255,135,.3)}
.msg-convos{flex:1;overflow-y:auto}
.msg-convo-item{display:flex;align-items:center;gap:10px;padding:12px 14px;cursor:pointer;transition:background .15s;border-bottom:1px solid rgba(255,255,255,.03);text-decoration:none}
.msg-convo-item:hover,.msg-convo-item.active{background:var(--bg3)}
.msg-convo-item.active{border-left:3px solid var(--green)}
.msg-convo-avt{width:40px;height:40px;border-radius:50%;background:var(--bg3);border:1px solid var(--border);display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0;overflow:hidden}
.msg-convo-avt img{width:100%;height:100%;object-fit:cover}
.msg-convo-info{flex:1;min-width:0}
.msg-convo-name{font-size:13px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.msg-convo-preview{font-size:11px;font-family:var(--font-mono);color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:2px}
.msg-convo-meta{display:flex;flex-direction:column;align-items:flex-end;gap:4px;flex-shrink:0}
.msg-convo-time{font-size:10px;font-family:var(--font-mono);color:var(--muted)}
.msg-unread-badge{background:var(--green);color:#080b12;font-size:10px;font-weight:800;border-radius:10px;padding:1px 7px;font-family:var(--font-mono)}
.msg-empty-state{text-align:center;padding:40px 20px;color:var(--muted);font-family:var(--font-mono);font-size:12px}

/* Chat panel */
.msg-chat{flex:1;display:flex;flex-direction:column;min-width:0}
.msg-chat-head{padding:14px 20px;border-bottom:1px solid var(--border);background:var(--bg2);display:flex;align-items:center;justify-content:space-between;gap:12px;flex-shrink:0}
.msg-chat-user{display:flex;align-items:center;gap:10px}
.msg-chat-avt{width:36px;height:36px;border-radius:50%;background:var(--bg3);border:1px solid var(--border);display:flex;align-items:center;justify-content:center;font-size:18px;overflow:hidden;flex-shrink:0}
.msg-chat-avt img{width:100%;height:100%;object-fit:cover}
.msg-chat-name{font-size:14px;font-weight:700}
.msg-chat-status{font-size:10px;font-family:var(--font-mono);color:var(--muted);margin-top:1px}

/* Call buttons */
.msg-call-btns{display:flex;align-items:center;gap:8px}
.msg-call-btn{display:flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:10px;border:1px solid var(--border);background:var(--bg3);cursor:pointer;font-size:16px;transition:all .2s;text-decoration:none;color:inherit}
.msg-call-btn:hover{transform:scale(1.08)}
.msg-call-btn.voice:hover{background:rgba(0,255,135,.12);border-color:rgba(0,255,135,.35)}
.msg-call-btn.video:hover{background:rgba(0,200,255,.12);border-color:rgba(0,200,255,.35)}
.msg-call-btn:disabled{opacity:.4;cursor:default;transform:none}

/* Messages area */
.msg-messages{flex:1;overflow-y:auto;padding:20px;display:flex;flex-direction:column;gap:12px;background:var(--bg)}
.msg-bubble-wrap{display:flex;align-items:flex-end;gap:8px;margin-bottom:2px}
.msg-bubble-wrap.mine{flex-direction:row-reverse}
.msg-bubble-content{display:flex;flex-direction:column}
.msg-bubble-wrap.mine .msg-bubble-content{align-items:flex-end}
.msg-bubble-avt{width:28px;height:28px;border-radius:50%;background:var(--bg3);border:1px solid var(--border);display:flex;align-items:center;justify-content:center;font-size:14px;flex-shrink:0;overflow:hidden}
.msg-bubble-avt img{width:100%;height:100%;object-fit:cover}
.msg-bubble{max-width:65%;padding:10px 14px;border-radius:14px;font-size:13px;line-height:1.5;word-break:break-word}
.msg-bubble.theirs{background:var(--bg2);border:1px solid var(--border);border-bottom-left-radius:4px}
.msg-bubble.mine{background:var(--green);color:#080b12;border-bottom-right-radius:4px}
.msg-bubble-time{font-size:10px;font-family:var(--font-mono);color:var(--muted);margin-top:4px}
.msg-bubble-wrap.mine .msg-bubble-time{text-align:right}
.msg-no-chat{flex:1;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:14px;color:var(--muted)}
.msg-no-chat h3{font-size:20px;font-weight:800;color:var(--text)}
.msg-no-chat p{font-size:13px;font-family:var(--font-mono)}

/* Input area */
.msg-input-area{padding:14px 16px;border-top:1px solid var(--border);background:var(--bg2);display:flex;align-items:flex-end;gap:10px;flex-shrink:0}
.msg-input-wrap{flex:1;background:var(--bg3);border:1px solid var(--border);border-radius:12px;padding:10px 14px;display:flex;align-items:flex-end;gap:8px;transition:border-color .2s}
.msg-input-wrap:focus-within{border-color:rgba(0,255,135,.3)}
.msg-input{flex:1;background:none;border:none;color:var(--text);font-size:13px;font-family:var(--font-head);outline:none;resize:none;line-height:1.5;max-height:120px;min-height:20px}
.msg-send-btn{display:flex;align-items:center;justify-content:center;width:40px;height:40px;border-radius:10px;background:var(--green);border:none;cursor:pointer;font-size:18px;flex-shrink:0;transition:filter .2s,transform .2s;color:#080b12}
.msg-send-btn:hover{filter:brightness(1.1);transform:scale(1.05)}
.msg-send-btn:disabled{opacity:.4;cursor:default;transform:none}

/* ── INCOMING CALL BANNER ────────────────────────────────────────────────── */
.incoming-call-banner{
  position:fixed;top:70px;right:20px;z-index:2000;
  background:var(--bg2);border:1px solid var(--green);border-radius:20px;
  padding:16px 20px;display:none;align-items:center;gap:16px;
  box-shadow:0 8px 40px rgba(0,255,135,.18),0 2px 12px rgba(0,0,0,.5);
  animation:slideIn .35s cubic-bezier(.22,1,.36,1);
  max-width:340px;min-width:280px
}
.incoming-call-banner.open{display:flex}
@keyframes slideIn{from{opacity:0;transform:translateX(40px)}to{opacity:1;transform:none}}
.icb-avatar{width:48px;height:48px;border-radius:50%;background:var(--bg3);border:2px solid var(--green);display:flex;align-items:center;justify-content:center;font-size:24px;overflow:hidden;flex-shrink:0}
.icb-avatar img{width:100%;height:100%;object-fit:cover}
.icb-info{flex:1;min-width:0}
.icb-name{font-size:14px;font-weight:800}
.icb-type{font-size:11px;font-family:var(--font-mono);color:var(--muted);margin-top:2px}
.icb-btns{display:flex;gap:10px;flex-shrink:0}
.icb-btn{width:40px;height:40px;border-radius:50%;border:none;cursor:pointer;font-size:18px;display:flex;align-items:center;justify-content:center;transition:transform .15s}
.icb-btn:hover{transform:scale(1.1)}
.icb-btn.accept{background:var(--green);color:#080b12}
.icb-btn.reject{background:#ff4444;color:#fff}

/* ── VOICE CALL MODAL ───────────────────────────────────────────────────── */
.call-modal-bg{position:fixed;inset:0;background:rgba(0,0,0,.88);backdrop-filter:blur(12px);z-index:1500;display:none;align-items:center;justify-content:center}
.call-modal-bg.open{display:flex}
.call-modal{background:var(--bg2);border:1px solid var(--border);border-radius:28px;padding:44px 52px;text-align:center;min-width:320px;position:relative;animation:popIn .3s cubic-bezier(.22,1,.36,1)}
@keyframes popIn{from{opacity:0;transform:scale(.9)}to{opacity:1;transform:none}}
.call-modal-avatar{margin-bottom:18px;position:relative;width:96px;height:96px;margin:0 auto 18px;display:flex;align-items:center;justify-content:center}
.call-modal-avatar img{width:88px;height:88px;border-radius:50%;border:3px solid var(--green);object-fit:cover;position:relative;z-index:1}
.call-modal-avatar .av-emoji{width:88px;height:88px;border-radius:50%;border:3px solid var(--green);display:flex;align-items:center;justify-content:center;font-size:44px;background:var(--bg3);position:relative;z-index:1}
/* Pulse ring during ringing */
@keyframes ringPulse{0%{box-shadow:0 0 0 0 rgba(0,255,135,.5)}70%{box-shadow:0 0 0 18px rgba(0,255,135,0)}100%{box-shadow:0 0 0 0 rgba(0,255,135,0)}}
.call-modal-avatar.ringing img,.call-modal-avatar.ringing .av-emoji{animation:ringPulse 1.4s infinite}
.call-modal-name{font-size:24px;font-weight:800;letter-spacing:-1px;margin-bottom:6px}
.call-modal-status{font-size:13px;font-family:var(--font-mono);color:var(--muted);margin-bottom:36px}
.call-modal-status.ringing{animation:pulse-text 1s infinite}
@keyframes pulse-text{0%,100%{opacity:1}50%{opacity:.35}}
.call-type-badge{position:absolute;top:18px;right:18px;font-size:11px;font-family:var(--font-mono);color:var(--muted);background:var(--bg3);border:1px solid var(--border);border-radius:6px;padding:3px 9px}
.call-modal-actions{display:flex;justify-content:center;gap:20px}
.call-action-btn{width:64px;height:64px;border-radius:50%;border:none;cursor:pointer;font-size:26px;display:flex;align-items:center;justify-content:center;transition:transform .15s,filter .15s}
.call-action-btn:hover{transform:scale(1.08);filter:brightness(1.1)}
.call-action-btn.hangup{background:#ff4444;color:#fff}
.call-action-btn.accept{background:var(--green);color:#080b12}
.call-timer-wrap{display:flex;align-items:center;justify-content:center;gap:8px;margin-top:12px}
.call-timer{font-size:28px;font-weight:800;font-family:var(--font-mono);letter-spacing:2px}
.call-mic-btn{background:rgba(255,255,255,.08);border:1px solid var(--border);border-radius:10px;padding:6px 12px;cursor:pointer;font-size:14px;color:var(--muted);transition:all .2s}
.call-mic-btn:hover{background:rgba(255,255,255,.14)}
.call-mic-btn.muted{color:#ff8080;background:rgba(255,80,80,.12)}

/* ── VIDEO CALL MODAL ───────────────────────────────────────────────────── */
.video-modal-bg{position:fixed;inset:0;background:#000;z-index:1500;display:none;flex-direction:column}
.video-modal-bg.open{display:flex}
.video-main{flex:1;position:relative;display:flex;align-items:center;justify-content:center;background:#080b12;overflow:hidden}
#remoteVideo{width:100%;height:100%;object-fit:cover;display:none}
.video-remote-placeholder{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:18px;color:var(--muted);position:absolute;inset:0}
.vp-avatar{font-size:88px;line-height:1}
.vp-avatar img{width:100px;height:100px;border-radius:50%;border:3px solid var(--green);object-fit:cover}
.vp-name{font-size:26px;font-weight:800;color:#fff}
.vp-status{font-size:14px;font-family:var(--font-mono)}
.vp-status.ringing{animation:pulse-text 1s infinite}
.video-self{position:absolute;bottom:88px;right:20px;width:168px;height:116px;border-radius:14px;overflow:hidden;border:2px solid rgba(255,255,255,.18);background:#0e1320;box-shadow:0 4px 20px rgba(0,0,0,.5)}
.video-self video{width:100%;height:100%;object-fit:cover;transform:scaleX(-1)}
.video-top-bar{position:absolute;top:0;left:0;right:0;padding:18px 24px;display:flex;align-items:center;justify-content:space-between;background:linear-gradient(to bottom,rgba(0,0,0,.75),transparent);z-index:2}
.video-top-name{font-size:15px;font-weight:700;color:#fff}
.video-top-timer{font-size:14px;font-family:var(--font-mono);color:rgba(255,255,255,.65)}
.video-controls{height:84px;background:rgba(0,0,0,.82);display:flex;align-items:center;justify-content:center;gap:18px;flex-shrink:0;border-top:1px solid rgba(255,255,255,.07)}
.vc-btn{width:54px;height:54px;border-radius:50%;border:none;cursor:pointer;font-size:22px;display:flex;align-items:center;justify-content:center;transition:transform .15s}
.vc-btn:hover{transform:scale(1.08)}
.vc-btn.red{background:#ff4444;color:#fff}
.vc-btn.gray{background:rgba(255,255,255,.12);color:#fff}
.vc-btn.muted-on{background:rgba(255,80,80,.25);color:#ff8080}

/* ── VIDEO FILTERS ──────────────────────────────────────────────────────────── */
.filter-btn{background:rgba(255,255,255,.12);color:#fff;border:1px solid rgba(255,255,255,.18);border-radius:10px;padding:6px 14px;cursor:pointer;font-size:13px;transition:all .2s;white-space:nowrap}
.filter-btn:hover{background:rgba(255,255,255,.22)}
.filter-btn.active-filter{background:rgba(0,255,135,.2);border-color:var(--green);color:var(--green)}
.filter-panel{display:none;position:absolute;bottom:100px;left:50%;transform:translateX(-50%);background:rgba(10,14,28,.92);border:1px solid rgba(255,255,255,.12);border-radius:16px;padding:12px 14px;z-index:5;backdrop-filter:blur(10px);gap:8px;flex-wrap:wrap;justify-content:center;max-width:340px}
.filter-panel.open{display:flex}
#localVideo.filter-none{filter:none}
#localVideo.filter-grayscale{filter:grayscale(100%)}
#localVideo.filter-sepia{filter:sepia(80%)}
#localVideo.filter-warm{filter:saturate(1.4) hue-rotate(-15deg) brightness(1.05)}
#localVideo.filter-cool{filter:saturate(1.2) hue-rotate(30deg) brightness(1.05)}
#localVideo.filter-blur-bg{filter:blur(0px);/* JS applies background blur */}
#localVideo.filter-vivid{filter:saturate(1.8) contrast(1.1)}
#localVideo.filter-noir{filter:grayscale(100%) contrast(1.3) brightness(0.9)}
.typing-indicator{display:none;align-items:center;gap:8px;padding:4px 20px 10px;font-size:11px;font-family:var(--font-mono);color:var(--muted)}
.typing-indicator.show{display:flex}
.typing-dots{display:flex;gap:3px;align-items:center}
.typing-dots span{width:5px;height:5px;border-radius:50%;background:var(--muted);animation:typingBounce 1.2s infinite}
.typing-dots span:nth-child(2){animation-delay:.2s}
.typing-dots span:nth-child(3){animation-delay:.4s}
@keyframes typingBounce{0%,80%,100%{transform:translateY(0);opacity:.4}40%{transform:translateY(-5px);opacity:1}}

/* Missed / system call messages */
.msg-call-log{display:flex;justify-content:center;padding:6px 0}
.msg-call-log-pill{display:inline-flex;align-items:center;gap:6px;font-size:11px;font-family:var(--font-mono);color:var(--muted);background:var(--bg2);border:1px solid var(--border);border-radius:20px;padding:4px 14px}
.msg-call-log-pill.missed{color:#ff8080;border-color:rgba(255,80,80,.25);background:rgba(255,80,80,.05)}
.msg-call-log-pill.ended{color:var(--green);border-color:rgba(0,255,135,.2);background:rgba(0,255,135,.04)}

/* ── MOBILE RESPONSIVE ───────────────────────────────────────────────────── */
@media(max-width:700px){
  .msg-wrap{height:calc(100vh - 58px);overflow:hidden;position:relative;}

  /* Sidebar: full-width panel, slides off left when chat opens */
  .msg-sidebar{
    width:100%;position:absolute;top:0;left:0;right:0;bottom:0;
    z-index:10;transform:translateX(0);
    transition:transform .28s cubic-bezier(.4,0,.2,1);
  }
  .msg-sidebar.hidden{transform:translateX(-100%);pointer-events:none;}

  /* Show everything in sidebar on mobile */
  .msg-sidebar-head h2{display:block}
  .msg-search{display:block}
  .msg-convo-info,.msg-convo-meta{display:flex}
  .msg-convo-avt{width:44px;height:44px}
  .msg-convo-item{padding:12px 14px}

  /* Chat panel: full-width, slides in from right */
  .msg-chat{
    width:100%;position:absolute;top:0;left:0;right:0;bottom:0;
    z-index:11;transform:translateX(100%);
    transition:transform .28s cubic-bezier(.4,0,.2,1);
    display:flex;flex-direction:column;
  }
  .msg-chat.open{transform:translateX(0);}

  /* Back button (mobile only) */
  .msg-back-btn{
    display:flex;align-items:center;justify-content:center;
    width:34px;height:34px;border-radius:9px;
    border:1px solid var(--border);background:var(--bg3);
    cursor:pointer;font-size:16px;color:var(--text);flex-shrink:0;
    transition:background .15s;
  }
  .msg-back-btn:hover{background:rgba(255,255,255,.08)}

  /* Chat header */
  .msg-chat-head{padding:10px 12px;gap:8px;}
  .msg-chat-name{font-size:13px}
  .msg-call-btns{gap:6px}
  .msg-call-btn{width:32px;height:32px;font-size:14px;border-radius:8px}

  /* Messages */
  .msg-messages{padding:12px 10px;gap:8px}
  .msg-bubble{max-width:82%;font-size:13px;padding:9px 12px}

  /* Input — font-size:16px prevents iOS auto-zoom */
  .msg-input-area{padding:10px;gap:8px}
  .msg-input-wrap{padding:8px 12px}
  .msg-input{font-size:16px}
  .msg-send-btn{width:40px;height:40px;font-size:17px;border-radius:9px}

  /* Typing */
  .typing-indicator{padding:2px 10px 8px}

  /* Incoming call banner */
  .incoming-call-banner{right:10px;left:10px;max-width:none;top:66px}

  /* Voice call modal */
  .call-modal{padding:32px 24px;min-width:0;width:calc(100vw - 32px)}
  .call-modal-name{font-size:20px}

  /* Video controls — larger tap targets */
  .vc-btn{width:58px;height:58px;font-size:24px}
  .video-controls{gap:22px}
  .video-self{width:120px;height:82px;bottom:96px}
}
</style>

<div class="msg-wrap">
  <!-- Sidebar -->
  <div class="msg-sidebar">
    <div class="msg-sidebar-head"><h2>💬 Messages</h2></div>
    <div class="msg-search">
      <input type="text" id="searchInput" placeholder="Search…" oninput="filterConvos(this.value)">
    </div>
    <div class="msg-convos" id="convoList">
      <div class="msg-empty-state" id="convoLoading">Loading…</div>
    </div>
  </div>

  <!-- Chat panel -->
  <div class="msg-chat" id="chatPanel">
    <div class="msg-no-chat" id="noChatMsg">
      <div style="font-size:48px">💬</div>
      <h3>Your Messages</h3>
      <p>Select a conversation or start a new one<br>from a user's profile or the leaderboard.</p>
    </div>

    <!-- Chat header -->
    <div class="msg-chat-head" id="chatHead" style="display:none">
      <div class="msg-chat-user">
        <button class="msg-back-btn" id="backBtn" onclick="goBackToSidebar()" title="Back" style="display:none">←</button>
        <div class="msg-chat-avt" id="chatHeadAvt">👤</div>
        <div>
          <div class="msg-chat-name" id="chatHeadName"></div>
          <div class="msg-chat-status" id="chatHeadStatus">codeMe user</div>
        </div>
      </div>
      <div class="msg-call-btns">
        <button class="msg-call-btn voice" title="Voice Call" onclick="initiateCall('voice')" id="voiceCallBtn">📞</button>
        <button class="msg-call-btn video" title="Video Call" onclick="initiateCall('video')" id="videoCallBtn">📹</button>
        <a class="msg-call-btn" id="viewProfileBtn" title="View Profile" target="_blank">👤</a>
      </div>
    </div>

    <div class="msg-messages" id="messagesList" style="display:none"></div>

    <!-- Typing indicator -->
    <div class="typing-indicator" id="typingIndicator">
      <div class="typing-dots"><span></span><span></span><span></span></div>
      <span id="typingLabel"></span> is typing…
    </div>

    <div class="msg-input-area" id="chatInput" style="display:none">
      <div class="msg-input-wrap">
        <textarea class="msg-input" id="msgTextarea" placeholder="Type a message…" rows="1"
                  oninput="autoResize(this);sendTyping()" onkeydown="handleKey(event)"></textarea>
      </div>
      <button class="msg-send-btn" onclick="sendMessage()" id="sendBtn">➤</button>
    </div>
  </div>
</div>

<!-- ── Incoming Call Banner ─────────────────────────────────────────────── -->
<div class="incoming-call-banner" id="incomingBanner">
  <div class="icb-avatar" id="icbAvatar">👤</div>
  <div class="icb-info">
    <div class="icb-name" id="icbName"></div>
    <div class="icb-type" id="icbType">📞 Voice Call</div>
  </div>
  <div class="icb-btns">
    <button class="icb-btn accept" onclick="acceptIncomingCall()" title="Accept">✔</button>
    <button class="icb-btn reject" onclick="rejectIncomingCall()" title="Reject">✕</button>
  </div>
</div>

<!-- ── Voice Call Modal ────────────────────────────────────────────────── -->
<div class="call-modal-bg" id="voiceCallModal">
  <div class="call-modal">
    <div class="call-type-badge" id="vcTypeBadge">📞 Voice Call</div>
    <div class="call-modal-avatar" id="vcAvt"></div>
    <div class="call-modal-name" id="vcName"></div>
    <div class="call-modal-status ringing" id="vcStatus">Calling…</div>
    <div class="call-modal-actions" id="vcActions">
      <button class="call-action-btn hangup" onclick="hangupCall()" title="End Call">📵</button>
    </div>
    <div class="call-timer-wrap" id="vcTimerWrap" style="display:none">
      <div class="call-timer" id="vcTimer">00:00</div>
      <button class="call-mic-btn" id="vcMicBtn" onclick="toggleVoiceMic()">🎤</button>
    </div>
  </div>
</div>

<!-- ── Video Call Modal ────────────────────────────────────────────────── -->
<div class="video-modal-bg" id="videoCallModal">
  <div class="video-main">
    <div class="video-top-bar">
      <div class="video-top-name" id="videoCallName"></div>
      <div class="video-top-timer" id="videoTimer">00:00</div>
    </div>
    <video id="remoteVideo" autoplay playsinline></video>
    <div class="video-remote-placeholder" id="remotePlaceholder">
      <div class="vp-avatar" id="videoPeerAvt">👤</div>
      <div class="vp-name" id="videoCallNameBig"></div>
      <div class="vp-status ringing" id="videoCallStatus">Connecting…</div>
    </div>
    <div class="video-self"><video id="localVideo" autoplay muted playsinline style="display:none"></video></div>
  </div>
  <div class="video-controls">
    <button class="vc-btn gray" id="muteMicBtn" onclick="toggleVideoMic()" title="Mute">🎤</button>
    <button class="vc-btn red" onclick="hangupVideoCall()" title="End Call">📵</button>
    <button class="vc-btn gray" id="camOffBtn" onclick="toggleCamera()" title="Camera Off">📷</button>
    <button class="vc-btn gray" id="filterToggleBtn" onclick="toggleFilterPanel()" title="Filters">✨</button>
  </div>
  <!-- Filter panel -->
  <div class="filter-panel" id="filterPanel">
    <button class="filter-btn active-filter" onclick="applyFilter('filter-none',this)">Normal</button>
    <button class="filter-btn" onclick="applyFilter('filter-grayscale',this)">B&W</button>
    <button class="filter-btn" onclick="applyFilter('filter-noir',this)">Noir</button>
    <button class="filter-btn" onclick="applyFilter('filter-sepia',this)">Sepia</button>
    <button class="filter-btn" onclick="applyFilter('filter-warm',this)">Warm</button>
    <button class="filter-btn" onclick="applyFilter('filter-cool',this)">Cool</button>
    <button class="filter-btn" onclick="applyFilter('filter-vivid',this)">Vivid</button>
  </div>
</div>
<script src="assets/security.js"></script>
<script>
const MY_ID   = <?= (int)$me['id'] ?>;
const MY_AVT  = <?= json_encode($me['avatar_img'] ? '<img src="'.$me['avatar_img'].'" alt="">' : e($me['avatar'] ?: '👤')) ?>;
const MY_NAME = <?= json_encode($me['username']) ?>;

// ─── Chat state ─────────────────────────────────────────────────────────────
let activeWith    = null;
let lastMessageId = 0;
let pollTimer     = null;
let allConvos     = [];

// ─── WebRTC & signaling state ────────────────────────────────────────────────
let pc              = null;   // RTCPeerConnection
let localStream     = null;
let callType        = null;   // 'voice' | 'video'
let callPeer        = null;   // {id, username, avatar, avatar_img}
let callRole        = null;   // 'caller' | 'callee'
let callTimer       = null;
let callSecs        = 0;
let signalPollTimer = null;
let lastSignalId    = 0;
let iceCandidateQueue = [];   // buffer ICE before remote desc set
let micMuted        = false;
let camOff          = false;
let voiceMicMuted   = false;
let noAnswerTimer   = null;   // auto-hangup if no answer after 30s
let typingTimer     = null;   // debounce typing sends
let typingPollTimer = null;   // poll peer typing state

// Pending incoming call data (before user accepts)
let pendingCallSignal = null;

const ICE_SERVERS = [{urls:'stun:stun.l.google.com:19302'},{urls:'stun:stun1.l.google.com:19302'}];

// ─── Helpers ─────────────────────────────────────────────────────────────────
function fmtTime(dateStr) {
  const d = new Date(dateStr.replace(' ','T')+'Z');
  const diff = (Date.now()-d)/1000;
  if (diff<60) return 'just now';
  if (diff<3600) return Math.floor(diff/60)+'m ago';
  if (diff<86400) return d.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
  return d.toLocaleDateString([],{month:'short',day:'numeric'});
}
function fmtDur(s){ return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0'); }
function escHtml(s){ const d=document.createElement('div');d.textContent=s;return d.innerHTML; }
function avatarHtml(u,size=40){
  if(u.avatar_img) return `<div class="msg-convo-avt" style="width:${size}px;height:${size}px"><img src="${escHtml(u.avatar_img)}" alt=""></div>`;
  return `<div class="msg-convo-avt" style="width:${size}px;height:${size}px;font-size:${size/2}px">${escHtml(u.avatar||'👤')}</div>`;
}
function peerAvtHtml(u,size=88){
  if(u&&u.avatar_img) return `<img src="${escHtml(u.avatar_img)}" alt="" style="width:${size}px;height:${size}px;border-radius:50%;border:3px solid var(--green);object-fit:cover;display:block;margin:0 auto">`;
  return `<div style="width:${size}px;height:${size}px;border-radius:50%;background:var(--bg3);border:3px solid var(--green);display:flex;align-items:center;justify-content:center;font-size:${Math.floor(size/2)}px;margin:0 auto">${escHtml((u&&u.avatar)||'👤')}</div>`;
}

// ─── Typing indicator ─────────────────────────────────────────────────────────
function sendTyping() {
  if (!activeWith) return;
  clearTimeout(typingTimer);
  const fd = new FormData(); fd.append('to', activeWith.id);
  fetch('messages.php?action=typing', {method:'POST', body:fd}).catch(()=>{});
  // Stop sending after 3s of no keypress (debounce)
  typingTimer = setTimeout(()=>{ typingTimer=null; }, 3000);
}

async function pollTyping() {
  if (!activeWith) return;
  try {
    const r = await fetch(`messages.php?action=check_typing&with=${activeWith.id}`);
    const d = await r.json();
    const el = document.getElementById('typingIndicator');
    if (d.ok && d.typing) {
      document.getElementById('typingLabel').textContent = activeWith.username;
      el.classList.add('show');
      // Scroll to show it
      const ml = document.getElementById('messagesList');
      ml.scrollTop = ml.scrollHeight;
    } else {
      el.classList.remove('show');
    }
  } catch(e){}
}

// ─── Call log helper — inserts a system message into chat ──────────────────
function insertCallLog(type, duration) {
  const list = document.getElementById('messagesList');
  if (!list || list.style.display==='none') return;
  const div = document.createElement('div');
  div.className = 'msg-call-log';
  let icon, label, cls;
  if (type==='missed') {
    icon='📵'; label='Missed call'; cls='missed';
  } else if (type==='rejected') {
    icon='🚫'; label='Call declined'; cls='missed';
  } else {
    const dur = duration ? ` · ${fmtDur(duration)}` : '';
    icon='📞'; label=`Call ended${dur}`; cls='ended';
  }
  div.innerHTML = `<div class="msg-call-log-pill ${cls}">${icon} ${label} · just now</div>`;
  list.appendChild(div);
  list.scrollTop = list.scrollHeight;
}

// ─── Signaling ────────────────────────────────────────────────────────────────
async function sendSignal(to, type, payload='') {
  await fetch('messages.php?action=signal', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({to, type, payload})
  });
}

async function pollSignals() {
  try {
    const r = await fetch(`messages.php?action=poll_signals&since=${lastSignalId}`);
    const d = await r.json();
    if (!d.ok) return;
    if (d.max_id > lastSignalId) lastSignalId = d.max_id;
    for (const sig of d.signals) await handleSignal(sig);
  } catch(e) {}
}

async function handleSignal(sig) {
  const fromId = parseInt(sig.from_id);
  let payload;
  try { payload = JSON.parse(sig.payload); } catch(e) { payload = sig.payload; }

  switch(sig.type) {

    case 'call-request': {
      // Someone is calling us — but only show banner if we're not already in a call
      if (pc) {
        // We're busy — reject automatically
        await sendSignal(fromId, 'call-busy', '');
        return;
      }
      pendingCallSignal = {fromId, sig, type: payload.callType||'voice'};
      showIncomingBanner(sig, payload.callType||'voice');
      break;
    }

    case 'call-reject': {
      if (callPeer && callPeer.id===fromId) {
        clearTimeout(noAnswerTimer); noAnswerTimer=null;
        setVoiceStatus('Call declined', false);
        insertCallLog('rejected', 0);
        setTimeout(()=>{ cleanupCall(); }, 2000);
      }
      break;
    }

    case 'call-busy': {
      if (callPeer && callPeer.id===fromId) {
        clearTimeout(noAnswerTimer); noAnswerTimer=null;
        setVoiceStatus('User is busy', false);
        insertCallLog('missed', 0);
        setTimeout(()=>{ cleanupCall(); }, 2000);
      }
      break;
    }

    case 'call-accept': {
      // Remote accepted — cancel no-answer timer, now caller creates offer
      clearTimeout(noAnswerTimer); noAnswerTimer=null;
      if (callRole==='caller' && callPeer && callPeer.id===fromId) {
        callType = payload.callType || callType;
        setVoiceStatus('Connecting…', false);
        if (callType==='video') setVideoStatus('Connecting…', true);
        await createOfferAndSend();
      }
      break;
    }

    case 'offer': {
      if (!pc) return;
      await pc.setRemoteDescription(new RTCSessionDescription(payload));
      // Flush queued ICE
      for (const c of iceCandidateQueue) await pc.addIceCandidate(new RTCIceCandidate(c));
      iceCandidateQueue = [];
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      await sendSignal(fromId, 'answer', pc.localDescription.toJSON());
      break;
    }

    case 'answer': {
      if (!pc) return;
      await pc.setRemoteDescription(new RTCSessionDescription(payload));
      // Flush queued ICE
      for (const c of iceCandidateQueue) await pc.addIceCandidate(new RTCIceCandidate(c));
      iceCandidateQueue = [];
      break;
    }

    case 'ice-candidate': {
      if (!pc) return;
      if (pc.remoteDescription) {
        await pc.addIceCandidate(new RTCIceCandidate(payload));
      } else {
        iceCandidateQueue.push(payload);
      }
      break;
    }

    case 'call-end': {
      if (callPeer && callPeer.id===fromId) {
        const dur = callSecs;
        insertCallLog('ended', dur);
        if (callType==='video') {
          setVideoStatus('Call ended', false);
          setTimeout(()=>{ cleanupVideoCall(); }, 1200);
        } else {
          setVoiceStatus('Call ended', false);
          setTimeout(()=>{ cleanupCall(); }, 1200);
        }
      }
      break;
    }
  }
}

// ─── Incoming call banner ────────────────────────────────────────────────────
function showIncomingBanner(sig, cType) {
  const banner = document.getElementById('incomingBanner');
  const avt    = document.getElementById('icbAvatar');
  avt.innerHTML = sig.avatar_img ? `<img src="${escHtml(sig.avatar_img)}" alt="">` : escHtml(sig.avatar||'👤');
  document.getElementById('icbName').textContent = sig.username;
  document.getElementById('icbType').textContent = cType==='video' ? '📹 Video Call' : '📞 Voice Call';
  banner.classList.add('open');
  // Ring sound via Audio API
  try {
    const ctx=new AudioContext(), osc=ctx.createOscillator(), gain=ctx.createGain();
    osc.connect(gain); gain.connect(ctx.destination);
    osc.type='sine'; osc.frequency.value=880; gain.gain.value=0.1;
    osc.start(); setTimeout(()=>osc.stop(),400);
  } catch(e){}
}

function hideIncomingBanner() {
  document.getElementById('incomingBanner').classList.remove('open');
}

async function acceptIncomingCall() {
  hideIncomingBanner();
  if (!pendingCallSignal) return;
  const {fromId, sig, type} = pendingCallSignal;
  pendingCallSignal = null;

  callPeer = {id:fromId, username:sig.username, avatar:sig.avatar, avatar_img:sig.avatar_img};
  callType = type;
  callRole = 'callee';

  await setupPeerConnection();
  await acquireMedia();

  if (callType==='video') {
    openVideoModal();
    setVideoStatus('Connecting…', true);
  } else {
    openVoiceModal('callee');
    setVoiceStatus('Connecting…', false);
  }

  await sendSignal(fromId, 'call-accept', {callType});
  // Speed up signal polling to reduce connection latency
  boostSignalPolling();
  pollSignals();
}

async function rejectIncomingCall() {
  hideIncomingBanner();
  if (!pendingCallSignal) return;
  const {fromId} = pendingCallSignal;
  pendingCallSignal = null;
  await sendSignal(fromId, 'call-reject', '');
}

// ─── Initiate call ────────────────────────────────────────────────────────────
async function initiateCall(type) {
  if (!activeWith) return;
  callType = type;
  callPeer = {...activeWith};
  callRole = 'caller';

  await setupPeerConnection();
  await acquireMedia();

  if (type==='video') {
    openVideoModal();
    setVideoStatus('Ringing…', true);
  } else {
    openVoiceModal('caller');
    setVoiceStatus('Calling…', true);
  }

  await sendSignal(callPeer.id, 'call-request', {callType: type});
  // ── Speed up signal polling during call setup to reduce connection latency
  boostSignalPolling();
  pollSignals(); // immediate poll

  // Auto-cancel after 30s if no answer
  noAnswerTimer = setTimeout(async ()=>{
    noAnswerTimer = null;
    if (!pc || pc.connectionState==='new' || pc.connectionState==='connecting') {
      await sendSignal(callPeer.id, 'call-end', '');
      insertCallLog('missed', 0);
      if (type==='video') { setVideoStatus('No answer', false); setTimeout(cleanupVideoCall, 1500); }
      else { setVoiceStatus('No answer', false); setTimeout(cleanupCall, 1500); }
    }
  }, 30000);
}

// ─── PeerConnection setup ─────────────────────────────────────────────────────
async function setupPeerConnection() {
  pc = new RTCPeerConnection({iceServers: ICE_SERVERS, iceCandidatePoolSize: 10});

  pc.onicecandidate = async e => {
    if (e.candidate) await sendSignal(callPeer.id, 'ice-candidate', e.candidate.toJSON());
    // When ICE gathering is complete, bump signal poll to fast mode
    if (!e.candidate) boostSignalPolling();
  };

  pc.ontrack = e => {
    const stream = (e.streams && e.streams[0]) ? e.streams[0] : new MediaStream([e.track]);
    if (callType==='video') {
      const rv = document.getElementById('remoteVideo');
      rv.srcObject = stream;
      rv.style.display = 'block';
      document.getElementById('remotePlaceholder').style.display = 'none';
      rv.play().catch(()=>{});
      setVideoStatus('Connected', false);
      if (!callTimer) startCallTimer('video');
    } else {
      let audio = document.getElementById('remoteAudio');
      if (!audio) {
        audio = document.createElement('audio');
        audio.id='remoteAudio'; audio.autoplay=true; document.body.appendChild(audio);
      }
      audio.srcObject = stream;
      audio.play().catch(()=>{});
      setVoiceStatus('Connected', false);
      if (!callTimer) startCallTimer('voice');
    }
  };

  pc.onconnectionstatechange = () => {
    if (pc && (pc.connectionState==='disconnected'||pc.connectionState==='failed')) {
      callType==='video' ? hangupVideoCall() : hangupCall();
    }
    // Resume normal poll rate when connected
    if (pc && pc.connectionState==='connected') normalSignalPolling();
  };
}

// ── Signal polling speed helpers (faster during call setup for lower latency) ─
function boostSignalPolling() {
  if (signalPollTimer) clearInterval(signalPollTimer);
  signalPollTimer = setInterval(pollSignals, 500); // 500ms during ICE / negotiation
}
function normalSignalPolling() {
  if (signalPollTimer) clearInterval(signalPollTimer);
  signalPollTimer = setInterval(pollSignals, 2000); // 2s when idle
}

async function acquireMedia() {
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    const msg = location.protocol !== 'https:' && location.hostname !== 'localhost'
      ? 'Camera/mic require HTTPS. Contact your admin.'
      : 'Your browser does not support media devices.';
    callType==='video' ? setVideoStatus(msg, false) : setVoiceStatus(msg, false);
    return;
  }
  try {
    const constraints = callType==='video' ? {video:{facingMode:'user'},audio:true} : {audio:true,video:false};
    localStream = await navigator.mediaDevices.getUserMedia(constraints);
    if (callType==='video') {
      const lv = document.getElementById('localVideo');
      lv.srcObject = localStream;
      lv.style.display = 'block';
      lv.play().catch(()=>{});
    }
    // Add tracks to peer connection (must happen before offer is created)
    localStream.getTracks().forEach(t => pc && pc.addTrack(t, localStream));
  } catch(e) {
    console.warn('Media error', e);
    // Try audio-only fallback for video calls
    if (callType==='video') {
      setVideoStatus('Camera unavailable — audio only', false);
      try {
        localStream = await navigator.mediaDevices.getUserMedia({audio:true,video:false});
        localStream.getTracks().forEach(t => pc && pc.addTrack(t, localStream));
      } catch(e2) { console.warn('Audio fallback failed', e2); }
    } else {
      setVoiceStatus('Microphone unavailable', false);
    }
  }
}

async function createOfferAndSend() {
  if (!pc) return;
  const offer = await pc.createOffer();
  await pc.setLocalDescription(offer);
  await sendSignal(callPeer.id, 'offer', pc.localDescription.toJSON());
}

// ─── Voice call modal ─────────────────────────────────────────────────────────
function openVoiceModal(role) {
  const avEl = document.getElementById('vcAvt');
  avEl.innerHTML = peerAvtHtml(callPeer);
  avEl.classList.add('ringing');
  document.getElementById('vcName').textContent = callPeer.username;
  document.getElementById('vcTypeBadge').textContent = '📞 Voice Call';
  document.getElementById('vcTimerWrap').style.display='none';
  document.getElementById('vcActions').innerHTML = `<button class="call-action-btn hangup" onclick="hangupCall()" title="End Call">📵</button>`;
  document.getElementById('voiceCallModal').classList.add('open');
}

function setVoiceStatus(txt, ringing) {
  const el = document.getElementById('vcStatus');
  el.textContent = txt;
  el.className = 'call-modal-status'+(ringing?' ringing':'');
  document.getElementById('vcAvt').classList.toggle('ringing', ringing);
}

function startCallTimer(mode) {
  callSecs = 0;
  callTimer = setInterval(()=>{
    callSecs++;
    const txt = fmtDur(callSecs);
    if (mode==='video') {
      document.getElementById('videoTimer').textContent = txt;
    } else {
      document.getElementById('vcTimer').textContent = txt;
      document.getElementById('vcTimerWrap').style.display='flex';
    }
  }, 1000);
}

async function hangupCall() {
  clearTimeout(noAnswerTimer); noAnswerTimer=null;
  if (callPeer) {
    await sendSignal(callPeer.id, 'call-end', '');
    insertCallLog('ended', callSecs);
  }
  cleanupCall();
}
function cleanupCall() {
  clearTimeout(noAnswerTimer); noAnswerTimer=null;
  clearInterval(callTimer);
  if (localStream) { localStream.getTracks().forEach(t=>t.stop()); localStream=null; }
  if (pc) { pc.close(); pc=null; }
  document.getElementById('voiceCallModal').classList.remove('open');
  const ra=document.getElementById('remoteAudio');
  if(ra){ra.srcObject=null;}
  callPeer=null; callRole=null; callType=null; iceCandidateQueue=[]; voiceMicMuted=false;
}

function toggleVoiceMic() {
  if (!localStream) return;
  voiceMicMuted = !voiceMicMuted;
  localStream.getAudioTracks().forEach(t=>t.enabled=!voiceMicMuted);
  const btn=document.getElementById('vcMicBtn');
  btn.textContent = voiceMicMuted?'🔇':'🎤';
  btn.classList.toggle('muted', voiceMicMuted);
}

// ─── Video call modal ─────────────────────────────────────────────────────────
function openVideoModal() {
  document.getElementById('videoCallName').textContent    = callPeer.username;
  document.getElementById('videoCallNameBig').textContent = callPeer.username;
  document.getElementById('videoPeerAvt').innerHTML       = peerAvtHtml(callPeer,80);
  document.getElementById('remoteVideo').style.display    = 'none';
  document.getElementById('remotePlaceholder').style.display='flex';
  document.getElementById('videoTimer').textContent       = '00:00';
  micMuted=false; camOff=false;
  document.getElementById('muteMicBtn').textContent='🎤';
  document.getElementById('muteMicBtn').className='vc-btn gray';
  document.getElementById('camOffBtn').textContent='📷';
  document.getElementById('camOffBtn').className='vc-btn gray';
  // Reset filters
  const lv=document.getElementById('localVideo');
  ['filter-none','filter-grayscale','filter-sepia','filter-warm','filter-cool','filter-vivid','filter-noir'].forEach(c=>lv.classList.remove(c));
  lv.classList.add('filter-none');
  document.getElementById('filterPanel').classList.remove('open');
  document.getElementById('filterToggleBtn').classList.remove('muted-on');
  document.getElementById('videoCallModal').classList.add('open');
}

function setVideoStatus(txt, ringing) {
  const el=document.getElementById('videoCallStatus');
  el.textContent=txt;
  el.className='vp-status'+(ringing?' ringing':'');
  // Also pulse the avatar
  const avEl=document.getElementById('videoPeerAvt');
  if(avEl) avEl.style.animation = ringing ? 'ringPulse 1.4s infinite' : '';
}

async function hangupVideoCall() {
  clearTimeout(noAnswerTimer); noAnswerTimer=null;
  if (callPeer) {
    await sendSignal(callPeer.id, 'call-end', '');
    insertCallLog('ended', callSecs);
  }
  cleanupVideoCall();
}
function cleanupVideoCall() {
  clearTimeout(noAnswerTimer); noAnswerTimer=null;
  clearInterval(callTimer);
  if (localStream){localStream.getTracks().forEach(t=>t.stop());localStream=null;}
  if (pc){pc.close();pc=null;}
  document.getElementById('videoCallModal').classList.remove('open');
  const lv = document.getElementById('localVideo');
  lv.srcObject=null; lv.style.display='none';
  document.getElementById('remoteVideo').srcObject=null;
  callPeer=null; callRole=null; callType=null; iceCandidateQueue=[]; micMuted=false; camOff=false;
}

function toggleVideoMic() {
  if(!localStream)return;
  micMuted=!micMuted;
  localStream.getAudioTracks().forEach(t=>t.enabled=!micMuted);
  const btn=document.getElementById('muteMicBtn');
  btn.textContent=micMuted?'🔇':'🎤';
  btn.className='vc-btn gray'+(micMuted?' muted-on':'');
}
function toggleCamera() {
  if(!localStream)return;
  camOff=!camOff;
  localStream.getVideoTracks().forEach(t=>t.enabled=!camOff);
  const btn=document.getElementById('camOffBtn');
  btn.textContent=camOff?'🚫':'📷';
  btn.className='vc-btn gray'+(camOff?' muted-on':'');
}

// ─── Messaging ────────────────────────────────────────────────────────────────
async function loadConvos() {
  const res=await fetch('messages.php?action=conversations');
  const data=await res.json();
  if(!data.ok)return;
  allConvos=data.conversations;
  renderConvos(allConvos);
  <?php if ($withUser): ?>
    openChat(<?= json_encode(['id'=>$withUser['id'],'username'=>$withUser['username'],'avatar'=>$withUser['avatar'],'avatar_img'=>$withUser['avatar_img']]) ?>);
    <?php if ($incomingCall): ?>
    // Arrived from global call banner — show incoming call UI immediately
    // Poll once to pick up the pending call-request signal
    setTimeout(async function(){
      await pollSignals();
    }, 800);
    <?php endif; ?>
  <?php endif; ?>
}

// Store convo user data by id for safe retrieval on click
const _convoUsers = {};

function renderConvos(convos) {
  const list=document.getElementById('convoList');
  if(!convos.length){
    list.innerHTML='<div class="msg-empty-state">No conversations yet.<br>Message someone from the leaderboard!</div>';
    return;
  }
  // Store user objects keyed by id so onclick can look them up safely
  convos.forEach(c => { _convoUsers[c.id] = {id:c.id, username:c.username, avatar:c.avatar, avatar_img:c.avatar_img||null}; });

  list.innerHTML=convos.map(c=>`
    <div class="msg-convo-item ${activeWith&&activeWith.id==c.id?'active':''}"
         onclick="openChatById(${c.id})"
         id="convo-${c.id}">
      ${avatarHtml(c)}
      <div class="msg-convo-info">
        <div class="msg-convo-name">${escHtml(c.username)}</div>
        <div class="msg-convo-preview">${c.last_sender==MY_ID?'You: ':''}${escHtml(c.last_message.substring(0,40))}${c.last_message.length>40?'…':''}</div>
      </div>
      <div class="msg-convo-meta">
        <div class="msg-convo-time">${fmtTime(c.last_at)}</div>
        ${c.unread>0?`<div class="msg-unread-badge">${c.unread}</div>`:''}
      </div>
    </div>
  `).join('');
}

function filterConvos(q){
  if(!q){renderConvos(allConvos);return;}
  renderConvos(allConvos.filter(c=>c.username.toLowerCase().includes(q.toLowerCase())));
}

async function openChatById(id) {
  // If user data is already cached, open immediately
  if (_convoUsers[id]) {
    openChat(_convoUsers[id]);
    return;
  }
  // Otherwise fetch conversations first, then open
  try {
    const res  = await fetch('messages.php?action=conversations');
    const data = await res.json();
    if (data.ok) {
      allConvos = data.conversations;
      renderConvos(allConvos);
    }
  } catch(e) {}
  const user = _convoUsers[id];
  if (user) openChat(user);
}

async function openChat(user) {
  activeWith=user;
  clearInterval(pollTimer);
  clearInterval(typingPollTimer);
  document.getElementById('typingIndicator').classList.remove('show');
  const avt=document.getElementById('chatHeadAvt');
  const hasImg = user.avatar_img && user.avatar_img.trim() !== '';
  avt.innerHTML = hasImg ? `<img src="${escHtml(user.avatar_img)}" alt="">` : (user.avatar || '👤');
  document.getElementById('chatHeadName').textContent=user.username;
  document.getElementById('viewProfileBtn').href=`showcase.php?user=${user.id}`;
  document.getElementById('noChatMsg').style.display='none';
  document.getElementById('chatHead').style.display='';
  document.getElementById('messagesList').style.display='';
  document.getElementById('chatInput').style.display='';
  document.querySelectorAll('.msg-convo-item').forEach(el=>el.classList.remove('active'));
  const ci=document.getElementById('convo-'+user.id);
  if(ci){ ci.classList.add('active'); }
  // also ensure renderConvos picks up active state if it re-renders later

  showChatPanel();
  const res=await fetch(`messages.php?action=messages&with=${user.id}`);
  const data=await res.json();
  if(!data.ok)return;
  const msgs=data.messages;
  lastMessageId=msgs.length?msgs[msgs.length-1].id:0;
  renderMessages(msgs,true);
  pollTimer=setInterval(pollMessages,2500);
  typingPollTimer=setInterval(pollTyping, 2000);
  const badge=ci?.querySelector('.msg-unread-badge');
  if(badge)badge.remove();
  loadConvos();
}

function renderMessages(msgs,replace=false){
  const list=document.getElementById('messagesList');
  const atBottom=list.scrollHeight-list.scrollTop-list.clientHeight<60;
  if(replace){
    list.innerHTML=msgs.length?'':`<div style="text-align:center;font-family:var(--font-mono);font-size:12px;color:var(--muted);padding:40px">No messages yet. Say hi! 👋</div>`;
  }
  msgs.forEach(m=>{
    const mine=(parseInt(m.sender_id)===MY_ID);
    const div=document.createElement('div');
    div.className=`msg-bubble-wrap${mine?' mine':''}`;
    div.innerHTML=`
      <div class="msg-bubble-avt">
        ${mine?MY_AVT:(activeWith.avatar_img&&activeWith.avatar_img.trim()!==''?`<img src="${escHtml(activeWith.avatar_img)}" alt="">`:(activeWith.avatar||'👤'))}
      </div>
      <div class="msg-bubble-content">
        <div class="msg-bubble ${mine?'mine':'theirs'}">${escHtml(m.message)}</div>
        <div class="msg-bubble-time">${fmtTime(m.sent_at)}</div>
      </div>`;
    list.appendChild(div);
    if(m.id>lastMessageId)lastMessageId=parseInt(m.id);
  });
  if(replace||atBottom)list.scrollTop=list.scrollHeight;
}

async function pollMessages(){
  if(!activeWith)return;
  const res=await fetch(`messages.php?action=poll&with=${activeWith.id}&since=${lastMessageId}`);
  const data=await res.json();
  if(data.ok&&data.messages.length){renderMessages(data.messages,false);loadConvos();}
}

async function sendMessage(){
  if(!activeWith)return;
  const ta=document.getElementById('msgTextarea');
  const msg=ta.value.trim();
  if(!msg)return;
  ta.value='';autoResize(ta);
  const btn=document.getElementById('sendBtn');btn.disabled=true;
  const fd=new FormData();fd.append('to',activeWith.id);fd.append('message',msg);
  const res=await fetch('messages.php?action=send',{method:'POST',body:fd});
  const data=await res.json();
  btn.disabled=false;
  if(data.ok){renderMessages([data.message],false);loadConvos();}
}

function handleKey(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendMessage();}}
function autoResize(el){el.style.height='auto';el.style.height=Math.min(el.scrollHeight,120)+'px';}

function toggleFilterPanel() {
  const panel = document.getElementById('filterPanel');
  const btn = document.getElementById('filterToggleBtn');
  panel.classList.toggle('open');
  btn.classList.toggle('muted-on', panel.classList.contains('open'));
}
const FILTER_CLASSES = ['filter-none','filter-grayscale','filter-sepia','filter-warm','filter-cool','filter-vivid','filter-noir'];
function applyFilter(cls, btn) {
  const lv = document.getElementById('localVideo');
  FILTER_CLASSES.forEach(c => lv.classList.remove(c));
  lv.classList.add(cls);
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active-filter'));
  btn.classList.add('active-filter');
}

// ─── Mobile panel switching ──────────────────────────────────────────────────
function isMobile(){ return window.innerWidth <= 700; }

function showChatPanel(){
  if(!isMobile()) return;
  document.querySelector('.msg-sidebar').classList.add('hidden');
  document.getElementById('chatPanel').classList.add('open');
  document.getElementById('backBtn').style.display = 'flex';
}

function goBackToSidebar(){
  document.querySelector('.msg-sidebar').classList.remove('hidden');
  document.getElementById('chatPanel').classList.remove('open');
  document.getElementById('backBtn').style.display = 'none';
  // remove active highlight
  document.querySelectorAll('.msg-convo-item').forEach(el=>el.classList.remove('active'));
  activeWith = null;
  clearInterval(pollTimer);
  clearInterval(typingPollTimer);
}

// On resize back to desktop, reset panel states
window.addEventListener('resize', ()=>{
  if(!isMobile()){
    document.querySelector('.msg-sidebar').classList.remove('hidden');
    document.getElementById('chatPanel').classList.remove('open');
    document.getElementById('backBtn').style.display = 'none';
  }
});


loadConvos();
// Start signal polling
signalPollTimer = setInterval(pollSignals, 2000);
pollSignals(); // immediate first poll
</script>

<?php pageFooter(); ?>
