<?php
require_once 'includes/config.php';
require_once 'includes/layout.php';

$user = auth();
requireLogin();

// ── Auto-migration: scheduled_posts table ────────────────────────────────────
try {
  db()->exec("CREATE TABLE IF NOT EXISTS `scheduled_posts` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `title` VARCHAR(120) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `html_code` MEDIUMTEXT DEFAULT NULL,
    `css_code` MEDIUMTEXT DEFAULT NULL,
    `js_code` MEDIUMTEXT DEFAULT NULL,
    `allow_versus` TINYINT(1) NOT NULL DEFAULT 0,
    `scheduled_at` DATETIME NOT NULL,
    `status` ENUM('pending','published','cancelled') NOT NULL DEFAULT 'pending',
    `showcase_post_id` INT DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_user` (`user_id`),
    KEY `idx_scheduled` (`scheduled_at`,`status`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Exception $e) {}

// ── Process any due scheduled posts (run on every page load) ─────────────────
try {
  $due = db()->query(
    "SELECT * FROM scheduled_posts WHERE status='pending' AND scheduled_at <= NOW() LIMIT 20"
  )->fetchAll();
  foreach ($due as $sp) {
    // Insert into showcase_posts
    $ins = db()->prepare(
      'INSERT INTO showcase_posts (user_id,title,description,html_code,css_code,js_code,allow_versus)
       VALUES (?,?,?,?,?,?,?)'
    );
    $ins->execute([
      $sp['user_id'], $sp['title'], $sp['description'],
      $sp['html_code'], $sp['css_code'], $sp['js_code'], $sp['allow_versus']
    ]);
    $newPostId = (int)db()->lastInsertId();
    db()->prepare("UPDATE scheduled_posts SET status='published', showcase_post_id=? WHERE id=?")
       ->execute([$newPostId, $sp['id']]);
  }
} catch (Exception $e) {}

// ── Handle AJAX ──────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
  header('Content-Type: application/json');
  $action = $_POST['action'];

  // Schedule a new post
  if ($action === 'schedule_post') {
    $title       = trim($_POST['title'] ?? '');
    $desc        = trim($_POST['description'] ?? '');
    $html        = $_POST['html_code'] ?? '';
    $css         = $_POST['css_code']  ?? '';
    $js          = $_POST['js_code']   ?? '';
    $allowVersus = isset($_POST['allow_versus']) ? 1 : 0;
    $schedAt     = trim($_POST['scheduled_at'] ?? '');

    if (!$title)   { echo json_encode(['ok'=>false,'msg'=>'Title is required']); exit; }
    if (!$schedAt) { echo json_encode(['ok'=>false,'msg'=>'Scheduled time is required']); exit; }

    $schedTs = strtotime($schedAt);
    if (!$schedTs || $schedTs <= time()) {
      echo json_encode(['ok'=>false,'msg'=>'Scheduled time must be in the future']); exit;
    }
    if (mb_strlen($title) > 120) { echo json_encode(['ok'=>false,'msg'=>'Title too long']); exit; }

    $stmt = db()->prepare(
      'INSERT INTO scheduled_posts (user_id,title,description,html_code,css_code,js_code,allow_versus,scheduled_at)
       VALUES (?,?,?,?,?,?,?,?)'
    );
    $stmt->execute([
      $user['id'], $title, $desc ?: null, $html, $css, $js, $allowVersus,
      date('Y-m-d H:i:s', $schedTs)
    ]);
    echo json_encode(['ok'=>true,'id'=>db()->lastInsertId()]);
    exit;
  }

  // Cancel a scheduled post
  if ($action === 'cancel_scheduled') {
    $id = (int)($_POST['id'] ?? 0);
    $chk = db()->prepare('SELECT user_id FROM scheduled_posts WHERE id=?');
    $chk->execute([$id]);
    $row = $chk->fetch();
    if (!$row || (int)$row['user_id'] !== (int)$user['id']) {
      echo json_encode(['ok'=>false,'msg'=>'Not your post']); exit;
    }
    db()->prepare("UPDATE scheduled_posts SET status='cancelled' WHERE id=?")->execute([$id]);
    echo json_encode(['ok'=>true]);
    exit;
  }

  echo json_encode(['ok'=>false,'msg'=>'Unknown action']);
  exit;
}

// ── Fetch user's scheduled posts ─────────────────────────────────────────────
$pending   = db()->prepare("SELECT * FROM scheduled_posts WHERE user_id=? AND status='pending' ORDER BY scheduled_at ASC");
$pending->execute([$user['id']]);
$pending   = $pending->fetchAll();

$published = db()->prepare("SELECT * FROM scheduled_posts WHERE user_id=? AND status='published' ORDER BY scheduled_at DESC LIMIT 20");
$published->execute([$user['id']]);
$published = $published->fetchAll();

// ── Fetch OTHER users' community Versus-enabled schedules ─────────────────────
// These are posts from other users that have allow_versus=1 and are pending.
// Other users can join a Versus battle using these as the target design.
$communityVs = db()->prepare(
    "SELECT sp.*, u.username
     FROM scheduled_posts sp
     LEFT JOIN users u ON u.id = sp.user_id
     WHERE sp.user_id != ?
       AND sp.allow_versus = 1
       AND sp.status = 'pending'
       AND sp.scheduled_at > NOW()
     ORDER BY sp.scheduled_at ASC
     LIMIT 20"
);
$communityVs->execute([$user['id']]);
$communityVs = $communityVs->fetchAll();

pageHeader('Auto-Post Scheduler');
?>

<style>
/* ── Auto-post page ─────────────────────────────────────────────── */
.ap-header{padding:36px 24px 20px;max-width:1100px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap}
.ap-header h1{font-size:28px;font-weight:800;letter-spacing:-1px}
.ap-header h1 span{color:var(--green)}
.ap-header p{font-size:12px;font-family:var(--font-mono);color:var(--muted);margin-top:4px}

.btn-schedule{background:var(--green);color:#080b12;border:none;border-radius:10px;padding:10px 22px;font-size:13px;font-weight:800;cursor:pointer;display:inline-flex;align-items:center;gap:7px;transition:filter .2s,transform .2s;font-family:var(--font-head)}
.btn-schedule:hover{filter:brightness(1.1);transform:translateY(-1px)}

.ap-wrap{max-width:1100px;margin:0 auto;padding:0 24px 80px}
.ap-section-hd{font-size:16px;font-weight:800;letter-spacing:-.4px;margin-bottom:14px;display:flex;align-items:center;gap:8px}

/* Pending table */
.ap-table{width:100%;border-collapse:collapse;margin-bottom:36px}
.ap-table th{text-align:left;font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:var(--muted);font-family:var(--font-mono);padding:8px 12px;border-bottom:1px solid var(--border)}
.ap-table td{padding:12px 12px;border-bottom:1px solid rgba(255,255,255,.04);vertical-align:middle}
.ap-table tr:last-child td{border-bottom:none}
.ap-row{background:var(--bg2);border-radius:10px}
.ap-row:hover td{background:rgba(255,255,255,.02)}
.ap-title{font-size:13px;font-weight:700}
.ap-time{font-size:11px;font-family:var(--font-mono);color:#a78bfa}
.ap-countdown{font-size:10px;font-family:var(--font-mono);color:var(--muted);margin-top:2px}
.ap-vs-badge{display:inline-flex;align-items:center;gap:3px;font-size:9px;font-weight:700;font-family:var(--font-mono);color:#a78bfa;background:rgba(167,139,250,.1);border:1px solid rgba(167,139,250,.25);border-radius:5px;padding:2px 6px}
.btn-cancel-sched{background:transparent;border:1px solid rgba(255,80,80,.3);color:#ff6b6b;border-radius:8px;padding:5px 12px;font-size:11px;font-weight:700;font-family:var(--font-mono);cursor:pointer;transition:all .15s}
.btn-cancel-sched:hover{background:rgba(255,68,68,.1)}

/* Published grid */
.ap-pub-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px;margin-bottom:40px}
.ap-pub-card{background:var(--bg2);border:1px solid var(--border);border-radius:14px;padding:14px 16px;display:flex;align-items:center;gap:12px;text-decoration:none;color:inherit;transition:border-color .2s}
.ap-pub-card:hover{border-color:rgba(0,255,135,.2)}
.ap-pub-icon{width:38px;height:38px;border-radius:10px;background:rgba(0,255,135,.08);border:1px solid rgba(0,255,135,.15);display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0}
.ap-pub-title{font-size:13px;font-weight:700;line-height:1.3}
.ap-pub-meta{font-size:10px;font-family:var(--font-mono);color:var(--muted);margin-top:2px}

.ap-empty{text-align:center;padding:50px 20px;color:var(--muted);background:var(--bg2);border:1px solid var(--border);border-radius:16px;margin-bottom:30px}
.ap-empty h3{font-size:16px;font-weight:700;color:#fff;margin-bottom:6px}
.ap-empty p{font-size:12px;font-family:var(--font-mono)}

/* Modal */
.modal-bg{position:fixed;inset:0;background:rgba(0,0,0,.75);backdrop-filter:blur(6px);z-index:500;display:none;align-items:center;justify-content:center;padding:20px}
.modal-bg.open{display:flex}
.modal{background:var(--bg2);border:1px solid var(--border);border-radius:20px;width:100%;max-width:680px;max-height:90vh;overflow-y:auto;padding:28px;position:relative}
.modal h2{font-size:20px;font-weight:800;margin-bottom:20px;letter-spacing:-.5px}
.modal-close{position:absolute;top:16px;right:18px;background:none;border:none;color:var(--muted);font-size:22px;cursor:pointer;line-height:1;padding:4px 8px;border-radius:6px}
.modal-close:hover{color:#fff;background:rgba(255,255,255,.07)}
.form-group{margin-bottom:14px}
.form-group label{display:block;font-size:11px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--muted);margin-bottom:6px;font-family:var(--font-mono)}
.form-group input,.form-group textarea{width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:10px;color:#fff;padding:10px 14px;font-size:13px;font-family:var(--font-mono);resize:vertical;transition:border-color .2s;outline:none}
.form-group input:focus,.form-group textarea:focus{border-color:rgba(0,255,135,.4)}
.form-group input[type=datetime-local]{color-scheme:dark}
.tab-bar{display:flex;gap:4px;margin-bottom:8px}
.tab-btn{background:none;border:none;color:var(--muted);font-size:12px;font-weight:700;font-family:var(--font-mono);padding:6px 14px;border-radius:8px;cursor:pointer;transition:color .15s,background .15s}
.tab-btn:hover{color:#fff}
.tab-btn.active{background:rgba(0,255,135,.12);color:var(--green)}
.form-actions{display:flex;gap:10px;justify-content:flex-end;margin-top:18px}
.btn-cancel{background:transparent;border:1px solid var(--border);color:var(--muted);border-radius:10px;padding:10px 20px;font-size:13px;font-weight:700;cursor:pointer;font-family:var(--font-head)}
.btn-cancel:hover{color:#fff}
.btn-submit{background:var(--green);color:#080b12;border:none;border-radius:10px;padding:10px 24px;font-size:13px;font-weight:800;cursor:pointer;font-family:var(--font-head)}

.vs-toggle-row{display:flex;align-items:flex-start;gap:12px;background:rgba(167,139,250,.05);border:1px solid rgba(167,139,250,.2);border-radius:12px;padding:14px;margin-bottom:16px;cursor:pointer;transition:background .15s}
.vs-toggle-row:hover{background:rgba(167,139,250,.09)}
.vs-toggle-row input[type=checkbox]{width:17px;height:17px;margin-top:2px;accent-color:#a78bfa;cursor:pointer;flex-shrink:0}
.vs-toggle-label strong{display:block;font-size:13px;font-weight:700;color:#fff;margin-bottom:3px}
.vs-toggle-label span{font-size:11px;font-family:var(--font-mono);color:var(--muted);line-height:1.5}

/* Countdown timer */
.ap-timer{font-size:11px;font-family:var(--font-mono)}
</style>

<div class="ap-header">
  <div>
    <h1>⏰ Auto-<span>Post</span> Scheduler</h1>
    <p>Schedule your HTML/CSS/JS creations to publish automatically at a specific time</p>
  </div>
  <button class="btn-schedule" onclick="openScheduleModal()">
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
    Schedule Post
  </button>
</div>

<div class="ap-wrap">

  <!-- Pending scheduled posts -->
  <div class="ap-section-hd">⏳ Scheduled (<?= count($pending) ?>)</div>
  <?php if (empty($pending)): ?>
    <div class="ap-empty">
      <h3>No scheduled posts</h3>
      <p>Schedule your first post to publish it automatically.</p>
    </div>
  <?php else: ?>
    <table class="ap-table">
      <thead>
        <tr>
          <th>Title</th>
          <th>Scheduled For</th>
          <th>Code</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($pending as $sp): ?>
          <tr class="ap-row">
            <td>
              <div class="ap-title"><?= e(mb_strimwidth($sp['title'],0,60,'…')) ?></div>
              <?php if ($sp['allow_versus']): ?>
                <span class="ap-vs-badge">⚔ Versus OK</span>
              <?php endif; ?>
            </td>
            <td>
              <div class="ap-time"><?= date('M j, Y @ H:i', strtotime($sp['scheduled_at'])) ?></div>
              <div class="ap-countdown" id="cd-<?= $sp['id'] ?>" data-ts="<?= strtotime($sp['scheduled_at']) ?>">calculating…</div>
            </td>
            <td>
              <span style="font-size:10px;font-family:var(--font-mono);color:var(--muted)">
                <?= $sp['html_code'] ? '🟡 HTML ' : '' ?>
                <?= $sp['css_code'] ? '🔵 CSS ' : '' ?>
                <?= $sp['js_code'] ? '🟢 JS' : '' ?>
              </span>
            </td>
            <td>
              <button class="btn-cancel-sched" onclick="cancelScheduled(<?= (int)$sp['id'] ?>,this)">Cancel</button>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>

  <!-- Published posts -->
  <?php if (!empty($published)): ?>
    <div class="ap-section-hd" style="margin-top:8px">✅ Auto-Published (<?= count($published) ?>)</div>
    <div class="ap-pub-grid">
      <?php foreach ($published as $sp): ?>
        <<?= $sp['showcase_post_id'] ? 'a href="showcase.php?id='.$sp['showcase_post_id'].'"' : 'div' ?> class="ap-pub-card">
          <div class="ap-pub-icon">✅</div>
          <div>
            <div class="ap-pub-title"><?= e(mb_strimwidth($sp['title'],0,50,'…')) ?></div>
            <div class="ap-pub-meta">Published <?= date('M j, Y @ H:i', strtotime($sp['scheduled_at'])) ?></div>
          </div>
        </<?= $sp['showcase_post_id'] ? 'a' : 'div' ?>>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <!-- ── Community Versus Schedules ─────────────────────────────────────────── -->
  <?php if (!empty($communityVs)): ?>
  <div class="ap-section-hd" style="margin-top:32px">
    ⚔️ Community Versus Schedules
    <span style="font-size:11px;font-weight:400;color:var(--muted);margin-left:8px">Posts from other users open for Versus battles</span>
  </div>
  <div style="margin-bottom:12px;font-size:12px;font-family:var(--font-mono);color:var(--muted);line-height:1.6">
    These scheduled posts have <strong style="color:#a78bfa">Versus mode enabled</strong>. When they publish, you can join a battle using them as the target design.
  </div>
  <table class="ap-table">
    <thead>
      <tr>
        <th>Creator</th>
        <th>Post Title</th>
        <th>Publishes At</th>
        <th>Time Left</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($communityVs as $cvs): ?>
      <tr class="ap-row">
        <td style="font-size:12px;font-weight:700"><?= e($cvs['username'] ?? 'Unknown') ?></td>
        <td>
          <div class="ap-title"><?= e(mb_strimwidth($cvs['title'],0,60,'…')) ?></div>
          <span class="ap-vs-badge">⚔ Versus OK</span>
        </td>
        <td>
          <div class="ap-time"><?= date('M j, Y @ H:i', strtotime($cvs['scheduled_at'])) ?></div>
        </td>
        <td>
          <div class="ap-countdown" id="cvs-cd-<?= $cvs['id'] ?>" data-ts="<?= strtotime($cvs['scheduled_at']) ?>">calculating…</div>
        </td>
        <td>
          <a href="lobby.php" style="display:inline-flex;align-items:center;gap:5px;background:rgba(167,139,250,.12);color:#a78bfa;border:1px solid rgba(167,139,250,.25);border-radius:8px;padding:5px 12px;font-size:11px;font-weight:700;text-decoration:none">
            ⚔️ Join Battle
          </a>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <?php else: ?>
  <div class="ap-section-hd" style="margin-top:32px">⚔️ Community Versus Schedules</div>
  <div class="ap-empty" style="margin-bottom:20px">
    <p style="color:var(--muted);font-size:13px">No community Versus schedules right now. When other users schedule posts with <strong style="color:#a78bfa">Versus mode ON</strong>, they will appear here so you can plan a battle around them.</p>
  </div>
  <?php endif; ?>

</div>

<!-- Schedule Post Modal -->
<div class="modal-bg" id="scheduleModal">
  <div class="modal">
    <button class="modal-close" onclick="closeScheduleModal()">✕</button>
    <h2>⏰ Schedule a Post</h2>

    <div class="form-group">
      <label>Title *</label>
      <input type="text" id="schedTitle" placeholder="e.g. My animated button" maxlength="120">
    </div>
    <div class="form-group">
      <label>Description</label>
      <input type="text" id="schedDesc" placeholder="Short description (optional)" maxlength="300">
    </div>
    <div class="form-group">
      <label>📅 Publish At *</label>
      <input type="datetime-local" id="schedAt">
    </div>

    <label class="vs-toggle-row" for="schedVersus">
      <input type="checkbox" id="schedVersus">
      <div class="vs-toggle-label">
        <strong>⚔ Allow as Versus Reference</strong>
        <span>Other players can use this post as the target design in Versus mode battles</span>
      </div>
    </label>

    <div class="form-group">
      <label>Code</label>
      <div class="tab-bar">
        <button class="tab-btn active" onclick="schedSwitchTab('html',this)">HTML</button>
        <button class="tab-btn" onclick="schedSwitchTab('css',this)">CSS</button>
        <button class="tab-btn" onclick="schedSwitchTab('js',this)">JS</button>
      </div>
      <textarea id="sched-html" placeholder="<!-- Your HTML here -->" style="min-height:160px;display:block;font-size:12px;line-height:1.5"></textarea>
      <textarea id="sched-css"  placeholder="/* Your CSS here */"  style="min-height:160px;display:none;font-size:12px;line-height:1.5"></textarea>
      <textarea id="sched-js"   placeholder="// Your JS here"     style="min-height:160px;display:none;font-size:12px;line-height:1.5"></textarea>
    </div>

    <div class="form-actions">
      <button class="btn-cancel" onclick="closeScheduleModal()">Cancel</button>
      <button class="btn-submit" onclick="submitScheduled()">⏰ Schedule ✦</button>
    </div>
  </div>
</div>
<script src="assets/security.js"></script>
<script>
// Set minimum datetime-local to now + 1 min
(function(){
  const inp=document.getElementById('schedAt');
  const now=new Date(Date.now()+60000);
  inp.min=now.toISOString().slice(0,16);
  inp.value='';
})();

function openScheduleModal(){ document.getElementById('scheduleModal').classList.add('open'); }
function closeScheduleModal(){ document.getElementById('scheduleModal').classList.remove('open'); }
document.getElementById('scheduleModal').addEventListener('click',function(e){if(e.target===this)closeScheduleModal();});

let schedActiveTab='html';
function schedSwitchTab(tab,btn){
  ['html','css','js'].forEach(t=>{document.getElementById('sched-'+t).style.display=t===tab?'block':'none';});
  document.querySelectorAll('#scheduleModal .tab-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  schedActiveTab=tab;
}

async function submitScheduled(){
  const title=document.getElementById('schedTitle').value.trim();
  const schedAt=document.getElementById('schedAt').value;
  if(!title){showToast('Please enter a title');return;}
  if(!schedAt){showToast('Please pick a publish time');return;}
  if(new Date(schedAt)<=new Date()){showToast('Time must be in the future');return;}
  const fd=new FormData();
  fd.append('action','schedule_post');
  fd.append('title',title);
  fd.append('description',document.getElementById('schedDesc').value.trim());
  fd.append('scheduled_at',schedAt);
  fd.append('html_code',document.getElementById('sched-html').value);
  fd.append('css_code',document.getElementById('sched-css').value);
  fd.append('js_code',document.getElementById('sched-js').value);
  if(document.getElementById('schedVersus').checked) fd.append('allow_versus','1');
  const res=await fetch('autopost.php',{method:'POST',body:fd});
  const data=await res.json();
  if(data.ok){
    showToast('Scheduled! ✦');
    setTimeout(()=>window.location.reload(),900);
  } else {
    showToast(data.msg||'Error');
  }
}

async function cancelScheduled(id, btn){
  if(!confirm('Cancel this scheduled post?'))return;
  btn.disabled=true;btn.textContent='Cancelling…';
  const fd=new FormData();
  fd.append('action','cancel_scheduled');
  fd.append('id',id);
  const res=await fetch('autopost.php',{method:'POST',body:fd});
  const data=await res.json();
  if(data.ok){
    showToast('Cancelled');
    const row=btn.closest('tr');
    if(row) row.style.opacity='0.3';
    setTimeout(()=>window.location.reload(),700);
  } else {
    btn.disabled=false;btn.textContent='Cancel';
    showToast(data.msg||'Error');
  }
}

// Countdown timers
function updateCountdowns(){
  document.querySelectorAll('[id^="cd-"],[id^="cvs-cd-"]').forEach(el=>{
    const ts=parseInt(el.dataset.ts,10)*1000;
    const diff=ts-Date.now();
    if(diff<=0){el.textContent='Publishing soon…';return;}
    const h=Math.floor(diff/3600000);
    const m=Math.floor((diff%3600000)/60000);
    const s=Math.floor((diff%60000)/1000);
    el.textContent=`in ${h?h+'h ':''} ${m?m+'m ':''} ${s}s`;
  });
}
updateCountdowns();
setInterval(updateCountdowns,1000);
</script>

<?php pageFooter(); ?>
