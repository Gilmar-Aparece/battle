<?php
// ─── menu_builder.php — Visual Menu / UI Builder ─────────────────────
require_once 'includes/config.php';
requireLogin();
$user = auth();

// ── Safe migrations ───────────────────────────────────────────────────────────
(function() {
    try {
        $d    = db();
        $cols = $d->query("SHOW COLUMNS FROM users")->fetchAll(PDO::FETCH_COLUMN);
        if (!in_array('ui_disabled',            $cols)) $d->exec("ALTER TABLE users ADD COLUMN ui_disabled tinyint(1) NOT NULL DEFAULT 0");
        if (!in_array('menu_builder_disabled',  $cols)) $d->exec("ALTER TABLE users ADD COLUMN menu_builder_disabled tinyint(1) NOT NULL DEFAULT 0");
        if (!in_array('folio_edit_allowed',     $cols)) $d->exec("ALTER TABLE users ADD COLUMN folio_edit_allowed tinyint(1) NOT NULL DEFAULT 0");
    } catch (Exception $e) {}
})();

// ── Admin controls: check if user has UI or builder restrictions ──────
$_ubRow = db()->prepare('SELECT ui_disabled, menu_builder_disabled FROM users WHERE id=?');
$_ubRow->execute([$user['id']]);
$_ubData         = $_ubRow->fetch();
$uiDisabled      = !empty($_ubData['ui_disabled']);
$builderDisabled = !empty($_ubData['menu_builder_disabled']);

if ($builderDisabled) {
    http_response_code(403);
    ?><!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>Access Restricted</title>
      <style>
        body { background:#080b12; color:#e8eaf0; font-family:sans-serif;
               display:flex; align-items:center; justify-content:center;
               min-height:100vh; flex-direction:column; gap:16px; }
        h1 { font-size:26px; color:#ff2d6f; }
        p  { color:#5a6380; font-size:14px; }
        a  { color:#00ff87; }
      </style>
    </head>
    <body>
      <h1>🚫 Menu Builder Access Restricted</h1>
      <p>An admin has disabled your access to the Menu Builder.</p>
      <p><a href="versus.php">← Back to Versus</a></p>
    </body>
    </html>
    <?php
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Menu Builder — codeMe Versus</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="menu_builder.css">
  <style>
    /* ── codeMe Versus top bar ── */
    #cm-topbar {
      position: fixed; top: 0; left: 0; right: 0; height: 40px; z-index: 9999;
      background: #080b12; border-bottom: 1px solid rgba(0,255,135,0.15);
      display: flex; align-items: center; padding: 0 16px; gap: 16px;
      font-family: 'Space Mono', monospace; font-size: 11px;
    }
    #cm-topbar .cm-logo { font-weight: 700; color: #fff; letter-spacing: -0.5px; }
    #cm-topbar .cm-logo span { color: #00ff87; }
    #cm-topbar .cm-sep { color: rgba(255,255,255,0.15); }
    #cm-topbar .cm-badge {
      background: rgba(0,255,135,0.1); border: 1px solid rgba(0,255,135,0.25);
      color: #00ff87; padding: 2px 8px; border-radius: 4px; font-size: 10px; font-weight: 700;
    }
    #cm-topbar .cm-user { color: #5a6380; margin-left: auto; }
    #cm-topbar .cm-back {
      color: #5a6380; text-decoration: none; font-size: 10px;
      border: 1px solid rgba(255,255,255,0.08); padding: 3px 10px; border-radius: 4px;
      transition: color .2s, border-color .2s;
    }
    #cm-topbar .cm-back:hover { color: #fff; border-color: rgba(255,255,255,0.2); }
    /* push builder panels below topbar */
    body { padding-top: 40px; }
    /* Override back link inside builder widget panel */
    .elements-panel .header a[href*="versus"] { display: none; }
  </style>
</head>
<body>

<!-- ── codeMe top bar ── -->
<div id="cm-topbar">
  <span class="cm-logo">code<span>Me</span></span>
  <span class="cm-sep">|</span>
  <span class="cm-badge">Menu Builder</span>
  <span class="cm-user">👤 <?= e($user['username']) ?></span>
  <a href="versus.php" class="cm-back">← Back to Versus</a>
</div>

<!-- ═══════════════════════════════════════════════════════ -->
<!--  LEFT PANEL — Widgets                                   -->
<!-- ═══════════════════════════════════════════════════════ -->
<div class="panel elements-panel">
  <div class="header" style="display:flex;justify-content:space-between;align-items:center;">
    <span>Widgets</span>
    <a href="versus.php" style="font-size:9px;">← Back</a>
  </div>

  <div class="widgets-grid">

    <!-- Basic -->
    <div class="widget-section-label">Basic</div>

    <div class="draggable" draggable="true" data-html="<h2>Heading</h2>">
      <span class="widget-icon">H</span>Heading
    </div>
    <div class="draggable" draggable="true" data-html="<p>Paragraph text goes here.</p>">
      <span class="widget-icon">¶</span>Text
    </div>
    <div class="draggable" draggable="true" data-html="<button>Button</button>">
      <span class="widget-icon">⬜</span>Button
    </div>
    <div class="draggable" draggable="true" data-html="<ul style='list-style:none;padding:0;'><li style='margin-bottom:10px;'>✔ Feature One</li><li style='margin-bottom:10px;'>✔ Feature Two</li><li style='margin-bottom:10px;'>✔ Feature Three</li></ul>">
      <span class="widget-icon">☰</span>List
    </div>
    <div class="draggable" draggable="true" data-type="image" data-html="<img src='img/logo.svg' class='pb-image-widget' style='width:100%;height:auto;'>">
      <span class="widget-icon">🖼</span>Image
    </div>
    <div class="draggable" draggable="true" data-html="<textarea placeholder='Textarea...' style='width:100%;min-height:80px;padding:8px;border:1px solid #d1d5db;border-radius:6px;'></textarea>">
      <span class="widget-icon">📝</span>Textarea
    </div>

    <!-- Layout -->
    <div class="widget-section-label">Layout</div>

    <div class="draggable" draggable="true" data-html="<section style='padding:40px 20px;background:#f8fafc;'>Section Content</section>">
      <span class="widget-icon">📦</span>Section
    </div>
    <div class="draggable" draggable="true" data-html="<article style='padding:20px;'><h2>Article Title</h2><p>Content...</p></article>">
      <span class="widget-icon">📰</span>Article
    </div>
    <div class="draggable" draggable="true" data-html="<aside style='padding:16px;background:#f1f5f9;border-left:3px solid #6366f1;'>Aside content</aside>">
      <span class="widget-icon">📋</span>Aside
    </div>
    <div class="draggable" draggable="true" data-html="<header style='padding:20px;background:#0b0e14;color:white;'>Header</header>">
      <span class="widget-icon">🔝</span>Header
    </div>
    <div class="draggable" draggable="true" data-html="<footer style='padding:20px;background:#0b0e14;color:#9ca3af;text-align:center;'>Footer</footer>">
      <span class="widget-icon">🔚</span>Footer
    </div>
    <div class="draggable" draggable="true" data-html="<nav style='padding:12px 20px;background:#f8fafc;display:flex;gap:16px;'>Nav</nav>">
      <span class="widget-icon">🧭</span>Nav
    </div>
    <div class="draggable" draggable="true" data-html="<details style='padding:12px;border:1px solid #e5e7eb;border-radius:8px;'><summary style='cursor:pointer;font-weight:600;'>Click to expand</summary><p style='margin-top:10px;color:#6b7280;'>Hidden details...</p></details>">
      <span class="widget-icon">🔍</span>Details
    </div>
    <div class="draggable" draggable="true" data-html="<hr style='border:none;border-top:1px solid #e5e7eb;margin:20px 0;'>">
      <span class="widget-icon">—</span>Divider
    </div>

    <!-- Typography -->
    <div class="widget-section-label">Typography</div>

    <div class="draggable" draggable="true" data-html="<abbr title='Abbreviation' style='border-bottom:1px dotted;cursor:help;'>Abbr.</abbr>">
      <span class="widget-icon">ab</span>Abbr
    </div>
    <div class="draggable" draggable="true" data-html="<address style='font-style:italic;color:#6b7280;'>123 Main St, City</address>">
      <span class="widget-icon">📍</span>Address
    </div>
    <div class="draggable" draggable="true" data-html="<code style='background:#f1f5f9;padding:2px 6px;border-radius:4px;font-family:monospace;'>console.log('hello');</code>">
      <span class="widget-icon">&lt;/&gt;</span>Code
    </div>
    <div class="draggable" draggable="true" data-html="<pre style='background:#1e293b;color:#a5b4fc;padding:16px;border-radius:8px;overflow-x:auto;font-size:13px;'>Preformatted\n  Text</pre>">
      <span class="widget-icon">📄</span>Pre
    </div>
    <div class="draggable" draggable="true" data-html="<mark style='background:#fef08a;padding:2px 4px;border-radius:2px;'>Highlighted Text</mark>">
      <span class="widget-icon">🖍</span>Mark
    </div>
    <div class="draggable" draggable="true" data-html="<del style='color:#9ca3af;'>Deleted Text</del>">
      <span class="widget-icon">~~</span>Delete
    </div>
    <div class="draggable" draggable="true" data-html="<small style='font-size:12px;color:#9ca3af;'>Disclaimer text here.</small>">
      <span class="widget-icon">s</span>Small
    </div>
    <div class="draggable" draggable="true" data-html="<blockquote style='border-left:4px solid #6366f1;padding:12px 20px;margin:0;background:#f5f3ff;color:#4b5563;font-style:italic;'>&ldquo;Quote text here...&rdquo;</blockquote>">
      <span class="widget-icon">"</span>Quote
    </div>

    <!-- Tables & Data -->
    <div class="widget-section-label">Tables & Data</div>

    <div class="draggable" draggable="true" data-html="<table style='width:100%;border-collapse:collapse;'><thead><tr style='background:#f8fafc;'><th style='padding:10px;border:1px solid #e5e7eb;text-align:left;'>Header 1</th><th style='padding:10px;border:1px solid #e5e7eb;text-align:left;'>Header 2</th></tr></thead><tbody><tr><td style='padding:10px;border:1px solid #e5e7eb;'>Cell 1</td><td style='padding:10px;border:1px solid #e5e7eb;'>Cell 2</td></tr></tbody></table>">
      <span class="widget-icon">📊</span>Table
    </div>
    <div class="draggable" draggable="true" data-html="<div style='padding:8px 0;'><progress value='70' max='100' style='width:100%;height:8px;'></progress><span style='font-size:12px;color:#6b7280;'>70%</span></div>">
      <span class="widget-icon">⏳</span>Progress
    </div>
    <div class="draggable" draggable="true" data-html="<meter value='0.6' style='width:100%;'></meter>">
      <span class="widget-icon">🌡</span>Meter
    </div>

    <!-- Multimedia -->
    <div class="widget-section-label">Multimedia</div>

    <div class="draggable" draggable="true" data-html="<audio controls style='width:100%;'><source src='audio.mp3' type='audio/mpeg'></audio>">
      <span class="widget-icon">🎵</span>Audio
    </div>
    <div class="draggable" draggable="true" data-html="<iframe src='about:blank' style='width:100%;height:200px;border:1px solid #e5e7eb;border-radius:8px;'></iframe>">
      <span class="widget-icon">🖼</span>Iframe
    </div>
    <div class="draggable" draggable="true" data-html="<canvas style='border:1px solid #e5e7eb;border-radius:8px;width:100%;height:120px;'></canvas>">
      <span class="widget-icon">🎨</span>Canvas
    </div>
    <div class="draggable" draggable="true" data-html="<svg viewBox='0 0 100 100' style='width:80px;height:80px;'><circle cx='50' cy='50' r='40' fill='#6366f1'/></svg>">
      <span class="widget-icon">♾</span>SVG
    </div>

    <!-- Inputs -->
    <div class="widget-section-label">Inputs</div>

    <div class="draggable" draggable="true" data-html="<input type='text' placeholder='Input Text' style='padding:10px 14px;border:1px solid #d1d5db;border-radius:6px;width:100%;font-size:14px;box-sizing:border-box;'>">
      <span class="widget-icon">Aa</span>Text
    </div>
    <div class="draggable" draggable="true" data-html="<input type='password' placeholder='Password' style='padding:10px 14px;border:1px solid #d1d5db;border-radius:6px;width:100%;font-size:14px;box-sizing:border-box;'>">
      <span class="widget-icon">🔒</span>Password
    </div>
    <div class="draggable" draggable="true" data-html="<input type='email' placeholder='Email' style='padding:10px 14px;border:1px solid #d1d5db;border-radius:6px;width:100%;font-size:14px;box-sizing:border-box;'>">
      <span class="widget-icon">@</span>Email
    </div>
    <div class="draggable" draggable="true" data-html="<input type='number' placeholder='0' style='padding:10px 14px;border:1px solid #d1d5db;border-radius:6px;width:100%;font-size:14px;box-sizing:border-box;'>">
      <span class="widget-icon">#</span>Number
    </div>
    <div class="draggable" draggable="true" data-html="<input type='range' min='0' max='100' style='width:100%;'>">
      <span class="widget-icon">↔</span>Range
    </div>
    <div class="draggable" draggable="true" data-html="<input type='tel' placeholder='Phone Number' style='padding:10px 14px;border:1px solid #d1d5db;border-radius:6px;width:100%;font-size:14px;box-sizing:border-box;'>">
      <span class="widget-icon">📞</span>Phone
    </div>
    <div class="draggable" draggable="true" data-html="<input type='url' placeholder='https://' style='padding:10px 14px;border:1px solid #d1d5db;border-radius:6px;width:100%;font-size:14px;box-sizing:border-box;'>">
      <span class="widget-icon">🔗</span>URL
    </div>
    <div class="draggable" draggable="true" data-html="<input type='date' style='padding:10px 14px;border:1px solid #d1d5db;border-radius:6px;width:100%;font-size:14px;box-sizing:border-box;'>">
      <span class="widget-icon">📅</span>Date
    </div>
    <div class="draggable" draggable="true" data-html="<input type='time' style='padding:10px 14px;border:1px solid #d1d5db;border-radius:6px;width:100%;font-size:14px;box-sizing:border-box;'>">
      <span class="widget-icon">🕒</span>Time
    </div>
    <div class="draggable" draggable="true" data-html="<input type='color' style='width:48px;height:48px;border:none;cursor:pointer;border-radius:6px;'>">
      <span class="widget-icon">🎨</span>Color
    </div>
    <div class="draggable" draggable="true" data-html="<input type='file' style='font-size:13px;'>">
      <span class="widget-icon">📁</span>File
    </div>
    <div class="draggable" draggable="true" data-html="<label style='display:flex;align-items:center;gap:8px;cursor:pointer;font-size:14px;'><input type='checkbox' style='width:16px;height:16px;cursor:pointer;'>Checkbox</label>">
      <span class="widget-icon">☑</span>Checkbox
    </div>
    <div class="draggable" draggable="true" data-html="<label style='display:flex;align-items:center;gap:8px;cursor:pointer;font-size:14px;'><input type='radio' style='width:16px;height:16px;cursor:pointer;'>Radio</label>">
      <span class="widget-icon">🔘</span>Radio
    </div>

    <hr style="border:none;border-top:1px solid var(--border);margin:4px 0;grid-column:1/-1;">

    <!-- Components -->
    <div class="widget-section-label">Components</div>

    <!-- Navbar Component -->
    <div class="draggable" draggable="true" data-type="navbar"
      data-html="<nav class='pb-navbar'><div class='pb-logo-container'><div class='pb-nav-text-logo' contenteditable='true'>LOGO</div></div><button class='pb-nav-toggle' onclick='pbToggleMobile(this)'>☰</button><ul class='pb-nav-list'><li>Home</li><li>About</li><li>Services</li><li class='pb-has-dropdown'>Dropdown<ul class='pb-dropdown'><li>Item One</li><li>Item Two</li></ul></li><li class='pb-nav-cta'>Get Started</li></ul></nav><div class='pb-mobile-drawer' id='pb-drawer'><button class='pb-drawer-close' onclick='pbCloseMobile()'>✕</button><ul class='pb-mobile-nav-list'><li>Home</li><li>About</li><li>Services</li><li onclick='pbToggleSubMenu(this)'>Dropdown<ul class='pb-mobile-dropdown'><li>Item One</li><li>Item Two</li></ul></li><li style='color:#22c55e;font-weight:600;'>Get Started</li></ul></div><div class='pb-drawer-overlay' onclick='pbCloseMobile()'></div>">
      <span class="widget-icon">≡</span>Navbar
    </div>

    <!-- Carousel Component -->
    <div class="draggable" draggable="true" data-type="carousel"
      data-html="<div class='pb-carousel'><div class='pb-slides'><img src='img/banner.png' class='active' alt='Slide 1'></div><div class='pb-prev' onclick='pbMoveSlide(this,-1)'>&#10094;</div><div class='pb-next' onclick='pbMoveSlide(this,1)'>&#10095;</div><div class='pb-dots'></div></div>">
      <span class="widget-icon">◀▶</span>Carousel
    </div>

    <!-- Footer Component -->
    <div class="draggable" draggable="true" data-type="footer"
      data-html="<footer class='pb-footer'><div class='pb-footer-grid'><div class='pb-footer-brand'><h3>MyBrand</h3><p>Building amazing digital experiences with modern tools and passionate teams.</p></div><div class='pb-footer-col'><h4>Company</h4><ul><li>Home</li><li>About Us</li><li>Services</li><li>Contact</li></ul></div><div class='pb-footer-col'><h4>Services</h4><ul><li>Web Design</li><li>Development</li><li>Marketing</li><li>SEO</li></ul></div><div class='pb-footer-col'><h4>Follow Us</h4><ul><li>Twitter</li><li>LinkedIn</li><li>GitHub</li><li>Instagram</li></ul></div></div><div class='pb-footer-bottom'><span>© 2025 MyBrand. All Rights Reserved.</span><div class='pb-footer-socials'><a title='Twitter'>𝕏</a><a title='LinkedIn'>in</a><a title='GitHub'>⌬</a></div></div></footer>">
      <span class="widget-icon">🔚</span>Footer
    </div>

    <!-- Registration Form -->
    <div class="draggable" draggable="true" data-type="form"
      data-html="<form class='pb-reg-form'><h3>Join Us</h3><input type='text' name='fullname' placeholder='Full Name'><input type='email' name='user_email' placeholder='Email Address'><button type='button'>Submit</button></form>">
      <span class="widget-icon">📋</span>Reg Form
    </div>

    <!-- Input Field -->
    <div class="draggable" draggable="true" data-type="input"
      data-html="<input type='text' class='pb-input-widget' name='custom_field' placeholder='Input Field'>">
      <span class="widget-icon">▭</span>Input Field
    </div>

    <!-- Card -->
    <div class="draggable" draggable="true"
      data-html="<div class='pb-card' style='background:#fff;border:1px solid #e5e7eb;border-radius:12px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,0.06);'><div style='background:#6366f1;height:120px;'></div><div style='padding:20px;'><h3 style='margin:0 0 8px;font-size:1rem;color:#111;'>Card Title</h3><p style='color:#6b7280;font-size:14px;margin:0;'>Card description text goes here with more detail.</p><button style='margin-top:16px;padding:8px 18px;background:#6366f1;color:white;border:none;border-radius:6px;cursor:pointer;font-size:13px;font-weight:600;'>Learn More</button></div></div>">
      <span class="widget-icon">🃏</span>Card
    </div>

    <!-- Alert -->
    <div class="draggable" draggable="true"
      data-html="<div class='pb-alert' style='padding:14px 18px;background:#eff6ff;border:1px solid #bfdbfe;border-radius:8px;border-left:4px solid #3b82f6;display:flex;gap:10px;align-items:flex-start;'><span style='font-size:16px;'>ℹ️</span><div><strong style='color:#1e40af;font-size:14px;'>Info</strong><p style='margin:4px 0 0;color:#1e40af;font-size:13px;'>This is an alert message for the user.</p></div></div>">
      <span class="widget-icon">⚠</span>Alert
    </div>

    <!-- Badge -->
    <div class="draggable" draggable="true"
      data-html="<span class='pb-badge' style='display:inline-block;padding:4px 12px;background:#6366f1;color:white;border-radius:20px;font-size:12px;font-weight:600;letter-spacing:0.04em;'>Badge</span>">
      <span class="widget-icon">🏷</span>Badge
    </div>

    <!-- Video Embed -->
    <div class="draggable" draggable="true"
      data-html="<div style='position:relative;padding-bottom:56.25%;height:0;overflow:hidden;border-radius:12px;background:#000;'><iframe style='position:absolute;top:0;left:0;width:100%;height:100%;border:none;' src='https://www.youtube.com/embed/dQw4w9WgXcQ' allowfullscreen></iframe></div>">
      <span class="widget-icon">▶</span>Video
    </div>

    <!-- Bootstrap 3-Column Card Grid -->
    <div class="draggable" draggable="true" data-type="bs-card-grid"
      data-html="<section class='pb-bs-card-grid' style='padding:60px 20px;background:#f8fafc;'><div class='container' style='max-width:1200px;margin:0 auto;'><div class='row g-4'><div class='col-lg-4 col-md-6 col-12'><div class='card h-100 border-0 shadow-sm' style='border-radius:12px;overflow:hidden;'><div style='background:#6366f1;height:160px;'></div><div class='card-body p-4'><h5 class='card-title fw-bold'>Card Title</h5><p class='card-text text-muted'>Card description text goes here with more detail about this feature or service.</p><a href='#' class='btn btn-primary mt-2' style='background:#6366f1;border-color:#6366f1;border-radius:6px;'>Learn More</a></div></div></div><div class='col-lg-4 col-md-6 col-12'><div class='card h-100 border-0 shadow-sm' style='border-radius:12px;overflow:hidden;'><div style='background:#22c55e;height:160px;'></div><div class='card-body p-4'><h5 class='card-title fw-bold'>Card Title</h5><p class='card-text text-muted'>Card description text goes here with more detail about this feature or service.</p><a href='#' class='btn btn-success mt-2' style='border-radius:6px;'>Learn More</a></div></div></div><div class='col-lg-4 col-md-6 col-12'><div class='card h-100 border-0 shadow-sm' style='border-radius:12px;overflow:hidden;'><div style='background:#f59e0b;height:160px;'></div><div class='card-body p-4'><h5 class='card-title fw-bold'>Card Title</h5><p class='card-text text-muted'>Card description text goes here with more detail about this feature or service.</p><a href='#' class='btn btn-warning mt-2' style='border-radius:6px;'>Learn More</a></div></div></div></div></div></section>">
      <span class="widget-icon">⊞</span>Cards 3Col
    </div>

    <!-- FolioOne Hero Banner -->
    <div class="draggable" draggable="true" data-type="folio-hero"
      data-html="<section class='pb-folio-hero' style='padding:80px 20px;background:linear-gradient(135deg,#f8f9fa 0%,#e9ecef 100%);'><div style='max-width:1200px;margin:0 auto;display:flex;align-items:center;gap:40px;flex-wrap:wrap;'><div style='flex:1;min-width:300px;'><h1 style='font-size:2.5rem;font-weight:700;color:#111;margin-bottom:12px;'>Hello, I&apos;m <span style='color:#6366f1;'>Your Name</span></h1><p style='font-size:1.1rem;color:#6b7280;margin-bottom:28px;line-height:1.7;'>Creative professional building amazing digital experiences with passion and modern tools.</p><div style='display:flex;gap:12px;flex-wrap:wrap;'><a href='#' style='padding:12px 28px;background:#6366f1;color:white;border-radius:8px;text-decoration:none;font-weight:600;font-size:15px;'>View My Work</a><a href='#' style='padding:12px 28px;border:2px solid #6366f1;color:#6366f1;border-radius:8px;text-decoration:none;font-weight:600;font-size:15px;'>Get In Touch</a></div></div><div style='flex:0 0 320px;text-align:center;'><div style='width:280px;height:280px;border-radius:50%;background:linear-gradient(135deg,#6366f1,#8b5cf6);margin:0 auto;display:flex;align-items:center;justify-content:center;font-size:80px;color:white;box-shadow:0 20px 60px rgba(99,102,241,0.3);overflow:hidden;'><img class='pb-hero-img' src='' style='width:100%;height:100%;object-fit:cover;display:none;border-radius:50%;'><span class='pb-hero-placeholder'>👤</span></div></div></div></section>">
      <span class="widget-icon">🌟</span>Hero Banner
    </div>

  </div>
</div><!-- /elements-panel -->


<!-- ═══════════════════════════════════════════════════════ -->
<!--  CENTER-LEFT PANEL — Code Editor                        -->
<!-- ═══════════════════════════════════════════════════════ -->
<div class="panel editor-panel">

  <div class="editor-toolbar header">
    <span>Code Editor</span>
    <div class="btn-group">
      <?php if (!$uiDisabled): ?>
      <button onclick="document.getElementById('folderInput').click()" class="btn btn-ghost">⬆ Import</button>
      <input type="file" id="folderInput" webkitdirectory multiple style="display:none;" onchange="importProjectFolder(this.files)">
      <button onclick="openExportModal()" class="btn btn-primary">⬇ Export</button>
      <?php else: ?>
      <!-- UI controls disabled by admin — export/import hidden -->
      <span style="font-size:10px;color:#5a6380;padding:4px 8px;border:1px solid rgba(255,140,66,.2);border-radius:6px;color:#ff8c42;">
        🚫 Export Disabled
      </span>
      <?php endif; ?>
    </div>
  </div>

  <!-- File list shown after import -->
  <div id="fileList">
    <label>Imported Files</label>
    <div id="fileItems"></div>
  </div>

  <!-- Code Tabs: Explorer / HTML / CSS / JS -->
  <div class="tabs">
    <div class="tab active" onclick="switchTab('explorer', event)">Explorer</div>
    <?php if (!$uiDisabled): ?>
    <div class="tab" onclick="switchTab('html', event)">HTML</div>
    <div class="tab" onclick="switchTab('css', event)">CSS</div>
    <div class="tab" onclick="switchTab('js', event)">JS</div>
    <?php endif; ?>
  </div>

  <!-- Explorer view (file tree) -->
  <div id="explorerView" style="display:block;">
    <div style="padding:8px;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;">
      <span style="font-size:9px;color:var(--text-muted);text-transform:uppercase;letter-spacing:.1em;font-weight:700;">Files</span>
      <div class="dropdown">
        <button class="new-btn" onclick="toggleNewMenu()">+ New</button>
        <div class="dropdown-content" id="newDropdown">
          <a href="#" onclick="addNewFile();return false;">📄 New File</a>
          <a href="#" onclick="addNewFolder();return false;">📁 New Folder</a>
        </div>
      </div>
    </div>
    <div id="fileTree" class="file-tree" style="padding:6px;">
      <div style="font-size:11px;color:var(--text-muted);padding:16px;text-align:center;line-height:1.6;">
        No files yet.<br>
        Import a project folder or<br>create a new file above.
      </div>
    </div>
  </div>

  <!-- Code output areas -->
  <textarea id="htmlCode" style="display:none;" readonly spellcheck="false" placeholder="HTML will appear here..."></textarea>
  <textarea id="cssCode"  style="display:none;" readonly spellcheck="false" placeholder="CSS will appear here..."></textarea>
  <textarea id="jsCode"   style="display:none;" readonly spellcheck="false" placeholder="JS will appear here..."></textarea>

</div><!-- /editor-panel -->


<!-- ═══════════════════════════════════════════════════════ -->
<!--  CENTER PANEL — Live Preview                            -->
<!-- ═══════════════════════════════════════════════════════ -->
<div class="panel preview-panel">

  <div class="preview-header">
    <div class="preview-label">
      <span class="live-dot"></span>
      Live Preview
    </div>
    <div style="display:flex;gap:6px;align-items:center;">
      <button id="back-to-builder-btn" onclick="backToBuilder()"
        style="display:none;background:var(--surface3);border:1px solid var(--border);color:var(--text-dim);padding:4px 10px;font-size:10px;font-weight:600;border-radius:3px;cursor:pointer;font-family:inherit;letter-spacing:.04em;">
        ← Builder
      </button>
      <button id="folioEditorBtn" onclick="openFolioEditor()"
        style="display:none;background:rgba(99,102,241,.15);border:1px solid rgba(99,102,241,.4);color:#a5b4fc;padding:4px 12px;font-size:10px;font-weight:700;border-radius:3px;cursor:pointer;font-family:inherit;letter-spacing:.04em;align-items:center;gap:5px;">
        🎨 Edit FolioOne
      </button>
      <div class="viewport-controls">
        <button onclick="setViewport('desktop')" id="vp-desktop" class="vp-active">🖥 Desktop</button>
        <button onclick="setViewport('tablet')"  id="vp-tablet">⬜ Tablet</button>
        <button onclick="setViewport('mobile')"  id="vp-mobile">📱 Mobile</button>
      </div>
    </div>
  </div>

  <!-- Import live preview iframe (shown when a file is imported) -->
  <iframe id="import-preview-frame" style="display:none;width:100%;height:calc(100% - 41px);border:none;background:white;" allow="same-origin"></iframe>

  <div id="preview-wrapper">
    <div id="preview-content" onclick="selectItem(this,'Global Body',event)">
      <div id="preview"></div>
      <div id="add-section-panel">
        <button class="plus-btn" onclick="openLayoutModal(null)" title="Add Section">+</button>
      </div>
    </div>
  </div>

</div><!-- /preview-panel -->


<!-- ═══════════════════════════════════════════════════════ -->
<!--  RIGHT PANEL — Style Editor                             -->
<!-- ═══════════════════════════════════════════════════════ -->
<div class="panel style-panel">
  <div class="header">Editor</div>

  <div class="style-panel-inner">

    <!-- Active element indicator -->
    <div class="editing-indicator">
      <span class="dot"></span>
      <span>Editing: <span id="activeLabel">Global Body</span></span>
    </div>

    <!-- Widget-specific settings (Navbar / Carousel / Form / Image) -->
    <div id="widgetSettings" style="display:none;margin-bottom:14px;">
      <span class="widget-settings-header">Widget Settings</span>
      <div id="navbarStructure"></div>
      <button onclick="addNavLink()" id="addNavLinkBtn"
        style="display:none;width:calc(100% - 20px);margin:8px 10px 10px;padding:8px;background:var(--accent);color:white;border:none;border-radius:var(--radius-sm);cursor:pointer;font-size:11px;font-weight:600;font-family:inherit;">
        + Add Nav Link
      </button>
    </div>

    <!-- FolioOne Live Editor Panel -->
    <div id="folioEditorPanel" style="display:none;margin-bottom:14px;">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;">
        <span class="widget-settings-header" style="margin:0;">🎨 FolioOne Editor</span>
        <button onclick="document.getElementById('folioEditorPanel').style.display='none'"
          style="background:none;border:none;color:var(--text-muted);cursor:pointer;font-size:16px;line-height:1;">×</button>
      </div>
      <!-- Section tabs -->
      <div id="folioTabBar" style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:10px;"></div>
      <!-- Section content -->
      <div id="folioTabContent"></div>
    </div>

    <!-- Custom CSS Input -->
    <div class="style-group">
      <label>Custom CSS</label>
      <textarea class="custom-css-area" id="cssInput"
        placeholder="background: #fff;&#10;color: #111;&#10;padding: 20px;"
        oninput="applyCSS()"></textarea>
    </div>

    <!-- Pseudo State Selector -->
    <div class="style-group">
      <label>Target State</label>
      <select id="pseudoSelector" onchange="loadCurrentCSS()">
        <option value="main">Default (Normal)</option>
        <option value="hover">Hover (:hover)</option>
        <option value="active">Active (:active)</option>
        <option value="nth-child(1)">First Child</option>
        <option value="nth-child(2)">Second Child</option>
        <option value="nth-child(even)">Even Children</option>
        <option value="nth-child(odd)">Odd Children</option>
      </select>
    </div>

    <p class="help-text">Click an element in the preview to edit its CSS. Click empty space to style the page body.</p>

    <!-- JS Editor -->
    <div class="style-group">
      <label>JS Mode</label>
      <select id="jsModeSelector" onchange="applyJS()" style="margin-bottom:8px;">
        <option value="click">On Click (Function)</option>
        <option value="raw">Raw JS (Global/Data)</option>
      </select>

      <label>Custom JS</label>
      <textarea class="custom-css-area" id="jsInput"
        placeholder="alert('Clicked!');"
        oninput="applyJS()"
        style="color:#86efac;"></textarea>
      <p id="jsHint" class="help-text" style="margin-top:4px;">Code runs when this widget is clicked.</p>
    </div>

  </div>
</div><!-- /style-panel -->


<!-- ═══════════════════════════════════════════════════════ -->
<!--  FACEBOOK FOLLOW MODAL  (blocks app until followed)    -->
<!-- ═══════════════════════════════════════════════════════ -->
<div id="fbFollowModal" style="
  position:fixed;inset:0;z-index:999999;
  background:rgba(0,0,0,0.92);
  backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);
  display:flex;align-items:center;justify-content:center;
  font-family:'Outfit',sans-serif;">

  <!-- Mobile: friendly redirect notice instead of blocking modal -->
  <div id="fb-mobile-notice" style="display:none;width:100%;max-width:340px;margin:20px;background:#111318;border:1px solid rgba(255,255,255,0.09);border-radius:20px;overflow:hidden;text-align:center;padding:32px 24px;">
    <div style="font-size:36px;margin-bottom:12px;">📱</div>
    <div style="color:#e2e4f0;font-size:1rem;font-weight:700;margin-bottom:8px;">Desktop Recommended</div>
    <div style="color:#6b7280;font-size:13px;line-height:1.7;margin-bottom:20px;">Pro Builder is designed for desktop use. For the best experience, open this on a computer.</div>
    <button onclick="fbConfirmFollowed()" style="width:100%;padding:12px;background:linear-gradient(135deg,#6366f1,#818cf8);color:white;border:none;border-radius:12px;font-size:14px;font-weight:700;cursor:pointer;font-family:'Outfit',sans-serif;">Continue Anyway</button>
  </div>

  <div id="fb-desktop-card" style="
    width:100%;max-width:400px;margin:20px;
    background:#111318;
    border:1px solid rgba(255,255,255,0.09);
    border-radius:20px;overflow:hidden;
    box-shadow:0 32px 80px rgba(0,0,0,0.8);">

    <!-- Blue header -->
    <div style="background:linear-gradient(135deg,#1877f2 0%,#0a52d4 100%);padding:32px 28px 24px;text-align:center;">
      <div style="width:72px;height:72px;background:white;border-radius:50%;margin:0 auto 16px;display:flex;align-items:center;justify-content:center;box-shadow:0 6px 24px rgba(0,0,0,0.3);">
        <svg width="40" height="40" viewBox="0 0 24 24" fill="#1877f2"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
      </div>
      <div style="color:white;font-size:1.25rem;font-weight:700;margin-bottom:8px;">Follow to Unlock</div>
      <div style="color:rgba(255,255,255,0.8);font-size:13px;line-height:1.6;">Follow my Facebook page Gilmar Aparece to<br>get full access to this app.</div>
    </div>

    <!-- Body -->
    <div style="padding:24px 28px 28px;">

      <!-- Page preview row -->
      <div style="display:flex;align-items:center;gap:12px;padding:14px;background:#1a1d28;border-radius:12px;border:1px solid rgba(255,255,255,0.07);margin-bottom:20px;">
        <div style="width:46px;height:46px;border-radius:50%;background:#1877f2;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
          <svg width="26" height="26" viewBox="0 0 24 24" fill="white"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
        </div>
        <div style="flex:1;">
          <div style="font-weight:600;color:#e2e4f0;font-size:14px;" id="fb-page-name">Facebook Page</div>
          <div style="color:#6b7280;font-size:12px;margin-top:2px;" id="fb-page-handle">facebook.com</div>
        </div>
        <div style="background:#1877f2;color:white;padding:7px 16px;border-radius:20px;font-size:12px;font-weight:700;">👍 Follow</div>
      </div>

      <!-- Step message -->
      <div id="fb-step-msg" style="text-align:center;font-size:12px;color:#6b7280;margin-bottom:18px;line-height:1.7;padding:0 4px;">
        Click below to open Facebook &amp; follow the page.<br>The app will unlock automatically when you return.
      </div>

      <!-- Main CTA button -->
      <button id="fb-main-btn" onclick="fbOpenPage()" style="
        width:100%;padding:14px;
        background:linear-gradient(135deg,#1877f2,#0a52d4);
        color:white;border:none;border-radius:12px;
        font-size:15px;font-weight:700;cursor:pointer;
        font-family:'Outfit',sans-serif;
        display:flex;align-items:center;justify-content:center;gap:10px;
        transition:opacity .18s,transform .15s;
        box-shadow:0 6px 24px rgba(24,119,242,0.45);"
        onmouseover="this.style.opacity='.88';this.style.transform='translateY(-1px)'"
        onmouseout="this.style.opacity='1';this.style.transform='translateY(0)'">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="white"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
        Follow on Facebook &amp; Continue
      </button>

      <!-- Shown after tab returns -->
      <div id="fb-already-row" style="display:none;margin-top:14px;text-align:center;">
        <button onclick="fbConfirmFollowed()" style="
          background:none;border:1px solid rgba(255,255,255,0.12);
          color:#9ca3af;font-size:12px;padding:9px 22px;
          border-radius:8px;cursor:pointer;font-family:'Outfit',sans-serif;
          transition:all .18s;"
          onmouseover="this.style.borderColor='rgba(255,255,255,0.35)';this.style.color='#e2e4f0'"
          onmouseout="this.style.borderColor='rgba(255,255,255,0.12)';this.style.color='#9ca3af'">
          ✓ I already followed — Enter App
        </button>
      </div>

    </div>
  </div>
</div>


<!-- ═══════════════════════════════════════════════════════ -->
<!--  MOBILE NOTICE BANNER (shown on small screens only)    -->
<!-- ═══════════════════════════════════════════════════════ -->
<div class="mobile-builder-notice">
  📱 Pro Builder works best on desktop. Switch to a larger screen for the full editor experience.
</div>


<!-- ═══════════════════════════════════════════════════════ -->
<!--  LAYOUT MODAL                                           -->
<!-- ═══════════════════════════════════════════════════════ -->
<div class="modal-overlay" id="layoutModal">
  <div class="modal-content">
    <div class="modal-header">Choose Column Structure</div>
    <div class="layout-grid-selector">

      <div class="layout-option" onclick="applyStructure('1-col')" title="1 Column">
        <div class="l-icon"><div></div></div>
      </div>

      <div class="layout-option" onclick="applyStructure('2-col')" title="2 Columns">
        <div class="l-icon" style="grid-template-columns:1fr 1fr;">
          <div></div><div></div>
        </div>
      </div>

      <div class="layout-option" onclick="applyStructure('3-col')" title="3 Columns">
        <div class="l-icon" style="grid-template-columns:1fr 1fr 1fr;">
          <div></div><div></div><div></div>
        </div>
      </div>

      <div class="layout-option" onclick="applyStructure('stack')" title="Stack (2 rows)">
        <div class="l-icon" style="grid-template-rows:1fr 1fr;">
          <div></div><div></div>
        </div>
      </div>

      <div class="layout-option" onclick="applyStructure('split')" title="Split 2/1">
        <div class="l-icon" style="grid-template-columns:2fr 1fr;">
          <div></div>
          <div style="display:grid;gap:2px;background:none;padding:0;">
            <div style="background:var(--surface3);"></div>
            <div style="background:var(--surface3);"></div>
          </div>
        </div>
      </div>

      <div class="layout-option" onclick="applyStructure('complex')" title="Complex Grid">
        <div class="l-icon" style="grid-template-columns:1fr 1fr;grid-template-rows:1fr 1fr;">
          <div></div><div></div>
          <div style="grid-column:span 2;"></div>
        </div>
      </div>

    </div>
  </div>
</div>


<!-- ═══════════════════════════════════════════════════════ -->
<!--  JAVASCRIPT ENGINE                                      -->
<!-- ═══════════════════════════════════════════════════════ -->
 <script src="assets/security.js"></script>
<script>
'use strict';

/* ═══════════════════════════════════════════════════════
   STATE & DOM REFERENCES
   ═══════════════════════════════════════════════════════ */

const preview        = document.getElementById('preview');
const previewContent = document.getElementById('preview-content');
const htmlCode       = document.getElementById('htmlCode');
const cssCode        = document.getElementById('cssCode');
const jsCode         = document.getElementById('jsCode');
const cssInput       = document.getElementById('cssInput');
const activeLabel    = document.getElementById('activeLabel');
const layoutModal    = document.getElementById('layoutModal');

let selected           = previewContent;
let modalTargetSection = null;
let activeNavbar       = null;

const counts = { section: 0, container: 0, column: 0, widget: 0 };

const widgetScripts   = new Map();
const widgetJSModes   = new Map();
const pseudoStyles    = new Map();
let   projectFiles    = {};


/* ═══════════════════════════════════════════════════════
   DRAG — Init widget drag from panel
   ═══════════════════════════════════════════════════════ */

document.querySelectorAll('.draggable').forEach(el => {
  el.addEventListener('dragstart', e => {
    e.dataTransfer.setData('html', el.dataset.html);
    e.dataTransfer.setData('type', el.dataset.type || 'generic');
  });

  // ── TOUCH DRAG (mobile) ─────────────────────────────────
  let touchClone = null, touchHtml = null, touchType = null;

  el.addEventListener('touchstart', e => {
    touchHtml = el.dataset.html;
    touchType = el.dataset.type || 'generic';

    // Create a ghost clone to follow the finger
    touchClone = el.cloneNode(true);
    touchClone.style.cssText = `
      position:fixed;z-index:99999;opacity:0.85;pointer-events:none;
      width:${el.offsetWidth}px;transform:scale(1.08);
      box-shadow:0 8px 24px rgba(99,102,241,0.5);
      border:2px solid #6366f1;border-radius:6px;background:#1e2230;
    `;
    document.body.appendChild(touchClone);

    const t = e.touches[0];
    touchClone.style.left = (t.clientX - el.offsetWidth / 2) + 'px';
    touchClone.style.top  = (t.clientY - el.offsetHeight / 2) + 'px';
  }, { passive: true });

  el.addEventListener('touchmove', e => {
    if (!touchClone) return;
    e.preventDefault();
    const t = e.touches[0];
    touchClone.style.left = (t.clientX - el.offsetWidth / 2) + 'px';
    touchClone.style.top  = (t.clientY - el.offsetHeight / 2) + 'px';

    // Highlight the column under the finger
    touchClone.style.display = 'none';
    const under = document.elementFromPoint(t.clientX, t.clientY);
    touchClone.style.display = '';
    document.querySelectorAll('.column.touch-over').forEach(c => c.classList.remove('touch-over'));
    if (under) {
      const col = under.closest('.column');
      if (col) col.classList.add('touch-over');
    }
  }, { passive: false });

  el.addEventListener('touchend', e => {
    if (!touchClone) return;
    const t = e.changedTouches[0];

    // Find drop target
    touchClone.style.display = 'none';
    const under = document.elementFromPoint(t.clientX, t.clientY);
    touchClone.style.display = '';
    document.body.removeChild(touchClone);
    touchClone = null;
    document.querySelectorAll('.column.touch-over').forEach(c => c.classList.remove('touch-over'));

    if (!under) return;
    const dropCol = under.closest('.column');
    if (dropCol && touchHtml) {
      dropWidget(dropCol, touchHtml, touchType);
    }
  }, { passive: true });
});


/* ═══════════════════════════════════════════════════════
   VIEWPORT TOGGLE
   ═══════════════════════════════════════════════════════ */

function setViewport(device) {
  previewContent.classList.remove('view-mobile', 'view-tablet', 'view-desktop');
  ['desktop', 'tablet', 'mobile'].forEach(d => {
    const btn = document.getElementById('vp-' + d);
    if (btn) btn.classList.remove('vp-active');
  });

  if (device === 'mobile')      previewContent.classList.add('view-mobile');
  else if (device === 'tablet') previewContent.classList.add('view-tablet');
  else                          previewContent.classList.add('view-desktop');

  const activeBtn = document.getElementById('vp-' + device);
  if (activeBtn) activeBtn.classList.add('vp-active');
}


/* ═══════════════════════════════════════════════════════
   TAB SWITCHER
   ═══════════════════════════════════════════════════════ */

function switchTab(type, event) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  event.currentTarget.classList.add('active');

  const allViews = ['explorerView', 'htmlCode', 'cssCode', 'jsCode'];
  allViews.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = 'none';
  });

  if (type === 'explorer') {
    document.getElementById('explorerView').style.display = 'block';
  } else {
    document.getElementById(type + 'Code').style.display = 'block';
  }
}


/* ═══════════════════════════════════════════════════════
   IMPORT — Open folder, load files, preview index.html
   ═══════════════════════════════════════════════════════ */

async function importProjectFolder(files) {
  if (!files || files.length === 0) return;

  let firstHTML = '', firstCSS = '', firstJS = '';
  let indexFound = false;
  projectFiles = {};

  const fileItemsContainer = document.getElementById('fileItems');
  fileItemsContainer.innerHTML = '';
  document.getElementById('fileList').style.display = 'block';

  const fileTree = document.getElementById('fileTree');
  fileTree.innerHTML = '';

  // Collect all file contents first (CSS/JS needed for HTML preview)
  const rawFiles = {};
  const readPromises = Array.from(files).map(file => {
    return file.text().then(content => { rawFiles[file.name] = content; });
  });
  await Promise.all(readPromises);

  // Build combined CSS and JS for pages that link external files
  let combinedCSS = '', combinedJS = '';
  for (const [name, content] of Object.entries(rawFiles)) {
    if (name.endsWith('.css')) combinedCSS += content + '\n';
    if (name.endsWith('.js'))  combinedJS  += content + '\n';
  }

  for (const [name, content] of Object.entries(rawFiles)) {
    if (name.endsWith('.html')) {
      // Build a self-contained version by inlining external refs
      const selfContained = inlineExternalRefs(content, rawFiles);
      projectFiles[name] = { raw: content, selfContained };

      if (name === 'index.html' || !indexFound) {
        firstHTML  = selfContained;
        indexFound = (name === 'index.html');
      }

      // File list entry
      const item = document.createElement('div');
      item.style = 'padding:5px 8px;font-size:11px;color:var(--text-dim);cursor:pointer;border-radius:3px;transition:background .15s;display:flex;align-items:center;gap:6px;';
      item.innerHTML = '<span style="color:#e34c26;font-size:9px;font-weight:700;">HTML</span> ' + name;
      item.onclick   = () => loadFileToEditor(name);
      item.onmouseover = () => item.style.background = 'var(--surface3)';
      item.onmouseout  = () => item.style.background = 'transparent';
      fileItemsContainer.appendChild(item);

      // Tree entry
      const treeItem = document.createElement('div');
      treeItem.className = 'tree-item';
      treeItem.innerHTML = '<span style="color:#e34c26;font-size:9px;font-weight:700;margin-right:4px;">HTML</span>' + name;
      treeItem.onclick   = () => loadFileToEditor(name);
      fileTree.appendChild(treeItem);

    } else if (name.endsWith('.css')) {
      projectFiles[name] = { raw: content };
      const treeItem = document.createElement('div');
      treeItem.className = 'tree-item';
      treeItem.innerHTML = '<span style="color:#264de4;font-size:9px;font-weight:700;margin-right:4px;">CSS</span>' + name;
      fileTree.appendChild(treeItem);

    } else if (name.endsWith('.js')) {
      projectFiles[name] = { raw: content };
      const treeItem = document.createElement('div');
      treeItem.className = 'tree-item';
      treeItem.innerHTML = '<span style="color:#f7df1e;font-size:9px;font-weight:700;margin-right:4px;">JS</span>' + name;
      fileTree.appendChild(treeItem);
    }
  }

  // Show raw source in code editor tabs
  const parser = new DOMParser();
  const doc = parser.parseFromString(firstHTML, 'text/html');
  let css = '', js = '';
  doc.querySelectorAll('style').forEach(s => { css += s.textContent + '\n'; });
  doc.querySelectorAll('script').forEach(s => { if (!s.src) js += s.textContent + '\n'; });
  htmlCode.value = doc.body ? doc.body.innerHTML.trim() : '';
  cssCode.value  = css.trim();
  jsCode.value   = js.trim();

  // Show in live preview via iframe
  syncImportToPreview(firstHTML);

  // Switch to explorer tab
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.tab')[0].classList.add('active');
  document.getElementById('explorerView').style.display = 'block';
  document.getElementById('htmlCode').style.display     = 'none';
  document.getElementById('cssCode').style.display      = 'none';
  document.getElementById('jsCode').style.display       = 'none';

  // Reset the file input so re-importing works
  document.getElementById('folderInput').value = '';
}

/* Inline <link rel="stylesheet"> and <script src=""> references if we have those files */
function inlineExternalRefs(htmlContent, rawFiles) {
  const parser = new DOMParser();
  const doc    = parser.parseFromString(htmlContent, 'text/html');

  // Inline linked stylesheets
  doc.querySelectorAll('link[rel="stylesheet"]').forEach(link => {
    const href = link.getAttribute('href');
    const fname = href ? href.split('/').pop() : '';
    if (fname && rawFiles[fname]) {
      const style = document.createElement('style');
      style.textContent = rawFiles[fname];
      link.replaceWith(style);
    }
  });

  // Inline external scripts
  doc.querySelectorAll('script[src]').forEach(script => {
    const src   = script.getAttribute('src');
    const fname = src ? src.split('/').pop() : '';
    if (fname && rawFiles[fname]) {
      const newScript = document.createElement('script');
      newScript.textContent = rawFiles[fname];
      script.replaceWith(newScript);
    }
  });

  return '<!DOCTYPE html>' + doc.documentElement.outerHTML;
}

/* Load a specific imported file into the editor and preview */
function loadFileToEditor(fileName) {
  const data = projectFiles[fileName];
  if (!data) return;

  // Highlight active file in file list
  document.querySelectorAll('#fileItems div').forEach(div => {
    const isActive = div.innerText.includes(fileName);
    div.style.color      = isActive ? 'var(--accent)' : 'var(--text-dim)';
    div.style.background = isActive ? 'var(--surface2)' : 'transparent';
  });

  // Show raw source in code tabs
  if (data.raw) {
    const parser = new DOMParser();
    const doc    = parser.parseFromString(data.raw, 'text/html');
    let css = '', js = '';
    doc.querySelectorAll('style').forEach(s  => { css += s.textContent + '\n'; });
    doc.querySelectorAll('script').forEach(s => { if (!s.src) js += s.textContent + '\n'; });
    htmlCode.value = doc.body ? doc.body.innerHTML.trim() : '';
    cssCode.value  = css.trim();
    jsCode.value   = js.trim();
  } else {
    htmlCode.value = '';
    cssCode.value  = data.css || '';
    jsCode.value   = data.js  || '';
  }

  if (data.selfContained) syncImportToPreview(data.selfContained);
}

/* Render a full HTML page into the live preview iframe */
function syncImportToPreview(fullHTML) {
  const frame       = document.getElementById('import-preview-frame');
  const wrapper     = document.getElementById('preview-wrapper');
  const backBtn     = document.getElementById('back-to-builder-btn');

  // Show iframe, hide the builder canvas
  frame.style.display   = 'block';
  wrapper.style.display = 'none';
  if (backBtn) backBtn.style.display = 'block';

  // Write the full HTML document into the iframe
  frame.srcdoc = fullHTML;
}

/* Return to the drag-and-drop builder canvas */
function backToBuilder() {
  const frame   = document.getElementById('import-preview-frame');
  const wrapper = document.getElementById('preview-wrapper');
  const backBtn = document.getElementById('back-to-builder-btn');
  frame.style.display   = 'none';
  wrapper.style.display = 'flex';
  if (backBtn) backBtn.style.display = 'none';
}

/* Re-bind click handlers on imported elements */
function rebindImportedElements() {
  const previewDiv = document.getElementById('preview');
  if (!previewDiv || document.getElementById('preview-wrapper').style.display === 'none') return;

  previewDiv.querySelectorAll('section').forEach(sec => {
    counts.section++;
    sec.onclick = e => selectItem(sec, `Imported Section ${counts.section}`, e);
  });

  previewDiv.querySelectorAll('*').forEach(el => {
    if (!el.onclick) {
      el.onclick = e => { e.stopPropagation(); selectItem(el, `Element: ${el.tagName.toLowerCase()}`, e); };
    }
  });
}

/* File tree helpers */
function addNewFile() {
  const fileName = prompt('Enter file name (e.g. about.html):', 'page.html');
  if (!fileName) return;
  projectFiles[fileName] = { html: '', css: '', js: '' };

  const fileTree = document.getElementById('fileTree');
  const emptyMsg = fileTree.querySelector('div[style]');
  if (emptyMsg) emptyMsg.remove();

  const item = document.createElement('div');
  item.className = 'tree-item';
  item.innerHTML = '📄 ' + fileName;
  item.onclick   = () => loadFileToEditor(fileName);
  fileTree.appendChild(item);
  loadFileToEditor(fileName);
}

function addNewFolder() {
  const name = prompt('Enter folder name:', 'New Folder');
  if (!name) return;
  const fileTree = document.getElementById('fileTree');
  const item = document.createElement('div');
  item.className = 'tree-item';
  item.innerHTML = '📁 <span contenteditable="true">' + name + '</span>';
  item.style.color = '#dcb67a';
  fileTree.appendChild(item);
}

function toggleNewMenu() {
  document.getElementById('newDropdown').classList.toggle('show');
}

window.addEventListener('click', e => {
  if (!e.target.matches('.new-btn')) {
    document.querySelectorAll('.dropdown-content.show').forEach(d => d.classList.remove('show'));
  }
});


/* ═══════════════════════════════════════════════════════
   EXPORT — Download complete HTML file
   ═══════════════════════════════════════════════════════ */

function downloadCode() {
  // Ask user for custom filename
  let exportName = prompt('Enter a filename for the export:', 'my-website') || 'my-website';
  exportName = exportName.replace(/\.html$/i, '').trim() || 'my-website';
  const fileName = exportName + '.html';

  // If we're in import-preview mode, export the currently loaded file
  const frame = document.getElementById('import-preview-frame');
  if (frame.style.display !== 'none' && frame.srcdoc) {
    const blob = new Blob([frame.srcdoc], { type: 'text/html' });
    const a    = document.createElement('a');
    a.href     = URL.createObjectURL(blob);
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { document.body.removeChild(a); URL.revokeObjectURL(a.href); }, 0);
    return;
  }

  // Builder mode export
  const exportClone = preview.cloneNode(true);

  // Strip builder UI elements
  exportClone.querySelectorAll('.section-controls, .plus-btn, .widget-actions, .top-plus-btn').forEach(el => el.remove());
  // Unwrap widget-wrapper divs (builder containers) keeping their inner content
  exportClone.querySelectorAll('.widget-wrapper').forEach(wrapper => {
    while (wrapper.firstChild) wrapper.parentNode.insertBefore(wrapper.firstChild, wrapper);
    wrapper.remove();
  });
  exportClone.querySelectorAll('*').forEach(el => {
    el.removeAttribute('contenteditable');
    el.removeAttribute('draggable');
    el.classList.remove('dragging-section', 'selected', 'selected-global');
    if (el.getAttribute('class') === '') el.removeAttribute('class');
  });

  // Remove builder-only dashed borders from sections and columns
  exportClone.querySelectorAll('.section, .container, .container-advanced, .column').forEach(el => {
    const s = el.getAttribute('style') || '';
    // Remove dashed border that is builder UI
    el.setAttribute('style', s.replace(/border:\s*1px dashed[^;]*;?/g, '').trim());
  });

  // Detect which widgets are actually on the canvas
  const exportHasNavbar   = !!exportClone.querySelector('.pb-navbar');
  const exportHasCarousel = !!exportClone.querySelector('.pb-carousel');
  const exportHasForm     = !!exportClone.querySelector('.pb-reg-form');
  const exportHasFooter   = !!exportClone.querySelector('.pb-footer');

  const navbarCSS = exportHasNavbar ? `
/* Navbar */
.pb-navbar         { display: flex; align-items: center; justify-content: space-between; padding: 0 32px; height: 64px; background: #0b0e14; position: relative; z-index: 1000; }
.pb-logo-container { display: flex; align-items: center; }
.pb-nav-text-logo  { font-weight: 700; font-size: 1.25rem; color: #6366f1; }
.pb-nav-list       { list-style: none; display: flex; align-items: center; gap: 4px; margin: 0; padding: 0; }
.pb-nav-list > li  { position: relative; padding: 8px 14px; font-size: 14px; color: #d1d5db; border-radius: 6px; cursor: pointer; transition: all .18s; }
.pb-nav-list > li:hover { color: white; background: rgba(255,255,255,.05); }
.pb-nav-cta        { background: #22c55e !important; color: white !important; border-radius: 20px !important; padding: 8px 18px !important; font-weight: 600 !important; }
.pb-nav-cta:hover  { background: #16a34a !important; }
.pb-has-dropdown::after { content: ' ▾'; font-size: 10px; opacity: 0.6; }
.pb-dropdown       { display: none; position: absolute; top: calc(100% + 6px); left: 0; background: rgba(13,17,23,.97); min-width: 200px; padding: 6px; border-radius: 10px; border: 1px solid rgba(255,255,255,.08); list-style: none; box-shadow: 0 20px 40px rgba(0,0,0,.5); z-index: 9999; }
.pb-nav-list > li:hover > .pb-dropdown { display: block; }
.pb-dropdown li    { padding: 9px 14px; color: #9ca3af; font-size: 13px; border-radius: 6px; cursor: pointer; transition: all .15s; }
.pb-dropdown li:hover { background: rgba(99,102,241,.15); color: #a5b4fc; }
.pb-nav-toggle     { display: none; background: rgba(255,255,255,.06); border: 1px solid rgba(255,255,255,.1); color: white; padding: 8px 12px; border-radius: 6px; cursor: pointer; font-size: 18px; }
.pb-mobile-drawer  { display: none; position: fixed; top: 0; right: -100%; width: 280px; height: 100vh; background: #0b0e14; flex-direction: column; padding: 24px 24px 40px; transition: right .35s cubic-bezier(.4,0,.2,1); box-shadow: -10px 0 40px rgba(0,0,0,.6); z-index: 99999; overflow-y: auto; }
.pb-mobile-drawer.open { right: 0; display: flex; }
.pb-drawer-close   { align-self: flex-end; background: transparent; border: none; color: #9ca3af; font-size: 22px; cursor: pointer; margin-bottom: 24px; }
.pb-mobile-nav-list { list-style: none; display: flex; flex-direction: column; gap: 2px; padding: 0; margin: 0; }
.pb-mobile-nav-list > li { padding: 12px 16px; color: #d1d5db; font-size: 15px; border-radius: 6px; cursor: pointer; }
.pb-mobile-nav-list > li:hover { background: rgba(255,255,255,.06); }
.pb-mobile-dropdown { list-style: none; padding: 4px 0 4px 16px; display: none; border-left: 2px solid rgba(99,102,241,.3); margin-top: 4px; }
.pb-mobile-dropdown.open { display: block; }
.pb-drawer-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,.6); z-index: 99998; }
.pb-drawer-overlay.open { display: block; }
@media (max-width: 768px) {
  .pb-nav-toggle { display: block; }
  .pb-nav-list   { display: none !important; }
}` : '';

  const carouselCSS = exportHasCarousel ? `
/* Carousel */
.pb-carousel  { position: relative; width: 100%; overflow: hidden; min-height: 240px; background: #1a1a2e; }
.pb-slides img { width: 100%; display: none; object-fit: cover; }
.pb-slides img.active { display: block; animation: slideIn .4s ease; }
@keyframes slideIn { from { opacity:0; transform:scale(1.02); } to { opacity:1; transform:scale(1); } }
.pb-prev, .pb-next { position:absolute; top:50%; transform:translateY(-50%); background:rgba(0,0,0,.5); border:1px solid rgba(255,255,255,.1); color:white; width:40px; height:40px; border-radius:50%; display:flex; align-items:center; justify-content:center; cursor:pointer; z-index:10; font-size:16px; transition:all .2s; margin:0 10px; }
.pb-next { right:0; }
.pb-prev:hover, .pb-next:hover { background:#6366f1; border-color:#6366f1; }` : '';

  const formCSS = exportHasForm ? `
/* Registration Form */
.pb-reg-form         { display:flex; flex-direction:column; gap:12px; padding:28px; border:1px solid #e5e7eb; border-radius:12px; max-width:360px; background:#fff; box-shadow:0 4px 24px rgba(0,0,0,.06); }
.pb-reg-form h3      { margin:0 0 4px; font-size:1.2rem; color:#111; }
.pb-reg-form input   { padding:11px 14px; border:1px solid #d1d5db; border-radius:6px; font-size:14px; outline:none; width:100%; box-sizing:border-box; }
.pb-reg-form input:focus { border-color:#6366f1; }
.pb-reg-form button  { padding:12px; background:#6366f1; color:white; border:none; border-radius:8px; cursor:pointer; font-weight:600; font-size:14px; }
.pb-reg-form button:hover { background:#4f46e5; }` : '';

  const footerCSS = exportHasFooter ? `
/* Footer */
.pb-footer { background:#0b0e14; color:#9ca3af; padding:60px 40px 30px; }
.pb-footer-grid { display:grid; grid-template-columns:2fr 1fr 1fr 1fr; gap:40px; margin-bottom:40px; }
.pb-footer-brand h3 { color:#6366f1; font-size:1.3rem; font-weight:700; margin-bottom:12px; }
.pb-footer-brand p { font-size:13px; line-height:1.7; color:#6b7280; max-width:240px; }
.pb-footer-col h4 { color:#e2e4f0; font-size:13px; font-weight:600; margin-bottom:14px; text-transform:uppercase; letter-spacing:.06em; }
.pb-footer-col ul { list-style:none; display:flex; flex-direction:column; gap:8px; padding:0; margin:0; }
.pb-footer-col ul li { font-size:13px; color:#6b7280; cursor:pointer; transition:color .15s; }
.pb-footer-col ul li:hover { color:#a5b4fc; }
.pb-footer-bottom { display:flex; align-items:center; justify-content:space-between; padding-top:24px; border-top:1px solid rgba(255,255,255,.06); font-size:12px; color:#4b5563; }
.pb-footer-socials { display:flex; gap:12px; }
.pb-footer-socials a { color:#6b7280; font-size:18px; transition:color .15s; cursor:pointer; }
.pb-footer-socials a:hover { color:#a5b4fc; }
@media (max-width:768px) { .pb-footer-grid { grid-template-columns:1fr; } }` : '';

  const fullCode = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${exportName}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
  <style>
/* Layout */
.section           { position: relative; box-sizing: border-box; }
.container         { display: flex; gap: 20px; width: 100%; max-width: 1200px; margin: 0 auto; }
.container-advanced{ display: grid; gap: 20px; width: 100%; max-width: 1200px; margin: 0 auto; }
.column            { flex: 1; min-height: 50px; }
@media (max-width: 768px) { .container { flex-direction: column; } }
${navbarCSS}${carouselCSS}${formCSS}${footerCSS}
/* Custom Styles */
${cssCode.value}
  </style>
</head>
<body>
${exportClone.innerHTML}

<script>
// Mobile menu (drawer-based)
function pbToggleMobile(btn) {
  var drawer  = document.getElementById('pb-drawer');
  var overlay = document.querySelector('.pb-drawer-overlay');
  if (!drawer) return;
  var isOpen = drawer.classList.toggle('open');
  btn.textContent = isOpen ? '\u2715' : '\u2630';
  if (overlay) overlay.classList.toggle('open', isOpen);
}
function pbCloseMobile() {
  var drawer  = document.getElementById('pb-drawer');
  var overlay = document.querySelector('.pb-drawer-overlay');
  if (drawer)  drawer.classList.remove('open');
  if (overlay) overlay.classList.remove('open');
  document.querySelectorAll('.pb-nav-toggle').forEach(function(b){ b.textContent = '\u2630'; });
}
function pbToggleSubMenu(li) {
  var sub = li.querySelector('.pb-mobile-dropdown');
  if (sub) sub.classList.toggle('open');
}
document.addEventListener('keydown', function(e){ if(e.key==='Escape') pbCloseMobile(); });
// Carousel
function pbMoveSlide(btn, dir) {
  var carousel = btn.closest('.pb-carousel');
  var slides   = carousel.querySelectorAll('.pb-slides img');
  if (slides.length <= 1) return;
  var idx = Array.from(slides).findIndex(function(i){ return i.classList.contains('active'); });
  slides[idx].classList.remove('active');
  idx = (idx + dir + slides.length) % slides.length;
  slides[idx].classList.add('active');
}
${jsCode.value}
<\/script>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"><\/script>
<!-- AOS -->
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"><\/script>
<script>if(typeof AOS!=='undefined') AOS.init({duration:800,once:true});<\/script>
</body>
</html>`;

  // ── Submit to approval queue instead of direct download ──────────────
  submitExportForApproval(exportName, fullCode);
}

/* ═══════════════════════════════════════════════════════
   EXPORT APPROVAL SYSTEM
   ═══════════════════════════════════════════════════════ */

// Open modal to confirm submission
function openExportModal() {
  document.getElementById('exportModal').style.display = 'flex';
  document.getElementById('exportFilename').value = 'my-website';
  document.getElementById('exportStatus').textContent = '';
  document.getElementById('exportStatus').className = 'export-status';
}
function closeExportModal() {
  document.getElementById('exportModal').style.display = 'none';
}

// Submit HTML to server for admin approval
async function submitExportForApproval(exportName, htmlContent) {
  const statusEl = document.getElementById('exportStatus');
  const btn      = document.getElementById('exportSubmitBtn');
  if (btn) { btn.disabled = true; btn.textContent = '⏳ Submitting…'; }
  if (statusEl) { statusEl.textContent = 'Uploading to server…'; statusEl.className = 'export-status info'; }

  try {
    const fd = new FormData();
    fd.append('action',   'submit_export');
    fd.append('filename', exportName);
    fd.append('content',  htmlContent);

    const res  = await fetch('menu_builder_api.php', { method: 'POST', body: fd });
    const data = await res.json();

    if (data.ok) {
      if (statusEl) {
        statusEl.textContent = '✅ ' + data.message;
        statusEl.className   = 'export-status success';
      }
      // Store export_id so user can check status later
      localStorage.setItem('last_export_id', data.export_id);
      refreshMyExports();
    } else {
      if (statusEl) {
        statusEl.textContent = '❌ ' + (data.error || 'Submission failed.');
        statusEl.className   = 'export-status error';
      }
    }
  } catch (err) {
    if (statusEl) {
      statusEl.textContent = '❌ Network error: ' + err.message;
      statusEl.className   = 'export-status error';
    }
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = '📤 Submit for Approval'; }
  }
}

// Download an already-approved export
async function downloadApprovedExport(exportId, filename) {
  const url = `menu_builder_api.php?action=download_export&id=${exportId}`;
  const a   = document.createElement('a');
  a.href    = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => document.body.removeChild(a), 0);
}

// Import an approved export directly into the builder
async function importApprovedExport(exportId, filename) {
  try {
    const res  = await fetch(`menu_builder_api.php?action=import_approved&id=${exportId}`);
    const data = await res.json();
    if (!data.ok) {
      alert('Could not load approved file: ' + (data.error || 'Unknown error'));
      return;
    }
    // Close export modal, load into builder
    closeExportModal();
    const frame = document.getElementById('import-preview-frame');
    if (frame) {
      frame.srcdoc       = data.content;
      frame.style.display = 'block';
      document.getElementById('back-to-builder-btn').style.display = 'inline-flex';
      document.getElementById('preview-wrapper').style.display     = 'none';
    }
    // Store in project files so export re-uses it
    projectFiles[data.filename] = { raw: data.content, selfContained: data.content };
    // Update file tree
    const fileTree = document.getElementById('fileTree');
    fileTree.innerHTML = '';
    const item       = document.createElement('div');
    item.className   = 'tree-item';
    item.style.color = 'var(--accent)';
    item.innerHTML   = `<span style="color:#e34c26;font-size:9px;font-weight:700;margin-right:4px;">HTML</span> ${data.filename} ✅`;
    item.onclick     = () => loadFileToEditor(data.filename);
    fileTree.appendChild(item);
    document.getElementById('fileList').style.display = 'block';
  } catch (err) {
    alert('Import failed: ' + err.message);
  }
}

// Fetch and display user's own export history
async function refreshMyExports() {
  const listEl = document.getElementById('myExportsList');
  if (!listEl) return;
  try {
    const res  = await fetch('menu_builder_api.php?action=list_exports');
    const data = await res.json();
    if (!data.ok || !data.exports.length) {
      listEl.innerHTML = '<div style="color:#5a6380;font-size:11px;padding:8px 0">No exports yet.</div>';
      return;
    }
    listEl.innerHTML = data.exports.map(exp => {
      const statusColors = { pending: '#ff8c42', approved: '#00ff87', rejected: '#ff2d6f' };
      const color = statusColors[exp.status] || '#fff';
      const dl = exp.status === 'approved'
        ? `<button onclick="downloadApprovedExport(${exp.id},'${exp.filename}')"
                  style="font-size:10px;padding:3px 8px;border-radius:5px;border:1px solid ${color};
                         background:transparent;color:${color};cursor:pointer;margin-left:6px;">
             ⬇ Download
           </button>
           <button onclick="importApprovedExport(${exp.id},'${exp.filename}')"
                  style="font-size:10px;padding:3px 8px;border-radius:5px;border:1px solid #00c8ff;
                         background:transparent;color:#00c8ff;cursor:pointer;margin-left:4px;">
             📥 Import into Builder
           </button>` : '';
      const note = exp.admin_note
        ? `<div style="font-size:10px;color:#5a6380;margin-top:3px">Note: ${exp.admin_note}</div>` : '';
      return `
        <div style="padding:8px 0;border-bottom:1px solid rgba(255,255,255,.05);font-size:12px">
          <div style="display:flex;align-items:center;justify-content:space-between">
            <span style="font-family:monospace">${exp.filename}</span>
            <span style="color:${color};font-size:10px;font-weight:700;text-transform:uppercase">${exp.status}${dl}</span>
          </div>
          <div style="color:#5a6380;font-size:10px;margin-top:2px">
            Submitted: ${new Date(exp.created_at).toLocaleDateString()}
          </div>
          ${note}
        </div>`;
    }).join('');
  } catch (e) {
    listEl.innerHTML = '<div style="color:#ff2d6f;font-size:11px">Failed to load exports.</div>';
  }
}

/* ═══════════════════════════════════════════════════════
   SECTION MANAGEMENT
   ═══════════════════════════════════════════════════════ */

function openLayoutModal(targetSection = null) {
  modalTargetSection  = targetSection;
  layoutModal.style.display = 'flex';
}

function closeModal() {
  layoutModal.style.display = 'none';
  modalTargetSection = null;
}

window.addEventListener('click', e => {
  if (e.target === layoutModal) closeModal();
});

function createNewSection() {
  counts.section++;
  const sec = document.createElement('section');
  sec.className = `section-${counts.section} section`;
  sec.setAttribute('draggable', 'true');
  sec.onclick = e => selectItem(sec, `Section ${counts.section}`, e);

  const controls   = document.createElement('div');
  controls.className = 'section-controls';
  controls.innerHTML = `
    <div class="drag-handle" title="Drag to reorder">⋮⋮</div>
    <button class="section-del-btn" title="Delete Section">×</button>
  `;
  controls.querySelector('.section-del-btn').onclick = e => {
    e.stopPropagation();
    if (confirm('Delete this entire section?')) { sec.remove(); updateCode(); }
  };

  const plusBtn     = document.createElement('button');
  plusBtn.className = 'plus-btn top-plus-btn';
  plusBtn.innerText = '+';
  plusBtn.title     = 'Add column layout';
  plusBtn.onclick   = e => { e.stopPropagation(); openLayoutModal(sec); };

  sec.appendChild(controls);
  sec.appendChild(plusBtn);
  preview.appendChild(sec);
  return sec;
}

function applyStructure(type) {
  const targetSec = modalTargetSection || createNewSection();
  targetSec.querySelectorAll('.layout-menu, .top-plus-btn').forEach(n => n.remove());

  counts.container++;
  const row = document.createElement('div');
  row.onclick = e => selectItem(row, `Container ${counts.container}`, e);

  let numCols = 1, gridMap = '', isGrid = false;
  switch (type) {
    case '1-col':   numCols = 1; break;
    case '2-col':   numCols = 2; break;
    case '3-col':   numCols = 3; break;
    case 'stack':   numCols = 2; gridMap = 'grid-template-rows:1fr 1fr;';             isGrid = true; break;
    case 'split':   numCols = 2; gridMap = 'grid-template-columns:2fr 1fr;';           isGrid = true; break;
    case 'complex': numCols = 4; gridMap = 'grid-template-columns:1fr 1fr;grid-template-rows:1fr 1fr;'; isGrid = true; break;
  }

  row.className = `container-${counts.container} ${isGrid ? 'container-advanced' : 'container'}`;
  if (gridMap) row.setAttribute('style', gridMap);

  for (let i = 0; i < numCols; i++) {
    counts.column++;
    const col    = document.createElement('div');
    col.className = `column-${counts.column} column`;
    if (type === 'complex' && i === 2) col.style.gridColumn = 'span 2';
    col.onclick   = e => selectItem(col, `Column ${counts.column}`, e);
    setupDropZone(col);
    row.appendChild(col);
  }

  targetSec.appendChild(row);

  const plusBtn     = document.createElement('button');
  plusBtn.className = 'plus-btn top-plus-btn';
  plusBtn.innerText = '+';
  plusBtn.onclick   = e => { e.stopPropagation(); openLayoutModal(targetSec); };
  targetSec.appendChild(plusBtn);

  closeModal();
  updateCode();
}


/* ═══════════════════════════════════════════════════════
   SECTION SORTING (drag to reorder)
   ═══════════════════════════════════════════════════════ */

function initSectionSorting() {
  preview.addEventListener('dragstart', e => {
    if (e.target.tagName === 'SECTION') { e.target.classList.add('dragging-section'); e.dataTransfer.effectAllowed = 'move'; }
  });
  preview.addEventListener('dragend', e => {
    if (e.target.tagName === 'SECTION') { e.target.classList.remove('dragging-section'); updateCode(); }
  });
  preview.addEventListener('dragover', e => {
    e.preventDefault();
    const dragging = document.querySelector('.dragging-section');
    if (!dragging) return;
    const after = getDragAfterElement(preview, e.clientY);
    if (after == null) preview.appendChild(dragging);
    else preview.insertBefore(dragging, after);
  });
}

function getDragAfterElement(container, y) {
  const els = [...container.querySelectorAll('section:not(.dragging-section)')];
  return els.reduce((closest, child) => {
    const box    = child.getBoundingClientRect();
    const offset = y - box.top - box.height / 2;
    if (offset < 0 && offset > closest.offset) return { offset, element: child };
    return closest;
  }, { offset: Number.NEGATIVE_INFINITY }).element;
}

initSectionSorting();


/* ═══════════════════════════════════════════════════════
   WIDGET DROP ZONES
   ═══════════════════════════════════════════════════════ */

function setupDropZone(zone) {
  zone.addEventListener('dragover', e => e.preventDefault());
  zone.addEventListener('drop', e => {
    e.preventDefault();
    e.stopPropagation();
    dropWidget(zone, e.dataTransfer.getData('html'), e.dataTransfer.getData('type'));
  });
}

/* Shared drop logic — called by both mouse drop and touch end */
function dropWidget(zone, html, type) {
  if (!html) return;
  counts.widget++;
  createWidget(zone, html, type);
}

function createWidget(parent, htmlContent, type) {
  const wrapper     = document.createElement('div');
  wrapper.className = `widget-wrapper codeme-${counts.widget}`;

  const overlay       = document.createElement('div');
  overlay.className   = 'widget-actions';
  overlay.innerHTML   = `
    <span class="action-btn pencil" title="Duplicate">❐</span>
    <span class="action-btn trash"  title="Delete">×</span>
  `;

  const content = document.createElement('div');
  content.innerHTML = htmlContent;
  const actualWidget  = content.firstChild;

  if (actualWidget && actualWidget.nodeType === 1) {
    // Only set contentEditable on text-container elements, not media/form/component elements
    const nonEditable = ['IMG','INPUT','SELECT','TEXTAREA','NAV','FORM'];
    const isComponent = actualWidget.classList.contains('pb-navbar') ||
                        actualWidget.classList.contains('pb-carousel') ||
                        actualWidget.classList.contains('pb-footer') ||
                        actualWidget.classList.contains('pb-reg-form') ||
                        actualWidget.classList.contains('pb-mobile-drawer') ||
                        actualWidget.classList.contains('pb-drawer-overlay');
    if (!nonEditable.includes(actualWidget.tagName) && !isComponent) {
      actualWidget.contentEditable = 'true';
    }
    actualWidget.onclick = e => { e.stopPropagation(); selectItem(actualWidget, `Element: ${actualWidget.tagName.toLowerCase()}`, e); };
  }

  wrapper.appendChild(overlay);
  if (actualWidget) wrapper.appendChild(actualWidget);
  parent.appendChild(wrapper);

  overlay.querySelector('.pencil').onclick = e => {
    e.stopPropagation();
    counts.widget++;
    createWidget(parent, actualWidget.outerHTML);
  };
  overlay.querySelector('.trash').onclick = e => {
    e.stopPropagation();
    wrapper.remove();
    updateCode();
  };

  wrapper.onclick = e => selectItem(wrapper, `Widget ${counts.widget}`, e);
  updateCode();
}


/* ═══════════════════════════════════════════════════════
   SELECTION SYSTEM
   ═══════════════════════════════════════════════════════ */

function selectItem(el, label, event) {
  if (event) event.stopPropagation();
  if (selected) selected.classList.remove('selected', 'selected-global');

  selected = el;
  el.classList.add(el === previewContent ? 'selected-global' : 'selected');
  activeLabel.innerText = label;

  document.getElementById('pseudoSelector').value = 'main';
  loadCurrentCSS();

  // Load inline CSS into editor
  const s = el.getAttribute('style') || '';
  cssInput.value = s.split(';').map(x => x.trim()).filter(x => x).join(';\n') + (s ? ';' : '');

  // Load widget JS
  const jsInput  = document.getElementById('jsInput');
  const uid      = findUID(el);
  jsInput.value  = (uid && widgetScripts.has(uid)) ? widgetScripts.get(uid) : '';

  // Widget-specific editor panel — detect which component was clicked
  const find = (cls) => el.classList.contains(cls) ? el : el.querySelector('.' + cls) || el.closest('.' + cls);
  const nav      = find('pb-navbar');
  const carousel = find('pb-carousel');
  const form     = find('pb-reg-form');
  const footer   = find('pb-footer');
  const img      = (el.tagName === 'IMG' && el.classList.contains('pb-image-widget')) ? el : el.querySelector('.pb-image-widget');
  const card     = el.classList.contains('pb-card') ? el : (el.closest('.pb-card') || (el.querySelector('.pb-card')));
  const hero     = find('pb-folio-hero');
  const alert    = find('pb-alert');
  const badge    = find('pb-badge');
  const heading  = ['H1','H2','H3','H4','H5','H6'].includes(el.tagName) ? el : el.querySelector('h1,h2,h3,h4,h5,h6');
  const para     = el.tagName === 'P' ? el : (!heading && el.querySelector('p') ? el.querySelector('p') : null);
  const btn      = el.tagName === 'BUTTON' ? el : el.querySelector('button:not(.widget-actions button):not(.plus-btn):not(.section-del-btn)');
  const list     = ['UL','OL'].includes(el.tagName) ? el : el.querySelector('ul,ol');
  const quote    = el.tagName === 'BLOCKQUOTE' ? el : el.querySelector('blockquote');
  const table    = el.tagName === 'TABLE' ? el : el.querySelector('table');
  const progress = el.tagName === 'PROGRESS' ? el : el.querySelector('progress');
  const meter    = el.tagName === 'METER'    ? el : el.querySelector('meter');
  const details  = el.tagName === 'DETAILS'  ? el : el.querySelector('details');
  const hr       = el.tagName === 'HR'       ? el : el.querySelector('hr');
  const video    = el.querySelector('iframe[src*="youtube"], iframe[src*="vimeo"], video');
  const settingsPanel = document.getElementById('widgetSettings');

  if (nav) {
    settingsPanel.style.display = 'block';
    activeNavbar = nav;
    refreshNavbarEditor();
  } else if (carousel) {
    settingsPanel.style.display = 'block';
    refreshCarouselEditor(el);
  } else if (hero) {
    refreshHeroEditor(hero);
  } else if (footer) {
    refreshFooterEditor(footer);
  } else if (form) {
    refreshFormEditor(el);
  } else if (img) {
    refreshImageEditor(img);
  } else if (card) {
    refreshCardEditor(card);
  } else if (alert) {
    refreshAlertEditor(alert);
  } else if (badge) {
    refreshBadgeEditor(badge);
  } else if (video) {
    refreshVideoEditor(video);
  } else if (table) {
    refreshTableEditor(table);
  } else if (progress) {
    refreshProgressEditor(progress);
  } else if (meter) {
    refreshMeterEditor(meter);
  } else if (details) {
    refreshDetailsEditor(details);
  } else if (hr) {
    refreshDividerEditor(hr);
  } else if (quote) {
    refreshQuoteEditor(quote);
  } else if (list) {
    refreshListEditor(list);
  } else if (heading) {
    refreshHeadingEditor(heading);
  } else if (btn) {
    refreshButtonEditor(btn);
  } else if (para) {
    refreshParaEditor(para);
  } else {
    settingsPanel.style.display = 'none';
    activeNavbar = null;
  }
}

function findUID(el) {
  return Array.from(el.classList).find(c => c.startsWith('codeme-')) ||
         (el.closest('.widget-wrapper') ? Array.from(el.closest('.widget-wrapper').classList).find(c => c.startsWith('codeme-')) : null);
}


/* ═══════════════════════════════════════════════════════
   NAVBAR MOBILE TOGGLE (in-preview functions)
   ═══════════════════════════════════════════════════════ */

function pbToggleMobile(btn) {
  // Search inside the preview div first, then fall back to document
  const ctx = btn.closest('#preview') || document;
  const drawer  = ctx.querySelector('#pb-drawer') || document.getElementById('pb-drawer');
  const overlay = ctx.querySelector('.pb-drawer-overlay') || document.querySelector('.pb-drawer-overlay');
  if (!drawer) return;
  const isOpen = drawer.classList.toggle('open');
  btn.textContent = isOpen ? '✕' : '☰';
  if (overlay) overlay.classList.toggle('open', isOpen);
}

function pbCloseMobile() {
  const ctx = document;
  const drawer  = ctx.getElementById ? ctx.getElementById('pb-drawer') : ctx.querySelector('#pb-drawer');
  const overlay = ctx.querySelector ? ctx.querySelector('.pb-drawer-overlay') : null;
  if (drawer)  { drawer.classList.remove('open'); }
  if (overlay) { overlay.classList.remove('open'); }
  // reset all hamburger buttons
  document.querySelectorAll('.pb-nav-toggle').forEach(b => b.textContent = '☰');
}

function pbToggleSubMenu(li) {
  const sub = li.querySelector('.pb-mobile-dropdown');
  if (sub) sub.classList.toggle('open');
}


/* ═══════════════════════════════════════════════════════
   CAROUSEL LOGIC
   ═══════════════════════════════════════════════════════ */

function pbMoveSlide(btn, dir) {
  const carousel = btn.closest('.pb-carousel');
  const slides   = carousel.querySelectorAll('.pb-slides img');
  if (slides.length <= 1) return;

  let idx = Array.from(slides).findIndex(img => img.classList.contains('active'));
  slides[idx].classList.remove('active');
  idx = (idx + dir + slides.length) % slides.length;
  slides[idx].classList.add('active');

  carousel.querySelectorAll('.pb-dot').forEach((d, i) => {
    d.classList.toggle('pb-dot-active', i === idx);
    d.style.background = i === idx ? 'white' : 'rgba(255,255,255,0.4)';
  });
}

function refreshCarouselEditor(el) {
  const settingsPanel     = document.getElementById('widgetSettings');
  const navStructContainer = document.getElementById('navbarStructure');
  const carousel = el.querySelector('.pb-carousel') || (el.classList.contains('pb-carousel') ? el : null);
  if (!carousel) return;

  settingsPanel.style.display = 'block';
  navStructContainer.innerHTML = '';

  const label        = createEditorLabel('Carousel Slides');
  navStructContainer.appendChild(label);

  const slidesContainer = carousel.querySelector('.pb-slides');
  const images          = slidesContainer.querySelectorAll('img');

  images.forEach((img, index) => {
    const row = document.createElement('div');
    row.style = 'display:flex;align-items:center;gap:8px;margin-bottom:6px;background:var(--surface3);padding:8px;border-radius:var(--radius-sm);cursor:pointer;border:1px solid var(--border);transition:border-color .15s;';
    row.innerHTML = `
      <img src="${img.src}" style="width:32px;height:32px;object-fit:cover;border-radius:3px;flex-shrink:0;">
      <span style="flex:1;font-size:11px;color:var(--text-muted);">Slide ${index + 1}</span>
      <button class="change-img-btn editor-btn">Change</button>
      <input type="file" accept="image/*" style="display:none;">
      <span class="del-slide remove-btn">×</span>
    `;

    row.querySelector('.change-img-btn').onclick = e => { e.stopPropagation(); row.querySelector('input[type=file]').click(); };
    row.querySelector('input[type=file]').onchange = e => {
      const reader = new FileReader();
      reader.onload = ev => { img.src = ev.target.result; row.querySelector('img').src = ev.target.result; updateCode(); };
      reader.readAsDataURL(e.target.files[0]);
    };
    row.querySelector('.del-slide').onclick = e => {
      e.stopPropagation();
      img.remove(); row.remove();
      const remaining = slidesContainer.querySelectorAll('img');
      if (remaining.length > 0 && !slidesContainer.querySelector('.active')) remaining[0].classList.add('active');
      rebuildCarouselDots(carousel);
      updateCode();
    };

    navStructContainer.appendChild(row);
  });

  const addBtn       = document.createElement('button');
  addBtn.className   = 'btn btn-primary';
  addBtn.style       = 'width:100%;margin-top:6px;';
  addBtn.innerText   = '+ Add New Slide';
  addBtn.onclick     = () => {
    const newImg = document.createElement('img');
    newImg.src   = 'img/banner.png';
    newImg.alt   = 'Slide';
    if (slidesContainer.children.length === 0) newImg.className = 'active';
    slidesContainer.appendChild(newImg);
    rebuildCarouselDots(carousel);
    refreshCarouselEditor(el);
    updateCode();
  };
  navStructContainer.appendChild(addBtn);
  rebuildCarouselDots(carousel);
}

function rebuildCarouselDots(carousel) {
  let dotsContainer = carousel.querySelector('.pb-dots');
  if (!dotsContainer) {
    dotsContainer           = document.createElement('div');
    dotsContainer.className = 'pb-dots';
    dotsContainer.style     = 'position:absolute;bottom:12px;left:50%;transform:translateX(-50%);display:flex;gap:6px;z-index:10;';
    carousel.appendChild(dotsContainer);
  }
  dotsContainer.innerHTML = '';

  carousel.querySelectorAll('.pb-slides img').forEach((img, i) => {
    const dot     = document.createElement('span');
    dot.className = 'pb-dot' + (img.classList.contains('active') ? ' pb-dot-active' : '');
    dot.style     = `width:8px;height:8px;border-radius:50%;background:${img.classList.contains('active') ? 'white' : 'rgba(255,255,255,0.4)'};cursor:pointer;transition:all .2s;`;
    dot.onclick   = () => { pbMoveSlide({ closest: () => carousel }, i - (i * 2)); };
    dotsContainer.appendChild(dot);
  });
}


/* ═══════════════════════════════════════════════════════
   IMAGE EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshImageEditor(img) {
  const settingsPanel      = document.getElementById('widgetSettings');
  const navStructContainer = document.getElementById('navbarStructure');
  settingsPanel.style.display  = 'block';

  navStructContainer.innerHTML = `
    <div style="padding:2px 0 8px;">
      ${createEditorLabel('Image Settings').outerHTML}
      <div style="background:var(--surface3);padding:10px;border-radius:var(--radius-sm);">
        <label style="font-size:9px;color:var(--text-muted);display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.06em;">Image URL</label>
        <input type="text" id="imgSrcInput" value="${img.src}"
          style="width:100%;background:var(--surface2);color:var(--text);border:1px solid var(--border);padding:6px 8px;font-size:11px;border-radius:3px;box-sizing:border-box;font-family:inherit;outline:none;margin-bottom:8px;">
        <button id="uploadImgBtn" class="btn btn-primary" style="width:100%;font-size:10px;">Upload Local File</button>
        <input type="file" id="hiddenFileIn" accept="image/*" style="display:none;">
        <p class="help-text" style="margin-top:8px;">Use CSS below to adjust width, border-radius, etc.</p>
      </div>
    </div>
  `;

  document.getElementById('imgSrcInput').oninput  = e => { img.src = e.target.value; updateCode(); };
  document.getElementById('uploadImgBtn').onclick  = () => document.getElementById('hiddenFileIn').click();
  document.getElementById('hiddenFileIn').onchange = e => {
    const reader = new FileReader();
    reader.onload = ev => { img.src = ev.target.result; document.getElementById('imgSrcInput').value = ev.target.result; updateCode(); };
    reader.readAsDataURL(e.target.files[0]);
  };
}


/* ═══════════════════════════════════════════════════════
   FORM EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshFormEditor(el) {
  const settingsPanel      = document.getElementById('widgetSettings');
  const navStructContainer = document.getElementById('navbarStructure');
  const form = el.querySelector('.pb-reg-form') || (el.classList.contains('pb-reg-form') ? el : el.closest('.pb-reg-form'));
  if (!form) return;

  settingsPanel.style.display = 'block';
  navStructContainer.innerHTML = '';
  navStructContainer.appendChild(createEditorLabel('Form Fields'));

  const title = form.querySelector('h3');
  if (title) {
    const row = makeEditorRow('Title', title.innerText, false);
    row.querySelector('input').oninput = e => { title.innerText = e.target.value; updateCode(); };
    navStructContainer.appendChild(row);
  }

  form.querySelectorAll('input').forEach((input) => {
    const row = document.createElement('div');
    row.style = 'display:flex;align-items:center;gap:5px;background:var(--surface3);padding:6px 8px;margin-bottom:4px;border-radius:3px;';
    row.innerHTML = `
      <select style="background:var(--surface2);color:var(--text);border:1px solid var(--border);font-size:10px;padding:3px 5px;border-radius:3px;font-family:inherit;outline:none;">
        <option value="text"     ${input.type==='text'     ?'selected':''}>Text</option>
        <option value="email"    ${input.type==='email'    ?'selected':''}>Email</option>
        <option value="password" ${input.type==='password' ?'selected':''}>Pass</option>
        <option value="number"   ${input.type==='number'   ?'selected':''}>Number</option>
      </select>
      <input type="text" value="${input.placeholder || ''}"
        style="flex:1;background:transparent;border:none;color:var(--text);font-size:11px;font-family:inherit;outline:none;"
        placeholder="Placeholder">
      <span style="color:var(--danger);cursor:pointer;font-weight:700;font-size:14px;line-height:1;" class="del-field">×</span>
    `;
    row.querySelector('select').onchange  = e => { input.type = e.target.value; updateCode(); };
    row.querySelector('input').oninput    = e => { input.placeholder = e.target.value; updateCode(); };
    row.querySelector('.del-field').onclick = () => { input.remove(); row.remove(); updateCode(); };
    navStructContainer.appendChild(row);
  });

  const addBtn     = document.createElement('button');
  addBtn.className = 'btn btn-primary';
  addBtn.style     = 'width:100%;margin-top:6px;font-size:10px;';
  addBtn.innerText = '+ Add Input Field';
  addBtn.onclick   = () => {
    const newInput       = document.createElement('input');
    newInput.type        = 'text';
    newInput.placeholder = 'New Field';
    form.insertBefore(newInput, form.querySelector('button'));
    refreshFormEditor(el);
    updateCode();
  };
  navStructContainer.appendChild(addBtn);
}


/* ═══════════════════════════════════════════════════════
   NAVBAR EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshNavbarEditor() {
  const settingsPanel      = document.getElementById('widgetSettings');
  const navStructContainer = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  if (!activeNavbar || !navStructContainer) return;
  navStructContainer.innerHTML = '';

  let logoWrap = activeNavbar.querySelector('.pb-logo-container');
  if (!logoWrap) {
    logoWrap           = document.createElement('div');
    logoWrap.className = 'pb-logo-container';
    activeNavbar.prepend(logoWrap);
  }

  // Logo type switcher
  const typeRow       = document.createElement('div');
  typeRow.style       = 'display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-bottom:8px;';
  typeRow.innerHTML   = `
    <button id="btn-text-mode" class="editor-btn">TEXT LOGO</button>
    <button id="btn-img-mode"  class="editor-btn">IMAGE LOGO</button>
  `;
  navStructContainer.appendChild(typeRow);

  const logoRow = document.createElement('div');
  logoRow.style = 'background:var(--surface3);padding:8px;margin-bottom:12px;border-radius:3px;border:1px solid var(--border);';
  navStructContainer.appendChild(logoRow);

  const switchToText  = () => {
    logoWrap.innerHTML = `<div class="pb-nav-text-logo" contenteditable="true" style="font-weight:700;">MyBrand</div>`;
    renderLogoUI(); updateCode();
  };
  const switchToImage = () => {
    logoWrap.innerHTML = `<img class="pb-nav-logo" src="img/logo.svg" style="height:30px;width:auto;">`;
    renderLogoUI(); updateCode();
  };

  function renderLogoUI() {
    const logoImg  = logoWrap.querySelector('.pb-nav-logo');
    const logoText = logoWrap.querySelector('.pb-nav-text-logo');
    logoRow.innerHTML = '';

    if (logoText) {
      logoRow.innerHTML = `
        <div style="display:flex;align-items:center;gap:8px;">
          <span class="badge blue">TEXT</span>
          <input type="text" value="${logoText.innerText}"
            style="flex:1;background:transparent;border:none;color:var(--text);outline:none;font-size:12px;font-family:inherit;">
        </div>
      `;
      logoRow.querySelector('input').oninput = e => { logoText.innerText = e.target.value; updateCode(); };

    } else if (logoImg) {
      logoRow.innerHTML = `
        <div style="display:flex;align-items:center;gap:8px;">
          <span class="badge blue">IMG</span>
          <button id="logo-upload-trigger" class="editor-btn" style="flex:1;">Upload File</button>
          <input type="file" id="logo-hidden-file" accept="image/*" style="display:none;">
        </div>
      `;
      const fileIn = logoRow.querySelector('#logo-hidden-file');
      logoRow.querySelector('#logo-upload-trigger').onclick = () => fileIn.click();
      fileIn.onchange = e => {
        const reader = new FileReader();
        reader.onload = ev => { logoImg.src = ev.target.result; updateCode(); };
        if (e.target.files[0]) reader.readAsDataURL(e.target.files[0]);
      };
    }
  }

  typeRow.querySelector('#btn-text-mode').onclick = switchToText;
  typeRow.querySelector('#btn-img-mode').onclick  = switchToImage;
  renderLogoUI();

  // Nav Links editor — with real drag-to-reorder
  const navList = activeNavbar.querySelector('.pb-nav-list');
  if (navList) {
    navStructContainer.appendChild(createEditorLabel('Navigation Links'));

    // Drag state for sidebar rows
    let dragSrcLi = null;

    navList.querySelectorAll(':scope > li').forEach(li => {
      const linkText = li.childNodes[0] ? li.childNodes[0].textContent.trim() : 'Link';

      /* ── Row ── */
      const row = document.createElement('div');
      row.dataset.navRow = '1';
      row.style = [
        'display:flex','align-items:center','gap:5px',
        'background:var(--surface3)','padding:6px 8px',
        'margin-bottom:4px','border-radius:4px',
        'border:1px solid var(--border)','cursor:default',
        'transition:border-color .15s,background .15s'
      ].join(';');

      row.innerHTML = `
        <span class="nav-drag-grip" draggable="true"
          title="Drag to reorder"
          style="cursor:grab;color:var(--text-muted);font-size:13px;padding:0 3px;
                 flex-shrink:0;line-height:1;user-select:none;letter-spacing:-1px;">⠿</span>
        <span style="background:var(--accent);color:#fff;font-size:8px;font-weight:700;
                     padding:2px 5px;border-radius:3px;flex-shrink:0;letter-spacing:.04em;">LINK</span>
        <input type="text" value="${linkText.replace(/"/g,'&quot;')}"
          style="flex:1;min-width:0;background:transparent;border:none;color:var(--text);
                 font-size:12px;outline:none;font-family:inherit;">
        <button class="nb-add-sub" title="Add sub-item"
          style="background:var(--surface2);border:1px solid var(--border);color:var(--text-muted);
                 border-radius:3px;padding:2px 6px;font-size:11px;cursor:pointer;flex-shrink:0;
                 font-family:inherit;transition:all .15s;">+sub</button>
        <button class="nb-del" title="Delete link"
          style="background:#f43f5e22;border:1px solid #f43f5e55;color:#f43f5e;
                 border-radius:3px;padding:2px 7px;font-size:14px;font-weight:700;
                 cursor:pointer;flex-shrink:0;font-family:inherit;line-height:1;
                 transition:all .15s;">×</button>
      `;

      /* Rename */
      row.querySelector('input').oninput = e => {
        if (li.childNodes[0] && li.childNodes[0].nodeType === 3)
          li.childNodes[0].textContent = e.target.value;
        else li.prepend(document.createTextNode(e.target.value));
        updateCode();
      };

      /* Delete */
      const delBtn = row.querySelector('.nb-del');
      delBtn.onmouseenter = () => { delBtn.style.background='#f43f5e'; delBtn.style.color='#fff'; };
      delBtn.onmouseleave = () => { delBtn.style.background='#f43f5e22'; delBtn.style.color='#f43f5e'; };
      delBtn.onclick = () => { li.remove(); refreshNavbarEditor(); updateCode(); };

      /* Add sub */
      row.querySelector('.nb-add-sub').onclick = () => {
        let dd = li.querySelector('.pb-dropdown');
        if (!dd) {
          li.classList.add('pb-has-dropdown');
          dd = document.createElement('ul');
          dd.className = 'pb-dropdown';
          li.appendChild(dd);
        }
        const s = document.createElement('li');
        s.innerText = 'Sub Item';
        dd.appendChild(s);
        refreshNavbarEditor();
        updateCode();
      };

      /* ── Drag-to-reorder on the grip ── */
      const grip = row.querySelector('.nav-drag-grip');

      grip.addEventListener('dragstart', e => {
        dragSrcLi = li;
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', '');   // required for Firefox
        setTimeout(() => { row.style.opacity = '0.45'; }, 0);
      });

      grip.addEventListener('dragend', () => {
        row.style.opacity = '1';
        // Remove all drag-over highlights
        navStructContainer.querySelectorAll('[data-nav-row]').forEach(r => {
          r.style.borderColor = 'var(--border)';
          r.style.background  = 'var(--surface3)';
        });
        dragSrcLi = null;
        updateCode();
      });

      row.addEventListener('dragover', e => {
        if (!dragSrcLi || dragSrcLi === li) return;
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        row.style.borderColor = 'var(--accent)';
        row.style.background  = 'rgba(99,102,241,0.12)';
      });

      row.addEventListener('dragleave', () => {
        row.style.borderColor = 'var(--border)';
        row.style.background  = 'var(--surface3)';
      });

      row.addEventListener('drop', e => {
        e.preventDefault();
        if (!dragSrcLi || dragSrcLi === li) return;
        row.style.borderColor = 'var(--border)';
        row.style.background  = 'var(--surface3)';

        // Insert dragSrcLi before the current li in the real navList
        const srcIdx = [...navList.children].indexOf(dragSrcLi);
        const tgtIdx = [...navList.children].indexOf(li);
        if (srcIdx < tgtIdx) navList.insertBefore(dragSrcLi, li.nextElementSibling);
        else                  navList.insertBefore(dragSrcLi, li);

        refreshNavbarEditor();
        updateCode();
      });

      navStructContainer.appendChild(row);

      /* ── Sub-items ── */
      const dropdown = li.querySelector('.pb-dropdown');
      if (dropdown) {
        dropdown.querySelectorAll(':scope > li').forEach(subLi => {
          const subRow = document.createElement('div');
          subRow.style = [
            'display:flex','align-items:center','gap:5px',
            'background:var(--bg)','padding:5px 8px',
            'margin-bottom:3px','margin-left:18px',
            'border-radius:3px','border-left:2px solid var(--accent)'
          ].join(';');
          subRow.innerHTML = `
            <span style="background:#6366f1;color:#fff;font-size:7px;font-weight:700;
                         padding:2px 4px;border-radius:2px;flex-shrink:0;">SUB</span>
            <input type="text" value="${subLi.innerText.replace(/"/g,'&quot;')}"
              style="flex:1;min-width:0;background:transparent;border:none;color:var(--text);
                     font-size:11px;outline:none;font-family:inherit;">
            <button class="nb-del-sub"
              style="background:#f43f5e22;border:1px solid #f43f5e55;color:#f43f5e;
                     border-radius:3px;padding:1px 6px;font-size:13px;font-weight:700;
                     cursor:pointer;flex-shrink:0;font-family:inherit;line-height:1;
                     transition:all .15s;">×</button>
          `;
          subRow.querySelector('input').oninput = e => { subLi.innerText = e.target.value; updateCode(); };
          const dBtn = subRow.querySelector('.nb-del-sub');
          dBtn.onmouseenter = () => { dBtn.style.background='#f43f5e'; dBtn.style.color='#fff'; };
          dBtn.onmouseleave = () => { dBtn.style.background='#f43f5e22'; dBtn.style.color='#f43f5e'; };
          dBtn.onclick = () => {
            subLi.remove();
            if (!dropdown.querySelector('li')) { dropdown.remove(); li.classList.remove('pb-has-dropdown'); }
            refreshNavbarEditor();
            updateCode();
          };
          navStructContainer.appendChild(subRow);
        });
      }
    });
  }

  /* ── Add Nav Link button ── */
  const addMainBtn = document.createElement('button');
  addMainBtn.className = 'btn btn-primary';
  addMainBtn.style = 'width:100%;margin-top:10px;font-size:10px;';
  addMainBtn.innerText = '+ Add Nav Link';
  addMainBtn.onclick = () => {
    const newLi = document.createElement('li');
    newLi.innerText = 'New Link';
    if (navList) navList.appendChild(newLi);
    refreshNavbarEditor();
    updateCode();
  };
  navStructContainer.appendChild(addMainBtn);
}

function addNavLink() {
  if (!activeNavbar) return;
  const list      = activeNavbar.querySelector('.pb-nav-list');
  const newItem   = document.createElement('li');
  newItem.contentEditable = 'true';
  newItem.innerText = 'New Link';
  if (list) list.appendChild(newItem);
  refreshNavbarEditor();
  updateCode();
}

/* ═══════════════════════════════════════════════════════
   FOOTER EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshFooterEditor(footer) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Footer Brand'));

  const brandH3 = footer.querySelector('.pb-footer-brand h3');
  const brandP  = footer.querySelector('.pb-footer-brand p');

  if (brandH3) {
    const r = makeEditorRow('Brand', brandH3.innerText, false);
    r.querySelector('input').oninput = e => { brandH3.innerText = e.target.value; updateCode(); };
    container.appendChild(r);
  }
  if (brandP) {
    const r2 = makeEditorRow('Tagline', brandP.innerText, false);
    r2.querySelector('input').oninput = e => { brandP.innerText = e.target.value; updateCode(); };
    container.appendChild(r2);
  }

  container.appendChild(createEditorLabel('Footer Columns'));
  footer.querySelectorAll('.pb-footer-col').forEach((col, ci) => {
    const h4 = col.querySelector('h4');
    if (h4) {
      const hRow = makeEditorRow('Col '+(ci+1), h4.innerText, false);
      hRow.querySelector('input').oninput = e => { h4.innerText = e.target.value; updateCode(); };
      container.appendChild(hRow);
    }
    col.querySelectorAll('li').forEach((li, li_i) => {
      const lRow = document.createElement('div');
      lRow.style = 'display:flex;align-items:center;gap:5px;padding:4px 8px 4px 18px;margin-bottom:3px;background:var(--bg);border-radius:3px;';
      lRow.innerHTML = `<span style="font-size:9px;color:var(--text-muted);">↳</span><input type="text" value="${li.innerText}" style="flex:1;background:transparent;border:none;color:var(--text);font-size:11px;outline:none;font-family:inherit;"><span class="remove-btn" style="font-size:12px;">×</span>`;
      lRow.querySelector('input').oninput = e => { li.innerText = e.target.value; updateCode(); };
      lRow.querySelector('.remove-btn').onclick = () => { li.remove(); lRow.remove(); updateCode(); };
      container.appendChild(lRow);
    });
    const addLi = document.createElement('button');
    addLi.className = 'btn btn-ghost'; addLi.style = 'width:100%;font-size:9px;margin-bottom:8px;';
    addLi.innerText = '+ Add Link to Col '+(ci+1);
    addLi.onclick = () => {
      const newLi = document.createElement('li'); newLi.innerText = 'New Link';
      col.querySelector('ul').appendChild(newLi);
      refreshFooterEditor(footer); updateCode();
    };
    container.appendChild(addLi);
  });

  container.appendChild(createEditorLabel('Copyright'));
  const copy = footer.querySelector('.pb-footer-bottom span');
  if (copy) {
    const cr = makeEditorRow('©', copy.innerText, false);
    cr.querySelector('input').oninput = e => { copy.innerText = e.target.value; updateCode(); };
    container.appendChild(cr);
  }
}


/* ═══════════════════════════════════════════════════════
   CARD EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshCardEditor(card) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Card'));

  // Find card inner elements — support both pb-card and generic card divs
  const root    = card;
  const titleEl = root.querySelector('h1,h2,h3,h4,h5,h6');
  const descEl  = root.querySelector('p');
  const btnEl   = root.querySelector('button,a.btn');
  const imgEl   = root.querySelector('img');
  const bannerEl = root.querySelector('div[style*="background"]');

  if (titleEl) {
    const r = makeEditorRow('Title', titleEl.innerText, false);
    r.querySelector('input').oninput = e => { titleEl.innerText = e.target.value; updateCode(); };
    container.appendChild(r);
  }
  if (descEl) {
    const r = makeEditorRow('Desc', descEl.innerText, false);
    r.querySelector('input').oninput = e => { descEl.innerText = e.target.value; updateCode(); };
    container.appendChild(r);
  }
  if (btnEl) {
    const r = makeEditorRow('Btn', btnEl.innerText, false);
    r.querySelector('input').oninput = e => { btnEl.innerText = e.target.value; updateCode(); };
    container.appendChild(r);
  }
  if (bannerEl && !imgEl) {
    container.appendChild(createEditorLabel('Banner Color'));
    const colorRow = document.createElement('div');
    colorRow.style = 'display:flex;align-items:center;gap:8px;margin-bottom:6px;';
    colorRow.innerHTML = `<input type="color" value="#6366f1" style="width:36px;height:28px;border:none;border-radius:3px;cursor:pointer;background:none;"><span style="font-size:11px;color:var(--text-muted);">Banner background</span>`;
    colorRow.querySelector('input[type=color]').oninput = e => {
      bannerEl.style.background = e.target.value; updateCode();
    };
    container.appendChild(colorRow);
  }
  if (imgEl) {
    container.appendChild(createEditorLabel('Card Image'));
    const uploadRow = document.createElement('div');
    uploadRow.innerHTML = `<button class="btn btn-primary" style="width:100%;font-size:10px;margin-bottom:4px;">Upload Image</button><input type="file" accept="image/*" style="display:none;">`;
    uploadRow.querySelector('button').onclick = () => uploadRow.querySelector('input[type=file]').click();
    uploadRow.querySelector('input[type=file]').onchange = e => {
      const r = new FileReader(); r.onload = ev => { imgEl.src = ev.target.result; updateCode(); };
      if (e.target.files[0]) r.readAsDataURL(e.target.files[0]);
    };
    container.appendChild(uploadRow);
  }
}


/* ═══════════════════════════════════════════════════════
   ALERT EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshAlertEditor(alert) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Alert'));

  const titleEl = alert.querySelector('strong');
  const msgEl   = alert.querySelector('p');
  const iconEl  = alert.querySelector('span:first-child');

  if (titleEl) {
    const r = makeEditorRow('Title', titleEl.innerText, false);
    r.querySelector('input').oninput = e => { titleEl.innerText = e.target.value; updateCode(); };
    container.appendChild(r);
  }
  if (msgEl) {
    const r = makeEditorRow('Message', msgEl.innerText, false);
    r.querySelector('input').oninput = e => { msgEl.innerText = e.target.value; updateCode(); };
    container.appendChild(r);
  }

  container.appendChild(createEditorLabel('Alert Type'));
  const types = [
    { label: 'Info',    bg: '#eff6ff', border: '#bfdbfe', left: '#3b82f6', color: '#1e40af', icon: 'ℹ️' },
    { label: 'Success', bg: '#f0fdf4', border: '#bbf7d0', left: '#22c55e', color: '#15803d', icon: '✅' },
    { label: 'Warning', bg: '#fffbeb', border: '#fde68a', left: '#f59e0b', color: '#b45309', icon: '⚠️' },
    { label: 'Error',   bg: '#fff1f2', border: '#fecdd3', left: '#f43f5e', color: '#be123c', icon: '🚫' },
  ];
  const typeGrid = document.createElement('div');
  typeGrid.style = 'display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-bottom:8px;';
  types.forEach(t => {
    const b = document.createElement('button');
    b.className = 'editor-btn'; b.innerText = t.label;
    b.onclick = () => {
      alert.style.background   = t.bg;
      alert.style.border       = `1px solid ${t.border}`;
      alert.style.borderLeft   = `4px solid ${t.left}`;
      if (titleEl) titleEl.style.color = t.color;
      if (msgEl)   msgEl.style.color   = t.color;
      if (iconEl)  iconEl.innerText    = t.icon;
      updateCode();
    };
    typeGrid.appendChild(b);
  });
  container.appendChild(typeGrid);
}


/* ═══════════════════════════════════════════════════════
   BADGE EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshBadgeEditor(badge) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Badge'));

  const r = makeEditorRow('Text', badge.innerText, false);
  r.querySelector('input').oninput = e => { badge.innerText = e.target.value; updateCode(); };
  container.appendChild(r);

  container.appendChild(createEditorLabel('Color'));
  const colors = ['#6366f1','#22c55e','#f59e0b','#f43f5e','#0ea5e9','#8b5cf6','#64748b'];
  const colorRow = document.createElement('div');
  colorRow.style = 'display:flex;gap:5px;flex-wrap:wrap;margin-bottom:8px;';
  colors.forEach(c => {
    const swatch = document.createElement('span');
    swatch.style = `width:20px;height:20px;border-radius:50%;background:${c};cursor:pointer;border:2px solid transparent;transition:border-color .15s;`;
    swatch.onclick = () => { badge.style.background = c; updateCode(); };
    swatch.onmouseover = () => swatch.style.borderColor = 'white';
    swatch.onmouseout  = () => swatch.style.borderColor = 'transparent';
    colorRow.appendChild(swatch);
  });
  container.appendChild(colorRow);

  container.appendChild(createEditorLabel('Shape'));
  const shapeRow = document.createElement('div');
  shapeRow.style = 'display:grid;grid-template-columns:1fr 1fr;gap:5px;';
  const shapes = [{ label: 'Pill', r: '20px' }, { label: 'Square', r: '4px' }];
  shapes.forEach(s => {
    const b = document.createElement('button');
    b.className = 'editor-btn'; b.innerText = s.label;
    b.onclick = () => { badge.style.borderRadius = s.r; updateCode(); };
    shapeRow.appendChild(b);
  });
  container.appendChild(shapeRow);
}


/* ═══════════════════════════════════════════════════════
   VIDEO EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshVideoEditor(videoEl) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Video Embed'));

  const curSrc = videoEl.src || videoEl.getAttribute('src') || '';
  const row = document.createElement('div');
  row.style = 'margin-bottom:8px;';
  row.innerHTML = `
    <label style="font-size:9px;color:var(--text-muted);display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.06em;">YouTube / Vimeo URL</label>
    <input type="text" value="${curSrc}" placeholder="https://youtube.com/embed/..." style="width:100%;background:var(--surface2);color:var(--text);border:1px solid var(--border);padding:6px 8px;font-size:11px;border-radius:3px;box-sizing:border-box;font-family:inherit;outline:none;">
  `;
  row.querySelector('input').oninput = e => {
    let url = e.target.value.trim();
    // Auto-convert watch URLs to embed
    url = url.replace('watch?v=', 'embed/').replace('youtu.be/', 'youtube.com/embed/');
    videoEl.src = url; updateCode();
  };
  container.appendChild(row);

  container.appendChild(createEditorLabel('Aspect Ratio'));
  const wrapper = videoEl.closest('div[style]');
  const ratioRow = document.createElement('div');
  ratioRow.style = 'display:grid;grid-template-columns:1fr 1fr 1fr;gap:5px;';
  [['16:9','56.25%'],['4:3','75%'],['1:1','100%']].forEach(([label, pb]) => {
    const b = document.createElement('button');
    b.className = 'editor-btn'; b.innerText = label;
    b.onclick = () => { if (wrapper) { wrapper.style.paddingBottom = pb; updateCode(); } };
    ratioRow.appendChild(b);
  });
  container.appendChild(ratioRow);
}


/* ═══════════════════════════════════════════════════════
   HEADING EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshHeadingEditor(el) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Heading'));

  const r = makeEditorRow('Text', el.innerText, false);
  r.querySelector('input').oninput = e => { el.innerText = e.target.value; updateCode(); };
  container.appendChild(r);

  container.appendChild(createEditorLabel('Tag'));
  const tagRow = document.createElement('div');
  tagRow.style = 'display:grid;grid-template-columns:repeat(3,1fr);gap:5px;margin-bottom:8px;';
  ['H1','H2','H3','H4','H5','H6'].forEach(tag => {
    const b = document.createElement('button');
    b.className = 'editor-btn' + (el.tagName === tag ? ' active' : '');
    b.innerText = tag;
    b.onclick = () => {
      const newEl = document.createElement(tag);
      newEl.innerHTML = el.innerHTML;
      Array.from(el.attributes).forEach(a => newEl.setAttribute(a.name, a.value));
      el.replaceWith(newEl);
      el = newEl;
      refreshHeadingEditor(newEl); updateCode();
    };
    tagRow.appendChild(b);
  });
  container.appendChild(tagRow);

  container.appendChild(createEditorLabel('Align'));
  const alignRow = document.createElement('div');
  alignRow.style = 'display:grid;grid-template-columns:1fr 1fr 1fr;gap:5px;';
  ['left','center','right'].forEach(a => {
    const b = document.createElement('button');
    b.className = 'editor-btn'; b.innerText = a[0].toUpperCase()+a.slice(1);
    b.onclick = () => { el.style.textAlign = a; updateCode(); };
    alignRow.appendChild(b);
  });
  container.appendChild(alignRow);
}


/* ═══════════════════════════════════════════════════════
   PARAGRAPH EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshParaEditor(el) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Text'));

  const textarea = document.createElement('textarea');
  textarea.className = 'custom-css-area';
  textarea.style.color = 'var(--text)';
  textarea.style.height = '80px';
  textarea.value = el.innerText;
  textarea.oninput = e => { el.innerText = e.target.value; updateCode(); };
  container.appendChild(textarea);

  container.appendChild(createEditorLabel('Align'));
  const alignRow = document.createElement('div');
  alignRow.style = 'display:grid;grid-template-columns:1fr 1fr 1fr;gap:5px;';
  ['left','center','right'].forEach(a => {
    const b = document.createElement('button'); b.className = 'editor-btn'; b.innerText = a[0].toUpperCase()+a.slice(1);
    b.onclick = () => { el.style.textAlign = a; updateCode(); };
    alignRow.appendChild(b);
  });
  container.appendChild(alignRow);
}


/* ═══════════════════════════════════════════════════════
   BUTTON EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshButtonEditor(btn) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Button'));

  const r = makeEditorRow('Label', btn.innerText, false);
  r.querySelector('input').oninput = e => { btn.innerText = e.target.value; updateCode(); };
  container.appendChild(r);

  const linkRow = makeEditorRow('Link', btn.getAttribute('onclick') || btn.getAttribute('href') || '', false);
  linkRow.querySelector('input').placeholder = 'https://... or #id';
  linkRow.querySelector('input').oninput = e => {
    const v = e.target.value;
    if (v.startsWith('http') || v.startsWith('#')) { btn.setAttribute('onclick', `window.location='${v}'`); }
    updateCode();
  };
  container.appendChild(linkRow);

  container.appendChild(createEditorLabel('Style'));
  const styleRow = document.createElement('div');
  styleRow.style = 'display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-bottom:8px;';
  [
    { label: 'Primary',   bg: '#6366f1', color: '#fff', border: 'none' },
    { label: 'Success',   bg: '#22c55e', color: '#fff', border: 'none' },
    { label: 'Danger',    bg: '#f43f5e', color: '#fff', border: 'none' },
    { label: 'Outline',   bg: 'transparent', color: '#6366f1', border: '2px solid #6366f1' },
    { label: 'Dark',      bg: '#0b0e14', color: '#fff', border: 'none' },
    { label: 'Light',     bg: '#f8fafc', color: '#111', border: '1px solid #e5e7eb' },
  ].forEach(s => {
    const b = document.createElement('button'); b.className = 'editor-btn'; b.innerText = s.label;
    b.onclick = () => {
      btn.style.background = s.bg; btn.style.color = s.color;
      btn.style.border = s.border; btn.style.padding = '10px 20px';
      btn.style.borderRadius = '6px'; btn.style.cursor = 'pointer';
      btn.style.fontWeight = '600'; btn.style.fontSize = '14px';
      updateCode();
    };
    styleRow.appendChild(b);
  });
  container.appendChild(styleRow);

  container.appendChild(createEditorLabel('Shape'));
  const shapeRow = document.createElement('div');
  shapeRow.style = 'display:grid;grid-template-columns:1fr 1fr 1fr;gap:5px;';
  [['Sharp','2px'],['Rounded','8px'],['Pill','50px']].forEach(([l,r]) => {
    const b = document.createElement('button'); b.className = 'editor-btn'; b.innerText = l;
    b.onclick = () => { btn.style.borderRadius = r; updateCode(); };
    shapeRow.appendChild(b);
  });
  container.appendChild(shapeRow);
}


/* ═══════════════════════════════════════════════════════
   LIST EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshListEditor(list) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('List Items'));

  list.querySelectorAll('li').forEach((li, i) => {
    const row = document.createElement('div');
    row.style = 'display:flex;align-items:center;gap:5px;background:var(--surface3);padding:5px 8px;margin-bottom:4px;border-radius:3px;';
    row.innerHTML = `<span style="font-size:9px;color:var(--text-muted);width:14px;">${i+1}</span><input type="text" value="${li.innerText}" style="flex:1;background:transparent;border:none;color:var(--text);font-size:12px;outline:none;font-family:inherit;"><span class="remove-btn" style="font-size:13px;">×</span>`;
    row.querySelector('input').oninput = e => { li.innerText = e.target.value; updateCode(); };
    row.querySelector('.remove-btn').onclick = () => { li.remove(); refreshListEditor(list); updateCode(); };
    container.appendChild(row);
  });

  const addBtn = document.createElement('button');
  addBtn.className = 'btn btn-primary'; addBtn.style = 'width:100%;margin-top:6px;font-size:10px;';
  addBtn.innerText = '+ Add Item';
  addBtn.onclick = () => {
    const li = document.createElement('li'); li.innerText = 'New Item';
    li.style.marginBottom = '10px'; list.appendChild(li);
    refreshListEditor(list); updateCode();
  };
  container.appendChild(addBtn);

  container.appendChild(createEditorLabel('List Style'));
  const styleRow = document.createElement('div');
  styleRow.style = 'display:grid;grid-template-columns:1fr 1fr 1fr;gap:5px;';
  [['None','none'],['Disc','disc'],['Decimal','decimal']].forEach(([l,s]) => {
    const b = document.createElement('button'); b.className = 'editor-btn'; b.innerText = l;
    b.onclick = () => { list.style.listStyle = s; list.style.paddingLeft = s === 'none' ? '0' : '20px'; updateCode(); };
    styleRow.appendChild(b);
  });
  container.appendChild(styleRow);
}


/* ═══════════════════════════════════════════════════════
   BLOCKQUOTE EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshQuoteEditor(el) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Blockquote'));

  const textarea = document.createElement('textarea');
  textarea.className = 'custom-css-area';
  textarea.style.color = 'var(--text)'; textarea.style.height = '80px';
  textarea.value = el.innerText.replace(/[""]/g, '');
  textarea.oninput = e => { el.innerHTML = `&ldquo;${e.target.value}&rdquo;`; updateCode(); };
  container.appendChild(textarea);

  container.appendChild(createEditorLabel('Accent Color'));
  const colorRow = document.createElement('div');
  colorRow.style = 'display:flex;gap:5px;flex-wrap:wrap;';
  ['#6366f1','#22c55e','#f59e0b','#f43f5e','#0ea5e9','#64748b'].forEach(c => {
    const swatch = document.createElement('span');
    swatch.style = `width:20px;height:20px;border-radius:50%;background:${c};cursor:pointer;border:2px solid transparent;`;
    swatch.onclick = () => { el.style.borderLeftColor = c; updateCode(); };
    colorRow.appendChild(swatch);
  });
  container.appendChild(colorRow);
}


/* ═══════════════════════════════════════════════════════
   TABLE EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshTableEditor(table) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Table'));

  const heads = table.querySelectorAll('th');
  const rows  = table.querySelectorAll('tbody tr');

  container.appendChild(createEditorLabel('Headers'));
  heads.forEach((th, i) => {
    const r = makeEditorRow('H'+(i+1), th.innerText, false);
    r.querySelector('input').oninput = e => { th.innerText = e.target.value; updateCode(); };
    container.appendChild(r);
  });

  const addColBtn = document.createElement('button');
  addColBtn.className = 'btn btn-ghost'; addColBtn.style = 'width:100%;font-size:9px;margin-bottom:8px;';
  addColBtn.innerText = '+ Add Column';
  addColBtn.onclick = () => {
    const th = document.createElement('th'); th.innerText = 'Header'; th.style = 'padding:10px;border:1px solid #e5e7eb;text-align:left;';
    table.querySelector('thead tr').appendChild(th);
    table.querySelectorAll('tbody tr').forEach(row => {
      const td = document.createElement('td'); td.innerText = 'Cell'; td.style = 'padding:10px;border:1px solid #e5e7eb;';
      row.appendChild(td);
    });
    refreshTableEditor(table); updateCode();
  };
  container.appendChild(addColBtn);

  const addRowBtn = document.createElement('button');
  addRowBtn.className = 'btn btn-ghost'; addRowBtn.style = 'width:100%;font-size:9px;margin-bottom:8px;';
  addRowBtn.innerText = '+ Add Row';
  addRowBtn.onclick = () => {
    const tr = document.createElement('tr');
    heads.forEach(() => {
      const td = document.createElement('td'); td.innerText = 'Cell'; td.style = 'padding:10px;border:1px solid #e5e7eb;';
      tr.appendChild(td);
    });
    table.querySelector('tbody').appendChild(tr);
    refreshTableEditor(table); updateCode();
  };
  container.appendChild(addRowBtn);

  container.appendChild(createEditorLabel('Style'));
  const styleRow = document.createElement('div');
  styleRow.style = 'display:grid;grid-template-columns:1fr 1fr;gap:5px;';
  [['Striped', () => {
      table.querySelectorAll('tbody tr:nth-child(even)').forEach(r => r.style.background = '#f8fafc');
   }], ['Bordered', () => {
      table.style.border = '2px solid #e5e7eb';
   }]].forEach(([l, fn]) => {
    const b = document.createElement('button'); b.className = 'editor-btn'; b.innerText = l;
    b.onclick = () => { fn(); updateCode(); };
    styleRow.appendChild(b);
  });
  container.appendChild(styleRow);
}


/* ═══════════════════════════════════════════════════════
   PROGRESS EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshProgressEditor(el) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Progress Bar'));

  const valRow = document.createElement('div');
  valRow.style = 'margin-bottom:10px;';
  valRow.innerHTML = `
    <label style="font-size:9px;color:var(--text-muted);display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.06em;">Value: <span id="progVal">${el.value}</span>%</label>
    <input type="range" min="0" max="100" value="${el.value}" style="width:100%;">
  `;
  valRow.querySelector('input[type=range]').oninput = e => {
    el.value = e.target.value;
    const label = el.parentElement.querySelector('span');
    if (label) label.innerText = e.target.value + '%';
    valRow.querySelector('#progVal').innerText = e.target.value;
    updateCode();
  };
  container.appendChild(valRow);

  const maxRow = makeEditorRow('Max', el.max || '100', false);
  maxRow.querySelector('input').oninput = e => { el.max = e.target.value; updateCode(); };
  container.appendChild(maxRow);
}


/* ═══════════════════════════════════════════════════════
   METER EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshMeterEditor(el) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Meter'));

  const valRow = document.createElement('div');
  valRow.style = 'margin-bottom:10px;';
  valRow.innerHTML = `
    <label style="font-size:9px;color:var(--text-muted);display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.06em;">Value: <span id="meterVal">${el.value}</span></label>
    <input type="range" min="0" max="1" step="0.05" value="${el.value}" style="width:100%;">
  `;
  valRow.querySelector('input[type=range]').oninput = e => {
    el.value = e.target.value;
    valRow.querySelector('#meterVal').innerText = e.target.value;
    updateCode();
  };
  container.appendChild(valRow);
}


/* ═══════════════════════════════════════════════════════
   DETAILS / ACCORDION EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshDetailsEditor(el) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Accordion'));

  const summary = el.querySelector('summary');
  const body    = el.querySelector('p');

  if (summary) {
    const r = makeEditorRow('Title', summary.innerText, false);
    r.querySelector('input').oninput = e => { summary.innerText = e.target.value; updateCode(); };
    container.appendChild(r);
  }
  if (body) {
    const textarea = document.createElement('textarea');
    textarea.className = 'custom-css-area';
    textarea.style.color = 'var(--text)'; textarea.style.height = '70px';
    textarea.style.marginBottom = '8px';
    textarea.value = body.innerText;
    textarea.oninput = e => { body.innerText = e.target.value; updateCode(); };
    container.appendChild(createEditorLabel('Body'));
    container.appendChild(textarea);
  }

  const openRow = document.createElement('div');
  openRow.style = 'display:flex;align-items:center;gap:8px;';
  openRow.innerHTML = `<input type="checkbox" ${el.open ? 'checked' : ''} style="cursor:pointer;"><span style="font-size:11px;color:var(--text-muted);">Open by default</span>`;
  openRow.querySelector('input').onchange = e => { e.target.checked ? el.setAttribute('open','') : el.removeAttribute('open'); updateCode(); };
  container.appendChild(openRow);
}


/* ═══════════════════════════════════════════════════════
   DIVIDER EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshDividerEditor(el) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Divider'));

  container.appendChild(createEditorLabel('Style'));
  const styleRow = document.createElement('div');
  styleRow.style = 'display:grid;grid-template-columns:1fr 1fr 1fr;gap:5px;margin-bottom:8px;';
  [['Solid','solid'],['Dashed','dashed'],['Dotted','dotted']].forEach(([l,s]) => {
    const b = document.createElement('button'); b.className = 'editor-btn'; b.innerText = l;
    b.onclick = () => { el.style.borderTop = `1px ${s} currentColor`; updateCode(); };
    styleRow.appendChild(b);
  });
  container.appendChild(styleRow);

  container.appendChild(createEditorLabel('Color'));
  const colorRow = document.createElement('div');
  colorRow.style = 'display:flex;gap:5px;flex-wrap:wrap;';
  ['#e5e7eb','#6366f1','#f43f5e','#22c55e','#f59e0b','#0b0e14'].forEach(c => {
    const swatch = document.createElement('span');
    swatch.style = `width:20px;height:20px;border-radius:50%;background:${c};cursor:pointer;border:2px solid rgba(255,255,255,.15);`;
    swatch.onclick = () => { el.style.borderTopColor = c; el.style.color = c; updateCode(); };
    colorRow.appendChild(swatch);
  });
  container.appendChild(colorRow);

  container.appendChild(createEditorLabel('Thickness'));
  const thickRow = document.createElement('div');
  thickRow.style = 'display:grid;grid-template-columns:1fr 1fr 1fr;gap:5px;';
  [['Thin','1px'],['Medium','2px'],['Thick','4px']].forEach(([l,t]) => {
    const b = document.createElement('button'); b.className = 'editor-btn'; b.innerText = l;
    b.onclick = () => {
      const cur = el.style.borderTop || 'solid #e5e7eb';
      const parts = cur.split(' ');
      el.style.borderTop = `${t} ${parts[1] || 'solid'} ${parts[2] || '#e5e7eb'}`;
      updateCode();
    };
    thickRow.appendChild(b);
  });
  container.appendChild(thickRow);
}

/* Helper: create a styled section label in the editor panel */
function createEditorLabel(text) {
  const label   = document.createElement('label');
  label.style   = 'font-size:9px;color:var(--accent);font-weight:700;display:block;margin-bottom:8px;text-transform:uppercase;letter-spacing:.1em;';
  label.innerText = text;
  return label;
}

function makeEditorRow(badgeText, value, canDelete) {
  const row = document.createElement('div');
  row.style = 'display:flex;align-items:center;gap:8px;background:var(--surface3);padding:6px 8px;margin-bottom:5px;border-radius:3px;';
  row.innerHTML = `
    <span class="badge blue">${badgeText}</span>
    <input type="text" value="${value}"
      style="flex:1;background:transparent;border:none;color:var(--text);outline:none;font-size:12px;font-family:inherit;">
    ${canDelete ? '<span class="del-btn remove-btn" style="font-size:12px;">×</span>' : ''}
  `;
  return row;
}


/* ═══════════════════════════════════════════════════════
   CSS ENGINE
   ═══════════════════════════════════════════════════════ */

function applyCSS() {
  if (!selected) return;
  const pseudo = document.getElementById('pseudoSelector').value;
  const val    = cssInput.value.trim();

  if (pseudo === 'main') {
    selected.setAttribute('style', val);
  } else {
    const cls = findUID(selected) || Array.from(selected.classList).find(c => c.startsWith('section-')) || selected.tagName.toLowerCase();
    if (!pseudoStyles.has(cls)) pseudoStyles.set(cls, {});
    pseudoStyles.get(cls)[pseudo] = val;
    renderRuntimeStyles();
  }
  updateCode();
}

function renderRuntimeStyles() {
  let sheet = document.getElementById('runtime-hover-sheet');
  if (!sheet) {
    sheet    = document.createElement('style');
    sheet.id = 'runtime-hover-sheet';
    document.head.appendChild(sheet);
  }
  let css = '';
  pseudoStyles.forEach((states, selector) => {
    for (const state in states) {
      const imp = states[state].split(';').map(s => s.trim() ? s + ' !important' : '').filter(Boolean).join('; ');
      css += `.${selector}:${state} { ${imp} }\n`;
    }
  });
  sheet.innerHTML = css;
}

function loadCurrentCSS() {
  if (!selected) return;
  const pseudo = document.getElementById('pseudoSelector').value;
  const cls    = findUID(selected) || selected.tagName.toLowerCase();

  if (pseudo === 'main') {
    const s = selected.getAttribute('style') || '';
    cssInput.value = s.split(';').map(x => x.trim()).filter(x => x).join(';\n') + (s ? ';' : '');
  } else {
    cssInput.value = (pseudoStyles.get(cls) || {})[pseudo] || '';
  }
}


/* ═══════════════════════════════════════════════════════
   JS ENGINE
   ═══════════════════════════════════════════════════════ */

function applyJS() {
  if (!selected) return;
  const wrapper    = selected.closest('.widget-wrapper') || selected;
  const uid        = Array.from(wrapper.classList).find(c => c.startsWith('codeme-'));
  if (!uid) return;

  const codeValue  = document.getElementById('jsInput').value;
  const mode       = document.getElementById('jsModeSelector').value;
  const hint       = document.getElementById('jsHint');

  widgetScripts.set(uid, codeValue);
  widgetJSModes.set(uid, mode);

  if (mode === 'click') {
    hint.innerText = "Code runs when clicked. 'this' refers to the element.";
    selected.onclick = e => {
      e.stopPropagation();
      try { new Function(codeValue).call(selected); } catch (err) { console.error(err); }
    };
  } else {
    hint.innerText   = 'Raw script mode. Use for global functions or data.';
    selected.onclick = null;
  }
  updateCode();
}


/* ═══════════════════════════════════════════════════════
   CODE GENERATION (HTML prettifier)
   ═══════════════════════════════════════════════════════ */

function prettifyHTML(node, level = 0) {
  const indent = '  '.repeat(level);
  let html = '';

  node.childNodes.forEach(child => {
    if (child.nodeType === 1) {
      // Skip builder-only UI elements
      if (child.classList.contains('plus-btn') || child.classList.contains('widget-actions')) return;

      const tag   = child.tagName.toLowerCase();
      const attrs = Array.from(child.attributes)
        .filter(a => !['contenteditable', 'selected'].includes(a.name))
        .map(a => ` ${a.name}="${a.value}"`)
        .join('');

      const inner = prettifyHTML(child, level + 1);
      if (inner.trim()) {
        html += `${indent}<${tag}${attrs}>\n${inner}${indent}</${tag}>\n`;
      } else {
        html += `${indent}<${tag}${attrs}></${tag}>\n`;
      }
    } else if (child.nodeType === 3 && child.textContent.trim()) {
      html += `${indent}  ${child.textContent.trim()}\n`;
    }
  });

  return html;
}

function updateCode() {
  const hasCarousel = !!preview.querySelector('.pb-carousel');
  const hasForm     = !!preview.querySelector('.pb-reg-form');
  const hasNavbar   = !!preview.querySelector('.pb-navbar');

  htmlCode.value = prettifyHTML(preview, 1);

  /* --- Build CSS output --- */
  const bodyStyles = previewContent.getAttribute('style') || '';
  let finalCSS = '';

  // Body styles - only if user added any
  if (bodyStyles.trim()) {
    finalCSS += `/* Body */\nbody {\n  ${bodyStyles.split(';').map(s => s.trim()).filter(Boolean).join(';\n  ')};\n}\n\n`;
  }

  // Per-element inline styles - only what user added
  preview.querySelectorAll('*').forEach(el => {
    const styleAttr = el.getAttribute('style');
    if (!styleAttr || styleAttr.trim() === '' || el.classList.contains('widget-actions')) return;

    const cls = Array.from(el.classList).find(c =>
      c.startsWith('section-') || c.startsWith('container-') ||
      c.startsWith('column-')  || c.startsWith('codeme-')    || c.startsWith('pb-')
    );
    const sel   = cls ? '.' + cls : el.tagName.toLowerCase();
    const props = styleAttr.split(';').map(p => p.trim()).filter(Boolean).join(';\n  ');
    finalCSS   += `${sel} {\n  ${props};\n}\n\n`;
  });

  if (hasNavbar) {
    finalCSS += `
/* Navbar */
.pb-navbar         { display: flex; align-items: center; justify-content: space-between; padding: 0 32px; height: 64px; background: #0b0e14; position: relative; z-index: 1000; }
.pb-nav-text-logo  { font-weight: 700; font-size: 1.25rem; color: #6366f1; }
.pb-nav-list       { list-style: none; display: flex; align-items: center; gap: 4px; margin: 0; padding: 0; }
.pb-nav-list > li  { position: relative; padding: 8px 14px; font-size: 14px; color: #d1d5db; border-radius: 6px; cursor: pointer; transition: all .18s; }
.pb-nav-list > li:hover { color: white; background: rgba(255,255,255,.05); }
.pb-nav-cta        { background: #22c55e !important; color: white !important; border-radius: 20px !important; padding: 8px 18px !important; font-weight: 600; }

/* Dropdown */
.pb-dropdown       { display: none; position: absolute; top: calc(100% + 6px); left: 0; background: rgba(13,17,23,.97); min-width: 200px; padding: 6px; border-radius: 10px; border: 1px solid rgba(255,255,255,.08); list-style: none; box-shadow: 0 20px 40px rgba(0,0,0,.5); z-index: 9999; }
.pb-nav-list > li:hover > .pb-dropdown { display: block; }
.pb-dropdown li    { padding: 9px 14px; color: #9ca3af; font-size: 13px; border-radius: 6px; transition: all .15s; }
.pb-dropdown li:hover { background: rgba(99,102,241,.15); color: #a5b4fc; }

/* Mobile */
.pb-nav-toggle     { display: none; background: rgba(255,255,255,.06); border: 1px solid rgba(255,255,255,.1); color: white; padding: 8px 12px; border-radius: 6px; cursor: pointer; font-size: 18px; }
@keyframes fadeIn  { from { opacity:0; transform:translateY(8px); } to { opacity:1; transform:translateY(0); } }
@media (max-width: 768px) {
  .pb-nav-toggle   { display: block; }
  .pb-nav-list     { display: none; position: fixed; top:0; right:-100%; width:280px; height:100vh; background:#0b0e14; flex-direction:column; padding:80px 30px 40px; transition:.35s cubic-bezier(.4,0,.2,1); box-shadow:-10px 0 40px rgba(0,0,0,.6); z-index:9999; }
  .pb-nav-list.active { display: flex; right: 0; }
}
`;
  }

  if (hasCarousel) {
    finalCSS += `
/* Carousel */
.pb-carousel  { position: relative; width: 100%; overflow: hidden; min-height: 240px; background: #1a1a2e; }
.pb-slides img { width: 100%; display: none; object-fit: cover; }
.pb-slides img.active { display: block; animation: slideIn .4s ease; }
@keyframes slideIn { from { opacity:0; transform:scale(1.02); } to { opacity:1; transform:scale(1); } }
.pb-prev, .pb-next { position:absolute; top:50%; transform:translateY(-50%); background:rgba(0,0,0,.5); border:1px solid rgba(255,255,255,.1); color:white; width:40px; height:40px; border-radius:50%; display:flex; align-items:center; justify-content:center; cursor:pointer; z-index:10; font-size:16px; transition:all .2s; margin:0 10px; }
.pb-next { right:0; }
.pb-prev:hover, .pb-next:hover { background:#6366f1; border-color:#6366f1; }
`;
  }

  if (hasForm) {
    finalCSS += `
/* Registration Form */
.pb-reg-form         { display:flex; flex-direction:column; gap:12px; padding:28px; border:1px solid #e5e7eb; border-radius:12px; max-width:360px; background:#fff; box-shadow:0 4px 24px rgba(0,0,0,.06); }
.pb-reg-form h3      { margin:0 0 4px; font-size:1.2rem; color:#111; }
.pb-reg-form input   { padding:11px 14px; border:1px solid #d1d5db; border-radius:6px; font-size:14px; outline:none; width:100%; box-sizing:border-box; }
.pb-reg-form input:focus { border-color:#6366f1; }
.pb-reg-form button  { padding:12px; background:#6366f1; color:white; border:none; border-radius:8px; cursor:pointer; font-weight:600; font-size:14px; }
.pb-reg-form button:hover { background:#4f46e5; }
`;
  }

  // Pseudo/hover states
  if (pseudoStyles.size > 0) {
    finalCSS += '\n/* State Styles */\n';
    pseudoStyles.forEach((states, selector) => {
      for (const state in states) {
        const props = states[state].split(';').map(s => s.trim()).filter(Boolean).join(';\n  ');
        finalCSS += `.${selector}:${state} {\n  ${props};\n}\n\n`;
      }
    });
  }

  cssCode.value = finalCSS.trim();

  /* --- Build JS output --- */
  let finalJS = '';

  if (hasCarousel) {
    finalJS += `// Carousel controls
function pbMoveSlide(btn, dir) {
  var carousel = btn.closest('.pb-carousel');
  var slides   = carousel.querySelectorAll('.pb-slides img');
  if (slides.length <= 1) return;
  var idx = Array.from(slides).findIndex(function(i){ return i.classList.contains('active'); });
  slides[idx].classList.remove('active');
  idx = (idx + dir + slides.length) % slides.length;
  slides[idx].classList.add('active');
}\n\n`;
  }

  if (hasNavbar) {
    finalJS += `// Mobile menu (drawer-based)
function pbToggleMobile(btn) {
  var drawer  = document.getElementById('pb-drawer');
  var overlay = document.querySelector('.pb-drawer-overlay');
  if (!drawer) return;
  var isOpen = drawer.classList.toggle('open');
  btn.textContent = isOpen ? '\u2715' : '\u2630';
  if (overlay) overlay.classList.toggle('open', isOpen);
}
function pbCloseMobile() {
  var drawer  = document.getElementById('pb-drawer');
  var overlay = document.querySelector('.pb-drawer-overlay');
  if (drawer)  drawer.classList.remove('open');
  if (overlay) overlay.classList.remove('open');
  document.querySelectorAll('.pb-nav-toggle').forEach(function(b){ b.textContent = '\u2630'; });
}
function pbToggleSubMenu(li) {
  var sub = li.querySelector('.pb-mobile-dropdown');
  if (sub) sub.classList.toggle('open');
}
document.addEventListener('keydown', function(e){ if(e.key==='Escape') pbCloseMobile(); });\n\n`;
  }

  widgetScripts.forEach((code, uid) => {
    const mode = widgetJSModes.get(uid) || 'click';
    if (mode === 'click') {
      finalJS += `// Widget: ${uid}\ndocument.querySelector('.${uid}').addEventListener('click', function() {\n  ${code}\n});\n\n`;
    } else {
      finalJS += `// Raw: ${uid}\n${code}\n\n`;
    }
  });

  jsCode.value = finalJS.trim();
}


/* ═══════════════════════════════════════════════════════
   FACEBOOK FOLLOW MODAL — blocks app, detects tab return
   ═══════════════════════════════════════════════════════ */

// ── CONFIG: set your Facebook page URL here ──────────────
const FB_PAGE_URL = 'https://www.facebook.com/share/1JR8DCb9Hm/';   // ← your Facebook page
// ─────────────────────────────────────────────────────────

let fbPageURL       = FB_PAGE_URL;
let fbTabOpened     = false;
let fbVisibilityFn  = null;

function fbInit() {
  // ── If user already followed before, skip the modal immediately ──
  if (localStorage.getItem('fb_followed') === '1') {
    const modal = document.getElementById('fbFollowModal');
    if (modal) modal.style.display = 'none';
    return;
  }

  // ── On mobile: show a friendly notice instead of the full modal ──
  const isMobile = window.innerWidth < 768 || ('ontouchstart' in window && window.innerWidth < 1024);
  if (isMobile) {
    const desktopCard = document.getElementById('fb-desktop-card');
    const mobileNote  = document.getElementById('fb-mobile-notice');
    if (desktopCard) desktopCard.style.display = 'none';
    if (mobileNote)  mobileNote.style.display  = 'block';
    return;
  }

  // Update the page name / handle display from URL
  const nameEl   = document.getElementById('fb-page-name');
  const handleEl = document.getElementById('fb-page-handle');
  if (fbPageURL && fbPageURL !== 'https://www.facebook.com/') {
    const parts  = fbPageURL.replace(/\/$/, '').split('/');
    const handle = parts[parts.length - 1] || '';
    if (nameEl)   nameEl.innerText   = handle ? handle.charAt(0).toUpperCase() + handle.slice(1) : 'My Page';
    if (handleEl) handleEl.innerText = 'facebook.com/' + (handle || '');
  }
}

function fbOpenPage() {
  // Open the Facebook page in a new tab
  window.open(fbPageURL || 'https://www.facebook.com/', '_blank');
  fbTabOpened = true;

  // Update the step message
  const msg = document.getElementById('fb-step-msg');
  if (msg) msg.innerHTML = '🔵 Facebook opened in a new tab.<br>Follow the page, then return here.';

  // Change button to a "waiting" state
  const btn = document.getElementById('fb-main-btn');
  if (btn) {
    btn.innerHTML = `<span style="display:inline-block;width:16px;height:16px;border:2px solid rgba(255,255,255,.4);border-top-color:white;border-radius:50%;animation:fbSpin 0.8s linear infinite;margin-right:8px;"></span> Waiting for you to follow…`;
    btn.style.background = 'rgba(24,119,242,0.5)';
    btn.style.cursor     = 'default';
    btn.onclick          = null;
  }

  // Show the "already followed" fallback button
  const alreadyRow = document.getElementById('fb-already-row');
  if (alreadyRow) alreadyRow.style.display = 'block';

  // Listen for the user returning to this tab (visibilitychange)
  if (fbVisibilityFn) document.removeEventListener('visibilitychange', fbVisibilityFn);
  fbVisibilityFn = function() {
    if (document.visibilityState === 'visible' && fbTabOpened) {
      // Small delay so it feels natural
      setTimeout(fbConfirmFollowed, 600);
      document.removeEventListener('visibilitychange', fbVisibilityFn);
    }
  };
  document.addEventListener('visibilitychange', fbVisibilityFn);
}

function fbConfirmFollowed() {
  const modal = document.getElementById('fbFollowModal');
  if (!modal) return;

  // Remember that this user has followed — won't see modal again
  try { localStorage.setItem('fb_followed', '1'); } catch(e) {}

  // Green success flash before dismiss
  const card = modal.querySelector('div[style*="max-width:400px"]') || modal.firstElementChild;
  if (card) {
    card.style.transition = 'transform .2s, opacity .35s';
    card.style.transform  = 'scale(1.03)';
    setTimeout(() => {
      card.style.transform = 'scale(1)';
      card.style.opacity   = '0';
    }, 180);
  }

  modal.style.transition = 'opacity .4s';
  modal.style.opacity    = '0';
  setTimeout(() => {
    modal.style.display = 'none';
    // Remove visibility listener in case it's still there
    if (fbVisibilityFn) document.removeEventListener('visibilitychange', fbVisibilityFn);
  }, 420);
}

// Inject the spinner keyframe into the page
(function() {
  const s = document.createElement('style');
  s.textContent = '@keyframes fbSpin { to { transform: rotate(360deg); } }';
  document.head.appendChild(s);
})();

// Kept for backward-compat (old calls in HTML attributes)
function updateFBPreview(val) { fbPageURL = val || FB_PAGE_URL; fbInit(); }
function openFBAndClose()     { fbOpenPage(); }
function dismissFBModal()     { fbConfirmFollowed(); }

// Show FB modal immediately on load (blocks app)
window.addEventListener('DOMContentLoaded', () => {
  fbInit();
  const modal = document.getElementById('fbFollowModal');
  if (modal) {
    modal.style.opacity    = '0';
    modal.style.transition = 'opacity .4s';
    requestAnimationFrame(() => requestAnimationFrame(() => { modal.style.opacity = '1'; }));
  }

  // Load FolioOne default in background while modal is showing
  loadFolioOneDefault();

  // ── Check FolioOne edit permission ──────────────────────────────────────
  (async function checkFolioPermission() {
    try {
      const res  = await fetch('menu_builder_api.php?action=check_folio_permission');
      const data = await res.json();
      if (!data.ok || !data.folio_edit_allowed) {
        // Lock direct editing of FolioOne elements in the import preview
        const style       = document.createElement('style');
        style.textContent = '#import-preview-frame { pointer-events: none; opacity: 0.85; }';
        document.head.appendChild(style);
        // Show a notice in the file tree
        const notice       = document.createElement('div');
        notice.style.cssText = 'font-size:10px;color:#ff8c42;padding:8px 10px;border:1px solid rgba(255,140,66,.2);border-radius:6px;margin:6px;line-height:1.5;';
        notice.textContent   = '🔒 FolioOne editing is locked. Submit your work for admin approval to unlock customisation.';
        const fileTree = document.getElementById('fileTree');
        if (fileTree) fileTree.prepend(notice);
      }
    } catch (e) { /* silent fail — don't block the builder */ }
  })();
});


/* ═══════════════════════════════════════════════════════
   FOLIO ONE DEFAULT PREVIEW
   Loads the FolioOne Bootstrap template as the
   default starting point in live preview
   ═══════════════════════════════════════════════════════ */

function loadFolioOneDefault() {
  const folioHTML = getFolioOneHTML();
  syncImportToPreview(folioHTML);
  htmlCode.value = '<!-- FolioOne Bootstrap Template loaded. Use Export to download. -->';
  cssCode.value  = '/* FolioOne styles loaded via CDN */';
  jsCode.value   = '/* FolioOne scripts loaded via CDN */';

  // Add to project files
  projectFiles['index.html'] = { raw: folioHTML, selfContained: folioHTML };

  // Update file tree
  const fileTree = document.getElementById('fileTree');
  fileTree.innerHTML = '';
  const item = document.createElement('div');
  item.className = 'tree-item';
  item.style.color = 'var(--accent)';
  item.innerHTML = '<span style="color:#e34c26;font-size:9px;font-weight:700;margin-right:4px;">HTML</span> index.html ⭐';
  item.onclick = () => loadFileToEditor('index.html');
  fileTree.appendChild(item);
  document.getElementById('fileList').style.display = 'block';

  // Show the FolioOne editor button
  const feb = document.getElementById('folioEditorBtn');
  if (feb) feb.style.display = 'flex';
}

function getFolioOneHTML() {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>FolioOne — My Portfolio</title>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
  <style>
    :root {
      --accent: #6366f1;
      --accent2: #8b5cf6;
      --dark: #0b0e14;
    }
    body { font-family: 'Poppins', sans-serif; }

    /* ── NAVBAR ─────────────── */
    .folio-navbar {
      background: #0b0e14;
      padding: 0 40px;
      height: 64px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      position: sticky;
      top: 0;
      z-index: 1000;
      gap: 16px;
    }
    .folio-nav-logo {
      color: var(--accent);
      font-weight: 700;
      font-size: 1.3rem;
      text-decoration: none;
      flex-shrink: 0;
    }

    /* ── Desktop nav (inline links) ── */
    .folio-nav-list {
      list-style: none;
      margin: 0;
      padding: 0;
      display: flex;
      align-items: center;
      gap: 4px;
      flex: 1;
      justify-content: flex-end;
    }
    .folio-nav-list li a {
      color: #d1d5db;
      font-size: 14px;
      padding: 7px 13px;
      border-radius: 6px;
      text-decoration: none;
      transition: all .18s;
      display: block;
      white-space: nowrap;
    }
    .folio-nav-list li a:hover,
    .folio-nav-list li a.active { color: white; background: rgba(255,255,255,.07); }
    .folio-nav-cta a {
      background: #22c55e !important;
      color: white !important;
      border-radius: 20px !important;
      font-weight: 600 !important;
    }
    .folio-nav-cta a:hover { background: #16a34a !important; }

    /* Social icons — inline on desktop */
    .folio-nav-socials-row {
      display: flex;
      align-items: center;
      gap: 2px;
    }
    .folio-nav-social {
      color: #9ca3af;
      font-size: 16px;
      display: inline-flex !important;
      align-items: center;
      justify-content: center;
      width: 34px;
      height: 34px;
      border-radius: 50%;
      transition: all .18s;
      text-decoration: none;
    }
    .folio-nav-social:hover { color: white; background: rgba(255,255,255,.08); }

    /* ── Hamburger — hidden on desktop ── */
    .folio-hamburger {
      display: none;
      background: rgba(255,255,255,.06);
      border: 1px solid rgba(255,255,255,.1);
      color: white;
      padding: 8px 12px;
      border-radius: 6px;
      cursor: pointer;
      font-size: 18px;
      transition: background .18s;
      flex-shrink: 0;
    }
    .folio-hamburger:hover { background: rgba(255,255,255,.12); }

    /* Overlay — hidden by default */
    #folio-nav-overlay {
      display: none;
      position: fixed;
      inset: 0;
      background: rgba(0,0,0,.55);
      z-index: 9998;
      backdrop-filter: blur(2px);
    }

    /* Desktop social icons row (next to nav links) */
    .folio-desktop-socials {
      display: flex;
      align-items: center;
      gap: 2px;
      flex-shrink: 0;
    }
    /* Hide the socials li inside drawer on desktop */
    .folio-drawer-socials-li { display: none; }

    /* ── Mobile (≤ 900px) — drawer nav ── */
    @media (max-width: 900px) {
      /* Hide desktop socials on mobile */
      .folio-desktop-socials { display: none; }
      /* Show socials inside drawer on mobile */
      .folio-drawer-socials-li { display: block !important; }
      .folio-navbar { padding: 0 20px; }

      /* Show hamburger, hide inline list */
      .folio-hamburger { display: block; }
      .folio-nav-list {
        /* Reset to drawer */
        position: fixed;
        top: 0;
        right: -100%;
        width: 280px;
        height: 100vh;
        background: #0b0e14;
        flex-direction: column;
        justify-content: flex-start;
        align-items: stretch;
        gap: 0;
        padding-top: 0;
        overflow-y: auto;
        transition: right .35s cubic-bezier(.4,0,.2,1);
        box-shadow: -10px 0 40px rgba(0,0,0,.6);
        z-index: 9999;
      }
      /* Drawer header label */
      .folio-nav-list::before {
        content: 'Menu';
        display: block;
        color: #6366f1;
        font-size: 1rem;
        font-weight: 700;
        padding: 22px 28px 16px;
        border-bottom: 1px solid rgba(255,255,255,.07);
        letter-spacing: .04em;
        flex-shrink: 0;
      }
      /* Open state */
      .folio-nav-list.open { right: 0; }

      /* Drawer list items */
      .folio-nav-list li { width: 100%; }
      .folio-nav-list li a {
        font-size: 15px;
        padding: 14px 28px;
        border-radius: 0;
        border-bottom: 1px solid rgba(255,255,255,.04);
      }
      .folio-nav-list li a:hover,
      .folio-nav-list li a.active {
        background: rgba(99,102,241,.15);
        padding-left: 34px;
      }
      .folio-nav-cta a {
        margin: 12px 20px !important;
        border-radius: 8px !important;
        padding: 12px 20px !important;
        text-align: center !important;
        border-bottom: none !important;
        display: block !important;
      }
      .folio-nav-socials-row {
        padding: 14px 20px;
        border-bottom: 1px solid rgba(255,255,255,.04);
        gap: 4px;
      }
      .folio-nav-social {
        width: 38px;
        height: 38px;
        font-size: 18px;
      }
    }

    /* ── HERO ───────────────── */
    #folio-hero { padding: 80px 40px; background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%); }
    #folio-hero .hero-img-wrap { width: 300px; height: 300px; border-radius: 50%; overflow: hidden; background: linear-gradient(135deg,var(--accent),var(--accent2)); display:flex;align-items:center;justify-content:center;font-size:100px;box-shadow:0 20px 60px rgba(99,102,241,.25); }
    #folio-hero .hero-img-wrap img { width:100%;height:100%;object-fit:cover;display:none; }
    #folio-hero h1 { font-size: 2.8rem; font-weight: 700; color: #111; }
    #folio-hero h1 span { color: var(--accent); }
    #folio-hero p.lead { color: #6b7280; font-size: 1.05rem; line-height: 1.8; }
    .btn-folio-primary { background: var(--accent); color: white; border-radius: 8px; padding: 12px 28px; font-weight: 600; font-size: 15px; text-decoration: none; display:inline-block; transition: all .2s; }
    .btn-folio-primary:hover { background: #4f46e5; transform: translateY(-2px); box-shadow: 0 8px 24px rgba(99,102,241,.35); color: white; }
    .btn-folio-outline { border: 2px solid var(--accent); color: var(--accent); border-radius: 8px; padding: 11px 28px; font-weight: 600; font-size: 15px; text-decoration: none; display:inline-block; transition: all .2s; }
    .btn-folio-outline:hover { background: var(--accent); color: white; }

    /* ── SERVICES ───────────── */
    #folio-services { padding: 80px 40px; }
    #folio-services .service-card { background: white; border: 1px solid #e5e7eb; border-radius: 16px; padding: 32px; height: 100%; transition: all .25s; box-shadow: 0 2px 12px rgba(0,0,0,.05); }
    #folio-services .service-card:hover { transform: translateY(-6px); box-shadow: 0 16px 48px rgba(99,102,241,.15); border-color: rgba(99,102,241,.3); }
    #folio-services .service-icon { width: 56px; height: 56px; background: rgba(99,102,241,.1); border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 24px; margin-bottom: 16px; }
    #folio-services .section-title { font-size: 2rem; font-weight: 700; color: #111; margin-bottom: 10px; }
    #folio-services .section-sub { color: #6b7280; max-width: 500px; margin: 0 auto 48px; }

    /* ── PORTFOLIO ───────────── */
    #folio-portfolio { padding: 80px 40px; background: #f8fafc; }
    #folio-portfolio .portfolio-card { border-radius: 12px; overflow: hidden; background: var(--accent); height: 200px; display: flex; align-items: center; justify-content: center; color: white; font-size: 14px; font-weight: 600; position: relative; cursor: pointer; transition: transform .25s; }
    #folio-portfolio .portfolio-card:hover { transform: scale(1.03); }
    #folio-portfolio .portfolio-card img { width: 100%; height: 100%; object-fit: cover; position: absolute; inset: 0; display: none; }

    /* ── ABOUT ───────────────── */
    #folio-about { padding: 80px 40px; }
    #folio-about .about-img { border-radius: 16px; overflow: hidden; background: linear-gradient(135deg,var(--accent),var(--accent2)); height: 380px; display: flex; align-items: center; justify-content: center; font-size: 80px; }
    #folio-about .about-img img { width:100%;height:100%;object-fit:cover;display:none; }
    .skill-bar { background: #e5e7eb; border-radius: 999px; height: 8px; margin-bottom: 4px; overflow: hidden; }
    .skill-bar-fill { height: 100%; border-radius: 999px; background: linear-gradient(90deg, var(--accent), var(--accent2)); }

    /* ── FOOTER ─────────────── */
    #folio-footer { background: #0b0e14; color: #9ca3af; padding: 60px 40px 30px; }
    #folio-footer .footer-brand h3 { color: var(--accent); font-weight: 700; font-size: 1.4rem; margin-bottom: 10px; }
    #folio-footer .footer-brand p { font-size: 13px; line-height: 1.7; max-width: 240px; }
    #folio-footer h5 { color: #e2e4f0; font-size: 13px; font-weight: 600; text-transform: uppercase; letter-spacing: .06em; margin-bottom: 16px; }
    #folio-footer ul { list-style: none; padding: 0; }
    #folio-footer ul li { margin-bottom: 8px; }
    #folio-footer ul li a { color: #6b7280; font-size: 13px; text-decoration: none; transition: color .15s; }
    #folio-footer ul li a:hover { color: #a5b4fc; }
    #folio-footer .footer-bottom { border-top: 1px solid rgba(255,255,255,.06); padding-top: 24px; font-size: 12px; color: #4b5563; }
    #folio-footer .social-links a { color: #6b7280; font-size: 18px; margin-right: 12px; transition: all .15s; text-decoration: none; }
    #folio-footer .social-links a:hover { color: #a5b4fc; }
    @media(max-width:768px) { #folio-hero { padding: 50px 20px; } #folio-hero h1 { font-size: 2rem; } }
  </style>
</head>
<body>

  <!-- NAVBAR -->
  <nav class="folio-navbar" id="folio-nav-component">
    <a href="#" class="folio-nav-logo" contenteditable="true">FolioOne</a>

    <!-- Desktop nav links (inline) -->
    <ul class="folio-nav-list" id="folio-main-nav">
      <li><a href="#folio-hero" class="active" onclick="folioCloseNav()">Home</a></li>
      <li><a href="#folio-about" onclick="folioCloseNav()">About</a></li>
      <li><a href="#folio-services" onclick="folioCloseNav()">Services</a></li>
      <li><a href="#folio-portfolio" onclick="folioCloseNav()">Portfolio</a></li>
      <li><a href="#folio-contact" onclick="folioCloseNav()">Contact</a></li>
      <li class="folio-nav-cta"><a href="#folio-contact" onclick="folioCloseNav()">Get Started</a></li>
      <!-- Mobile-only socials row inside drawer -->
      <li class="folio-drawer-socials-li" style="padding:0;border:none;">
        <div class="folio-nav-socials-row">
          <a class="folio-nav-social" href="https://www.facebook.com/share/1JR8DCb9Hm/" target="_blank" onmouseover="this.style.color='#1877f2';this.style.background='rgba(24,119,242,.12)'" onmouseout="this.style.color='#9ca3af';this.style.background='transparent'"><i class="bi bi-facebook"></i></a>
          <a class="folio-nav-social" href="#" onmouseover="this.style.color='#e1306c';this.style.background='rgba(225,48,108,.12)'" onmouseout="this.style.color='#9ca3af';this.style.background='transparent'"><i class="bi bi-instagram"></i></a>
          <a class="folio-nav-social" href="#" onmouseover="this.style.color='#0077b5';this.style.background='rgba(0,119,181,.12)'" onmouseout="this.style.color='#9ca3af';this.style.background='transparent'"><i class="bi bi-linkedin"></i></a>
          <a class="folio-nav-social" href="#" onmouseover="this.style.color='white';this.style.background='rgba(255,255,255,.1)'" onmouseout="this.style.color='#9ca3af';this.style.background='transparent'"><i class="bi bi-github"></i></a>
        </div>
      </li>
    </ul>

    <!-- Desktop social icons (outside the drawer list) -->
    <div class="folio-desktop-socials">
      <a class="folio-nav-social" href="https://www.facebook.com/share/1JR8DCb9Hm/" target="_blank" onmouseover="this.style.color='#1877f2';this.style.background='rgba(24,119,242,.12)'" onmouseout="this.style.color='#9ca3af';this.style.background='transparent'"><i class="bi bi-facebook"></i></a>
      <a class="folio-nav-social" href="#" onmouseover="this.style.color='#e1306c';this.style.background='rgba(225,48,108,.12)'" onmouseout="this.style.color='#9ca3af';this.style.background='transparent'"><i class="bi bi-instagram"></i></a>
      <a class="folio-nav-social" href="#" onmouseover="this.style.color='#0077b5';this.style.background='rgba(0,119,181,.12)'" onmouseout="this.style.color='#9ca3af';this.style.background='transparent'"><i class="bi bi-linkedin"></i></a>
      <a class="folio-nav-social" href="#" onmouseover="this.style.color='white';this.style.background='rgba(255,255,255,.1)'" onmouseout="this.style.color='#9ca3af';this.style.background='transparent'"><i class="bi bi-github"></i></a>
    </div>

    <!-- Hamburger (mobile only — hidden on desktop via CSS) -->
    <button class="folio-hamburger" id="folio-hamburger-btn" onclick="folioToggleNav(this)">☰</button>

    <div id="folio-nav-overlay" onclick="folioCloseNav()"></div>
  </nav>

  <!-- HERO SECTION -->
  <section id="folio-hero">
    <div class="container-xxl">
      <div class="row align-items-center gy-5">
        <div class="col-lg-6 order-lg-1 order-2">
          <h1>Hello, I'm <span contenteditable="true">CodeMe</span></h1>
          <p class="lead mb-4" contenteditable="true">Creative UI/UX Designer &amp; Web Developer building amazing digital experiences with passion and modern tools.</p>
          <div class="d-flex gap-3 flex-wrap mb-4">
            <a href="#folio-portfolio" class="btn-folio-primary">View My Work</a>
            <a href="#folio-contact" class="btn-folio-outline">Get In Touch</a>
          </div>
          <div class="d-flex gap-3">
            <a href="https://www.facebook.com/share/1JR8DCb9Hm/" target="_blank" style="color:#6b7280;font-size:20px;transition:color .15s;" onmouseover="this.style.color='#1877f2'" onmouseout="this.style.color='#6b7280'"><i class="bi bi-facebook"></i></a>
            <a href="#" style="color:#6b7280;font-size:20px;transition:color .15s;" onmouseover="this.style.color='#e1306c'" onmouseout="this.style.color='#6b7280'"><i class="bi bi-instagram"></i></a>
            <a href="#" style="color:#6b7280;font-size:20px;transition:color .15s;" onmouseover="this.style.color='#0077b5'" onmouseout="this.style.color='#6b7280'"><i class="bi bi-linkedin"></i></a>
            <a href="#" style="color:#6b7280;font-size:20px;transition:color .15s;" onmouseover="this.style.color='#111'" onmouseout="this.style.color='#6b7280'"><i class="bi bi-github"></i></a>
          </div>
        </div>
        <div class="col-lg-6 order-lg-2 order-1 text-center">
          <div class="hero-img-wrap mx-auto" id="folio-hero-img-wrap">
            <img src="" alt="" id="folio-hero-img">
            <span>👤</span>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- SERVICES SECTION -->
  <section id="folio-services">
    <div class="container-xxl">
      <div class="text-center">
        <h2 class="section-title" contenteditable="true">My Services</h2>
        <p class="section-sub text-center" contenteditable="true">Professional services tailored to bring your vision to life</p>
      </div>
      <div class="row g-4">
        <div class="col-lg-4 col-md-6">
          <div class="service-card">
            <div class="service-icon">🎨</div>
            <h5 class="fw-bold mb-2" contenteditable="true">UI/UX Design</h5>
            <p class="text-muted" contenteditable="true">Creating beautiful, intuitive interfaces that users love to interact with.</p>
          </div>
        </div>
        <div class="col-lg-4 col-md-6">
          <div class="service-card">
            <div class="service-icon">💻</div>
            <h5 class="fw-bold mb-2" contenteditable="true">Web Development</h5>
            <p class="text-muted" contenteditable="true">Building fast, responsive websites using modern technologies and best practices.</p>
          </div>
        </div>
        <div class="col-lg-4 col-md-6">
          <div class="service-card">
            <div class="service-icon">📱</div>
            <h5 class="fw-bold mb-2" contenteditable="true">Mobile Development</h5>
            <p class="text-muted" contenteditable="true">Creating cross-platform mobile applications for iOS and Android.</p>
          </div>
        </div>
        <div class="col-lg-4 col-md-6">
          <div class="service-card">
            <div class="service-icon">🚀</div>
            <h5 class="fw-bold mb-2" contenteditable="true">SEO Optimization</h5>
            <p class="text-muted" contenteditable="true">Boosting your online visibility with proven SEO strategies and techniques.</p>
          </div>
        </div>
        <div class="col-lg-4 col-md-6">
          <div class="service-card">
            <div class="service-icon">🎯</div>
            <h5 class="fw-bold mb-2" contenteditable="true">Digital Marketing</h5>
            <p class="text-muted" contenteditable="true">Reaching your target audience through effective digital marketing campaigns.</p>
          </div>
        </div>
        <div class="col-lg-4 col-md-6">
          <div class="service-card">
            <div class="service-icon">☁️</div>
            <h5 class="fw-bold mb-2" contenteditable="true">Cloud Solutions</h5>
            <p class="text-muted" contenteditable="true">Scalable cloud infrastructure and deployment solutions for your business.</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- PORTFOLIO SECTION -->
  <section id="folio-portfolio">
    <div class="container-xxl">
      <div class="text-center mb-5">
        <h2 class="fw-bold" style="font-size:2rem;color:#111;" contenteditable="true">My Portfolio</h2>
        <p class="text-muted" contenteditable="true">A selection of my recent work and projects</p>
      </div>
      <div class="row g-4">
        <div class="col-lg-4 col-md-6"><div class="portfolio-card" style="background:linear-gradient(135deg,#6366f1,#8b5cf6);">Project 1</div></div>
        <div class="col-lg-4 col-md-6"><div class="portfolio-card" style="background:linear-gradient(135deg,#0ea5e9,#6366f1);">Project 2</div></div>
        <div class="col-lg-4 col-md-6"><div class="portfolio-card" style="background:linear-gradient(135deg,#22c55e,#0ea5e9);">Project 3</div></div>
        <div class="col-lg-4 col-md-6"><div class="portfolio-card" style="background:linear-gradient(135deg,#f59e0b,#ef4444);">Project 4</div></div>
        <div class="col-lg-4 col-md-6"><div class="portfolio-card" style="background:linear-gradient(135deg,#ec4899,#8b5cf6);">Project 5</div></div>
        <div class="col-lg-4 col-md-6"><div class="portfolio-card" style="background:linear-gradient(135deg,#0b0e14,#6366f1);">Project 6</div></div>
      </div>
    </div>
  </section>

  <!-- ABOUT SECTION -->
  <section id="folio-about">
    <div class="container-xxl">
      <div class="row align-items-center gy-5">
        <div class="col-lg-5">
          <div class="about-img" id="folio-about-img">
            <img src="" alt="" id="folio-about-photo">
            <span>🧑‍💻</span>
          </div>
        </div>
        <div class="col-lg-7 ps-lg-5">
          <h2 class="fw-bold mb-3" style="font-size:2rem;" contenteditable="true">About Me</h2>
          <p class="text-muted mb-4" contenteditable="true">I'm a passionate creative professional with 5+ years of experience in design and development. I love building beautiful, functional products that make people's lives easier.</p>
          <div class="row g-3 mb-4">
            <div class="col-6"><div style="background:#f8fafc;border-radius:10px;padding:16px;text-align:center;"><div style="font-size:1.8rem;font-weight:700;color:var(--accent);" contenteditable="true">50+</div><div style="font-size:13px;color:#6b7280;" contenteditable="true">Projects Done</div></div></div>
            <div class="col-6"><div style="background:#f8fafc;border-radius:10px;padding:16px;text-align:center;"><div style="font-size:1.8rem;font-weight:700;color:var(--accent);" contenteditable="true">30+</div><div style="font-size:13px;color:#6b7280;" contenteditable="true">Happy Clients</div></div></div>
          </div>
          <div class="mb-2 d-flex justify-content-between"><span class="fw-semibold" style="font-size:13px;" contenteditable="true">Web Design</span><span style="font-size:13px;color:#6b7280;">90%</span></div>
          <div class="skill-bar mb-3"><div class="skill-bar-fill" style="width:90%;"></div></div>
          <div class="mb-2 d-flex justify-content-between"><span class="fw-semibold" style="font-size:13px;" contenteditable="true">Development</span><span style="font-size:13px;color:#6b7280;">85%</span></div>
          <div class="skill-bar mb-3"><div class="skill-bar-fill" style="width:85%;"></div></div>
          <div class="mb-2 d-flex justify-content-between"><span class="fw-semibold" style="font-size:13px;" contenteditable="true">SEO & Marketing</span><span style="font-size:13px;color:#6b7280;">70%</span></div>
          <div class="skill-bar"><div class="skill-bar-fill" style="width:70%;"></div></div>
        </div>
      </div>
    </div>
  </section>

  <!-- CONTACT SECTION -->
  <section id="folio-contact" style="padding:80px 40px;background:#f8fafc;">
    <div class="container-xxl">
      <div class="row justify-content-center">
        <div class="col-lg-6 text-center">
          <h2 class="fw-bold mb-2" style="font-size:2rem;" contenteditable="true">Get In Touch</h2>
          <p class="text-muted mb-5" contenteditable="true">Have a project in mind? Let's work together!</p>
          <div style="background:white;border-radius:16px;padding:36px;box-shadow:0 4px 24px rgba(0,0,0,.08);text-align:left;">
            <div class="mb-3">
              <input type="text" placeholder="Your Name" style="width:100%;padding:12px 16px;border:1px solid #e5e7eb;border-radius:8px;font-size:14px;outline:none;box-sizing:border-box;">
            </div>
            <div class="mb-3">
              <input type="email" placeholder="Your Email" style="width:100%;padding:12px 16px;border:1px solid #e5e7eb;border-radius:8px;font-size:14px;outline:none;box-sizing:border-box;">
            </div>
            <div class="mb-3">
              <textarea placeholder="Your Message" rows="4" style="width:100%;padding:12px 16px;border:1px solid #e5e7eb;border-radius:8px;font-size:14px;outline:none;box-sizing:border-box;resize:vertical;"></textarea>
            </div>
            <button style="width:100%;padding:14px;background:var(--accent);color:white;border:none;border-radius:8px;font-size:15px;font-weight:600;cursor:pointer;" onmouseover="this.style.background='#4f46e5'" onmouseout="this.style.background='var(--accent)'">Send Message</button>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- FOOTER -->
  <footer id="folio-footer">
    <div class="container-xxl">
      <div class="row g-5 mb-4">
        <div class="col-lg-4 footer-brand">
          <h3 contenteditable="true">FolioOne</h3>
          <p contenteditable="true">Building amazing digital experiences with modern tools and passionate teams.</p>
          <div class="social-links mt-3">
            <a href="https://www.facebook.com/share/1JR8DCb9Hm/" target="_blank"><i class="bi bi-facebook"></i></a>
            <a href="#"><i class="bi bi-instagram"></i></a>
            <a href="#"><i class="bi bi-twitter-x"></i></a>
            <a href="#"><i class="bi bi-linkedin"></i></a>
          </div>
        </div>
        <div class="col-lg-2 col-6">
          <h5>Company</h5>
          <ul>
            <li><a href="#">Home</a></li>
            <li><a href="#">About Us</a></li>
            <li><a href="#">Services</a></li>
            <li><a href="#">Contact</a></li>
          </ul>
        </div>
        <div class="col-lg-2 col-6">
          <h5>Services</h5>
          <ul>
            <li><a href="#">Web Design</a></li>
            <li><a href="#">Development</a></li>
            <li><a href="#">Marketing</a></li>
            <li><a href="#">SEO</a></li>
          </ul>
        </div>
        <div class="col-lg-4">
          <h5>Newsletter</h5>
          <p style="font-size:13px;line-height:1.7;" contenteditable="true">Subscribe to get the latest updates and news.</p>
          <div style="display:flex;gap:8px;margin-top:12px;">
            <input type="email" placeholder="Your email" style="flex:1;padding:10px 14px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:6px;color:white;font-size:13px;outline:none;">
            <button style="padding:10px 18px;background:var(--accent);color:white;border:none;border-radius:6px;cursor:pointer;font-weight:600;font-size:13px;">Subscribe</button>
          </div>
        </div>
      </div>
      <div class="footer-bottom d-flex justify-content-between align-items-center flex-wrap gap-2">
        <span contenteditable="true">© 2025 FolioOne. All Rights Reserved.</span>
        <div class="social-links">
          <a href="#"><i class="bi bi-twitter-x"></i></a>
          <a href="#"><i class="bi bi-linkedin"></i></a>
          <a href="#"><i class="bi bi-github"></i></a>
        </div>
      </div>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"><\/script>
  <script>
    function folioToggleNav(btn) {
      var nav     = document.getElementById('folio-main-nav');
      var overlay = document.getElementById('folio-nav-overlay');
      var isOpen  = nav.classList.toggle('open');
      btn.textContent = isOpen ? '✕' : '☰';
      btn.style.background = isOpen ? 'rgba(239,68,68,.15)' : 'rgba(255,255,255,.06)';
      btn.style.borderColor = isOpen ? 'rgba(239,68,68,.3)' : 'rgba(255,255,255,.1)';
      if (overlay) overlay.style.display = isOpen ? 'block' : 'none';
    }
    function folioCloseNav() {
      var nav     = document.getElementById('folio-main-nav');
      var btn     = document.getElementById('folio-hamburger-btn');
      var overlay = document.getElementById('folio-nav-overlay');
      if (nav)     nav.classList.remove('open');
      if (btn)     { btn.textContent = '☰'; btn.style.background = 'rgba(255,255,255,.06)'; btn.style.borderColor = 'rgba(255,255,255,.1)'; }
      if (overlay) overlay.style.display = 'none';
    }
    // Close drawer with Escape key
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape') folioCloseNav();
    });
  <\/script>
</html>`;
}


/* ═══════════════════════════════════════════════════════
   HERO BANNER EDITOR
   ═══════════════════════════════════════════════════════ */

function refreshHeroEditor(hero) {
  const settingsPanel = document.getElementById('widgetSettings');
  const container     = document.getElementById('navbarStructure');
  settingsPanel.style.display = 'block';
  container.innerHTML = '';
  container.appendChild(createEditorLabel('Hero Banner'));

  const h1    = hero.querySelector('h1');
  const para  = hero.querySelector('p');
  const img   = hero.querySelector('.pb-hero-img');
  const ph    = hero.querySelector('.pb-hero-placeholder');

  if (h1) {
    const r = makeEditorRow('Headline', h1.innerText, false);
    r.querySelector('input').oninput = e => { h1.innerHTML = e.target.value; updateCode(); };
    container.appendChild(r);
  }
  if (para) {
    const r = makeEditorRow('Subtitle', para.innerText, false);
    r.querySelector('input').oninput = e => { para.innerText = e.target.value; updateCode(); };
    container.appendChild(r);
  }

  if (img) {
    container.appendChild(createEditorLabel('Profile Photo'));
    const uploadRow = document.createElement('div');
    uploadRow.innerHTML = `<button class="btn btn-primary" style="width:100%;font-size:10px;margin-bottom:4px;">Upload Photo</button><input type="file" accept="image/*" style="display:none;">`;
    uploadRow.querySelector('button').onclick = () => uploadRow.querySelector('input[type=file]').click();
    uploadRow.querySelector('input[type=file]').onchange = e => {
      const r = new FileReader();
      r.onload = ev => {
        img.src = ev.target.result;
        img.style.display = 'block';
        if (ph) ph.style.display = 'none';
        updateCode();
      };
      if (e.target.files[0]) r.readAsDataURL(e.target.files[0]);
    };
    container.appendChild(uploadRow);
  }

  container.appendChild(createEditorLabel('Background'));
  const bgRow = document.createElement('div');
  bgRow.style = 'display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-bottom:8px;';
  [['Light Gray','linear-gradient(135deg,#f8f9fa 0%,#e9ecef 100%)'],['White','#ffffff'],['Dark','#0b0e14'],['Purple','linear-gradient(135deg,#6366f1,#8b5cf6)'],['Blue','linear-gradient(135deg,#0ea5e9,#6366f1)'],['Custom','']].forEach(([label, bg]) => {
    const b = document.createElement('button');
    b.className = 'editor-btn'; b.innerText = label;
    if (bg) b.onclick = () => { hero.style.background = bg; updateCode(); };
    else b.onclick = () => {
      const c = prompt('Enter CSS background (color, gradient, etc):', hero.style.background);
      if (c) { hero.style.background = c; updateCode(); }
    };
    bgRow.appendChild(b);
  });
  container.appendChild(bgRow);
}


</script>
</body>

<script>
/* ═══════════════════════════════════════════════════════
   FOLIO ONE LIVE EDITOR
   Communicates with the FolioOne iframe via contentDocument
   ═══════════════════════════════════════════════════════ */

// Get the FolioOne iframe document safely
function getFolioDoc() {
  const frame = document.getElementById('import-preview-frame');
  if (!frame || frame.style.display === 'none') return null;
  try { return frame.contentDocument || frame.contentWindow.document; } catch(e) { return null; }
}

// Re-serialize the iframe HTML back into projectFiles and show editor
function folioSync() {
  const doc = getFolioDoc();
  if (!doc) return;
  const html = '<!DOCTYPE html>\n' + doc.documentElement.outerHTML;
  projectFiles['index.html'] = { raw: html, selfContained: html };
  const frame = document.getElementById('import-preview-frame');
  if (frame) frame.srcdoc = html; // re-render to persist
}

// Open the FolioOne editor panel and populate tabs
function openFolioEditor() {
  const doc = getFolioDoc();
  if (!doc) {
    alert('Load the FolioOne template first (it should be the default when you open the builder).');
    return;
  }
  document.getElementById('widgetSettings').style.display   = 'none';
  document.getElementById('folioEditorPanel').style.display = 'block';
  buildFolioTabs(doc);
}

function buildFolioTabs(doc) {
  const bar     = document.getElementById('folioTabBar');
  const content = document.getElementById('folioTabContent');
  bar.innerHTML = '';
  const tabs = [
    { id:'nav',       label:'🔗 Navbar'   },
    { id:'hero',      label:'🏠 Hero'     },
    { id:'services',  label:'🛠 Services' },
    { id:'portfolio', label:'🖼 Portfolio'},
    { id:'about',     label:'👤 About'    },
    { id:'contact',   label:'✉ Contact'  },
    { id:'footer',    label:'📋 Footer'  },
  ];
  tabs.forEach((t, i) => {
    const btn = document.createElement('button');
    btn.className = 'editor-btn';
    btn.style = 'padding:4px 8px;font-size:10px;flex-shrink:0;' + (i===0?'background:var(--accent);color:#fff;':'');
    btn.textContent = t.label;
    btn.onclick = () => {
      bar.querySelectorAll('button').forEach(b => { b.style.background=''; b.style.color=''; });
      btn.style.background = 'var(--accent)'; btn.style.color = '#fff';
      renderFolioTab(t.id, doc);
    };
    bar.appendChild(btn);
  });
  renderFolioTab('nav', doc);
}

function renderFolioTab(tab, doc) {
  const el = document.getElementById('folioTabContent');
  el.innerHTML = '';

  if (tab === 'nav')      renderFolioNavEditor(doc, el);
  if (tab === 'hero')     renderFolioSectionEditor(doc, el, '#folio-hero',      folioHeroFields);
  if (tab === 'services') renderFolioServicesEditor(doc, el);
  if (tab === 'portfolio')renderFolioPortfolioEditor(doc, el);
  if (tab === 'about')    renderFolioSectionEditor(doc, el, '#folio-about',     folioAboutFields);
  if (tab === 'contact')  renderFolioSectionEditor(doc, el, '#folio-contact',   folioContactFields);
  if (tab === 'footer')   renderFolioFooterEditor(doc, el);
}

/* ── Shared helpers ── */
function folioMakeInput(label, value, onChange) {
  const wrap = document.createElement('div');
  wrap.style = 'margin-bottom:8px;';
  wrap.innerHTML = `<label style="font-size:10px;color:var(--text-muted);display:block;margin-bottom:3px;text-transform:uppercase;letter-spacing:.06em;">${label}</label>
    <input type="text" value="${(value||'').replace(/"/g,'&quot;')}"
      style="width:100%;background:var(--surface3);border:1px solid var(--border);color:var(--text);
             padding:6px 8px;border-radius:4px;font-size:12px;outline:none;box-sizing:border-box;">`;
  wrap.querySelector('input').oninput = e => onChange(e.target.value);
  return wrap;
}
function folioMakeColor(label, value, onChange) {
  const wrap = document.createElement('div');
  wrap.style = 'margin-bottom:8px;display:flex;align-items:center;gap:8px;';
  wrap.innerHTML = `<label style="font-size:10px;color:var(--text-muted);flex:1;text-transform:uppercase;letter-spacing:.06em;">${label}</label>
    <input type="color" value="${value||'#6366f1'}" style="width:32px;height:28px;border:none;background:none;cursor:pointer;border-radius:4px;">`;
  wrap.querySelector('input').oninput = e => onChange(e.target.value);
  return wrap;
}
function folioMakeTextarea(label, value, onChange) {
  const wrap = document.createElement('div');
  wrap.style = 'margin-bottom:8px;';
  wrap.innerHTML = `<label style="font-size:10px;color:var(--text-muted);display:block;margin-bottom:3px;text-transform:uppercase;letter-spacing:.06em;">${label}</label>
    <textarea style="width:100%;background:var(--surface3);border:1px solid var(--border);color:var(--text);
             padding:6px 8px;border-radius:4px;font-size:12px;outline:none;box-sizing:border-box;resize:vertical;min-height:60px;">${(value||'').replace(/</g,'&lt;')}</textarea>`;
  wrap.querySelector('textarea').oninput = e => onChange(e.target.value);
  return wrap;
}
function folioMakeSelect(label, options, current, onChange) {
  const wrap = document.createElement('div');
  wrap.style = 'margin-bottom:8px;';
  const opts = options.map(o => `<option value="${o.v}" ${o.v===current?'selected':''}>${o.l}</option>`).join('');
  wrap.innerHTML = `<label style="font-size:10px;color:var(--text-muted);display:block;margin-bottom:3px;text-transform:uppercase;letter-spacing:.06em;">${label}</label>
    <select style="width:100%;background:var(--surface3);border:1px solid var(--border);color:var(--text);
             padding:6px 8px;border-radius:4px;font-size:12px;outline:none;box-sizing:border-box;">${opts}</select>`;
  wrap.querySelector('select').onchange = e => onChange(e.target.value);
  return wrap;
}
function folioLabel(text) {
  const d = document.createElement('div');
  d.style = 'font-size:11px;font-weight:700;color:var(--text);text-transform:uppercase;letter-spacing:.08em;margin:12px 0 6px;border-bottom:1px solid var(--border);padding-bottom:4px;';
  d.textContent = text;
  return d;
}
function folioSaveThenRefresh(doc, tab) {
  // Persist changes to srcdoc then re-render the tab
  const html = '<!DOCTYPE html>\n' + doc.documentElement.outerHTML;
  projectFiles['index.html'] = { raw: html, selfContained: html };
  renderFolioTab(tab, doc);
}

/* ══════════════════════════════════════════════
   NAVBAR EDITOR — full add/edit/delete + sub-dropdown
   ══════════════════════════════════════════════ */
function renderFolioNavEditor(doc, el) {
  const nav      = doc.getElementById('folio-nav-component');
  const mainNav  = doc.getElementById('folio-main-nav');
  if (!nav || !mainNav) { el.innerHTML='<p style="color:var(--text-muted);font-size:12px;">Navbar not found.</p>'; return; }

  // ── Logo ──
  el.appendChild(folioLabel('Logo'));
  const logoEl = nav.querySelector('.folio-nav-logo');
  if (logoEl) {
    el.appendChild(folioMakeInput('Logo Text', logoEl.textContent, v => { logoEl.textContent = v; folioSaveThenRefresh(doc,'nav'); }));
    el.appendChild(folioMakeColor('Logo Color', rgbToHex(getComputedStyle(logoEl).color) || '#6366f1', v => { logoEl.style.color = v; folioSaveThenRefresh(doc,'nav'); }));
  }

  // ── Navbar background ──
  el.appendChild(folioLabel('Navbar Style'));
  el.appendChild(folioMakeColor('Background', rgbToHex(getComputedStyle(nav).backgroundColor)||'#0b0e14', v => { nav.style.background = v; folioSaveThenRefresh(doc,'nav'); }));
  el.appendChild(folioMakeSelect('Position', [
    {v:'sticky',l:'Sticky (follows scroll)'},{v:'fixed',l:'Fixed'},{v:'relative',l:'Static'}
  ], nav.style.position||'sticky', v => { nav.style.position = v; folioSaveThenRefresh(doc,'nav'); }));

  // ── Nav Links ──
  el.appendChild(folioLabel('Navigation Links'));

  // Get only top-level <li> items (exclude the drawer-socials li)
  const items = [...mainNav.querySelectorAll(':scope > li')].filter(li => !li.classList.contains('folio-drawer-socials-li'));

  items.forEach((li, idx) => {
    const linkEl    = li.querySelector('a') || li;
    const linkText  = linkEl.tagName === 'A' ? linkEl.textContent.trim() : li.childNodes[0]?.textContent?.trim() || '';
    const linkHref  = linkEl.tagName === 'A' ? linkEl.getAttribute('href') || '#' : '#';
    const hasDrop   = !!li.querySelector('.folio-dropdown');

    const card = document.createElement('div');
    card.style = 'background:var(--surface3);border:1px solid var(--border);border-radius:6px;padding:8px;margin-bottom:6px;';

    // Link row
    const linkRow = document.createElement('div');
    linkRow.style = 'display:flex;align-items:center;gap:5px;margin-bottom:6px;';
    linkRow.innerHTML = `
      <span style="background:var(--accent);color:#fff;font-size:8px;font-weight:700;padding:2px 5px;border-radius:3px;flex-shrink:0;">LINK</span>
      <input type="text" value="${linkText.replace(/"/g,'&quot;')}" placeholder="Label"
        style="flex:1;min-width:0;background:var(--bg);border:1px solid var(--border);color:var(--text);
               padding:5px 7px;border-radius:4px;font-size:12px;outline:none;">
      <input type="text" value="${linkHref.replace(/"/g,'&quot;')}" placeholder="href"
        style="flex:1;min-width:0;background:var(--bg);border:1px solid var(--border);color:var(--text);
               padding:5px 7px;border-radius:4px;font-size:12px;outline:none;">
      <button class="nb-del" style="background:#f43f5e22;border:1px solid #f43f5e55;color:#f43f5e;
               border-radius:3px;padding:2px 8px;font-size:14px;font-weight:700;cursor:pointer;line-height:1;">×</button>
    `;
    const [labelIn, hrefIn] = linkRow.querySelectorAll('input');
    labelIn.oninput = e => {
      if (linkEl.tagName === 'A') linkEl.textContent = e.target.value;
      else if (li.childNodes[0]) li.childNodes[0].textContent = e.target.value;
    };
    hrefIn.oninput = e => { if (linkEl.tagName === 'A') linkEl.setAttribute('href', e.target.value); };
    const delBtn = linkRow.querySelector('.nb-del');
    delBtn.onclick = () => { li.remove(); folioSaveThenRefresh(doc,'nav'); };
    card.appendChild(linkRow);

    // Sub-dropdown section
    const dropList = li.querySelector('.folio-dropdown');
    if (dropList) {
      const subItems = dropList.querySelectorAll(':scope > li');
      subItems.forEach(subLi => {
        const subA    = subLi.querySelector('a') || subLi;
        const subText = subA.tagName === 'A' ? subA.textContent.trim() : subLi.textContent.trim();
        const subHref = subA.tagName === 'A' ? subA.getAttribute('href') || '#' : '#';
        const subRow  = document.createElement('div');
        subRow.style  = 'display:flex;align-items:center;gap:5px;margin-bottom:4px;margin-left:14px;';
        subRow.innerHTML = `
          <span style="width:2px;height:20px;background:var(--accent);border-radius:2px;flex-shrink:0;"></span>
          <span style="background:#6366f1;color:#fff;font-size:7px;font-weight:700;padding:2px 4px;border-radius:2px;flex-shrink:0;">SUB</span>
          <input type="text" value="${subText.replace(/"/g,'&quot;')}" placeholder="Label"
            style="flex:1;min-width:0;background:var(--bg);border:1px solid var(--border);color:var(--text);
                   padding:4px 6px;border-radius:4px;font-size:11px;outline:none;">
          <input type="text" value="${subHref.replace(/"/g,'&quot;')}" placeholder="href"
            style="flex:1;min-width:0;background:var(--bg);border:1px solid var(--border);color:var(--text);
                   padding:4px 6px;border-radius:4px;font-size:11px;outline:none;">
          <button style="background:#f43f5e22;border:1px solid #f43f5e55;color:#f43f5e;
                   border-radius:3px;padding:2px 7px;font-size:13px;font-weight:700;cursor:pointer;line-height:1;">×</button>
        `;
        const [sl, sh] = subRow.querySelectorAll('input');
        sl.oninput = e => { if (subA.tagName==='A') subA.textContent=e.target.value; else subLi.textContent=e.target.value; };
        sh.oninput = e => { if (subA.tagName==='A') subA.setAttribute('href',e.target.value); };
        subRow.querySelector('button').onclick = () => {
          subLi.remove();
          if (!dropList.querySelector('li')) {
            dropList.remove();
            li.classList.remove('folio-has-dropdown');
          }
          folioSaveThenRefresh(doc,'nav');
        };
        card.appendChild(subRow);
      });
    }

    // Add sub-item + move up/down buttons
    const actRow = document.createElement('div');
    actRow.style = 'display:flex;gap:5px;margin-top:4px;';
    actRow.innerHTML = `
      <button class="add-sub-btn" style="flex:1;background:var(--surface2);border:1px solid var(--border);color:var(--text-muted);
              border-radius:4px;padding:4px 6px;font-size:10px;cursor:pointer;">+ Sub-item</button>
      <button class="move-up-btn" style="background:var(--surface2);border:1px solid var(--border);color:var(--text-muted);
              border-radius:4px;padding:4px 8px;font-size:10px;cursor:pointer;" title="Move up">↑</button>
      <button class="move-dn-btn" style="background:var(--surface2);border:1px solid var(--border);color:var(--text-muted);
              border-radius:4px;padding:4px 8px;font-size:10px;cursor:pointer;" title="Move down">↓</button>
    `;
    actRow.querySelector('.add-sub-btn').onclick = () => {
      let dd = li.querySelector('.folio-dropdown');
      if (!dd) {
        li.classList.add('folio-has-dropdown');
        dd = doc.createElement('ul');
        dd.className = 'folio-dropdown';
        li.appendChild(dd);
      }
      const newSub  = doc.createElement('li');
      const newSubA = doc.createElement('a');
      newSubA.href  = '#'; newSubA.textContent = 'Sub Item';
      newSub.appendChild(newSubA);
      dd.appendChild(newSub);
      folioSaveThenRefresh(doc,'nav');
    };
    actRow.querySelector('.move-up-btn').onclick = () => {
      const prev = li.previousElementSibling;
      if (prev && !prev.classList.contains('folio-drawer-socials-li')) { mainNav.insertBefore(li, prev); folioSaveThenRefresh(doc,'nav'); }
    };
    actRow.querySelector('.move-dn-btn').onclick = () => {
      const next = li.nextElementSibling;
      if (next && !next.classList.contains('folio-drawer-socials-li')) { mainNav.insertBefore(next, li); folioSaveThenRefresh(doc,'nav'); }
    };
    card.appendChild(actRow);
    el.appendChild(card);
  });

  // Add link button
  const addBtn = document.createElement('button');
  addBtn.className = 'btn btn-primary';
  addBtn.style     = 'width:100%;margin-top:4px;font-size:11px;';
  addBtn.textContent = '+ Add Nav Link';
  addBtn.onclick = () => {
    const newLi = doc.createElement('li');
    const newA  = doc.createElement('a');
    newA.href = '#'; newA.textContent = 'New Link';
    newA.setAttribute('onclick','folioCloseNav()');
    newLi.appendChild(newA);
    // Insert before the drawer socials li if present
    const drawerSocials = mainNav.querySelector('.folio-drawer-socials-li');
    if (drawerSocials) mainNav.insertBefore(newLi, drawerSocials);
    else mainNav.appendChild(newLi);
    folioSaveThenRefresh(doc,'nav');
  };
  el.appendChild(addBtn);

  // Ensure dropdown CSS exists in doc
  ensureFolioDropdownCSS(doc);
}

// Inject dropdown CSS into the FolioOne document if missing
function ensureFolioDropdownCSS(doc) {
  if (doc.getElementById('folio-dropdown-css')) return;
  const s = doc.createElement('style');
  s.id = 'folio-dropdown-css';
  s.textContent = `
    /* ── Folio Dropdown Menus ── */
    .folio-has-dropdown { position: relative; }
    .folio-dropdown {
      list-style: none; margin: 0; padding: 6px 0;
      position: absolute; top: 100%; left: 0;
      min-width: 180px;
      background: #0b0e14;
      border: 1px solid rgba(255,255,255,.1);
      border-radius: 8px;
      box-shadow: 0 12px 32px rgba(0,0,0,.5);
      opacity: 0; visibility: hidden; transform: translateY(6px);
      transition: opacity .18s, transform .18s, visibility .18s;
      z-index: 2000;
    }
    .folio-has-dropdown:hover > .folio-dropdown { opacity:1; visibility:visible; transform:translateY(0); }
    .folio-dropdown li a {
      display: block; padding: 9px 18px;
      color: #d1d5db; font-size: 13px; text-decoration: none;
      transition: background .15s, color .15s;
      white-space: nowrap;
    }
    .folio-dropdown li a:hover { background: rgba(99,102,241,.15); color: #fff; padding-left: 22px; }
    /* Mobile: show sub-items inline in drawer */
    @media(max-width:900px){
      .folio-dropdown { position:static; opacity:1; visibility:visible; transform:none; box-shadow:none; border:none; background:transparent; padding:0; }
      .folio-dropdown li a { padding:10px 28px 10px 42px; font-size:13px; border-bottom:1px solid rgba(255,255,255,.04); color:#9ca3af; }
    }
  `;
  doc.head.appendChild(s);
}

/* ══════════════════════════════════════════════
   HERO SECTION EDITOR
   ══════════════════════════════════════════════ */
function folioHeroFields(doc, section, el) {
  const h1   = section.querySelector('h1');
  const span = h1 ? h1.querySelector('span') : null;
  const lead = section.querySelector('p.lead');
  const btn1 = section.querySelector('.btn-folio-primary');
  const btn2 = section.querySelector('.btn-folio-outline');

  if (h1) el.appendChild(folioMakeInput('Headline "Hello, I\'m"', h1.childNodes[0]?.textContent?.trim()||'Hello, I\'m', v => {
    if (h1.childNodes[0]) h1.childNodes[0].textContent = v + ' ';
  }));
  if (span) el.appendChild(folioMakeInput('Name / Highlight', span.textContent, v => { span.textContent = v; }));
  if (lead) el.appendChild(folioMakeTextarea('Subtitle / Bio', lead.textContent, v => { lead.textContent = v; }));
  if (btn1) el.appendChild(folioMakeInput('Button 1 Text', btn1.textContent, v => { btn1.textContent = v; }));
  if (btn1) el.appendChild(folioMakeInput('Button 1 Link', btn1.getAttribute('href')||'#', v => { btn1.setAttribute('href',v); }));
  if (btn2) el.appendChild(folioMakeInput('Button 2 Text', btn2.textContent, v => { btn2.textContent = v; }));
  if (btn2) el.appendChild(folioMakeInput('Button 2 Link', btn2.getAttribute('href')||'#', v => { btn2.setAttribute('href',v); }));

  el.appendChild(folioLabel('Hero Colors'));
  el.appendChild(folioMakeColor('Accent Color', '#6366f1', v => {
    section.querySelectorAll('[style*="#6366f1"]').forEach(n => { n.style.cssText = n.style.cssText.replace(/#6366f1/g,v); });
    if (span) span.style.color = v;
  }));
  el.appendChild(folioLabel('Hero Background'));
  const bgBtns = document.createElement('div');
  bgBtns.style = 'display:grid;grid-template-columns:1fr 1fr;gap:4px;';
  [
    ['Light','linear-gradient(135deg,#f8fafc,#f1f5f9)'],
    ['Dark','#0b0e14'],
    ['Purple','linear-gradient(135deg,#6366f1,#8b5cf6)'],
    ['Blue','linear-gradient(135deg,#0ea5e9,#6366f1)'],
    ['Green','linear-gradient(135deg,#22c55e,#0ea5e9)'],
    ['Custom',''],
  ].forEach(([l,bg]) => {
    const b = document.createElement('button');
    b.className = 'editor-btn'; b.style='font-size:10px;'; b.textContent = l;
    b.onclick = () => {
      if (bg) section.style.background = bg;
      else {
        const c = prompt('CSS background:', section.style.background);
        if (c) section.style.background = c;
      }
    };
    bgBtns.appendChild(b);
  });
  el.appendChild(bgBtns);
}

/* ══════════════════════════════════════════════
   SERVICES EDITOR
   ══════════════════════════════════════════════ */
function renderFolioServicesEditor(doc, el) {
  const section = doc.getElementById('folio-services');
  if (!section) { el.innerHTML='<p style="color:var(--text-muted);font-size:12px;">Services section not found.</p>'; return; }

  el.appendChild(folioLabel('Section Title'));
  const title = section.querySelector('.section-title');
  const sub   = section.querySelector('.section-sub');
  if (title) el.appendChild(folioMakeInput('Title', title.textContent, v => { title.textContent = v; }));
  if (sub)   el.appendChild(folioMakeInput('Subtitle', sub.textContent, v => { sub.textContent = v; }));

  el.appendChild(folioLabel('Service Cards'));
  const cards = section.querySelectorAll('.service-card');
  cards.forEach((card, i) => {
    const h5   = card.querySelector('h5');
    const desc = card.querySelector('p');
    const icon = card.querySelector('.service-icon');
    const cardWrap = document.createElement('div');
    cardWrap.style = 'background:var(--surface3);border:1px solid var(--border);border-radius:6px;padding:8px;margin-bottom:8px;';
    cardWrap.appendChild(folioLabel(`Card ${i+1}`));
    if (icon) cardWrap.appendChild(folioMakeInput('Icon (emoji)', icon.textContent.trim(), v => { icon.textContent = v; }));
    if (h5)   cardWrap.appendChild(folioMakeInput('Title', h5.textContent, v => { h5.textContent = v; }));
    if (desc) cardWrap.appendChild(folioMakeTextarea('Description', desc.textContent, v => { desc.textContent = v; }));
    el.appendChild(cardWrap);
  });

  // Add/remove service card
  const addBtn = document.createElement('button');
  addBtn.className = 'btn btn-primary';
  addBtn.style = 'width:100%;font-size:11px;margin-top:4px;';
  addBtn.textContent = '+ Add Service Card';
  addBtn.onclick = () => {
    const grid = section.querySelector('.row.g-4');
    if (!grid) return;
    const col  = doc.createElement('div'); col.className='col-lg-4 col-md-6';
    col.innerHTML = `<div class="service-card"><div class="service-icon">⭐</div><h5 class="fw-bold mb-2" contenteditable="true">New Service</h5><p class="text-muted" contenteditable="true">Service description here.</p></div>`;
    grid.appendChild(col);
    folioSaveThenRefresh(doc,'services');
  };
  el.appendChild(addBtn);
}

/* ══════════════════════════════════════════════
   PORTFOLIO EDITOR
   ══════════════════════════════════════════════ */
function renderFolioPortfolioEditor(doc, el) {
  const section = doc.getElementById('folio-portfolio');
  if (!section) { el.innerHTML='<p style="color:var(--text-muted);font-size:12px;">Portfolio section not found.</p>'; return; }

  el.appendChild(folioLabel('Section Title'));
  const title = section.querySelector('h2');
  const sub   = section.querySelector('p.text-muted');
  if (title) el.appendChild(folioMakeInput('Title', title.textContent, v => { title.textContent = v; }));
  if (sub)   el.appendChild(folioMakeInput('Subtitle', sub.textContent, v => { sub.textContent = v; }));

  el.appendChild(folioLabel('Portfolio Cards'));
  const cards = section.querySelectorAll('.portfolio-card');
  cards.forEach((card, i) => {
    const cardWrap = document.createElement('div');
    cardWrap.style = 'background:var(--surface3);border:1px solid var(--border);border-radius:6px;padding:8px;margin-bottom:6px;display:flex;align-items:center;gap:6px;';
    const label = document.createElement('span');
    label.style = 'font-size:11px;color:var(--text-muted);flex:1;';
    label.textContent = `Card ${i+1}: ${card.textContent.trim()}`;

    const colorIn = document.createElement('input');
    colorIn.type  = 'color'; colorIn.title = 'Background color';
    colorIn.style = 'width:28px;height:28px;border:none;background:none;cursor:pointer;';
    colorIn.oninput = e => { card.style.background = e.target.value; };

    const imgBtn = document.createElement('button');
    imgBtn.style = 'background:var(--surface2);border:1px solid var(--border);color:var(--text-muted);border-radius:4px;padding:3px 7px;font-size:10px;cursor:pointer;';
    imgBtn.textContent = '🖼 Img';
    const fileIn = document.createElement('input'); fileIn.type='file'; fileIn.accept='image/*'; fileIn.style='display:none;';
    imgBtn.onclick = () => fileIn.click();
    fileIn.onchange = e => {
      const r = new FileReader(); r.onload = ev => {
        let img = card.querySelector('img');
        if (!img) { img = doc.createElement('img'); img.style='width:100%;height:100%;object-fit:cover;position:absolute;inset:0;border-radius:12px;'; card.style.position='relative'; card.prepend(img); }
        img.src = ev.target.result;
      };
      if (e.target.files[0]) r.readAsDataURL(e.target.files[0]);
    };

    const labelIn = document.createElement('input');
    labelIn.type='text'; labelIn.value=card.textContent.trim(); labelIn.placeholder='Label';
    labelIn.style='flex:1;background:var(--bg);border:1px solid var(--border);color:var(--text);padding:4px 6px;border-radius:4px;font-size:11px;outline:none;';
    labelIn.oninput = e => {
      const txt = [...card.childNodes].find(n=>n.nodeType===3);
      if (txt) txt.textContent = e.target.value; else card.prepend(doc.createTextNode(e.target.value));
    };

    const delBtn = document.createElement('button');
    delBtn.style='background:#f43f5e22;border:1px solid #f43f5e55;color:#f43f5e;border-radius:3px;padding:2px 7px;font-size:13px;cursor:pointer;';
    delBtn.textContent='×';
    delBtn.onclick = () => { card.closest('.col-lg-4, .col-md-6')?.remove(); folioSaveThenRefresh(doc,'portfolio'); };

    cardWrap.append(labelIn, colorIn, imgBtn, fileIn, delBtn);
    el.appendChild(cardWrap);
  });

  const addBtn = document.createElement('button');
  addBtn.className='btn btn-primary'; addBtn.style='width:100%;font-size:11px;margin-top:4px;'; addBtn.textContent='+ Add Portfolio Card';
  addBtn.onclick = () => {
    const grid = section.querySelector('.row.g-4'); if (!grid) return;
    const col = doc.createElement('div'); col.className='col-lg-4 col-md-6';
    col.innerHTML=`<div class="portfolio-card" style="background:linear-gradient(135deg,#6366f1,#8b5cf6);">New Project</div>`;
    grid.appendChild(col);
    folioSaveThenRefresh(doc,'portfolio');
  };
  el.appendChild(addBtn);
}

/* ══════════════════════════════════════════════
   ABOUT SECTION — field definitions
   ══════════════════════════════════════════════ */
function folioAboutFields(doc, section, el) {
  const h2   = section.querySelector('h2');
  const para = section.querySelector('p.text-muted');
  if (h2)   el.appendChild(folioMakeInput('Heading', h2.textContent, v => { h2.textContent = v; }));
  if (para) el.appendChild(folioMakeTextarea('Bio', para.textContent, v => { para.textContent = v; }));

  el.appendChild(folioLabel('Stats'));
  section.querySelectorAll('.col-6 [style*="1.8rem"]').forEach((stat, i) => {
    el.appendChild(folioMakeInput(`Stat ${i+1} Number`, stat.textContent, v => { stat.textContent = v; }));
    const lbl = stat.nextElementSibling;
    if (lbl) el.appendChild(folioMakeInput(`Stat ${i+1} Label`, lbl.textContent, v => { lbl.textContent = v; }));
  });

  el.appendChild(folioLabel('Skill Bars'));
  section.querySelectorAll('.skill-bar').forEach((bar, i) => {
    const fill  = bar.querySelector('.skill-bar-fill');
    const label = bar.previousElementSibling?.querySelector('.fw-semibold');
    const pct   = bar.previousElementSibling?.querySelector('[style*="color:#6b7280"]');
    if (label) el.appendChild(folioMakeInput(`Skill ${i+1} Name`, label.textContent, v => { label.textContent = v; }));
    if (fill) {
      const wrap = document.createElement('div');
      wrap.style = 'margin-bottom:8px;';
      wrap.innerHTML = `<label style="font-size:10px;color:var(--text-muted);display:block;margin-bottom:3px;text-transform:uppercase;">Skill ${i+1} %</label>
        <input type="range" min="0" max="100" value="${parseInt(fill.style.width)||80}"
          style="width:100%;accent-color:var(--accent);">
        <span style="font-size:10px;color:var(--text-muted);">${parseInt(fill.style.width)||80}%</span>`;
      const range = wrap.querySelector('input'); const pctSpan = wrap.querySelector('span');
      range.oninput = e => {
        fill.style.width = e.target.value + '%';
        if (pct) pct.textContent = e.target.value + '%';
        pctSpan.textContent = e.target.value + '%';
      };
      el.appendChild(wrap);
    }
  });
}

/* ══════════════════════════════════════════════
   CONTACT SECTION — field definitions
   ══════════════════════════════════════════════ */
function folioContactFields(doc, section, el) {
  const h2   = section.querySelector('h2');
  const para = section.querySelector('p.text-muted');
  const btn  = section.querySelector('button');
  if (h2)   el.appendChild(folioMakeInput('Heading', h2.textContent, v => { h2.textContent = v; }));
  if (para) el.appendChild(folioMakeInput('Subheading', para.textContent, v => { para.textContent = v; }));
  if (btn)  el.appendChild(folioMakeInput('Button Text', btn.textContent, v => { btn.textContent = v; }));
  el.appendChild(folioMakeColor('Button Color', '#6366f1', v => { if(btn) btn.style.background = v; }));
}

/* ══════════════════════════════════════════════
   FOOTER EDITOR
   ══════════════════════════════════════════════ */
function renderFolioFooterEditor(doc, el) {
  const footer = doc.getElementById('folio-footer');
  if (!footer) { el.innerHTML='<p style="color:var(--text-muted);font-size:12px;">Footer not found.</p>'; return; }

  const brand     = footer.querySelector('.footer-brand h3');
  const brandDesc = footer.querySelector('.footer-brand p');
  const copyright = footer.querySelector('.footer-bottom span');

  el.appendChild(folioLabel('Brand'));
  if (brand)     el.appendChild(folioMakeInput('Brand Name', brand.textContent, v => { brand.textContent = v; }));
  if (brandDesc) el.appendChild(folioMakeTextarea('Brand Description', brandDesc.textContent, v => { brandDesc.textContent = v; }));
  if (copyright) el.appendChild(folioMakeInput('Copyright Text', copyright.textContent, v => { copyright.textContent = v; }));

  el.appendChild(folioLabel('Footer Columns'));
  footer.querySelectorAll('h5').forEach((h5, i) => {
    const colWrap = document.createElement('div');
    colWrap.style = 'background:var(--surface3);border:1px solid var(--border);border-radius:6px;padding:8px;margin-bottom:6px;';
    colWrap.appendChild(folioMakeInput(`Column ${i+1} Title`, h5.textContent, v => { h5.textContent = v; }));
    const ul = h5.nextElementSibling;
    if (ul && ul.tagName === 'UL') {
      ul.querySelectorAll('li a').forEach((a, j) => {
        colWrap.appendChild(folioMakeInput(`  Link ${j+1}`, a.textContent, v => { a.textContent = v; }));
      });
    }
    el.appendChild(colWrap);
  });

  el.appendChild(folioMakeColor('Footer Background', '#0b0e14', v => { footer.style.background = v; }));
}

/* ══════════════════════════════════════════════
   Generic section editor — uses field-def fn
   ══════════════════════════════════════════════ */
function renderFolioSectionEditor(doc, el, selector, fieldsFn) {
  const section = doc.querySelector(selector);
  if (!section) { el.innerHTML=`<p style="color:var(--text-muted);font-size:12px;">Section "${selector}" not found.</p>`; return; }
  fieldsFn(doc, section, el);

  // Auto-save on any input change
  el.querySelectorAll('input,textarea,select').forEach(inp => {
    inp.addEventListener('change', () => {
      const html = '<!DOCTYPE html>\n' + doc.documentElement.outerHTML;
      projectFiles['index.html'] = { raw: html, selfContained: html };
    });
  });
}

/* ── RGB → Hex helper ── */
function rgbToHex(rgb) {
  if (!rgb) return '#000000';
  const m = rgb.match(/\d+/g);
  if (!m || m.length < 3) return '#000000';
  return '#' + m.slice(0,3).map(x => (+x).toString(16).padStart(2,'0')).join('');
}

/* ── Show the FolioOne editor button when in import-preview mode ── */
(function watchFolioMode() {
  const frame   = document.getElementById('import-preview-frame');
  const btn     = document.getElementById('folioEditorBtn');
  if (!frame) return;
  const mo = new MutationObserver(() => {
    const vis = frame.style.display !== 'none';
    if (btn) btn.style.display = vis ? 'flex' : 'none';
  });
  mo.observe(frame, { attributes: true, attributeFilter: ['style'] });
})();

/* ── Override export to capture live iframe DOM ── */
const _origOpenExportAndSubmit = typeof openExportAndSubmit === 'function' ? openExportAndSubmit : null;
function openExportAndSubmit(exportName) {
  exportName = (exportName || 'my-website').replace(/\.html$/i,'').trim() || 'my-website';
  const frame = document.getElementById('import-preview-frame');
  // If FolioOne is active in iframe, export the live DOM
  if (frame && frame.style.display !== 'none') {
    try {
      const doc  = frame.contentDocument || frame.contentWindow.document;
      if (doc) {
        // Clean up editor artifacts
        const clone = doc.documentElement.cloneNode(true);
        clone.querySelectorAll('[contenteditable]').forEach(el => el.removeAttribute('contenteditable'));
        clone.querySelectorAll('#folio-dropdown-css').forEach(el => {}); // keep the CSS
        const fullCode = '<!DOCTYPE html>\n' + clone.outerHTML;
        submitExportForApproval(exportName, fullCode);
        return;
      }
    } catch(e) {}
    // Fall back to srcdoc
    if (frame.srcdoc) { submitExportForApproval(exportName, frame.srcdoc); return; }
  }
  // Otherwise fall through to original builder export
  if (_origOpenExportAndSubmit) _origOpenExportAndSubmit(exportName);
}

/* ══════════════════════════════════════════════
   FOLIO ONE DEFAULT PREVIEW — wire up editor button
   ══════════════════════════════════════════════ */

/* ══════════════════════════════════════════════
   SOURCE PROTECTION
// ══════════════════════════════════════════════════════
//  SOURCE PROTECTION — blocks DevTools, right-click,
//  view-source, and text selection so other users
//  cannot inspect or copy the builder code.
// ══════════════════════════════════════════════════════
(function () {
  'use strict';

  /* 1. Block DevTools keyboard shortcuts */
  document.addEventListener('keydown', function (e) {
    // F12
    if (e.keyCode === 123) { e.preventDefault(); e.stopImmediatePropagation(); return false; }
    // Ctrl+Shift+I  (DevTools)
    if (e.ctrlKey && e.shiftKey && e.keyCode === 73) { e.preventDefault(); e.stopImmediatePropagation(); return false; }
    // Ctrl+Shift+J  (Console)
    if (e.ctrlKey && e.shiftKey && e.keyCode === 74) { e.preventDefault(); e.stopImmediatePropagation(); return false; }
    // Ctrl+Shift+C  (Inspector)
    if (e.ctrlKey && e.shiftKey && e.keyCode === 67) { e.preventDefault(); e.stopImmediatePropagation(); return false; }
    // Ctrl+U  (View Source)
    if (e.ctrlKey && e.keyCode === 85) { e.preventDefault(); e.stopImmediatePropagation(); return false; }
    // Ctrl+S  (Save page)
    if (e.ctrlKey && e.keyCode === 83) { e.preventDefault(); return false; }
  }, true);

  /* 2. Block right-click context menu */
  document.addEventListener('contextmenu', function (e) {
    e.preventDefault();
    return false;
  }, true);

  /* 3. Block text selection outside inputs/textareas */
  document.addEventListener('selectstart', function (e) {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
    e.preventDefault();
  });

  /* 4. DevTools detection via debugger timing trick */
  (function devToolsDetect() {
    var threshold = 160;
    var blocked   = false;
    var check = function () {
      if (blocked) return;
      var start = performance.now();
      // eslint-disable-next-line no-debugger
      debugger;
      var delta = performance.now() - start;
      if (delta > threshold) {
        blocked = true;
        document.body.innerHTML =
          '<div style="display:flex;align-items:center;justify-content:center;' +
          'height:100vh;background:#080b12;color:#ff2d6f;font-family:sans-serif;' +
          'font-size:1.1rem;text-align:center;padding:20px;">' +
          '⛔ Developer tools are not allowed in the Menu Builder.</div>';
      }
    };
    setInterval(check, 2000);
  })();

})();
</script>

<!-- ═══════════════════════════════════════════════════════
     EXPORT APPROVAL MODAL
     ═══════════════════════════════════════════════════════ -->
<div id="exportModal" style="
  display:none; position:fixed; inset:0; background:rgba(0,0,0,.75);
  z-index:99999; align-items:center; justify-content:center;">
  <div style="
    background:#0e1320; border:1px solid rgba(255,255,255,.1);
    border-radius:16px; padding:28px; width:100%; max-width:460px;
    box-shadow:0 24px 60px rgba(0,0,0,.6); font-family:'Syne',sans-serif;">

    <h3 style="font-size:16px;font-weight:800;color:#e8eaf0;margin-bottom:6px;">
      📦 Submit Export for Approval
    </h3>
    <p style="font-size:12px;color:#5a6380;margin-bottom:20px;line-height:1.6">
      Your exported file will be reviewed by an admin. Once approved you will be
      able to download it and re-import it into the builder.
    </p>

    <!-- Filename input -->
    <label style="font-size:11px;font-weight:700;color:#5a6380;letter-spacing:1px;text-transform:uppercase;display:block;margin-bottom:6px;">
      Filename
    </label>
    <input id="exportFilename" type="text" value="my-website"
      style="width:100%;padding:9px 14px;border-radius:9px;border:1px solid rgba(255,255,255,.1);
             background:#141b2d;color:#e8eaf0;font-size:13px;outline:none;margin-bottom:16px;box-sizing:border-box;">

    <!-- Status output -->
    <div id="exportStatus" class="export-status" style="
      min-height:20px;font-size:12px;margin-bottom:14px;padding:8px 12px;
      border-radius:8px;display:none;"></div>

    <!-- My past exports -->
    <div style="margin-bottom:18px;">
      <div style="font-size:11px;font-weight:700;color:#5a6380;letter-spacing:1px;text-transform:uppercase;margin-bottom:8px;">
        My Exports
        <button onclick="refreshMyExports()"
                style="font-size:10px;padding:2px 8px;border-radius:5px;border:1px solid rgba(255,255,255,.1);
                       background:transparent;color:#5a6380;cursor:pointer;margin-left:8px;">↻ Refresh</button>
      </div>
      <div id="myExportsList" style="max-height:160px;overflow-y:auto;padding-right:4px;">
        <div style="color:#5a6380;font-size:11px">Loading…</div>
      </div>
    </div>

    <!-- Buttons -->
    <div style="display:flex;gap:10px;justify-content:flex-end">
      <button onclick="closeExportModal()"
              style="padding:9px 18px;border-radius:8px;border:1px solid rgba(255,255,255,.1);
                     background:#141b2d;color:#5a6380;font-size:13px;cursor:pointer;font-family:inherit;">
        Cancel
      </button>
      <button id="exportSubmitBtn"
              onclick="(function(){
                var name = (document.getElementById('exportFilename').value||'export').replace(/\.html$/i,'').trim()||'export';
                document.getElementById('exportStatus').style.display='block';
                downloadCode_submit(name);
              })()"
              style="padding:9px 18px;border-radius:8px;border:none;background:#00ff87;
                     color:#080b12;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit;">
        📤 Submit for Approval
      </button>
    </div>
  </div>
</div>

<style>
.export-status         { display:block !important; border-radius:8px; }
.export-status.info    { background:rgba(0,200,255,.07); border:1px solid rgba(0,200,255,.2); color:#00c8ff; }
.export-status.success { background:rgba(0,255,135,.07); border:1px solid rgba(0,255,135,.2); color:#00ff87; }
.export-status.error   { background:rgba(255,45,111,.07); border:1px solid rgba(255,45,111,.2); color:#ff2d6f; }
</style>

<script>
// Wrapper that calls existing downloadCode logic then routes to approval
function downloadCode_submit(exportName) {
  // Re-use existing fullCode build logic from downloadCode() but skip the direct download
  // We call the original function then intercept — here we just call the export builder:
  openExportAndSubmit(exportName);
}

function openExportAndSubmit(exportName) {
  exportName = (exportName || 'my-website').replace(/\.html$/i,'').trim() || 'my-website';
  const fileName = exportName + '.html';

  const frame = document.getElementById('import-preview-frame');
  if (frame && frame.style.display !== 'none' && frame.srcdoc) {
    submitExportForApproval(exportName, frame.srcdoc);
    return;
  }

  // Builder mode — clone and clean the canvas
  const preview       = document.getElementById('preview');
  const cssCode       = document.getElementById('cssCode');
  const jsCode        = document.getElementById('jsCode');
  const exportClone   = preview.cloneNode(true);

  exportClone.querySelectorAll('.section-controls, .plus-btn, .widget-actions, .top-plus-btn').forEach(el => el.remove());
  exportClone.querySelectorAll('.widget-wrapper').forEach(wrapper => {
    while (wrapper.firstChild) wrapper.parentNode.insertBefore(wrapper.firstChild, wrapper);
    wrapper.remove();
  });
  exportClone.querySelectorAll('*').forEach(el => {
    el.removeAttribute('contenteditable');
    el.removeAttribute('draggable');
    el.classList.remove('dragging-section', 'selected', 'selected-global');
    if (el.getAttribute('class') === '') el.removeAttribute('class');
  });
  exportClone.querySelectorAll('.section, .container, .container-advanced, .column').forEach(el => {
    const s = el.getAttribute('style') || '';
    el.setAttribute('style', s.replace(/border:\s*1px dashed[^;]*;?/g, '').trim());
  });

  /* ── Pretty-print the cloned HTML ── */
  function prettyNode(node, level) {
    const pad = '  '.repeat(level);
    let   out = '';
    const INLINE = new Set(['a','abbr','b','bdi','bdo','br','cite','code','data','dfn',
                             'em','i','kbd','mark','q','s','samp','small','span','strong',
                             'sub','sup','time','u','var','wbr']);
    node.childNodes.forEach(child => {
      if (child.nodeType === 3) {
        const t = child.textContent.replace(/\s+/g, ' ').trim();
        if (t) out += pad + t + '\n';
      } else if (child.nodeType === 1) {
        const tag   = child.tagName.toLowerCase();
        const attrs = Array.from(child.attributes)
          .filter(a => !['contenteditable','draggable'].includes(a.name))
          .map(a => ' ' + a.name + '="' + a.value + '"')
          .join('');
        const VOID = new Set(['area','base','br','col','embed','hr','img','input',
                               'link','meta','param','source','track','wbr']);
        if (VOID.has(tag)) {
          out += pad + '<' + tag + attrs + '>\n';
        } else {
          const inner = prettyNode(child, level + 1);
          if (!inner.trim()) {
            out += pad + '<' + tag + attrs + '></' + tag + '>\n';
          } else if (INLINE.has(tag) && !inner.includes('\n')) {
            out += pad + '<' + tag + attrs + '>' + inner.trim() + '</' + tag + '>\n';
          } else {
            out += pad + '<' + tag + attrs + '>\n' + inner + pad + '</' + tag + '>\n';
          }
        }
      }
    });
    return out;
  }

  const prettyBody = prettyNode(exportClone, 1);

  const fullCode = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${exportName}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
  <style>
/* ── Layout ── */
.section            { position: relative; box-sizing: border-box; }
.container          { display: flex; gap: 20px; width: 100%; max-width: 1200px; margin: 0 auto; }
.container-advanced { display: grid; gap: 20px; width: 100%; max-width: 1200px; margin: 0 auto; }
.column             { flex: 1; min-height: 50px; }
@media (max-width: 768px) { .container { flex-direction: column; } }

/* ── Custom Styles ── */
${(cssCode ? cssCode.value : '')}
  </style>
</head>
<body>

${prettyBody}

<script>
/* ── Custom Scripts ── */
${(jsCode ? jsCode.value : '')}
<\/script>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"><\/script>
</body>
</html>`;

  submitExportForApproval(exportName, fullCode);
}

// Load exports list when modal opens
document.addEventListener('DOMContentLoaded', function() {
  var modal = document.getElementById('exportModal');
  if (modal) {
    var observer = new MutationObserver(function(mutations) {
      mutations.forEach(function(m) {
        if (m.target.style.display === 'flex') refreshMyExports();
      });
    });
    observer.observe(modal, { attributes: true, attributeFilter: ['style'] });
  }
});
</script>
</body>
</html>
