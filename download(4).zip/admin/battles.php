<?php
require_once '../includes/config.php';
require_once 'guard.php';
requireAdmin();

$db  = db();
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $rid    = (int)($_POST['room_id'] ?? 0);
    if ($action === 'delete' && $rid) {
        $db->prepare('DELETE FROM rooms WHERE id=?')->execute([$rid]);
        adminLog('DELETE_ROOM', 'room', $rid);
        $msg = ['ok', 'Battle room deleted.'];
    } elseif ($action === 'finish' && $rid) {
        $db->prepare("UPDATE rooms SET status='finished' WHERE id=?")->execute([$rid]);
        adminLog('FORCE_FINISH_ROOM', 'room', $rid);
        $msg = ['ok', 'Room forced to finished.'];
    } elseif ($action === 'lock_arena' && $rid) {
        $db->prepare('UPDATE rooms SET arena_locked=1 WHERE id=?')->execute([$rid]);
        adminLog('LOCK_ARENA', 'room', $rid, 'Admin locked arena');
        $msg = ['ok', '🔒 Arena locked — copy/paste/screenshots blocked for players.'];
    } elseif ($action === 'unlock_arena' && $rid) {
        $db->prepare('UPDATE rooms SET arena_locked=0 WHERE id=?')->execute([$rid]);
        adminLog('UNLOCK_ARENA', 'room', $rid, 'Admin unlocked arena');
        $msg = ['ok', '🔓 Arena unlocked — normal access restored.'];
    }
}

// Ensure arena_locked column exists
try {
  $chk = $db->query("SHOW COLUMNS FROM `rooms` LIKE 'arena_locked'");
  if (!$chk->fetch()) {
    $db->exec("ALTER TABLE `rooms` ADD COLUMN `arena_locked` TINYINT(1) NOT NULL DEFAULT 0");
  }
} catch(Exception $e) {}

$status  = $_GET['status'] ?? 'all';
$page    = max(1,(int)($_GET['page']??1));
$perPage = 25;
$offset  = ($page-1)*$perPage;
$where   = $status !== 'all' ? "WHERE r.status='".htmlspecialchars($status,ENT_QUOTES)."'" : '';

$total = (int)$db->query("SELECT COUNT(*) FROM rooms r $where")->fetchColumn();
$pages = max(1,ceil($total/$perPage));

$rooms = $db->query(
    "SELECT r.id, r.code, r.status, r.is_public, r.room_mode,
            r.host_score, r.guest_score, r.created_at, r.finished_at,
            COALESCE(r.arena_locked,0) AS arena_locked,
            h.username AS host, g.username AS guest, w.username AS winner
     FROM rooms r
     LEFT JOIN users h ON h.id=r.host_id
     LEFT JOIN users g ON g.id=r.guest_id
     LEFT JOIN users w ON w.id=r.winner_id
     $where ORDER BY r.created_at DESC LIMIT $perPage OFFSET $offset"
)->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Battles — Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;600;800&display=swap" rel="stylesheet">
<style>
:root{--green:#00ff87;--pink:#ff2d6f;--blue:#00c8ff;--yellow:#ffe14d;--orange:#ff8c42;--purple:#b14fff;--bg:#080b12;--bg2:#0e1320;--bg3:#141b2d;--border:rgba(255,255,255,0.07);--text:#e8eaf0;--muted:#5a6380;--font-head:'Syne',sans-serif;--font-mono:'Space Mono',monospace}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{min-height:100%;background:var(--bg);color:var(--text);font-family:var(--font-head)}
a{color:inherit;text-decoration:none} button{font-family:inherit}
.layout{display:flex;min-height:100vh}
.sidebar{width:220px;flex-shrink:0;background:var(--bg2);border-right:1px solid var(--border);display:flex;flex-direction:column;position:sticky;top:0;height:100vh;overflow-y:auto}
.sidebar-logo{padding:24px 20px 20px;border-bottom:1px solid var(--border)}
.sidebar-logo .brand{font-size:16px;font-weight:800}
.sidebar-logo .brand span{color:var(--green)}
.admin-badge{display:inline-block;margin-top:6px;padding:2px 8px;border-radius:4px;background:rgba(177,79,255,.15);color:var(--purple);font-size:10px;font-weight:700;letter-spacing:1px;border:1px solid rgba(177,79,255,.3)}
.nav-section{padding:16px 12px 8px;font-size:10px;font-weight:700;letter-spacing:1.5px;color:var(--muted);text-transform:uppercase}
.nav-item{display:flex;align-items:center;gap:10px;padding:9px 16px;border-radius:10px;margin:2px 8px;font-size:13px;font-weight:600;color:var(--muted);transition:all .15s}
.nav-item:hover{color:#fff;background:rgba(255,255,255,.05)}
.nav-item.active{color:var(--green);background:rgba(0,255,135,.06)}
.nav-item .icon{font-size:15px;width:20px;text-align:center}
.sidebar-footer{margin-top:auto;padding:16px;border-top:1px solid var(--border)}
.sidebar-footer a{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--muted);padding:8px;border-radius:8px}
.sidebar-footer a:hover{color:#fff}
.main{flex:1}
.topbar{display:flex;align-items:center;padding:0 32px;height:60px;background:var(--bg2);border-bottom:1px solid var(--border);position:sticky;top:0;z-index:10}
.topbar-title{font-size:18px;font-weight:800}
.content{padding:32px}
.card{background:var(--bg2);border:1px solid var(--border);border-radius:14px;overflow:hidden}
table{width:100%;border-collapse:collapse}
th{padding:11px 16px;text-align:left;font-size:10px;font-weight:700;letter-spacing:1px;color:var(--muted);text-transform:uppercase;border-bottom:1px solid var(--border);background:var(--bg3)}
td{padding:11px 16px;font-size:12px;border-bottom:1px solid rgba(255,255,255,.04);vertical-align:middle}
tr:last-child td{border-bottom:none}
.badge{display:inline-block;padding:2px 8px;border-radius:20px;font-size:10px;font-weight:700}
.badge-green{background:rgba(0,255,135,.1);color:var(--green);border:1px solid rgba(0,255,135,.2)}
.badge-blue{background:rgba(0,200,255,.1);color:var(--blue);border:1px solid rgba(0,200,255,.2)}
.badge-muted{background:rgba(90,99,128,.15);color:var(--muted);border:1px solid rgba(90,99,128,.2)}
.badge-pink{background:rgba(255,45,111,.1);color:var(--pink);border:1px solid rgba(255,45,111,.2)}
.btn{padding:5px 11px;border-radius:7px;border:none;font-size:11px;font-weight:700;cursor:pointer;transition:all .15s}
.btn-del{background:rgba(255,45,111,.08);color:#ff6b8a;border:1px solid rgba(255,45,111,.15)}
.btn-del:hover{background:rgba(255,45,111,.2)}
.btn-finish{background:rgba(0,255,135,.07);color:var(--green);border:1px solid rgba(0,255,135,.2)}
.btn-finish:hover{background:rgba(0,255,135,.15)}
.filter-tabs{display:flex;gap:6px;margin-bottom:16px;flex-wrap:wrap}
.filter-tab{padding:7px 14px;border-radius:8px;border:1px solid var(--border);background:var(--bg3);color:var(--muted);font-size:12px;font-weight:600;text-decoration:none;transition:all .15s}
.filter-tab:hover,.filter-tab.active{color:var(--green);border-color:rgba(0,255,135,.3)}
.msg{padding:12px 16px;border-radius:10px;margin-bottom:16px;font-size:13px}
.msg-ok{background:rgba(0,255,135,.08);border:1px solid rgba(0,255,135,.2);color:var(--green)}
.pagination{display:flex;gap:6px;margin-top:20px;justify-content:center}
.page-btn{padding:6px 12px;border-radius:8px;border:1px solid var(--border);background:var(--bg2);color:var(--muted);font-size:12px;font-weight:600;text-decoration:none;transition:all .15s}
.page-btn:hover,.page-btn.active{color:var(--green);border-color:rgba(0,255,135,.3)}
.table-wrap{overflow-x:auto}

/* ── RESPONSIVE / MOBILE ── */
.hamburger{
  display:none;align-items:center;justify-content:center;
  width:36px;height:36px;border-radius:8px;border:1px solid var(--border);
  background:var(--bg3);cursor:pointer;flex-shrink:0;
  transition:background .15s;
}
.hamburger:hover{background:rgba(255,255,255,.08)}
.hamburger span{display:block;width:16px;height:2px;background:var(--text);
  position:relative;transition:background .2s}
.hamburger span::before,.hamburger span::after{
  content:'';position:absolute;width:16px;height:2px;background:var(--text);
  left:0;transition:transform .25s,top .25s,opacity .25s}
.hamburger span::before{top:-5px}
.hamburger span::after{top:5px}
.hamburger.open span{background:transparent}
.hamburger.open span::before{top:0;transform:rotate(45deg)}
.hamburger.open span::after{top:0;transform:rotate(-45deg)}

.sidebar-overlay{
  display:none;position:fixed;inset:0;background:rgba(0,0,0,.65);
  z-index:99;backdrop-filter:blur(2px);
}
.sidebar-overlay.visible{display:block}

@media(max-width:768px){
  .hamburger{display:flex}

  .sidebar{
    position:fixed;top:0;left:0;height:100vh;z-index:100;
    transform:translateX(-100%);transition:transform .28s cubic-bezier(.4,0,.2,1);
    width:260px;
  }
  .sidebar.open{transform:translateX(0)}

  .main{width:100%;min-width:0}

  .topbar{padding:0 16px;gap:12px}
  .topbar-title{font-size:15px}
  .topbar-user{font-size:11px;gap:6px}

  .content{padding:16px}

  .stats-grid{grid-template-columns:repeat(2,1fr);gap:12px;margin-bottom:20px}
  .stat-card .value{font-size:24px}

  .two-col{grid-template-columns:1fr !important;gap:16px}

  .table-wrap{overflow-x:auto;-webkit-overflow-scrolling:touch}
  table{min-width:480px}
  th,td{padding:9px 12px;font-size:12px}

  .toolbar{flex-direction:column;align-items:stretch}
  .search-box{width:100%}
  .filter-tabs{overflow-x:auto;flex-wrap:nowrap;padding-bottom:2px}

  .btn{padding:4px 8px;font-size:10px}

  .pagination{flex-wrap:wrap;gap:6px}

  /* analytics / chart responsive */
  .chart-row{flex-direction:column}
  .chart-wrap{min-width:0 !important;width:100% !important}
}

@media(max-width:400px){
  .stats-grid{grid-template-columns:1fr}
  .topbar-user .admin-pill{display:none}
}

</style>
</head>
<body>
<div class="sidebar-overlay"></div>
<div class="layout">
<aside class="sidebar">
  <div class="sidebar-logo">
    <div class="brand">code<span>Me</span> Admin</div>
    <div class="admin-badge">⚡ ADMIN PANEL</div>
  </div>
  <div class="nav-section">Overview</div>
  <a class="nav-item" href="index.php"><span class="icon">📊</span> Dashboard</a>
  <a class="nav-item" href="analytics.php"><span class="icon">📈</span> Analytics</a>
  <div class="nav-section">Management</div>
  <a class="nav-item" href="users.php"><span class="icon">👥</span> Users</a>
  <a class="nav-item" href="challenges.php"><span class="icon">🎯</span> Challenges</a>
  <a class="nav-item active" href="battles.php"><span class="icon">⚔️</span> Battles</a>
  <div class="nav-section">Security</div>
  <a class="nav-item" href="scanner.php"><span class="icon">🛡️</span> File Scanner</a>
  <a class="nav-item" href="logs.php"><span class="icon">📋</span> Admin Logs</a>
  <div class="sidebar-footer">
    <a href="../versus.php">← Back to Site</a>
    <a href="../logout.php" style="margin-top:4px">🚪 Logout</a>
  </div>
</aside>
<div class="main">
  <div class="topbar">
  <button class="hamburger" aria-label="Toggle menu"><span></span></button>
  <div class="topbar-title">Battles (<?= $total ?>)</div></div>
  <div class="content">
    <?php if($msg): ?>
    <div class="msg msg-ok"><?= $msg[1] ?></div>
    <?php endif ?>
    <div class="filter-tabs">
      <a class="filter-tab <?= $status==='all'?'active':'' ?>" href="?status=all">All</a>
      <a class="filter-tab <?= $status==='waiting'?'active':'' ?>" href="?status=waiting">Waiting</a>
      <a class="filter-tab <?= $status==='active'?'active':'' ?>" href="?status=active">Active</a>
      <a class="filter-tab <?= $status==='finished'?'active':'' ?>" href="?status=finished">Finished</a>
    </div>
    <div class="card">
      <div class="table-wrap">
        <table>
          <tr><th>Code</th><th>Host</th><th>Guest</th><th>Score</th><th>Winner</th><th>Status</th><th>Arena</th><th>Mode</th><th>Date</th><th>Actions</th></tr>
          <?php foreach($rooms as $r): ?>
          <tr>
            <td style="font-family:var(--font-mono);color:var(--blue)"><?= e($r['code']) ?></td>
            <td><?= e($r['host'] ?? '?') ?></td>
            <td><?= e($r['guest'] ?? '…') ?></td>
            <td style="font-family:var(--font-mono)">
              <span style="color:var(--green)"><?= $r['host_score'] ?></span>
              <span style="color:var(--muted)"> / </span>
              <span style="color:var(--blue)"><?= $r['guest_score'] ?></span>
            </td>
            <td><?= e($r['winner'] ?? '—') ?></td>
            <td>
              <?php $cls=['waiting'=>'badge-muted','active'=>'badge-blue','finished'=>'badge-green'][$r['status']]??'badge-muted'; ?>
              <span class="badge <?= $cls ?>"><?= strtoupper($r['status']) ?></span>
            </td>
            <td style="color:var(--muted)"><?= strtoupper($r['room_mode']) ?></td>
            <td style="color:var(--muted)"><?= date('m/d H:i', strtotime($r['created_at'])) ?></td>
            <!-- Arena Lock Status -->
            <td style="text-align:center">
              <?php if(!empty($r['arena_locked'])): ?>
                <span class="badge" style="background:rgba(255,45,111,.12);color:#ff2d6f;border:1px solid rgba(255,45,111,.25)">🔒 Locked</span>
              <?php else: ?>
                <span class="badge badge-muted">🔓 Open</span>
              <?php endif ?>
            </td>
            <td>
              <div style="display:flex;gap:6px;flex-wrap:wrap">
                <!-- Arena Lock / Unlock -->
                <?php if(in_array($r['status'],['waiting','active'])): ?>
                  <?php if(empty($r['arena_locked'])): ?>
                  <form method="POST" style="display:inline">
                    <input type="hidden" name="action" value="lock_arena">
                    <input type="hidden" name="room_id" value="<?= $r['id'] ?>">
                    <button class="btn" type="submit" style="background:rgba(255,45,111,.1);color:#ff2d6f;border:1px solid rgba(255,45,111,.25)"
                      onclick="return confirm('Lock arena? Players will not be able to copy, paste or screenshot.')">🔒 Lock</button>
                  </form>
                  <?php else: ?>
                  <form method="POST" style="display:inline">
                    <input type="hidden" name="action" value="unlock_arena">
                    <input type="hidden" name="room_id" value="<?= $r['id'] ?>">
                    <button class="btn" type="submit" style="background:rgba(0,255,135,.08);color:#00ff87;border:1px solid rgba(0,255,135,.2)">🔓 Unlock</button>
                  </form>
                  <?php endif ?>
                <?php endif ?>
                <?php if($r['status']==='active'): ?>
                <form method="POST" style="display:inline">
                  <input type="hidden" name="action" value="finish">
                  <input type="hidden" name="room_id" value="<?= $r['id'] ?>">
                  <button class="btn btn-finish" type="submit">Force Finish</button>
                </form>
                <?php endif ?>
                <form method="POST" style="display:inline">
                  <input type="hidden" name="action" value="delete">
                  <input type="hidden" name="room_id" value="<?= $r['id'] ?>">
                  <button class="btn btn-del" onclick="return confirm('Delete this room?')">Delete</button>
                </form>
              </div>
            </td>
          </tr>
          <?php endforeach ?>
        </table>
      </div>
    </div>
    <?php if($pages>1): ?>
    <div class="pagination">
      <?php for($i=1;$i<=$pages;$i++): ?>
      <a class="page-btn <?= $i===$page?'active':'' ?>" href="?status=<?= e($status) ?>&page=<?= $i ?>"><?= $i ?></a>
      <?php endfor ?>
    </div>
    <?php endif ?>
  </div>
</div>
</div>
<script>
(function(){
  var btn     = document.querySelector('.hamburger');
  var sidebar = document.querySelector('.sidebar');
  var overlay = document.querySelector('.sidebar-overlay');
  if (!btn || !sidebar || !overlay) return;

  function openMenu() {
    sidebar.classList.add('open');
    overlay.classList.add('visible');
    btn.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  function closeMenu() {
    sidebar.classList.remove('open');
    overlay.classList.remove('visible');
    btn.classList.remove('open');
    document.body.style.overflow = '';
  }

  btn.addEventListener('click', function() {
    sidebar.classList.contains('open') ? closeMenu() : openMenu();
  });
  overlay.addEventListener('click', closeMenu);
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeMenu();
  });
})();
</script>
</body>
</html>
