<?php
require_once '../includes/config.php';
require_once 'guard.php';
requireAdmin();

$db = db();

// Signups per day (last 30 days)
$signups = $db->query(
    "SELECT DATE(created_at) AS d, COUNT(*) AS cnt FROM users
     WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
     GROUP BY DATE(created_at) ORDER BY d ASC"
)->fetchAll(PDO::FETCH_KEY_PAIR);

// Battles per day (last 30 days)
$battles = $db->query(
    "SELECT DATE(created_at) AS d, COUNT(*) AS cnt FROM rooms
     WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
     GROUP BY DATE(created_at) ORDER BY d ASC"
)->fetchAll(PDO::FETCH_KEY_PAIR);

// Fill all 30 days
$labels = [];
$signupVals = [];
$battleVals = [];
for ($i = 29; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $labels[]    = date('m/d', strtotime($d));
    $signupVals[]= (int)($signups[$d] ?? 0);
    $battleVals[]= (int)($battles[$d] ?? 0);
}

// Top 10 players by score
$topScore = $db->query(
    'SELECT username, wins, losses, total_score FROM users ORDER BY total_score DESC LIMIT 10'
)->fetchAll();

// Win rate top players
$winRate = $db->query(
    'SELECT username, wins, losses,
     ROUND(wins/(wins+losses+0.001)*100,1) AS wr
     FROM users WHERE wins+losses > 0 ORDER BY wr DESC LIMIT 10'
)->fetchAll();

// Room status distribution
$roomDist = $db->query(
    "SELECT status, COUNT(*) AS cnt FROM rooms GROUP BY status"
)->fetchAll(PDO::FETCH_KEY_PAIR);

// Challenge popularity
$chalPop = $db->query(
    'SELECT c.title, COUNT(r.id) AS uses
     FROM challenges c
     LEFT JOIN rooms r ON r.challenge_id = c.id
     GROUP BY c.id ORDER BY uses DESC LIMIT 8'
)->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Analytics — Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;600;800&display=swap" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<style>
:root{--green:#00ff87;--pink:#ff2d6f;--blue:#00c8ff;--yellow:#ffe14d;--orange:#ff8c42;--purple:#b14fff;--bg:#080b12;--bg2:#0e1320;--bg3:#141b2d;--border:rgba(255,255,255,0.07);--text:#e8eaf0;--muted:#5a6380;--font-head:'Syne',sans-serif;--font-mono:'Space Mono',monospace}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{min-height:100%;background:var(--bg);color:var(--text);font-family:var(--font-head)}
a{color:inherit;text-decoration:none}
.layout{display:flex;min-height:100vh}
.sidebar{width:220px;flex-shrink:0;background:var(--bg2);border-right:1px solid var(--border);display:flex;flex-direction:column;position:sticky;top:0;height:100vh;overflow-y:auto}
.sidebar-logo{padding:24px 20px 20px;border-bottom:1px solid var(--border)}
.sidebar-logo .brand{font-size:16px;font-weight:800;letter-spacing:-.5px}
.sidebar-logo .brand span{color:var(--green)}
.admin-badge{display:inline-block;margin-top:6px;padding:2px 8px;border-radius:4px;background:rgba(177,79,255,.15);color:var(--purple);font-size:10px;font-weight:700;letter-spacing:1px;border:1px solid rgba(177,79,255,.3)}
.nav-section{padding:16px 12px 8px;font-size:10px;font-weight:700;letter-spacing:1.5px;color:var(--muted);text-transform:uppercase}
.nav-item{display:flex;align-items:center;gap:10px;padding:9px 16px;border-radius:10px;margin:2px 8px;font-size:13px;font-weight:600;color:var(--muted);transition:all .15s;cursor:pointer}
.nav-item:hover{color:#fff;background:rgba(255,255,255,.05)}
.nav-item.active{color:var(--green);background:rgba(0,255,135,.06)}
.nav-item .icon{font-size:15px;width:20px;text-align:center}
.sidebar-footer{margin-top:auto;padding:16px;border-top:1px solid var(--border)}
.sidebar-footer a{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--muted);padding:8px;border-radius:8px;transition:color .15s}
.sidebar-footer a:hover{color:#fff}
.main{flex:1;overflow-x:hidden}
.topbar{display:flex;align-items:center;padding:0 32px;height:60px;background:var(--bg2);border-bottom:1px solid var(--border);position:sticky;top:0;z-index:10}
.topbar-title{font-size:18px;font-weight:800}
.content{padding:32px}
.card{background:var(--bg2);border:1px solid var(--border);border-radius:14px;overflow:hidden;margin-bottom:24px}
.card-header{padding:16px 20px;border-bottom:1px solid var(--border);font-size:14px;font-weight:800}
.card-body{padding:20px}
.two-col{display:grid;grid-template-columns:1fr 1fr;gap:20px}
@media(max-width:900px){.two-col{grid-template-columns:1fr}}
table{width:100%;border-collapse:collapse}
th{padding:10px 14px;text-align:left;font-size:10px;font-weight:700;letter-spacing:1px;color:var(--muted);text-transform:uppercase;border-bottom:1px solid var(--border);background:var(--bg3)}
td{padding:11px 14px;font-size:12px;border-bottom:1px solid rgba(255,255,255,.04)}
tr:last-child td{border-bottom:none}
.bar-row{display:flex;align-items:center;gap:10px;margin-bottom:8px;font-size:12px}
.bar-label{width:100px;color:var(--muted);text-overflow:ellipsis;overflow:hidden;white-space:nowrap;text-align:right;flex-shrink:0}
.bar-track{flex:1;height:8px;background:var(--bg3);border-radius:4px;overflow:hidden}
.bar-fill{height:100%;border-radius:4px;transition:width .6s ease}
.bar-val{width:36px;color:var(--text);font-family:var(--font-mono);font-weight:700;text-align:right}

/* ── RESPONSIVE / MOBILE ── */
.hamburger{
  display:none;align-items:center;justify-content:center;
  width:36px;height:36px;border-radius:8px;border:1px solid var(--border);
  background:var(--bg3);cursor:pointer;flex-shrink:0;
  transition:background .15s;
}
.hamburger:hover{background:rgba(255,255,255,.08)}
.hamburger span{display:block;width:16px;height:2px;background:var(--text);
  position:relative;transition:background .2s}
.hamburger span::before,.hamburger span::after{
  content:'';position:absolute;width:16px;height:2px;background:var(--text);
  left:0;transition:transform .25s,top .25s,opacity .25s}
.hamburger span::before{top:-5px}
.hamburger span::after{top:5px}
.hamburger.open span{background:transparent}
.hamburger.open span::before{top:0;transform:rotate(45deg)}
.hamburger.open span::after{top:0;transform:rotate(-45deg)}

.sidebar-overlay{
  display:none;position:fixed;inset:0;background:rgba(0,0,0,.65);
  z-index:99;backdrop-filter:blur(2px);
}
.sidebar-overlay.visible{display:block}

@media(max-width:768px){
  .hamburger{display:flex}

  .sidebar{
    position:fixed;top:0;left:0;height:100vh;z-index:100;
    transform:translateX(-100%);transition:transform .28s cubic-bezier(.4,0,.2,1);
    width:260px;
  }
  .sidebar.open{transform:translateX(0)}

  .main{width:100%;min-width:0}

  .topbar{padding:0 16px;gap:12px}
  .topbar-title{font-size:15px}
  .topbar-user{font-size:11px;gap:6px}

  .content{padding:16px}

  .stats-grid{grid-template-columns:repeat(2,1fr);gap:12px;margin-bottom:20px}
  .stat-card .value{font-size:24px}

  .two-col{grid-template-columns:1fr !important;gap:16px}

  .table-wrap{overflow-x:auto;-webkit-overflow-scrolling:touch}
  table{min-width:480px}
  th,td{padding:9px 12px;font-size:12px}

  .toolbar{flex-direction:column;align-items:stretch}
  .search-box{width:100%}
  .filter-tabs{overflow-x:auto;flex-wrap:nowrap;padding-bottom:2px}

  .btn{padding:4px 8px;font-size:10px}

  .pagination{flex-wrap:wrap;gap:6px}

  /* analytics / chart responsive */
  .chart-row{flex-direction:column}
  .chart-wrap{min-width:0 !important;width:100% !important}
}

@media(max-width:400px){
  .stats-grid{grid-template-columns:1fr}
  .topbar-user .admin-pill{display:none}
}

</style>
</head>
<body>
<div class="sidebar-overlay"></div>
<div class="layout">
<aside class="sidebar">
  <div class="sidebar-logo">
    <div class="brand">code<span>Me</span> Admin</div>
    <div class="admin-badge">⚡ ADMIN PANEL</div>
  </div>
  <div class="nav-section">Overview</div>
  <a class="nav-item" href="index.php"><span class="icon">📊</span> Dashboard</a>
  <a class="nav-item active" href="analytics.php"><span class="icon">📈</span> Analytics</a>
  <div class="nav-section">Management</div>
  <a class="nav-item" href="users.php"><span class="icon">👥</span> Users</a>
  <a class="nav-item" href="challenges.php"><span class="icon">🎯</span> Challenges</a>
  <a class="nav-item" href="battles.php"><span class="icon">⚔️</span> Battles</a>
  <div class="nav-section">Security</div>
  <a class="nav-item" href="scanner.php"><span class="icon">🛡️</span> File Scanner</a>
  <a class="nav-item" href="logs.php"><span class="icon">📋</span> Admin Logs</a>
  <div class="sidebar-footer">
    <a href="../versus.php">← Back to Site</a>
    <a href="../logout.php" style="margin-top:4px">🚪 Logout</a>
  </div>
</aside>
<div class="main">
  <div class="topbar">
  <button class="hamburger" aria-label="Toggle menu"><span></span></button>
  <div class="topbar-title">Analytics (Last 30 Days)</div></div>
  <div class="content">

    <!-- Line chart: signups + battles -->
    <div class="card">
      <div class="card-header">📈 Daily Signups & Battles</div>
      <div class="card-body">
        <canvas id="lineChart" height="80"></canvas>
      </div>
    </div>

    <div class="two-col">
      <!-- Top players table -->
      <div class="card">
        <div class="card-header">🏆 Top Players by Score</div>
        <table>
          <tr><th>#</th><th>Player</th><th>W/L</th><th>Score</th></tr>
          <?php foreach($topScore as $i=>$p): ?>
          <tr>
            <td style="color:var(--muted);font-family:var(--font-mono)"><?= $i+1 ?></td>
            <td><?= e($p['username']) ?></td>
            <td style="font-family:var(--font-mono)">
              <span style="color:var(--green)"><?= $p['wins'] ?>W</span>/<span style="color:var(--pink)"><?= $p['losses'] ?>L</span>
            </td>
            <td style="font-family:var(--font-mono);font-weight:700;color:var(--yellow)"><?= $p['total_score'] ?></td>
          </tr>
          <?php endforeach ?>
        </table>
      </div>

      <!-- Win rate -->
      <div class="card">
        <div class="card-header">🎯 Win Rate Leaders</div>
        <div class="card-body">
          <?php $maxWr = max(1, array_column($winRate,'wr')[0] ?? 1); ?>
          <?php foreach($winRate as $i=>$p): ?>
          <div class="bar-row">
            <div class="bar-label"><?= e($p['username']) ?></div>
            <div class="bar-track">
              <div class="bar-fill" style="width:<?= $p['wr'] ?>%;background:<?= ['var(--green)','var(--blue)','var(--yellow)','var(--orange)','var(--purple)','var(--green)','var(--blue)','var(--yellow)','var(--orange)','var(--purple)'][$i] ?>"></div>
            </div>
            <div class="bar-val"><?= $p['wr'] ?>%</div>
          </div>
          <?php endforeach ?>
        </div>
      </div>
    </div>

    <div class="two-col">
      <!-- Challenge popularity -->
      <div class="card">
        <div class="card-header">🎮 Challenge Popularity</div>
        <div class="card-body">
          <?php $maxU = max(1, array_column($chalPop,'uses')[0] ?? 1); ?>
          <?php foreach($chalPop as $i=>$c): ?>
          <div class="bar-row">
            <div class="bar-label"><?= e($c['title']) ?></div>
            <div class="bar-track">
              <div class="bar-fill" style="width:<?= round($c['uses']/$maxU*100) ?>%;background:var(--blue)"></div>
            </div>
            <div class="bar-val"><?= $c['uses'] ?></div>
          </div>
          <?php endforeach ?>
        </div>
      </div>

      <!-- Room status doughnut -->
      <div class="card">
        <div class="card-header">⚔️ Battle Status Breakdown</div>
        <div class="card-body" style="display:flex;align-items:center;justify-content:center">
          <canvas id="doughnut" width="220" height="220"></canvas>
        </div>
      </div>
    </div>

  </div>
</div>
</div>

<script>
const labels = <?= json_encode($labels) ?>;
const signupData = <?= json_encode($signupVals) ?>;
const battleData = <?= json_encode($battleVals) ?>;

const gridColor = 'rgba(255,255,255,0.05)';
const textColor = '#5a6380';

// Line chart
new Chart(document.getElementById('lineChart'), {
  type: 'line',
  data: {
    labels,
    datasets: [
      {
        label: 'New Users',
        data: signupData,
        borderColor: '#00ff87',
        backgroundColor: 'rgba(0,255,135,0.08)',
        tension: 0.4,
        fill: true,
        pointRadius: 3,
      },
      {
        label: 'Battles Created',
        data: battleData,
        borderColor: '#00c8ff',
        backgroundColor: 'rgba(0,200,255,0.06)',
        tension: 0.4,
        fill: true,
        pointRadius: 3,
      }
    ]
  },
  options: {
    responsive: true,
    plugins: { legend: { labels: { color: '#e8eaf0', font: { family: "'Syne'" } } } },
    scales: {
      x: { ticks: { color: textColor, maxTicksLimit: 10 }, grid: { color: gridColor } },
      y: { ticks: { color: textColor }, grid: { color: gridColor }, beginAtZero: true }
    }
  }
});

// Doughnut
const roomDist = <?= json_encode($roomDist) ?>;
new Chart(document.getElementById('doughnut'), {
  type: 'doughnut',
  data: {
    labels: Object.keys(roomDist).map(s => s.charAt(0).toUpperCase()+s.slice(1)),
    datasets: [{
      data: Object.values(roomDist),
      backgroundColor: ['#00ff87','#00c8ff','#ff2d6f','#ffe14d'],
      borderWidth: 0,
    }]
  },
  options: {
    plugins: { legend: { labels: { color: '#e8eaf0', font: { family: "'Syne'" } } } },
    cutout: '65%'
  }
});
</script>
<script>
(function(){
  var btn     = document.querySelector('.hamburger');
  var sidebar = document.querySelector('.sidebar');
  var overlay = document.querySelector('.sidebar-overlay');
  if (!btn || !sidebar || !overlay) return;

  function openMenu() {
    sidebar.classList.add('open');
    overlay.classList.add('visible');
    btn.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  function closeMenu() {
    sidebar.classList.remove('open');
    overlay.classList.remove('visible');
    btn.classList.remove('open');
    document.body.style.overflow = '';
  }

  btn.addEventListener('click', function() {
    sidebar.classList.contains('open') ? closeMenu() : openMenu();
  });
  overlay.addEventListener('click', closeMenu);
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeMenu();
  });
})();
</script>
</body>
</html>
