<?php
// ─── admin/guard.php ─────────────────────────────────────
// Include at the top of every admin page.
// Requires the caller to have already done: require_once '../includes/config.php';

function requireAdmin(): void {
    $user = auth();
    if (!$user) {
        header('Location: ../login.php');
        exit;
    }
    // Fetch fresh role from DB (session could be stale)
    $row = db()->prepare('SELECT role, is_banned FROM users WHERE id = ?');
    $row->execute([$user['id']]);
    $data = $row->fetch();
    if (!$data || $data['role'] != 1 || $data['is_banned']) {
        http_response_code(403);
        die('<h1 style="font-family:monospace;color:#ff2d6f;padding:40px">403 — Admin access required.</h1>');
    }
}

function adminLog(string $action, ?string $targetType = null, ?int $targetId = null, ?string $detail = null): void {
    $user = auth();
    if (!$user) return;
    $stmt = db()->prepare(
        'INSERT INTO admin_logs (admin_id, action, target_type, target_id, detail) VALUES (?,?,?,?,?)'
    );
    $stmt->execute([$user['id'], $action, $targetType, $targetId, $detail]);
}
