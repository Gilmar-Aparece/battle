<?php
// ─── admin/export_approvals.php ──────────────────────────────────────────────
// Admin page: review, approve or reject user-submitted Menu Builder exports.
// ─────────────────────────────────────────────────────────────────────────────
require_once '../includes/config.php';
require_once 'guard.php';
requireAdmin();

$db  = db();
$me  = auth();
$msg = '';

// ── Safe migrations: add columns if they don't exist yet ─────────────────────
(function() use ($db) {
    $cols = $db->query("SHOW COLUMNS FROM users")->fetchAll(PDO::FETCH_COLUMN);
    if (!in_array('ui_disabled', $cols)) {
        $db->exec("ALTER TABLE users ADD COLUMN ui_disabled tinyint(1) NOT NULL DEFAULT 0");
    }
    if (!in_array('menu_builder_disabled', $cols)) {
        $db->exec("ALTER TABLE users ADD COLUMN menu_builder_disabled tinyint(1) NOT NULL DEFAULT 0");
    }
    if (!in_array('folio_edit_allowed', $cols)) {
        $db->exec("ALTER TABLE users ADD COLUMN folio_edit_allowed tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Admin grants FolioOne edit permission after export approval'");
    }

    // Ensure menu_builder_exports table exists
    $db->exec("CREATE TABLE IF NOT EXISTS `menu_builder_exports` (
        `id`           int(11)      NOT NULL AUTO_INCREMENT,
        `user_id`      int(11)      NOT NULL,
        `filename`     varchar(255) NOT NULL,
        `file_content` longtext     NOT NULL,
        `status`       enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
        `admin_note`   text         DEFAULT NULL,
        `reviewed_by`  int(11)      DEFAULT NULL,
        `reviewed_at`  datetime     DEFAULT NULL,
        `created_at`   datetime     NOT NULL DEFAULT current_timestamp(),
        PRIMARY KEY (`id`),
        KEY `user_id` (`status`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // Add reviewed_by / reviewed_at if missing
    $expCols = $db->query("SHOW COLUMNS FROM menu_builder_exports")->fetchAll(PDO::FETCH_COLUMN);
    if (!in_array('reviewed_by', $expCols)) {
        $db->exec("ALTER TABLE menu_builder_exports ADD COLUMN reviewed_by int(11) DEFAULT NULL");
    }
    if (!in_array('reviewed_at', $expCols)) {
        $db->exec("ALTER TABLE menu_builder_exports ADD COLUMN reviewed_at datetime DEFAULT NULL");
    }
    if (!in_array('admin_note', $expCols)) {
        $db->exec("ALTER TABLE menu_builder_exports ADD COLUMN admin_note text DEFAULT NULL");
    }
})();

// ── Actions ───────────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $eid    = (int)($_POST['export_id'] ?? 0);
    $note   = htmlspecialchars(trim($_POST['admin_note'] ?? ''), ENT_QUOTES);

    if ($action === 'approve' && $eid) {
        $db->prepare(
            "UPDATE menu_builder_exports
                SET status='approved', admin_note=?, reviewed_by=?, reviewed_at=NOW()
              WHERE id=?"
        )->execute([$note, $me['id'], $eid]);
        adminLog('EXPORT_APPROVED', 'menu_builder_export', $eid, $note);
        $msg = ['ok', 'Export approved — the user may now import this file.'];

    } elseif ($action === 'approve_folio' && $eid) {
        // Approve + grant FolioOne edit permission to user
        $db->prepare(
            "UPDATE menu_builder_exports
                SET status='approved', admin_note=?, reviewed_by=?, reviewed_at=NOW()
              WHERE id=?"
        )->execute([$note ?: 'Approved with FolioOne edit permission.', $me['id'], $eid]);
        // Grant folio edit permission on the user
        $expRow = $db->prepare('SELECT user_id FROM menu_builder_exports WHERE id=?');
        $expRow->execute([$eid]);
        $expData = $expRow->fetch();
        if ($expData) {
            $db->prepare('UPDATE users SET folio_edit_allowed=1 WHERE id=?')
               ->execute([$expData['user_id']]);
        }
        adminLog('EXPORT_APPROVED_FOLIO', 'menu_builder_export', $eid, 'FolioOne edit access granted.');
        $msg = ['ok', 'Export approved and FolioOne edit permission granted to user.'];

    } elseif ($action === 'reject' && $eid) {
        $db->prepare(
            "UPDATE menu_builder_exports
                SET status='rejected', admin_note=?, reviewed_by=?, reviewed_at=NOW()
              WHERE id=?"
        )->execute([$note, $me['id'], $eid]);
        adminLog('EXPORT_REJECTED', 'menu_builder_export', $eid, $note);
        $msg = ['error', 'Export rejected.'];

    } elseif ($action === 'delete' && $eid) {
        $db->prepare('DELETE FROM menu_builder_exports WHERE id=?')->execute([$eid]);
        adminLog('EXPORT_DELETED', 'menu_builder_export', $eid);
        $msg = ['ok', 'Export record deleted.'];
    }
}

// ── Filter / Pagination ───────────────────────────────────────────────────────
$filter       = $_GET['filter'] ?? 'pending';
$page         = max(1, (int)($_GET['page'] ?? 1));
$perPage      = 15;
$offset       = ($page - 1) * $perPage;

$statusMap    = ['pending' => 'pending', 'approved' => 'approved', 'rejected' => 'rejected', 'all' => null];
$statusFilter = $statusMap[$filter] ?? 'pending';
$where        = $statusFilter ? "status = '$statusFilter'" : '1=1';

$totalStmt = $db->query("SELECT COUNT(*) FROM menu_builder_exports WHERE $where");
$total     = (int)$totalStmt->fetchColumn();
$pages     = max(1, ceil($total / $perPage));

$exports = $db->query(
    "SELECT e.*,
            u.username,
            u.email,
            IFNULL(u.folio_edit_allowed, 0) AS folio_edit_allowed,
            r.username                       AS reviewer_name
     FROM   menu_builder_exports e
     LEFT JOIN users u ON u.id = e.user_id
     LEFT JOIN users r ON r.id = e.reviewed_by
     WHERE  $where
     ORDER BY e.created_at DESC
     LIMIT  $perPage OFFSET $offset"
)->fetchAll();

// ── Counts for badge tabs ─────────────────────────────────────────────────────
$counts        = $db->query(
    "SELECT status, COUNT(*) AS cnt FROM menu_builder_exports GROUP BY status"
)->fetchAll(PDO::FETCH_KEY_PAIR);
$pendingCount  = (int)($counts['pending']  ?? 0);
$approvedCount = (int)($counts['approved'] ?? 0);
$rejectedCount = (int)($counts['rejected'] ?? 0);
$allCount      = $pendingCount + $approvedCount + $rejectedCount;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Export Approvals — Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="admin-responsive.css">
    <link rel="stylesheet" href="export_approvals.css">
</head>
<body>

<div class="sidebar-overlay"></div>
<div class="layout">

    <!-- ── Sidebar ── -->
    <aside class="sidebar">
        <div class="sidebar-logo">
            <div class="brand">code<span>Me</span> Admin</div>
            <div class="admin-badge">⚡ ADMIN PANEL</div>
        </div>
        <div class="nav-section">Overview</div>
        <a class="nav-item" href="index.php"><span class="icon">📊</span> Dashboard</a>
        <a class="nav-item" href="analytics.php"><span class="icon">📈</span> Analytics</a>
        <div class="nav-section">Management</div>
        <a class="nav-item" href="users.php"><span class="icon">👥</span> Users</a>
        <a class="nav-item" href="challenges.php"><span class="icon">🎯</span> Challenges</a>
        <a class="nav-item" href="battles.php"><span class="icon">⚔️</span> Battles</a>
        <a class="nav-item active" href="export_approvals.php"><span class="icon">📦</span> Export Approvals</a>
        <div class="nav-section">Security</div>
        <a class="nav-item" href="scanner.php"><span class="icon">🛡️</span> File Scanner</a>
        <a class="nav-item" href="logs.php"><span class="icon">📋</span> Admin Logs</a>
        <div class="sidebar-footer">
            <a href="../versus.php">← Back to Site</a>
            <a href="../logout.php" style="margin-top:4px">🚪 Logout</a>
        </div>
    </aside>

    <!-- ── Main ── -->
    <div class="main">
        <div class="topbar">
            <button class="hamburger" aria-label="Toggle menu"><span></span></button>
            <div class="topbar-title">
                Export Approvals
                <?php if ($pendingCount > 0): ?>
                    <span class="pending-badge"><?= $pendingCount ?></span>
                <?php endif; ?>
            </div>
            <span class="topbar-sub">Review user-submitted Menu Builder files before they can be re-imported</span>
        </div>

        <div class="content">

            <?php if ($msg): ?>
            <div class="msg <?= $msg[0] === 'ok' ? 'msg-ok' : 'msg-err' ?>"><?= $msg[1] ?></div>
            <?php endif; ?>

            <!-- Filter tabs -->
            <div class="filter-tabs">
                <?php
                $tabs = [
                    'pending'  => ['label' => '⏳ Pending',  'count' => $pendingCount],
                    'approved' => ['label' => '✅ Approved', 'count' => $approvedCount],
                    'rejected' => ['label' => '❌ Rejected', 'count' => $rejectedCount],
                    'all'      => ['label' => '📋 All',      'count' => $allCount],
                ];
                foreach ($tabs as $key => $tab):
                ?>
                <a class="filter-tab <?= $filter === $key ? 'active' : '' ?>"
                   href="?filter=<?= $key ?>">
                    <?= $tab['label'] ?>
                    <?php if ($tab['count'] > 0): ?>
                        <span class="cnt"><?= $tab['count'] ?></span>
                    <?php endif; ?>
                </a>
                <?php endforeach; ?>
            </div>

            <!-- Export cards -->
            <?php if (empty($exports)): ?>
            <div class="empty-state">
                <div class="icon">📭</div>
                <h3>No exports found</h3>
                <p>
                    <?php if ($filter === 'pending'): ?>
                        No pending exports waiting for review.
                    <?php else: ?>
                        No <?= e($filter) ?> export records.
                    <?php endif; ?>
                </p>
            </div>

            <?php else: ?>
            <div class="exports-list">
                <?php foreach ($exports as $exp): ?>
                <?php
                    $statusClass = 'status-' . $exp['status'];
                    $statusLabel = [
                        'pending'  => ['🟡 Pending Review', 'badge-orange'],
                        'approved' => ['✅ Approved',        'badge-green'],
                        'rejected' => ['❌ Rejected',        'badge-pink'],
                    ][$exp['status']] ?? ['Unknown', 'badge-muted'];
                    $previewId   = 'frame-' . $exp['id'];
                    $hasFolio    = !empty($exp['folio_edit_allowed']);
                ?>
                <div class="export-card <?= $statusClass ?>">

                    <!-- Header -->
                    <div class="ec-head">
                        <div class="ec-meta">
                            <div class="ec-filename">📄 <?= e($exp['filename']) ?></div>
                            <div class="ec-sub">
                                <span>👤 <?= e($exp['username'] ?? 'Unknown') ?> (<?= e($exp['email'] ?? '') ?>)</span>
                                <span>🕐 Submitted: <?= date('M j, Y  H:i', strtotime($exp['created_at'])) ?></span>
                                <?php if ($exp['reviewed_at']): ?>
                                <span>👮 Reviewed by <?= e($exp['reviewer_name'] ?? 'Admin') ?> on <?= date('M j, Y', strtotime($exp['reviewed_at'])) ?></span>
                                <?php endif; ?>
                                <span>📏 <?= number_format(strlen($exp['file_content'])) ?> bytes</span>
                                <?php if ($hasFolio): ?>
                                <span class="folio-tag">🎨 FolioOne Edit Allowed</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <span class="badge <?= $statusLabel[1] ?>"><?= $statusLabel[0] ?></span>
                    </div>

                    <!-- Preview toggle -->
                    <span class="preview-toggle" onclick="togglePreview('<?= $previewId ?>', this)">
                        🔍 Preview HTML output
                    </span>
                    <iframe id="<?= $previewId ?>" class="preview-frame" sandbox="allow-scripts"></iframe>

                    <!-- Admin note from previous review -->
                    <?php if ($exp['admin_note']): ?>
                    <div class="admin-note-box">
                        <strong>Admin note:</strong> <?= e($exp['admin_note']) ?>
                    </div>
                    <?php endif; ?>

                    <!-- Action row -->
                    <div class="ec-actions">
                        <input type="text"
                               id="note-<?= $exp['id'] ?>"
                               class="ec-note-input"
                               placeholder="Optional note (e.g. 'Approved — looks good' or 'Rejected — unsafe script')">

                        <?php if ($exp['status'] !== 'approved'): ?>
                        <form method="POST">
                            <input type="hidden" name="action"     value="approve">
                            <input type="hidden" name="export_id"  value="<?= $exp['id'] ?>">
                            <input type="hidden" name="admin_note" id="approve-note-<?= $exp['id'] ?>" value="">
                            <button class="btn btn-approve" type="submit"
                                    onclick="document.getElementById('approve-note-<?= $exp['id'] ?>').value=document.getElementById('note-<?= $exp['id'] ?>').value">
                                ✅ Approve
                            </button>
                        </form>

                        <!-- Approve + grant FolioOne edit permission -->
                        <form method="POST" title="Approve and allow user to edit their FolioOne template">
                            <input type="hidden" name="action"     value="approve_folio">
                            <input type="hidden" name="export_id"  value="<?= $exp['id'] ?>">
                            <input type="hidden" name="admin_note" id="folio-note-<?= $exp['id'] ?>" value="">
                            <button class="btn btn-folio" type="submit"
                                    onclick="document.getElementById('folio-note-<?= $exp['id'] ?>').value=document.getElementById('note-<?= $exp['id'] ?>').value">
                                🎨 Approve + Allow FolioOne Edit
                            </button>
                        </form>
                        <?php endif; ?>

                        <?php if ($exp['status'] !== 'rejected'): ?>
                        <form method="POST">
                            <input type="hidden" name="action"     value="reject">
                            <input type="hidden" name="export_id"  value="<?= $exp['id'] ?>">
                            <input type="hidden" name="admin_note" id="reject-note-<?= $exp['id'] ?>" value="">
                            <button class="btn btn-reject" type="submit"
                                    onclick="document.getElementById('reject-note-<?= $exp['id'] ?>').value=document.getElementById('note-<?= $exp['id'] ?>').value">
                                ❌ Reject
                            </button>
                        </form>
                        <?php endif; ?>

                        <form method="POST" style="margin-left:auto">
                            <input type="hidden" name="action"    value="delete">
                            <input type="hidden" name="export_id" value="<?= $exp['id'] ?>">
                            <button class="btn btn-delete" type="submit"
                                    onclick="return confirm('Delete this export record permanently?')">
                                🗑 Delete
                            </button>
                        </form>
                    </div>

                </div>
                <?php endforeach; ?>
            </div>

            <?php if ($pages > 1): ?>
            <div class="pagination">
                <?php for ($i = 1; $i <= $pages; $i++): ?>
                <a class="page-btn <?= $i === $page ? 'active' : '' ?>"
                   href="?filter=<?= e($filter) ?>&page=<?= $i ?>"><?= $i ?></a>
                <?php endfor; ?>
            </div>
            <?php endif; ?>

            <?php endif; /* /empty check */ ?>

        </div><!-- /content -->
    </div><!-- /main -->
</div><!-- /layout -->

<!-- ── Embed preview content ── -->
<?php foreach ($exports as $exp): ?>
<script>
    (function () {
        var frame   = document.getElementById('frame-<?= $exp['id'] ?>');
        var content = <?= json_encode($exp['file_content']) ?>;
        if (frame) frame.srcdoc = content;
    })();
</script>
<?php endforeach; ?>

<script src="export_approvals.js"></script>
</body>
</html>
