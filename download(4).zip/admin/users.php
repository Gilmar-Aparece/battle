<?php
// ─── admin/users.php ─────────────────────────────────────────────────────────
require_once '../includes/config.php';
require_once 'guard.php';
requireAdmin();

$db = db();
$me = auth();
$msg = '';

// ── Actions ───────────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $uid    = (int)($_POST['user_id'] ?? 0);

    // ── BULK ACTIONS ─────────────────────────────────────────────────────────
    if ($action === 'bulk_action') {
        $bulkOp  = $_POST['bulk_op'] ?? '';
        $ids     = array_map('intval', (array)($_POST['bulk_ids'] ?? []));
        // never affect yourself
        $ids     = array_filter($ids, fn($id) => $id !== (int)$me['id']);
        $count   = 0;

        if (!empty($ids)) {
            foreach ($ids as $id) {
                switch ($bulkOp) {
                    case 'ban':
                        $db->prepare('UPDATE users SET is_banned=1, ban_reason=? WHERE id=?')
                           ->execute(['Bulk ban by admin', $id]);
                        adminLog('BAN_USER', 'user', $id, 'Bulk ban');
                        $count++;
                        break;
                    case 'unban':
                        $db->prepare('UPDATE users SET is_banned=0, ban_reason=NULL WHERE id=?')
                           ->execute([$id]);
                        adminLog('UNBAN_USER', 'user', $id, 'Bulk unban');
                        $count++;
                        break;
                    case 'promote':
                        $db->prepare('UPDATE users SET role=1 WHERE id=?')->execute([$id]);
                        adminLog('PROMOTE_ADMIN', 'user', $id, 'Bulk promote');
                        $count++;
                        break;
                    case 'demote':
                        $db->prepare('UPDATE users SET role=0 WHERE id=?')->execute([$id]);
                        adminLog('DEMOTE_ADMIN', 'user', $id, 'Bulk demote');
                        $count++;
                        break;
                    case 'disable_ui':
                        $db->prepare('UPDATE users SET ui_disabled=1 WHERE id=?')->execute([$id]);
                        adminLog('DISABLE_UI', 'user', $id, 'Bulk disable UI');
                        $count++;
                        break;
                    case 'enable_ui':
                        $db->prepare('UPDATE users SET ui_disabled=0 WHERE id=?')->execute([$id]);
                        adminLog('ENABLE_UI', 'user', $id, 'Bulk enable UI');
                        $count++;
                        break;
                    case 'delete':
                        $db->prepare('DELETE FROM users WHERE id=?')->execute([$id]);
                        adminLog('DELETE_USER', 'user', $id, 'Bulk delete');
                        $count++;
                        break;
                }
            }
        }
        $msg = ['ok', "Bulk action '{$bulkOp}' applied to {$count} user(s)."];

    // ── SINGLE ACTIONS ────────────────────────────────────────────────────────
    } elseif ($uid === (int)$me['id']) {
        $msg = ['error', 'You cannot modify your own account.'];
    } elseif ($action === 'ban' || $action === 'unban') {
        $banned = $action === 'ban' ? 1 : 0;
        $reason = $banned ? htmlspecialchars(trim($_POST['reason'] ?? ''), ENT_QUOTES) : null;
        $db->prepare('UPDATE users SET is_banned=?, ban_reason=? WHERE id=?')->execute([$banned, $reason, $uid]);
        adminLog($action === 'ban' ? 'BAN_USER' : 'UNBAN_USER', 'user', $uid, $reason);
        $msg = ['ok', 'User ' . ($action === 'ban' ? 'banned' : 'unbanned') . ' successfully.'];

    } elseif ($action === 'promote') {
        $db->prepare('UPDATE users SET role=1 WHERE id=?')->execute([$uid]);
        adminLog('PROMOTE_ADMIN', 'user', $uid);
        $msg = ['ok', 'User promoted to admin.'];

    } elseif ($action === 'demote') {
        $db->prepare('UPDATE users SET role=0 WHERE id=?')->execute([$uid]);
        adminLog('DEMOTE_ADMIN', 'user', $uid);
        $msg = ['ok', 'Admin demoted to regular user.'];

    } elseif ($action === 'delete') {
        $db->prepare('DELETE FROM users WHERE id=?')->execute([$uid]);
        adminLog('DELETE_USER', 'user', $uid);
        $msg = ['ok', 'User deleted.'];

    } elseif ($action === 'disable_ui') {
        $db->prepare('UPDATE users SET ui_disabled=1 WHERE id=?')->execute([$uid]);
        adminLog('DISABLE_UI', 'user', $uid, 'Admin disabled UI controls for user');
        $msg = ['ok', 'UI controls hidden for this user.'];

    } elseif ($action === 'enable_ui') {
        $db->prepare('UPDATE users SET ui_disabled=0 WHERE id=?')->execute([$uid]);
        adminLog('ENABLE_UI', 'user', $uid, 'Admin re-enabled UI controls for user');
        $msg = ['ok', 'UI controls restored for this user.'];

    } elseif ($action === 'disable_builder') {
        $db->prepare('UPDATE users SET menu_builder_disabled=1 WHERE id=?')->execute([$uid]);
        adminLog('DISABLE_BUILDER', 'user', $uid, 'Admin blocked menu builder access');
        $msg = ['ok', 'Menu Builder access revoked.'];

    } elseif ($action === 'enable_builder') {
        $db->prepare('UPDATE users SET menu_builder_disabled=0 WHERE id=?')->execute([$uid]);
        adminLog('ENABLE_BUILDER', 'user', $uid, 'Admin restored menu builder access');
        $msg = ['ok', 'Menu Builder access restored.'];
    }
}

// ── Query ─────────────────────────────────────────────────────────────────────
$search  = trim($_GET['q'] ?? '');
$filter  = $_GET['filter'] ?? 'all';
$page    = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;
$offset  = ($page - 1) * $perPage;

$where  = '1=1';
$params = [];
if ($search !== '') {
    $where   .= ' AND (username LIKE ? OR email LIKE ?)';
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($filter === 'banned')   { $where .= ' AND is_banned=1'; }
if ($filter === 'admins')   { $where .= ' AND role=1'; }
if ($filter === 'disabled') { $where .= ' AND ui_disabled=1'; }

$totalStmt = $db->prepare("SELECT COUNT(*) FROM users WHERE $where");
$totalStmt->execute($params);
$total = (int)$totalStmt->fetchColumn();
$pages = max(1, ceil($total / $perPage));

$stmt = $db->prepare("SELECT * FROM users WHERE $where ORDER BY created_at DESC LIMIT $perPage OFFSET $offset");
$stmt->execute($params);
$users = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Users — Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;600;800&display=swap" rel="stylesheet">
<style>
:root {
  --green:  #00ff87;
  --pink:   #ff2d6f;
  --blue:   #00c8ff;
  --yellow: #ffe14d;
  --orange: #ff8c42;
  --purple: #b14fff;
  --cyan:   #00e5ff;
  --bg:     #080b12;
  --bg2:    #0e1320;
  --bg3:    #141b2d;
  --border: rgba(255,255,255,0.07);
  --text:   #e8eaf0;
  --muted:  #5a6380;
  --font-head: 'Syne', sans-serif;
  --font-mono: 'Space Mono', monospace;
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html, body { min-height: 100%; background: var(--bg); color: var(--text); font-family: var(--font-head); }
a { color: inherit; text-decoration: none; }
button, input, select { font-family: inherit; }

/* Layout */
.layout  { display: flex; min-height: 100vh; }
.sidebar {
  width: 220px; flex-shrink: 0; background: var(--bg2);
  border-right: 1px solid var(--border);
  display: flex; flex-direction: column;
  position: sticky; top: 0; height: 100vh; overflow-y: auto;
}
.sidebar-logo              { padding: 24px 20px 20px; border-bottom: 1px solid var(--border); }
.sidebar-logo .brand       { font-size: 16px; font-weight: 800; letter-spacing: -.5px; }
.sidebar-logo .brand span  { color: var(--green); }
.admin-badge               { display: inline-block; margin-top: 6px; padding: 2px 8px; border-radius: 4px; background: rgba(177,79,255,.15); color: var(--purple); font-size: 10px; font-weight: 700; letter-spacing: 1px; border: 1px solid rgba(177,79,255,.3); }
.nav-section               { padding: 16px 12px 8px; font-size: 10px; font-weight: 700; letter-spacing: 1.5px; color: var(--muted); text-transform: uppercase; }
.nav-item                  { display: flex; align-items: center; gap: 10px; padding: 9px 16px; border-radius: 10px; margin: 2px 8px; font-size: 13px; font-weight: 600; color: var(--muted); transition: all .15s; cursor: pointer; }
.nav-item:hover            { color: #fff; background: rgba(255,255,255,.05); }
.nav-item.active           { color: var(--green); background: rgba(0,255,135,.06); }
.nav-item .icon            { font-size: 15px; width: 20px; text-align: center; }
.sidebar-footer            { margin-top: auto; padding: 16px; border-top: 1px solid var(--border); }
.sidebar-footer a          { display: flex; align-items: center; gap: 8px; font-size: 12px; color: var(--muted); padding: 8px; border-radius: 8px; transition: color .15s; }
.sidebar-footer a:hover    { color: #fff; }

.main     { flex: 1; overflow-x: hidden; }
.topbar   { display: flex; align-items: center; justify-content: space-between; padding: 0 32px; height: 60px; background: var(--bg2); border-bottom: 1px solid var(--border); position: sticky; top: 0; z-index: 10; }
.topbar-title { font-size: 18px; font-weight: 800; }
.content  { padding: 32px; }

/* Card / Table */
.card       { background: var(--bg2); border: 1px solid var(--border); border-radius: 14px; overflow: hidden; }
.table-wrap { overflow-x: auto; }
table       { width: 100%; border-collapse: collapse; }
th {
  padding: 11px 14px; text-align: left; font-size: 10px; font-weight: 700;
  letter-spacing: 1px; color: var(--muted); text-transform: uppercase;
  border-bottom: 1px solid var(--border); background: var(--bg3);
}
td {
  padding: 11px 14px; font-size: 13px;
  border-bottom: 1px solid rgba(255,255,255,.04);
  vertical-align: middle;
}
tr:last-child td { border-bottom: none; }
tr:hover td      { background: rgba(255,255,255,.02); }

/* Checkbox column */
.th-check { width: 36px; padding-left: 16px !important; }
.td-check { padding-left: 16px !important; }
.cb       { width: 15px; height: 15px; cursor: pointer; accent-color: var(--green); }

/* Badges */
.badge        { display: inline-block; padding: 2px 8px; border-radius: 20px; font-size: 11px; font-weight: 700; }
.badge-green  { background: rgba(0,255,135,.1);  color: var(--green);  border: 1px solid rgba(0,255,135,.2); }
.badge-pink   { background: rgba(255,45,111,.1); color: var(--pink);   border: 1px solid rgba(255,45,111,.2); }
.badge-purple { background: rgba(177,79,255,.1); color: var(--purple); border: 1px solid rgba(177,79,255,.2); }
.badge-muted  { background: rgba(90,99,128,.15); color: var(--muted);  border: 1px solid rgba(90,99,128,.2); }
.badge-orange { background: rgba(255,140,66,.1); color: var(--orange); border: 1px solid rgba(255,140,66,.3); }
.badge-cyan   { background: rgba(0,229,255,.1);  color: var(--cyan);   border: 1px solid rgba(0,229,255,.25); }

/* Toolbar */
.toolbar    { display: flex; align-items: center; gap: 12px; margin-bottom: 16px; flex-wrap: wrap; }
.search-box { display: flex; align-items: center; flex: 1; min-width: 200px; }
.search-box input  { flex: 1; padding: 9px 14px; border-radius: 10px 0 0 10px; border: 1px solid var(--border); background: var(--bg3); color: var(--text); font-size: 13px; outline: none; }
.search-box input:focus { border-color: var(--green); }
.search-box button { padding: 9px 16px; border-radius: 0 10px 10px 0; border: 1px solid var(--border); border-left: none; background: var(--green); color: #080b12; font-weight: 700; font-size: 13px; cursor: pointer; }
.filter-tabs { display: flex; gap: 6px; flex-wrap: wrap; }
.filter-tab  { padding: 7px 14px; border-radius: 8px; border: 1px solid var(--border); background: var(--bg3); color: var(--muted); font-size: 12px; font-weight: 600; cursor: pointer; text-decoration: none; transition: all .15s; }
.filter-tab:hover, .filter-tab.active { color: #fff; border-color: rgba(255,255,255,.15); background: rgba(255,255,255,.05); }
.filter-tab.active { color: var(--green); border-color: rgba(0,255,135,.3); }

/* ── Bulk Actions Bar ── */
.bulk-bar {
  display: flex; align-items: center; gap: 10px; flex-wrap: wrap;
  background: var(--bg3); border: 1px solid var(--border);
  border-radius: 12px; padding: 10px 16px; margin-bottom: 14px;
  transition: border-color .2s;
}
.bulk-bar.has-selection { border-color: rgba(0,255,135,.25); }
.bulk-select-label {
  display: flex; align-items: center; gap: 8px;
  font-size: 12px; font-weight: 600; color: var(--muted); cursor: pointer; white-space: nowrap;
}
.bulk-count {
  font-size: 11px; font-family: var(--font-mono); color: var(--green);
  background: rgba(0,255,135,.1); border: 1px solid rgba(0,255,135,.2);
  border-radius: 20px; padding: 1px 8px; min-width: 28px; text-align: center;
}
.bulk-sep { width: 1px; height: 20px; background: var(--border); flex-shrink: 0; }
.bulk-ops { display: flex; gap: 6px; flex-wrap: wrap; }
.bulk-btn {
  padding: 5px 12px; border-radius: 7px; font-size: 11px; font-weight: 700;
  cursor: pointer; border: none; font-family: var(--font-head); transition: all .15s;
  opacity: .45; pointer-events: none;
}
.bulk-btn.enabled { opacity: 1; pointer-events: auto; }
.bulk-btn-ban    { background: rgba(255,45,111,.12); color: var(--pink);   border: 1px solid rgba(255,45,111,.25); }
.bulk-btn-ban.enabled:hover    { background: rgba(255,45,111,.25); }
.bulk-btn-unban  { background: rgba(0,255,135,.1);  color: var(--green);  border: 1px solid rgba(0,255,135,.2); }
.bulk-btn-unban.enabled:hover  { background: rgba(0,255,135,.22); }
.bulk-btn-promote { background: rgba(177,79,255,.1); color: var(--purple); border: 1px solid rgba(177,79,255,.2); }
.bulk-btn-promote.enabled:hover { background: rgba(177,79,255,.22); }
.bulk-btn-demote  { background: rgba(90,99,128,.12); color: var(--muted);  border: 1px solid rgba(90,99,128,.2); }
.bulk-btn-demote.enabled:hover  { background: rgba(90,99,128,.25); color: var(--text); }
.bulk-btn-disui  { background: rgba(255,140,66,.1); color: var(--orange); border: 1px solid rgba(255,140,66,.25); }
.bulk-btn-disui.enabled:hover  { background: rgba(255,140,66,.22); }
.bulk-btn-enui   { background: rgba(0,229,255,.08); color: var(--cyan);   border: 1px solid rgba(0,229,255,.2); }
.bulk-btn-enui.enabled:hover   { background: rgba(0,229,255,.2); }
.bulk-btn-delete { background: rgba(255,45,111,.08); color: #ff6b8a;      border: 1px solid rgba(255,45,111,.15); }
.bulk-btn-delete.enabled:hover { background: rgba(255,45,111,.22); }
.bulk-hint { font-size:11px; color:var(--muted); margin-left:auto; font-family: var(--font-mono); }

/* Individual Buttons */
.btn       { padding: 5px 11px; border-radius: 7px; border: none; font-size: 11px; font-weight: 700; cursor: pointer; transition: all .15s; white-space: nowrap; }
.btn-ban   { background: rgba(255,45,111,.15); color: var(--pink);   border: 1px solid rgba(255,45,111,.3); }
.btn-ban:hover   { background: rgba(255,45,111,.28); }
.btn-unban { background: rgba(0,255,135,.1);  color: var(--green);  border: 1px solid rgba(0,255,135,.2); }
.btn-unban:hover { background: rgba(0,255,135,.22); }
.btn-admin { background: rgba(177,79,255,.1); color: var(--purple); border: 1px solid rgba(177,79,255,.2); }
.btn-admin:hover { background: rgba(177,79,255,.22); }
.btn-del   { background: rgba(255,45,111,.08); color: #ff6b8a; border: 1px solid rgba(255,45,111,.15); }
.btn-del:hover { background: rgba(255,45,111,.22); }
.btn-ui-off { background: rgba(255,140,66,.12); color: var(--orange); border: 1px solid rgba(255,140,66,.3); }
.btn-ui-off:hover { background: rgba(255,140,66,.26); }
.btn-ui-on  { background: rgba(0,229,255,.1);  color: var(--cyan);   border: 1px solid rgba(0,229,255,.25); }
.btn-ui-on:hover  { background: rgba(0,229,255,.22); }
.action-cell { display: flex; gap: 5px; flex-wrap: wrap; align-items: center; }

/* Messages */
.msg     { padding: 12px 16px; border-radius: 10px; margin-bottom: 16px; font-size: 13px; }
.msg-ok  { background: rgba(0,255,135,.08);  border: 1px solid rgba(0,255,135,.2);  color: var(--green); }
.msg-err { background: rgba(255,45,111,.08); border: 1px solid rgba(255,45,111,.2); color: var(--pink); }

/* Pagination */
.pagination { display: flex; gap: 6px; margin-top: 20px; justify-content: center; flex-wrap: wrap; }
.page-btn   { padding: 6px 12px; border-radius: 8px; border: 1px solid var(--border); background: var(--bg2); color: var(--muted); font-size: 12px; font-weight: 600; cursor: pointer; text-decoration: none; transition: all .15s; }
.page-btn:hover, .page-btn.active { color: var(--green); border-color: rgba(0,255,135,.3); }

/* Modal */
.modal-bg     { display: none; position: fixed; inset: 0; background: rgba(0,0,0,.7); z-index: 100; align-items: center; justify-content: center; }
.modal-bg.open { display: flex; }
.modal        { background: var(--bg2); border: 1px solid var(--border); border-radius: 16px; padding: 28px; width: 100%; max-width: 420px; }
.modal h3     { font-size: 16px; font-weight: 800; margin-bottom: 8px; }
.modal p      { font-size: 13px; color: var(--muted); margin-bottom: 16px; }
.modal input  { width: 100%; padding: 9px 14px; border-radius: 9px; border: 1px solid var(--border); background: var(--bg3); color: var(--text); font-size: 13px; outline: none; margin-bottom: 14px; }
.modal input:focus { border-color: var(--pink); }
.modal-btns   { display: flex; gap: 10px; justify-content: flex-end; }
.modal-cancel  { padding: 8px 18px; border-radius: 8px; border: 1px solid var(--border); background: var(--bg3); color: var(--muted); font-size: 13px; cursor: pointer; }
.modal-confirm { padding: 8px 18px; border-radius: 8px; border: none; background: var(--pink); color: #fff; font-size: 13px; font-weight: 700; cursor: pointer; }

/* Row states */
tr.ui-off td { opacity: .75; }
tr.ui-off td:first-child { border-left: 3px solid var(--orange); }
tr.row-selected td { background: rgba(0,255,135,.04) !important; }

/* Hamburger / mobile */
.hamburger { display:none;align-items:center;justify-content:center;width:36px;height:36px;border-radius:8px;border:1px solid var(--border);background:var(--bg3);cursor:pointer;flex-shrink:0; }
.hamburger span { display:block;width:16px;height:2px;background:var(--text);position:relative; }
.hamburger span::before,.hamburger span::after { content:'';position:absolute;width:16px;height:2px;background:var(--text);left:0; }
.hamburger span::before{top:-5px} .hamburger span::after{top:5px}
.sidebar-overlay { display:none;position:fixed;inset:0;background:rgba(0,0,0,.65);z-index:99;backdrop-filter:blur(2px); }
.sidebar-overlay.visible { display:block }

@media(max-width:768px){
  .hamburger{display:flex}
  .sidebar{position:fixed;top:0;left:0;height:100vh;z-index:100;transform:translateX(-100%);transition:transform .28s cubic-bezier(.4,0,.2,1);width:260px;}
  .sidebar.open{transform:translateX(0)}
  .main{width:100%;min-width:0}
  .topbar{padding:0 14px;gap:10px} .topbar-title{font-size:14px}
  .content{padding:12px}
  .toolbar{flex-direction:column;align-items:stretch;gap:10px}
  .search-box{width:100%}
  .filter-tabs{overflow-x:auto;flex-wrap:nowrap;padding-bottom:4px}
  .filter-tab{white-space:nowrap;flex-shrink:0}
  .bulk-bar{flex-direction:column;align-items:stretch}
  .bulk-ops{flex-wrap:wrap}
  .bulk-hint{margin-left:0}
  .table-wrap{overflow-x:visible}
  table thead{display:none}
  table,tbody,tr,td{display:block;width:100%}
  tr{background:var(--bg3);border:1px solid var(--border);border-radius:12px;margin-bottom:10px;padding:12px 14px;position:relative;}
  tr:hover td{background:none}
  tr:last-child td{border-bottom:none}
  td{padding:4px 0;border-bottom:none !important;font-size:13px;display:flex;align-items:flex-start;gap:8px;}
  td[data-label]::before{content:attr(data-label);font-size:10px;font-weight:700;letter-spacing:.8px;color:var(--muted);text-transform:uppercase;min-width:72px;flex-shrink:0;padding-top:2px;}
  .td-check{padding-left:0 !important}
  .action-cell{flex-wrap:wrap;gap:6px;padding-top:6px;border-top:1px solid var(--border);margin-top:4px;}
  td[data-label="Actions"]::before{display:none}
  td[data-label="Actions"]{flex-direction:column;align-items:stretch}
  .btn{padding:7px 12px;font-size:12px;text-align:center}
  tr.ui-off{border-left:3px solid var(--orange)}
  tr.ui-off td:first-child{border-left:none}
  .pagination{flex-wrap:wrap;gap:6px;justify-content:center}
  .modal{margin:16px;width:calc(100% - 32px);max-width:none}
}
@media(max-width:400px){
  .topbar-title .user-count{display:none}
  .filter-tab{padding:6px 10px;font-size:11px}
}
</style>
</head>
<body>
<div class="sidebar-overlay"></div>
<div class="layout">

<!-- ── Sidebar ── -->
<aside class="sidebar">
  <div class="sidebar-logo">
    <div class="brand">code<span>Me</span> Admin</div>
    <div class="admin-badge">⚡ ADMIN PANEL</div>
  </div>
  <div class="nav-section">Overview</div>
  <a class="nav-item" href="index.php"><span class="icon">📊</span> Dashboard</a>
  <a class="nav-item" href="analytics.php"><span class="icon">📈</span> Analytics</a>
  <div class="nav-section">Management</div>
  <a class="nav-item active" href="users.php"><span class="icon">👥</span> Users</a>
  <a class="nav-item" href="challenges.php"><span class="icon">🎯</span> Challenges</a>
  <a class="nav-item" href="battles.php"><span class="icon">⚔️</span> Battles</a>
  <a class="nav-item" href="schedule.php"><span class="icon">🗓️</span> Scheduled Posts</a>
  <a class="nav-item" href="export_approvals.php"><span class="icon">📦</span> Export Approvals</a>
  <div class="nav-section">Security</div>
  <a class="nav-item" href="scanner.php"><span class="icon">🛡️</span> File Scanner</a>
  <a class="nav-item" href="logs.php"><span class="icon">📋</span> Admin Logs</a>
  <div class="sidebar-footer">
    <a href="../versus.php">← Back to Site</a>
    <a href="../logout.php" style="margin-top:4px">🚪 Logout</a>
  </div>
</aside>

<!-- ── Main ── -->
<div class="main">
  <div class="topbar">
    <button class="hamburger" aria-label="Toggle menu"><span></span></button>
    <div class="topbar-title">
      Users
      <span class="user-count" style="color:var(--muted);font-size:14px;font-weight:400">(<?= $total ?>)</span>
    </div>
    <a href="export_approvals.php"
       style="font-size:12px;color:var(--orange);border:1px solid rgba(255,140,66,.3);
              padding:6px 14px;border-radius:8px;font-weight:700;">
      📦 Export Approvals
    </a>
  </div>

  <div class="content">

    <?php if ($msg): ?>
    <div class="msg <?= $msg[0] === 'ok' ? 'msg-ok' : 'msg-err' ?>">
      <?= $msg[0] === 'ok' ? '✅' : '❌' ?> <?= e($msg[1]) ?>
    </div>
    <?php endif; ?>

    <!-- Legend -->
    <div style="display:flex;align-items:center;gap:16px;margin-bottom:16px;font-size:12px;color:var(--muted);">
      <span style="display:flex;align-items:center;gap:6px;">
        <span style="width:10px;height:10px;border-radius:2px;background:var(--orange);display:inline-block;"></span>
        UI Disabled — user's view-source / builder controls are hidden
      </span>
    </div>

    <!-- ── Search / Filter Toolbar ── -->
    <div class="toolbar">
      <form class="search-box" method="GET">
        <input type="text" name="q" value="<?= e($search) ?>" placeholder="Search username or email…">
        <?php if ($filter !== 'all'): ?>
          <input type="hidden" name="filter" value="<?= e($filter) ?>">
        <?php endif; ?>
        <button type="submit">Search</button>
      </form>
      <div class="filter-tabs">
        <a class="filter-tab <?= $filter === 'all'      ? 'active' : '' ?>" href="?q=<?= urlencode($search) ?>&filter=all">All</a>
        <a class="filter-tab <?= $filter === 'admins'   ? 'active' : '' ?>" href="?q=<?= urlencode($search) ?>&filter=admins">Admins</a>
        <a class="filter-tab <?= $filter === 'banned'   ? 'active' : '' ?>" href="?q=<?= urlencode($search) ?>&filter=banned">Banned</a>
        <a class="filter-tab <?= $filter === 'disabled' ? 'active' : '' ?>" href="?q=<?= urlencode($search) ?>&filter=disabled"
           style="<?= $filter === 'disabled' ? 'color:var(--orange);border-color:rgba(255,140,66,.4)' : '' ?>">
          UI Disabled
        </a>
      </div>
    </div>

    <!-- ── Bulk Actions Bar ── -->
    <form method="POST" id="bulkForm">
      <input type="hidden" name="action"  value="bulk_action">
      <input type="hidden" name="bulk_op" id="bulkOp" value="">

      <div class="bulk-bar" id="bulkBar">
        <!-- Select All -->
        <label class="bulk-select-label">
          <input type="checkbox" class="cb" id="selectAll" onchange="toggleAll(this)">
          Select All
        </label>
        <span class="bulk-count" id="bulkCount">0</span>

        <div class="bulk-sep"></div>

        <!-- Bulk action buttons -->
        <div class="bulk-ops">
          <button type="button" class="bulk-btn bulk-btn-ban"     id="bBan"     onclick="bulkDo('ban',     'Ban all selected users?')">🚫 Ban</button>
          <button type="button" class="bulk-btn bulk-btn-unban"   id="bUnban"   onclick="bulkDo('unban',   'Unban all selected users?')">✅ Unban</button>
          <button type="button" class="bulk-btn bulk-btn-promote" id="bPromote" onclick="bulkDo('promote', 'Promote selected to Admin?')">⬆️ +Admin</button>
          <button type="button" class="bulk-btn bulk-btn-demote"  id="bDemote"  onclick="bulkDo('demote',  'Demote selected from Admin?')">⬇️ −Admin</button>
          <button type="button" class="bulk-btn bulk-btn-disui"   id="bDisUI"   onclick="bulkDo('disable_ui', 'Disable UI controls for selected?')">🚫 Disable UI</button>
          <button type="button" class="bulk-btn bulk-btn-enui"    id="bEnUI"    onclick="bulkDo('enable_ui',  'Enable UI controls for selected?')">✓ Enable UI</button>
          <button type="button" class="bulk-btn bulk-btn-delete"  id="bDelete"  onclick="bulkDo('delete',  '⚠️ PERMANENTLY DELETE selected users? This cannot be undone!')">🗑️ Delete</button>
        </div>

        <span class="bulk-hint" id="bulkHint">Select rows to enable bulk actions</span>
      </div>

    <!-- ── Users Table ── -->
    <div class="card">
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th class="th-check"><input type="checkbox" class="cb" id="selectAllTh" onchange="toggleAll(this)"></th>
              <th>ID</th>
              <th>Username</th>
              <th>Email</th>
              <th>W / L</th>
              <th>Score</th>
              <th>Role</th>
              <th>UI Controls</th>
              <th>Joined</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($users as $u): ?>
          <?php $uiOff = !empty($u['ui_disabled']); $builderOff = !empty($u['menu_builder_disabled']); $isMe = (int)$u['id'] === (int)$me['id']; ?>
          <tr class="<?= $uiOff ? 'ui-off' : '' ?>" id="row-<?= $u['id'] ?>">

            <td class="td-check">
              <?php if (!$isMe): ?>
              <input type="checkbox" class="cb row-cb" name="bulk_ids[]" value="<?= $u['id'] ?>" onchange="updateBulkCount()">
              <?php endif; ?>
            </td>

            <td data-label="ID" style="font-family:var(--font-mono);font-size:11px;color:var(--muted)"><?= $u['id'] ?></td>

            <td data-label="Username">
              <strong><?= e($u['username']) ?></strong>
              <?php if ($u['is_banned']): ?>
                <br><small style="color:var(--pink)"><?= e($u['ban_reason'] ?? 'Banned') ?></small>
              <?php endif; ?>
            </td>

            <td data-label="Email" style="font-size:12px;color:var(--muted)"><?= e($u['email']) ?></td>

            <td data-label="W / L" style="font-family:var(--font-mono);font-size:12px">
              <span style="color:var(--green)"><?= $u['wins'] ?>W</span>/<span style="color:var(--pink)"><?= $u['losses'] ?>L</span>
            </td>

            <td data-label="Score" style="font-family:var(--font-mono);font-size:12px"><?= $u['total_score'] ?></td>

            <td data-label="Role">
              <?php if ($u['role'] == 1): ?>
                <span class="badge badge-purple">ADMIN</span>
              <?php elseif ($u['is_banned']): ?>
                <span class="badge badge-pink">BANNED</span>
              <?php else: ?>
                <span class="badge badge-muted">User</span>
              <?php endif; ?>
            </td>

            <td data-label="UI Controls">
              <?php if ($uiOff): ?>
                <span class="badge badge-orange">🚫 Disabled</span>
              <?php else: ?>
                <span class="badge badge-green">✓ Active</span>
              <?php endif; ?>
              <?php if ($builderOff): ?>
                <br><span class="badge badge-pink" style="margin-top:3px;font-size:10px">Builder Blocked</span>
              <?php endif; ?>
            </td>

            <td data-label="Joined" style="font-size:11px;color:var(--muted)"><?= date('Y-m-d', strtotime($u['created_at'])) ?></td>

            <td data-label="Actions">
              <?php if (!$isMe): ?>
              <div class="action-cell">
                <a class="btn btn-unban" href="../messages.php?with=<?= $u['id'] ?>">💬 Message</a>

                <?php if (!$u['is_banned']): ?>
                  <button class="btn btn-ban" onclick="openBan(<?= $u['id'] ?>, '<?= e($u['username']) ?>')">Ban</button>
                <?php else: ?>
                  <form method="POST" style="display:inline">
                    <input type="hidden" name="action"  value="unban">
                    <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                    <button class="btn btn-unban" type="submit">Unban</button>
                  </form>
                <?php endif; ?>

                <?php if ($u['role'] == 0): ?>
                  <form method="POST" style="display:inline">
                    <input type="hidden" name="action"  value="promote">
                    <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                    <button class="btn btn-admin" type="submit"
                            onclick="return confirm('Make <?= e($u['username']) ?> an admin?')">+Admin</button>
                  </form>
                <?php else: ?>
                  <form method="POST" style="display:inline">
                    <input type="hidden" name="action"  value="demote">
                    <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                    <button class="btn btn-ban" type="submit"
                            onclick="return confirm('Remove admin from <?= e($u['username']) ?>?')">−Admin</button>
                  </form>
                <?php endif; ?>

                <?php if (!$uiOff): ?>
                  <form method="POST" style="display:inline">
                    <input type="hidden" name="action"  value="disable_ui">
                    <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                    <button class="btn btn-ui-off" type="submit"
                            onclick="return confirm('Hide UI source controls for <?= e($u['username']) ?>?')">
                      🚫 Disable UI
                    </button>
                  </form>
                <?php else: ?>
                  <form method="POST" style="display:inline">
                    <input type="hidden" name="action"  value="enable_ui">
                    <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                    <button class="btn btn-ui-on" type="submit">✓ Enable UI</button>
                  </form>
                <?php endif; ?>

                <?php if (!$builderOff): ?>
                  <form method="POST" style="display:inline">
                    <input type="hidden" name="action"  value="disable_builder">
                    <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                    <button class="btn btn-ui-off" type="submit"
                            onclick="return confirm('Block Menu Builder for <?= e($u['username']) ?>?')">
                      🔒 Block Builder
                    </button>
                  </form>
                <?php else: ?>
                  <form method="POST" style="display:inline">
                    <input type="hidden" name="action"  value="enable_builder">
                    <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                    <button class="btn btn-ui-on" type="submit">🔓 Allow Builder</button>
                  </form>
                <?php endif; ?>

                <form method="POST" style="display:inline">
                  <input type="hidden" name="action"  value="delete">
                  <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                  <button class="btn btn-del" type="submit"
                          onclick="return confirm('PERMANENTLY delete <?= e($u['username']) ?>? This cannot be undone.')">Delete</button>
                </form>

              </div>
              <?php else: ?>
                <span style="color:var(--muted);font-size:11px">— (you)</span>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>

    </form><!-- /bulkForm -->

    <?php if ($pages > 1): ?>
    <div class="pagination">
      <?php for ($i = 1; $i <= $pages; $i++): ?>
      <a class="page-btn <?= $i === $page ? 'active' : '' ?>"
         href="?q=<?= urlencode($search) ?>&filter=<?= e($filter) ?>&page=<?= $i ?>"><?= $i ?></a>
      <?php endfor; ?>
    </div>
    <?php endif; ?>

  </div><!-- /content -->
</div><!-- /main -->
</div><!-- /layout -->

<!-- ── Ban Modal ── -->
<div class="modal-bg" id="banModal">
  <div class="modal">
    <h3>🚫 Ban User</h3>
    <p>Provide a reason for banning <strong id="banTarget"></strong>.</p>
    <form method="POST">
      <input type="hidden" name="action"  value="ban">
      <input type="hidden" name="user_id" id="banUserId">
      <input type="text"   name="reason"  placeholder="Reason (e.g. spam, cheating)…" required>
      <div class="modal-btns">
        <button type="button"  class="modal-cancel"  onclick="closeBan()">Cancel</button>
        <button type="submit"  class="modal-confirm">Ban User</button>
      </div>
    </form>
  </div>
</div>

<script>
// ── Ban modal ─────────────────────────────────────────────────────────────────
function openBan(id, name) {
  document.getElementById('banUserId').value = id;
  document.getElementById('banTarget').textContent = name;
  document.getElementById('banModal').classList.add('open');
}
function closeBan() {
  document.getElementById('banModal').classList.remove('open');
}
document.getElementById('banModal').addEventListener('click', function(e) {
  if (e.target === this) closeBan();
});

// ── Bulk selection ────────────────────────────────────────────────────────────
function toggleAll(master) {
  var checked = master.checked;
  // sync both checkboxes (header + bar)
  document.getElementById('selectAll').checked   = checked;
  document.getElementById('selectAllTh').checked = checked;
  document.querySelectorAll('.row-cb').forEach(function(cb) { cb.checked = checked; });
  updateBulkCount();
}

function updateBulkCount() {
  var checkboxes = document.querySelectorAll('.row-cb');
  var checked    = document.querySelectorAll('.row-cb:checked');
  var count      = checked.length;
  var total      = checkboxes.length;

  // Update count badge
  document.getElementById('bulkCount').textContent = count;

  // Enable / disable buttons
  var allBtns = document.querySelectorAll('.bulk-btn');
  allBtns.forEach(function(b) {
    b.classList.toggle('enabled', count > 0);
  });

  // Highlight the bar
  document.getElementById('bulkBar').classList.toggle('has-selection', count > 0);

  // Update hint text
  var hint = document.getElementById('bulkHint');
  hint.textContent = count > 0
    ? count + ' user' + (count > 1 ? 's' : '') + ' selected — choose an action above'
    : 'Select rows to enable bulk actions';

  // Indeterminate state for master checkboxes
  ['selectAll', 'selectAllTh'].forEach(function(id) {
    var el = document.getElementById(id);
    if (!el) return;
    el.indeterminate = count > 0 && count < total;
    el.checked = total > 0 && count === total;
  });

  // Highlight selected rows
  checkboxes.forEach(function(cb) {
    var row = cb.closest('tr');
    if (row) row.classList.toggle('row-selected', cb.checked);
  });
}

function bulkDo(op, confirmMsg) {
  var count = document.querySelectorAll('.row-cb:checked').length;
  if (count === 0) { alert('No users selected.'); return; }
  if (!confirm(confirmMsg + '\n\n' + count + ' user(s) will be affected.')) return;
  document.getElementById('bulkOp').value = op;
  document.getElementById('bulkForm').submit();
}

// ── Sidebar hamburger ─────────────────────────────────────────────────────────
(function(){
  var btn     = document.querySelector('.hamburger');
  var sidebar = document.querySelector('.sidebar');
  var overlay = document.querySelector('.sidebar-overlay');
  if (!btn) return;
  function open()  { sidebar.classList.add('open');    overlay.classList.add('visible');    document.body.style.overflow='hidden'; }
  function close() { sidebar.classList.remove('open'); overlay.classList.remove('visible'); document.body.style.overflow=''; }
  btn.addEventListener('click',   function() { sidebar.classList.contains('open') ? close() : open(); });
  overlay.addEventListener('click', close);
  document.addEventListener('keydown', function(e) { if (e.key === 'Escape') close(); });
})();
</script>
</body>
</html>
