<?php
require_once '../includes/config.php';
require_once 'guard.php';
requireAdmin();

$db  = db();
$me  = auth();

// ── Malware signature patterns ────────────────────────────────────────
$SIGNATURES = [
    // Obfuscation / encoding tricks
    'Base64 eval'           => '/eval\s*\(\s*base64_decode\s*\(/i',
    'Gzinflate eval'        => '/eval\s*\(\s*gzinflate\s*\(/i',
    'Gzuncompress eval'     => '/eval\s*\(\s*gzuncompress\s*\(/i',
    'Str rot13 eval'        => '/eval\s*\(\s*str_rot13\s*\(/i',
    'Double base64'         => '/base64_decode\s*\(\s*base64_decode/i',
    'Hex encoded eval'      => '/eval\s*\(\s*"\\\\x/i',
    'Preg replace /e exec'  => '/preg_replace\s*\(\s*[\'"].*\/e[\'"],/i',

    // Remote code execution
    'System shell cmd'      => '/\b(system|passthru|shell_exec|popen|proc_open)\s*\(/i',
    'PHP exec()'            => '/\bexec\s*\(/i',
    'Assert string eval'    => '/assert\s*\(\s*[\$_]/i',

    // File operations (suspicious context)
    'File write fopen'      => '/fopen\s*\(.*[\'"]w[\'"]/i',
    'file_put_contents'     => '/file_put_contents\s*\(/i',
    'Move uploaded file'    => '/move_uploaded_file\s*\(/i',

    // Network / backdoors
    'fsockopen backdoor'    => '/fsockopen\s*\(/i',
    'curl_exec'             => '/curl_exec\s*\(/i',
    'HTTP header redirect'  => '/header\s*\(\s*[\'"]Location:.*\$_/i',

    // Obfuscated variable names
    'Long hex var'          => '/\$\{[\'"\\\\x[0-9a-f]{4,}[\'"]\}/i',
    'Variable variables'    => '/\$\{\$[a-zA-Z_]/i',
    'Superglobal injection' => '/\$_(GET|POST|COOKIE|REQUEST|SERVER)\s*\[.*\]\s*\(/',

    // Webshell indicators
    'Webshell keyword'      => '/(c99|r57|phpspy|carbylamine|b374k|wso shell)/i',
    'chmod 0777'            => '/chmod\s*\(.*0777\)/i',
    'Disable functions'     => '/disable_functions\s*=/i',
];

$scanResults = null;
$scanSummary = null;
$previousScans = $db->query(
    'SELECT ss.*, u.username FROM security_scans ss
     LEFT JOIN users u ON u.id=ss.scanned_by
     ORDER BY ss.created_at DESC LIMIT 5'
)->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['scan'])) {

    $rootDir  = realpath(__DIR__ . '/..');
    $findings = [];
    $fileCount = 0;
    $issueCount = 0;

    // Recursively scan PHP files
    $iter = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($rootDir, FilesystemIterator::SKIP_DOTS)
    );

    foreach ($iter as $file) {
        if ($file->getExtension() !== 'php') continue;
        $path = $file->getRealPath();

        // Skip the admin panel itself to avoid false positives on this scanner
        if (strpos($path, realpath(__DIR__)) === 0) continue;

        $fileCount++;
        $content = @file_get_contents($path);
        if ($content === false) continue;

        $lines   = explode("\n", $content);
        $fileHits = [];

        foreach ($SIGNATURES as $name => $pattern) {
            foreach ($lines as $lineNum => $line) {
                if (preg_match($pattern, $line)) {
                    $fileHits[] = [
                        'rule'    => $name,
                        'line'    => $lineNum + 1,
                        'snippet' => trim(substr($line, 0, 120)),
                    ];
                    $issueCount++;
                }
            }
        }

        if (!empty($fileHits)) {
            $relPath = ltrim(str_replace($rootDir, '', $path), '/\\');
            $findings[] = [
                'file' => $relPath,
                'hits' => $fileHits,
            ];
        }
    }

    $scanResults = $findings;
    $scanSummary = ['files' => $fileCount, 'issues' => $issueCount];

    // Save to DB
    $db->prepare(
        'INSERT INTO security_scans (scanned_by, files_scanned, issues_found, result_json) VALUES (?,?,?,?)'
    )->execute([$me['id'], $fileCount, $issueCount, json_encode($findings)]);

    adminLog('SECURITY_SCAN', null, null, "Scanned $fileCount files, found $issueCount issues");

    // Refresh
    $previousScans = $db->query(
        'SELECT ss.*, u.username FROM security_scans ss
         LEFT JOIN users u ON u.id=ss.scanned_by
         ORDER BY ss.created_at DESC LIMIT 5'
    )->fetchAll();
}

// Load a previous scan
if (isset($_GET['view']) && !$scanResults) {
    $row = $db->prepare('SELECT * FROM security_scans WHERE id=?');
    $row->execute([(int)$_GET['view']]);
    $row = $row->fetch();
    if ($row) {
        $scanResults  = json_decode($row['result_json'], true);
        $scanSummary  = ['files' => $row['files_scanned'], 'issues' => $row['issues_found']];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Security Scanner — Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;600;800&display=swap" rel="stylesheet">
<style>
:root{--green:#00ff87;--pink:#ff2d6f;--blue:#00c8ff;--yellow:#ffe14d;--orange:#ff8c42;--purple:#b14fff;--bg:#080b12;--bg2:#0e1320;--bg3:#141b2d;--border:rgba(255,255,255,0.07);--text:#e8eaf0;--muted:#5a6380;--font-head:'Syne',sans-serif;--font-mono:'Space Mono',monospace}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{min-height:100%;background:var(--bg);color:var(--text);font-family:var(--font-head)}
a{color:inherit;text-decoration:none}
.layout{display:flex;min-height:100vh}
.sidebar{width:220px;flex-shrink:0;background:var(--bg2);border-right:1px solid var(--border);display:flex;flex-direction:column;position:sticky;top:0;height:100vh;overflow-y:auto}
.sidebar-logo{padding:24px 20px 20px;border-bottom:1px solid var(--border)}
.sidebar-logo .brand{font-size:16px;font-weight:800;letter-spacing:-.5px}
.sidebar-logo .brand span{color:var(--green)}
.admin-badge{display:inline-block;margin-top:6px;padding:2px 8px;border-radius:4px;background:rgba(177,79,255,.15);color:var(--purple);font-size:10px;font-weight:700;letter-spacing:1px;border:1px solid rgba(177,79,255,.3)}
.nav-section{padding:16px 12px 8px;font-size:10px;font-weight:700;letter-spacing:1.5px;color:var(--muted);text-transform:uppercase}
.nav-item{display:flex;align-items:center;gap:10px;padding:9px 16px;border-radius:10px;margin:2px 8px;font-size:13px;font-weight:600;color:var(--muted);transition:all .15s;cursor:pointer}
.nav-item:hover{color:#fff;background:rgba(255,255,255,.05)}
.nav-item.active{color:var(--green);background:rgba(0,255,135,.06)}
.nav-item .icon{font-size:15px;width:20px;text-align:center}
.sidebar-footer{margin-top:auto;padding:16px;border-top:1px solid var(--border)}
.sidebar-footer a{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--muted);padding:8px;border-radius:8px;transition:color .15s}
.sidebar-footer a:hover{color:#fff}
.main{flex:1;overflow-x:hidden}
.topbar{display:flex;align-items:center;padding:0 32px;height:60px;background:var(--bg2);border-bottom:1px solid var(--border);position:sticky;top:0;z-index:10}
.topbar-title{font-size:18px;font-weight:800}
.content{padding:32px;max-width:1000px}
.card{background:var(--bg2);border:1px solid var(--border);border-radius:14px;overflow:hidden;margin-bottom:24px}
.card-header{padding:16px 20px;border-bottom:1px solid var(--border);font-size:14px;font-weight:800;display:flex;align-items:center;justify-content:space-between}
.card-body{padding:20px}
.scan-hero{
  background:linear-gradient(135deg,rgba(0,255,135,.05),rgba(0,200,255,.05));
  border:1px solid rgba(0,255,135,.15);border-radius:16px;
  padding:32px;text-align:center;margin-bottom:24px;
}
.scan-hero h2{font-size:24px;font-weight:800;margin-bottom:8px}
.scan-hero p{color:var(--muted);font-size:14px;margin-bottom:24px;line-height:1.6}
.btn-scan{
  display:inline-flex;align-items:center;gap:10px;
  padding:14px 32px;border-radius:12px;border:none;
  background:var(--green);color:#080b12;font-size:15px;font-weight:800;cursor:pointer;
  font-family:var(--font-head);letter-spacing:-.2px;
  transition:filter .2s,transform .2s;
}
.btn-scan:hover{filter:brightness(1.1);transform:translateY(-2px)}
.btn-scan:disabled{opacity:.5;cursor:not-allowed;transform:none}
.summary-row{display:flex;gap:16px;margin-bottom:20px;flex-wrap:wrap}
.sum-box{flex:1;min-width:140px;background:var(--bg3);border-radius:12px;padding:16px;text-align:center}
.sum-box .sv{font-size:28px;font-weight:800;font-family:var(--font-mono)}
.sum-box .sl{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.8px;margin-top:4px}
.clean-banner{
  background:rgba(0,255,135,.06);border:1px solid rgba(0,255,135,.2);
  border-radius:12px;padding:20px;text-align:center;color:var(--green);font-size:15px;font-weight:700;
}
.finding{border:1px solid rgba(255,45,111,.2);border-radius:12px;margin-bottom:16px;overflow:hidden}
.finding-header{
  background:rgba(255,45,111,.08);padding:12px 16px;
  display:flex;align-items:center;gap:10px;
  font-family:var(--font-mono);font-size:12px;color:var(--pink);cursor:pointer;
}
.finding-header .file-name{font-weight:700;flex:1}
.finding-header .hit-count{background:rgba(255,45,111,.2);padding:2px 8px;border-radius:20px;font-size:11px}
.finding-body{padding:0}
.hit-row{
  padding:10px 16px;border-bottom:1px solid rgba(255,255,255,.04);
  display:grid;grid-template-columns:auto 1fr;gap:10px;align-items:start;
}
.hit-row:last-child{border-bottom:none}
.hit-meta{width:160px}
.hit-rule{font-size:11px;font-weight:700;color:var(--orange)}
.hit-line{font-size:10px;color:var(--muted);margin-top:2px}
.hit-snippet{font-family:var(--font-mono);font-size:11px;color:var(--muted);word-break:break-all;background:var(--bg3);padding:6px 10px;border-radius:6px;line-height:1.5}
.prev-table{width:100%;border-collapse:collapse}
.prev-table th{padding:10px 14px;text-align:left;font-size:10px;font-weight:700;letter-spacing:1px;color:var(--muted);text-transform:uppercase;border-bottom:1px solid var(--border);background:var(--bg3)}
.prev-table td{padding:11px 14px;font-size:12px;border-bottom:1px solid rgba(255,255,255,.04)}
.prev-table tr:last-child td{border-bottom:none}
.btn-view{padding:5px 12px;border-radius:7px;border:1px solid var(--border);background:var(--bg3);color:var(--muted);font-size:11px;cursor:pointer;text-decoration:none;transition:all .15s}
.btn-view:hover{color:#fff;border-color:rgba(255,255,255,.2)}
.rules-list{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:8px}
.rule-item{background:var(--bg3);border-radius:8px;padding:10px 14px;font-size:12px}
.rule-item .rn{font-weight:700;color:var(--text);margin-bottom:2px}
.rule-item .rp{font-family:var(--font-mono);font-size:10px;color:var(--muted);word-break:break-all}

/* ── RESPONSIVE / MOBILE ── */
.hamburger{
  display:none;align-items:center;justify-content:center;
  width:36px;height:36px;border-radius:8px;border:1px solid var(--border);
  background:var(--bg3);cursor:pointer;flex-shrink:0;
  transition:background .15s;
}
.hamburger:hover{background:rgba(255,255,255,.08)}
.hamburger span{display:block;width:16px;height:2px;background:var(--text);
  position:relative;transition:background .2s}
.hamburger span::before,.hamburger span::after{
  content:'';position:absolute;width:16px;height:2px;background:var(--text);
  left:0;transition:transform .25s,top .25s,opacity .25s}
.hamburger span::before{top:-5px}
.hamburger span::after{top:5px}
.hamburger.open span{background:transparent}
.hamburger.open span::before{top:0;transform:rotate(45deg)}
.hamburger.open span::after{top:0;transform:rotate(-45deg)}

.sidebar-overlay{
  display:none;position:fixed;inset:0;background:rgba(0,0,0,.65);
  z-index:99;backdrop-filter:blur(2px);
}
.sidebar-overlay.visible{display:block}

@media(max-width:768px){
  .hamburger{display:flex}

  .sidebar{
    position:fixed;top:0;left:0;height:100vh;z-index:100;
    transform:translateX(-100%);transition:transform .28s cubic-bezier(.4,0,.2,1);
    width:260px;
  }
  .sidebar.open{transform:translateX(0)}

  .main{width:100%;min-width:0}

  .topbar{padding:0 16px;gap:12px}
  .topbar-title{font-size:15px}
  .topbar-user{font-size:11px;gap:6px}

  .content{padding:16px}

  .stats-grid{grid-template-columns:repeat(2,1fr);gap:12px;margin-bottom:20px}
  .stat-card .value{font-size:24px}

  .two-col{grid-template-columns:1fr !important;gap:16px}

  .table-wrap{overflow-x:auto;-webkit-overflow-scrolling:touch}
  table{min-width:480px}
  th,td{padding:9px 12px;font-size:12px}

  .toolbar{flex-direction:column;align-items:stretch}
  .search-box{width:100%}
  .filter-tabs{overflow-x:auto;flex-wrap:nowrap;padding-bottom:2px}

  .btn{padding:4px 8px;font-size:10px}

  .pagination{flex-wrap:wrap;gap:6px}

  /* analytics / chart responsive */
  .chart-row{flex-direction:column}
  .chart-wrap{min-width:0 !important;width:100% !important}
}

@media(max-width:400px){
  .stats-grid{grid-template-columns:1fr}
  .topbar-user .admin-pill{display:none}
}


@media(max-width:768px){
  .summary-row{flex-direction:column}
  .rules-list{grid-template-columns:1fr}
  .finding-header{flex-wrap:wrap}
}

</style>
</head>
<body>
<div class="sidebar-overlay"></div>
<div class="layout">
<aside class="sidebar">
  <div class="sidebar-logo">
    <div class="brand">code<span>Me</span> Admin</div>
    <div class="admin-badge">⚡ ADMIN PANEL</div>
  </div>
  <div class="nav-section">Overview</div>
  <a class="nav-item" href="index.php"><span class="icon">📊</span> Dashboard</a>
  <a class="nav-item" href="analytics.php"><span class="icon">📈</span> Analytics</a>
  <div class="nav-section">Management</div>
  <a class="nav-item" href="users.php"><span class="icon">👥</span> Users</a>
  <a class="nav-item" href="challenges.php"><span class="icon">🎯</span> Challenges</a>
  <a class="nav-item" href="battles.php"><span class="icon">⚔️</span> Battles</a>
  <div class="nav-section">Security</div>
  <a class="nav-item active" href="scanner.php"><span class="icon">🛡️</span> File Scanner</a>
  <a class="nav-item" href="logs.php"><span class="icon">📋</span> Admin Logs</a>
  <div class="sidebar-footer">
    <a href="../versus.php">← Back to Site</a>
    <a href="../logout.php" style="margin-top:4px">🚪 Logout</a>
  </div>
</aside>
<div class="main">
  <div class="topbar">
  <button class="hamburger" aria-label="Toggle menu"><span></span></button>
  <div class="topbar-title">🛡️ Security File Scanner</div></div>
  <div class="content">

    <div class="scan-hero">
      <h2>PHP Malware Scanner</h2>
      <p>
        Scans all <code style="color:var(--green)">.php</code> files in your site root for known malware patterns:<br>
        eval injection, webshells, obfuscated code, backdoors, remote execution, and more.
      </p>
      <form method="POST">
        <button class="btn-scan" type="submit" name="scan" id="scanBtn" onclick="this.disabled=true;this.textContent='🔍 Scanning…';this.form.submit()">
          🔍 Run Security Scan
        </button>
      </form>
    </div>

    <?php if($scanResults !== null): ?>
    <!-- Summary -->
    <div class="summary-row">
      <div class="sum-box">
        <div class="sv" style="color:var(--blue)"><?= $scanSummary['files'] ?></div>
        <div class="sl">Files Scanned</div>
      </div>
      <div class="sum-box">
        <div class="sv" style="color:<?= count($scanResults)>0 ? 'var(--pink)' : 'var(--green)' ?>"><?= count($scanResults) ?></div>
        <div class="sl">Files Flagged</div>
      </div>
      <div class="sum-box">
        <div class="sv" style="color:<?= $scanSummary['issues']>0 ? 'var(--orange)' : 'var(--green)' ?>"><?= $scanSummary['issues'] ?></div>
        <div class="sl">Total Issues</div>
      </div>
    </div>

    <?php if(empty($scanResults)): ?>
    <div class="clean-banner">✅ No threats detected — your site looks clean!</div>
    <?php else: ?>
    <div style="margin-bottom:12px">
      <strong style="color:var(--pink)">⚠️ Potential threats detected.</strong>
      <span style="color:var(--muted);font-size:13px"> Review each finding carefully. False positives are possible — legitimate code may match some patterns.</span>
    </div>
    <?php foreach($scanResults as $f): ?>
    <div class="finding">
      <div class="finding-header" onclick="this.nextSibling.style.display=this.nextSibling.style.display==='none'?'block':'none'">
        <span>📄</span>
        <span class="file-name"><?= e($f['file']) ?></span>
        <span class="hit-count"><?= count($f['hits']) ?> issue<?= count($f['hits'])>1?'s':'' ?></span>
        <span style="color:var(--muted);font-size:12px">▼</span>
      </div>
      <div class="finding-body">
        <?php foreach($f['hits'] as $h): ?>
        <div class="hit-row">
          <div class="hit-meta">
            <div class="hit-rule"><?= e($h['rule']) ?></div>
            <div class="hit-line">Line <?= $h['line'] ?></div>
          </div>
          <div class="hit-snippet"><?= e($h['snippet']) ?></div>
        </div>
        <?php endforeach ?>
      </div>
    </div>
    <?php endforeach ?>
    <?php endif ?>
    <?php endif ?>

    <!-- Previous scans -->
    <?php if(!empty($previousScans)): ?>
    <div class="card">
      <div class="card-header">📂 Previous Scans</div>
      <table class="prev-table">
        <tr><th>Date</th><th>By</th><th>Files</th><th>Issues</th><th></th></tr>
        <?php foreach($previousScans as $ps): ?>
        <tr>
          <td><?= date('Y-m-d H:i', strtotime($ps['created_at'])) ?></td>
          <td><?= e($ps['username'] ?? '?') ?></td>
          <td style="font-family:var(--font-mono)"><?= $ps['files_scanned'] ?></td>
          <td style="font-family:var(--font-mono);color:<?= $ps['issues_found']>0?'var(--pink)':'var(--green)' ?>;font-weight:700">
            <?= $ps['issues_found'] ?>
          </td>
          <td><a class="btn-view" href="?view=<?= $ps['id'] ?>">View</a></td>
        </tr>
        <?php endforeach ?>
      </table>
    </div>
    <?php endif ?>

    <!-- Signatures reference -->
    <div class="card">
      <div class="card-header" style="cursor:pointer" onclick="document.getElementById('sigList').style.display=document.getElementById('sigList').style.display==='none'?'grid':'none'">
        🔬 Detection Rules (<?= count($SIGNATURES) ?>) <span style="color:var(--muted);font-size:12px;font-weight:400">— click to toggle</span>
      </div>
      <div class="card-body">
        <div class="rules-list" id="sigList" style="display:none">
          <?php foreach($SIGNATURES as $name=>$pat): ?>
          <div class="rule-item">
            <div class="rn"><?= e($name) ?></div>
            <div class="rp"><?= e($pat) ?></div>
          </div>
          <?php endforeach ?>
        </div>
      </div>
    </div>

  </div>
</div>
</div>
<script>
(function(){
  var btn     = document.querySelector('.hamburger');
  var sidebar = document.querySelector('.sidebar');
  var overlay = document.querySelector('.sidebar-overlay');
  if (!btn || !sidebar || !overlay) return;

  function openMenu() {
    sidebar.classList.add('open');
    overlay.classList.add('visible');
    btn.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  function closeMenu() {
    sidebar.classList.remove('open');
    overlay.classList.remove('visible');
    btn.classList.remove('open');
    document.body.style.overflow = '';
  }

  btn.addEventListener('click', function() {
    sidebar.classList.contains('open') ? closeMenu() : openMenu();
  });
  overlay.addEventListener('click', closeMenu);
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeMenu();
  });
})();
</script>
</body>
</html>
