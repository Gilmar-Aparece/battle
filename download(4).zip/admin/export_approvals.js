/* ═══════════════════════════════════════════════════════
   export_approvals.js — Admin Export Approvals page
   ═══════════════════════════════════════════════════════ */

/* ── Preview toggle ── */
function togglePreview(frameId, btn) {
    var frame = document.getElementById(frameId);
    var show  = !frame.classList.contains('visible');
    frame.classList.toggle('visible', show);
    btn.textContent = show ? '🔒 Hide preview' : '🔍 Preview HTML output';
}

/* ── Hamburger / mobile sidebar ── */
(function () {
    var btn     = document.querySelector('.hamburger');
    var sidebar = document.querySelector('.sidebar');
    var overlay = document.querySelector('.sidebar-overlay');
    if (!btn || !sidebar || !overlay) return;

    function openMenu() {
        sidebar.classList.add('open');
        overlay.classList.add('visible');
        btn.classList.add('open');
        document.body.style.overflow = 'hidden';
    }

    function closeMenu() {
        sidebar.classList.remove('open');
        overlay.classList.remove('visible');
        btn.classList.remove('open');
        document.body.style.overflow = '';
    }

    btn.addEventListener('click', function () {
        sidebar.classList.contains('open') ? closeMenu() : openMenu();
    });

    overlay.addEventListener('click', closeMenu);

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') closeMenu();
    });
})();
