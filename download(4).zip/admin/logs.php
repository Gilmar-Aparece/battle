<?php
require_once '../includes/config.php';
require_once 'guard.php';
requireAdmin();

$db = db();

$page    = max(1,(int)($_GET['page']??1));
$perPage = 30;
$offset  = ($page-1)*$perPage;

$total = (int)$db->query('SELECT COUNT(*) FROM admin_logs')->fetchColumn();
$pages = max(1,ceil($total/$perPage));

$logs = $db->query(
    "SELECT al.*, u.username FROM admin_logs al
     LEFT JOIN users u ON u.id=al.admin_id
     ORDER BY al.created_at DESC LIMIT $perPage OFFSET $offset"
)->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin Logs</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;600;800&display=swap" rel="stylesheet">
<style>
:root{--green:#00ff87;--pink:#ff2d6f;--blue:#00c8ff;--yellow:#ffe14d;--orange:#ff8c42;--purple:#b14fff;--bg:#080b12;--bg2:#0e1320;--bg3:#141b2d;--border:rgba(255,255,255,0.07);--text:#e8eaf0;--muted:#5a6380;--font-head:'Syne',sans-serif;--font-mono:'Space Mono',monospace}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{min-height:100%;background:var(--bg);color:var(--text);font-family:var(--font-head)}
a{color:inherit;text-decoration:none}
.layout{display:flex;min-height:100vh}
.sidebar{width:220px;flex-shrink:0;background:var(--bg2);border-right:1px solid var(--border);display:flex;flex-direction:column;position:sticky;top:0;height:100vh;overflow-y:auto}
.sidebar-logo{padding:24px 20px 20px;border-bottom:1px solid var(--border)}
.sidebar-logo .brand{font-size:16px;font-weight:800}
.sidebar-logo .brand span{color:var(--green)}
.admin-badge{display:inline-block;margin-top:6px;padding:2px 8px;border-radius:4px;background:rgba(177,79,255,.15);color:var(--purple);font-size:10px;font-weight:700;letter-spacing:1px;border:1px solid rgba(177,79,255,.3)}
.nav-section{padding:16px 12px 8px;font-size:10px;font-weight:700;letter-spacing:1.5px;color:var(--muted);text-transform:uppercase}
.nav-item{display:flex;align-items:center;gap:10px;padding:9px 16px;border-radius:10px;margin:2px 8px;font-size:13px;font-weight:600;color:var(--muted);transition:all .15s}
.nav-item:hover{color:#fff;background:rgba(255,255,255,.05)}
.nav-item.active{color:var(--green);background:rgba(0,255,135,.06)}
.nav-item .icon{font-size:15px;width:20px;text-align:center}
.sidebar-footer{margin-top:auto;padding:16px;border-top:1px solid var(--border)}
.sidebar-footer a{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--muted);padding:8px;border-radius:8px;transition:color .15s}
.sidebar-footer a:hover{color:#fff}
.main{flex:1}
.topbar{display:flex;align-items:center;padding:0 32px;height:60px;background:var(--bg2);border-bottom:1px solid var(--border);position:sticky;top:0;z-index:10}
.topbar-title{font-size:18px;font-weight:800}
.content{padding:32px}
.card{background:var(--bg2);border:1px solid var(--border);border-radius:14px;overflow:hidden}
table{width:100%;border-collapse:collapse}
th{padding:11px 16px;text-align:left;font-size:10px;font-weight:700;letter-spacing:1px;color:var(--muted);text-transform:uppercase;border-bottom:1px solid var(--border);background:var(--bg3)}
td{padding:11px 16px;font-size:13px;border-bottom:1px solid rgba(255,255,255,.04)}
tr:last-child td{border-bottom:none}
tr:hover td{background:rgba(255,255,255,.02)}
.badge{display:inline-block;padding:2px 8px;border-radius:20px;font-size:10px;font-weight:700}
.pagination{display:flex;gap:6px;margin-top:20px;justify-content:center}
.page-btn{padding:6px 12px;border-radius:8px;border:1px solid var(--border);background:var(--bg2);color:var(--muted);font-size:12px;font-weight:600;text-decoration:none;transition:all .15s}
.page-btn:hover,.page-btn.active{color:var(--green);border-color:rgba(0,255,135,.3)}

/* ── RESPONSIVE / MOBILE ── */
.hamburger{
  display:none;align-items:center;justify-content:center;
  width:36px;height:36px;border-radius:8px;border:1px solid var(--border);
  background:var(--bg3);cursor:pointer;flex-shrink:0;
  transition:background .15s;
}
.hamburger:hover{background:rgba(255,255,255,.08)}
.hamburger span{display:block;width:16px;height:2px;background:var(--text);
  position:relative;transition:background .2s}
.hamburger span::before,.hamburger span::after{
  content:'';position:absolute;width:16px;height:2px;background:var(--text);
  left:0;transition:transform .25s,top .25s,opacity .25s}
.hamburger span::before{top:-5px}
.hamburger span::after{top:5px}
.hamburger.open span{background:transparent}
.hamburger.open span::before{top:0;transform:rotate(45deg)}
.hamburger.open span::after{top:0;transform:rotate(-45deg)}

.sidebar-overlay{
  display:none;position:fixed;inset:0;background:rgba(0,0,0,.65);
  z-index:99;backdrop-filter:blur(2px);
}
.sidebar-overlay.visible{display:block}

@media(max-width:768px){
  .hamburger{display:flex}

  .sidebar{
    position:fixed;top:0;left:0;height:100vh;z-index:100;
    transform:translateX(-100%);transition:transform .28s cubic-bezier(.4,0,.2,1);
    width:260px;
  }
  .sidebar.open{transform:translateX(0)}

  .main{width:100%;min-width:0}

  .topbar{padding:0 16px;gap:12px}
  .topbar-title{font-size:15px}
  .topbar-user{font-size:11px;gap:6px}

  .content{padding:16px}

  .stats-grid{grid-template-columns:repeat(2,1fr);gap:12px;margin-bottom:20px}
  .stat-card .value{font-size:24px}

  .two-col{grid-template-columns:1fr !important;gap:16px}

  .table-wrap{overflow-x:auto;-webkit-overflow-scrolling:touch}
  table{min-width:480px}
  th,td{padding:9px 12px;font-size:12px}

  .toolbar{flex-direction:column;align-items:stretch}
  .search-box{width:100%}
  .filter-tabs{overflow-x:auto;flex-wrap:nowrap;padding-bottom:2px}

  .btn{padding:4px 8px;font-size:10px}

  .pagination{flex-wrap:wrap;gap:6px}

  /* analytics / chart responsive */
  .chart-row{flex-direction:column}
  .chart-wrap{min-width:0 !important;width:100% !important}
}

@media(max-width:400px){
  .stats-grid{grid-template-columns:1fr}
  .topbar-user .admin-pill{display:none}
}

</style>
</head>
<body>
<div class="sidebar-overlay"></div>
<div class="layout">
<aside class="sidebar">
  <div class="sidebar-logo">
    <div class="brand">code<span>Me</span> Admin</div>
    <div class="admin-badge">⚡ ADMIN PANEL</div>
  </div>
  <div class="nav-section">Overview</div>
  <a class="nav-item" href="index.php"><span class="icon">📊</span> Dashboard</a>
  <a class="nav-item" href="analytics.php"><span class="icon">📈</span> Analytics</a>
  <div class="nav-section">Management</div>
  <a class="nav-item" href="users.php"><span class="icon">👥</span> Users</a>
  <a class="nav-item" href="challenges.php"><span class="icon">🎯</span> Challenges</a>
  <a class="nav-item" href="battles.php"><span class="icon">⚔️</span> Battles</a>
  <div class="nav-section">Security</div>
  <a class="nav-item" href="scanner.php"><span class="icon">🛡️</span> File Scanner</a>
  <a class="nav-item active" href="logs.php"><span class="icon">📋</span> Admin Logs</a>
  <div class="sidebar-footer">
    <a href="../versus.php">← Back to Site</a>
    <a href="../logout.php" style="margin-top:4px">🚪 Logout</a>
  </div>
</aside>
<div class="main">
  <div class="topbar">
  <button class="hamburger" aria-label="Toggle menu"><span></span></button>
  <div class="topbar-title">Admin Logs (<?= $total ?>)</div></div>
  <div class="content">
    <div class="card">
      <table>
        <tr><th>Time</th><th>Admin</th><th>Action</th><th>Target</th><th>Detail</th></tr>
        <?php if(empty($logs)): ?>
        <tr><td colspan="5" style="text-align:center;color:var(--muted);padding:24px">No admin actions logged yet.</td></tr>
        <?php else: foreach($logs as $log): ?>
        <tr>
          <td style="font-size:11px;color:var(--muted);font-family:var(--font-mono);white-space:nowrap"><?= date('Y-m-d H:i:s', strtotime($log['created_at'])) ?></td>
          <td style="font-weight:600"><?= e($log['username'] ?? '?') ?></td>
          <td>
            <?php
            $colors = [
              'BAN_USER'=>'var(--pink)','UNBAN_USER'=>'var(--green)',
              'DELETE_USER'=>'var(--pink)','PROMOTE_ADMIN'=>'var(--purple)',
              'DEMOTE_ADMIN'=>'var(--orange)','SECURITY_SCAN'=>'var(--blue)',
            ];
            $col = $colors[$log['action']] ?? 'var(--muted)';
            ?>
            <span style="font-family:var(--font-mono);font-size:11px;font-weight:700;color:<?= $col ?>"><?= e($log['action']) ?></span>
          </td>
          <td style="font-size:12px;color:var(--muted)">
            <?= $log['target_type'] ? e($log['target_type']).' #'.$log['target_id'] : '—' ?>
          </td>
          <td style="font-size:12px;color:var(--muted)"><?= e($log['detail'] ?? '') ?></td>
        </tr>
        <?php endforeach; endif ?>
      </table>
    </div>
    <?php if($pages>1): ?>
    <div class="pagination">
      <?php for($i=1;$i<=$pages;$i++): ?>
      <a class="page-btn <?= $i===$page?'active':'' ?>" href="?page=<?= $i ?>"><?= $i ?></a>
      <?php endfor ?>
    </div>
    <?php endif ?>
  </div>
</div>
</div>
<script>
(function(){
  var btn     = document.querySelector('.hamburger');
  var sidebar = document.querySelector('.sidebar');
  var overlay = document.querySelector('.sidebar-overlay');
  if (!btn || !sidebar || !overlay) return;

  function openMenu() {
    sidebar.classList.add('open');
    overlay.classList.add('visible');
    btn.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  function closeMenu() {
    sidebar.classList.remove('open');
    overlay.classList.remove('visible');
    btn.classList.remove('open');
    document.body.style.overflow = '';
  }

  btn.addEventListener('click', function() {
    sidebar.classList.contains('open') ? closeMenu() : openMenu();
  });
  overlay.addEventListener('click', closeMenu);
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeMenu();
  });
})();
</script>
</body>
</html>
