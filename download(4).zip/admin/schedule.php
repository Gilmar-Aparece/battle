<?php
require_once '../includes/config.php';
require_once 'guard.php';
requireAdmin();

$db   = db();
$user = auth();

// ── Handle POST actions ───────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // ── Single approve ────────────────────────────────────────────────────────
    if ($action === 'approve') {
        $id = (int)($_POST['id'] ?? 0);
        // Fetch the scheduled post
        $sp = $db->prepare('SELECT * FROM scheduled_posts WHERE id=?');
        $sp->execute([$id]);
        $sp = $sp->fetch();
        if ($sp && $sp['status'] === 'pending') {
            // Insert directly into showcase_posts
            $ins = $db->prepare(
                'INSERT INTO showcase_posts (user_id,title,description,html_code,css_code,js_code,allow_versus)
                 VALUES (?,?,?,?,?,?,?)'
            );
            $ins->execute([
                $sp['user_id'], $sp['title'], $sp['description'],
                $sp['html_code'], $sp['css_code'], $sp['js_code'], $sp['allow_versus']
            ]);
            $newId = (int)$db->lastInsertId();
            $db->prepare("UPDATE scheduled_posts SET status='published', showcase_post_id=? WHERE id=?")
               ->execute([$newId, $id]);
            adminLog('approve_scheduled', 'scheduled_post', $id, 'Force-approved by admin');
            $_SESSION['flash_sched'] = ['ok', "Post #{$id} approved & published."];
        }
        header('Location: schedule.php');
        exit;
    }

    // ── Single delete ─────────────────────────────────────────────────────────
    if ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        $db->prepare('DELETE FROM scheduled_posts WHERE id=?')->execute([$id]);
        adminLog('delete_scheduled', 'scheduled_post', $id);
        $_SESSION['flash_sched'] = ['ok', "Post #{$id} deleted."];
        header('Location: schedule.php');
        exit;
    }

    // ── Bulk approve ──────────────────────────────────────────────────────────
    if ($action === 'bulk_approve') {
        $ids = array_map('intval', (array)($_POST['ids'] ?? []));
        $count = 0;
        foreach ($ids as $id) {
            $sp = $db->prepare('SELECT * FROM scheduled_posts WHERE id=? AND status=\'pending\'');
            $sp->execute([$id]);
            $sp = $sp->fetch();
            if ($sp) {
                $ins = $db->prepare(
                    'INSERT INTO showcase_posts (user_id,title,description,html_code,css_code,js_code,allow_versus)
                     VALUES (?,?,?,?,?,?,?)'
                );
                $ins->execute([
                    $sp['user_id'], $sp['title'], $sp['description'],
                    $sp['html_code'], $sp['css_code'], $sp['js_code'], $sp['allow_versus']
                ]);
                $newId = (int)$db->lastInsertId();
                $db->prepare("UPDATE scheduled_posts SET status='published', showcase_post_id=? WHERE id=?")
                   ->execute([$newId, $id]);
                adminLog('approve_scheduled', 'scheduled_post', $id, 'Bulk-approved');
                $count++;
            }
        }
        $_SESSION['flash_sched'] = ['ok', "Bulk approved {$count} post(s)."];
        header('Location: schedule.php');
        exit;
    }

    // ── Bulk delete ───────────────────────────────────────────────────────────
    if ($action === 'bulk_delete') {
        $ids = array_map('intval', (array)($_POST['ids'] ?? []));
        $count = 0;
        foreach ($ids as $id) {
            $db->prepare('DELETE FROM scheduled_posts WHERE id=?')->execute([$id]);
            adminLog('delete_scheduled', 'scheduled_post', $id, 'Bulk-deleted');
            $count++;
        }
        $_SESSION['flash_sched'] = ['ok', "Bulk deleted {$count} post(s)."];
        header('Location: schedule.php');
        exit;
    }
}

// ── Flash ─────────────────────────────────────────────────────────────────────
$flash = $_SESSION['flash_sched'] ?? null;
unset($_SESSION['flash_sched']);

// ── Filter / pagination ───────────────────────────────────────────────────────
$filter  = in_array($_GET['filter'] ?? '', ['pending','published','cancelled']) ? $_GET['filter'] : 'all';
$page    = max(1, (int)($_GET['p'] ?? 1));
$perPage = 20;
$offset  = ($page - 1) * $perPage;

$where = $filter !== 'all' ? "WHERE sp.status = " . $db->quote($filter) : '';

$total = (int)$db->query(
    "SELECT COUNT(*) FROM scheduled_posts sp $where"
)->fetchColumn();

$rows = $db->query(
    "SELECT sp.*, u.username, u.email
     FROM scheduled_posts sp
     LEFT JOIN users u ON u.id = sp.user_id
     $where
     ORDER BY sp.scheduled_at DESC
     LIMIT $perPage OFFSET $offset"
)->fetchAll();

$pages = max(1, (int)ceil($total / $perPage));

// ── Stats ─────────────────────────────────────────────────────────────────────
$stats = [];
foreach (['pending','published','cancelled'] as $s) {
    $stats[$s] = (int)$db->query("SELECT COUNT(*) FROM scheduled_posts WHERE status='$s'")->fetchColumn();
}
$stats['all'] = array_sum($stats);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Scheduled Posts — Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;600;800&display=swap" rel="stylesheet">
<style>
:root{
  --green:#00ff87;--pink:#ff2d6f;--blue:#00c8ff;--yellow:#ffe14d;
  --orange:#ff8c42;--purple:#b14fff;
  --bg:#080b12;--bg2:#0e1320;--bg3:#141b2d;--bg4:#1a2240;
  --border:rgba(255,255,255,0.07);--text:#e8eaf0;--muted:#5a6380;
  --font-head:'Syne',sans-serif;--font-mono:'Space Mono',monospace;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{min-height:100%;background:var(--bg);color:var(--text);font-family:var(--font-head)}
a{color:inherit;text-decoration:none}
button,input,select,textarea{font-family:inherit}

/* ── Layout ── */
.layout{display:flex;min-height:100vh}

/* ── Sidebar ── */
.sidebar{
  width:220px;flex-shrink:0;background:var(--bg2);
  border-right:1px solid var(--border);
  display:flex;flex-direction:column;
  position:sticky;top:0;height:100vh;overflow-y:auto;
}
.sidebar-logo{padding:24px 20px 20px;border-bottom:1px solid var(--border)}
.sidebar-logo .brand{font-size:16px;font-weight:800;letter-spacing:-.5px}
.sidebar-logo .brand span{color:var(--green)}
.sidebar-logo .admin-badge{display:inline-block;margin-top:6px;padding:2px 8px;border-radius:4px;background:rgba(177,79,255,.15);color:var(--purple);font-size:10px;font-weight:700;letter-spacing:1px;border:1px solid rgba(177,79,255,.3)}
.nav-section{padding:16px 12px 8px;font-size:10px;font-weight:700;letter-spacing:1.5px;color:var(--muted);text-transform:uppercase}
.nav-item{display:flex;align-items:center;gap:10px;padding:9px 16px;border-radius:10px;margin:2px 8px;font-size:13px;font-weight:600;color:var(--muted);transition:all .15s;cursor:pointer}
.nav-item:hover{color:#fff;background:rgba(255,255,255,.05)}
.nav-item.active{color:var(--green);background:rgba(0,255,135,.06)}
.nav-item .icon{font-size:15px;width:20px;text-align:center}
.sidebar-footer{margin-top:auto;padding:16px;border-top:1px solid var(--border)}
.sidebar-footer a{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--muted);padding:8px;border-radius:8px;transition:color .15s}
.sidebar-footer a:hover{color:#fff}

/* ── Main ── */
.main{flex:1;overflow-x:hidden}
.topbar{display:flex;align-items:center;justify-content:space-between;padding:0 32px;height:60px;background:var(--bg2);border-bottom:1px solid var(--border);position:sticky;top:0;z-index:10}
.topbar-title{font-size:18px;font-weight:800}
.topbar-user{display:flex;align-items:center;gap:10px;font-size:13px;color:var(--muted)}
.topbar-user strong{color:var(--text)}
.admin-pill{padding:3px 10px;border-radius:20px;background:rgba(177,79,255,.15);color:var(--purple);font-size:11px;font-weight:700;border:1px solid rgba(177,79,255,.3)}
.hamburger{display:none;align-items:center;justify-content:center;width:36px;height:36px;border-radius:8px;border:1px solid var(--border);background:var(--bg3);cursor:pointer;flex-shrink:0}
.hamburger span{display:block;width:16px;height:2px;background:var(--text);position:relative}
.hamburger span::before,.hamburger span::after{content:'';position:absolute;width:16px;height:2px;background:var(--text);left:0}
.hamburger span::before{top:-5px}.hamburger span::after{top:5px}
.sidebar-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.65);z-index:99;backdrop-filter:blur(2px)}
.sidebar-overlay.visible{display:block}

.content{padding:32px}

/* ── Stats ── */
.stats-row{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:14px;margin-bottom:28px}
.stat-card{background:var(--bg2);border:1px solid var(--border);border-radius:12px;padding:16px;cursor:pointer;transition:border-color .2s}
.stat-card:hover{border-color:rgba(255,255,255,.2)}
.stat-card.active-filter{border-color:var(--green)}
.stat-card .label{font-size:10px;font-weight:700;letter-spacing:1px;color:var(--muted);text-transform:uppercase;margin-bottom:8px}
.stat-card .value{font-size:28px;font-weight:800;font-family:var(--font-mono)}
.stat-card.c-all .value{color:var(--text)}
.stat-card.c-pending .value{color:var(--yellow)}
.stat-card.c-published .value{color:var(--green)}
.stat-card.c-cancelled .value{color:var(--muted)}

/* ── Flash ── */
.flash{padding:12px 16px;border-radius:10px;font-size:13px;margin-bottom:18px;display:flex;align-items:center;gap:8px}
.flash.ok{background:rgba(0,255,135,.07);border:1px solid rgba(0,255,135,.2);color:var(--green)}
.flash.err{background:rgba(255,45,111,.07);border:1px solid rgba(255,45,111,.2);color:var(--pink)}

/* ── Toolbar ── */
.toolbar{display:flex;align-items:center;gap:10px;margin-bottom:16px;flex-wrap:wrap}
.btn{display:inline-flex;align-items:center;gap:6px;padding:6px 14px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;border:none;transition:all .15s;font-family:var(--font-head)}
.btn-green{background:rgba(0,255,135,.12);color:var(--green);border:1px solid rgba(0,255,135,.25)}
.btn-green:hover{background:rgba(0,255,135,.22)}
.btn-pink{background:rgba(255,45,111,.1);color:var(--pink);border:1px solid rgba(255,45,111,.2)}
.btn-pink:hover{background:rgba(255,45,111,.2)}
.btn-muted{background:rgba(90,99,128,.12);color:var(--muted);border:1px solid rgba(90,99,128,.2)}
.btn-muted:hover{background:rgba(90,99,128,.22);color:var(--text)}
.bulk-actions{display:flex;gap:8px;align-items:center;margin-left:auto}
.bulk-count{font-size:11px;font-family:var(--font-mono);color:var(--muted)}

/* ── Card ── */
.card{background:var(--bg2);border:1px solid var(--border);border-radius:14px;overflow:hidden}

/* ── Table ── */
.table-wrap{overflow-x:auto}
table{width:100%;border-collapse:collapse}
th{padding:11px 14px;text-align:left;font-size:10px;font-weight:700;letter-spacing:1px;color:var(--muted);text-transform:uppercase;border-bottom:1px solid var(--border);background:var(--bg3)}
td{padding:11px 14px;font-size:13px;border-bottom:1px solid rgba(255,255,255,.04);vertical-align:middle}
tr:last-child td{border-bottom:none}
tr:hover td{background:rgba(255,255,255,.015)}
.th-check{width:36px}
.cb{width:15px;height:15px;cursor:pointer;accent-color:var(--green)}

/* ── Badges ── */
.badge{display:inline-block;padding:2px 8px;border-radius:20px;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px}
.badge-yellow{background:rgba(255,225,77,.1);color:var(--yellow);border:1px solid rgba(255,225,77,.2)}
.badge-green{background:rgba(0,255,135,.1);color:var(--green);border:1px solid rgba(0,255,135,.2)}
.badge-muted{background:rgba(90,99,128,.15);color:var(--muted);border:1px solid rgba(90,99,128,.2)}
.badge-purple{background:rgba(177,79,255,.1);color:var(--purple);border:1px solid rgba(177,79,255,.2)}

/* ── Action buttons in table ── */
.tbl-actions{display:flex;gap:6px;align-items:center}
.tbl-btn{padding:4px 10px;border-radius:6px;font-size:11px;font-weight:700;border:none;cursor:pointer;font-family:var(--font-head);transition:all .15s}
.tbl-btn-approve{background:rgba(0,255,135,.1);color:var(--green);border:1px solid rgba(0,255,135,.2)}
.tbl-btn-approve:hover{background:rgba(0,255,135,.22)}
.tbl-btn-delete{background:rgba(255,45,111,.1);color:var(--pink);border:1px solid rgba(255,45,111,.2)}
.tbl-btn-delete:hover{background:rgba(255,45,111,.22)}

/* ── Schedule time display ── */
.sched-time{font-size:11px;font-family:var(--font-mono);color:#a78bfa}
.sched-ago{font-size:10px;color:var(--muted);margin-top:1px}
.overdue{color:var(--pink)!important}

/* ── Post title ── */
.post-title{font-size:13px;font-weight:700;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.post-desc{font-size:11px;color:var(--muted);margin-top:2px;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}

/* ── Versus badge ── */
.vs-badge{display:inline-flex;align-items:center;gap:3px;font-size:9px;font-weight:700;font-family:var(--font-mono);color:#a78bfa;background:rgba(167,139,250,.1);border:1px solid rgba(167,139,250,.25);border-radius:5px;padding:2px 6px}

/* ── Pagination ── */
.pagination{display:flex;align-items:center;gap:6px;padding:16px;border-top:1px solid var(--border)}
.page-btn{padding:5px 11px;border-radius:7px;font-size:12px;font-weight:700;border:1px solid var(--border);background:var(--bg3);color:var(--muted);cursor:pointer;transition:all .15s;text-decoration:none;display:inline-flex}
.page-btn:hover{color:var(--text);border-color:rgba(255,255,255,.15)}
.page-btn.active{background:rgba(0,255,135,.1);border-color:rgba(0,255,135,.2);color:var(--green)}
.page-info{font-size:11px;font-family:var(--font-mono);color:var(--muted);margin-left:auto}

/* ── Empty ── */
.empty{text-align:center;padding:60px 20px;color:var(--muted)}
.empty .ico{font-size:40px;margin-bottom:12px}

/* ── MOBILE ── */
@media(max-width:768px){
  .hamburger{display:flex}
  .sidebar{position:fixed;top:0;left:0;height:100vh;z-index:100;transform:translateX(-100%);transition:transform .28s;width:260px}
  .sidebar.open{transform:translateX(0)}
  .main{width:100%}
  .topbar{padding:0 16px;gap:12px}
  .content{padding:16px}
  .stats-row{grid-template-columns:repeat(2,1fr)}
  .toolbar{flex-direction:column;align-items:stretch}
  .bulk-actions{margin-left:0}
  table{min-width:700px}
}
</style>
</head>
<body>
<div class="sidebar-overlay"></div>
<div class="layout">

<!-- ── Sidebar ── -->
<aside class="sidebar">
  <div class="sidebar-logo">
    <div class="brand">code<span>Me</span> Admin</div>
    <div class="admin-badge">⚡ ADMIN PANEL</div>
  </div>
  <div class="nav-section">Overview</div>
  <a class="nav-item" href="index.php"><span class="icon">📊</span> Dashboard</a>
  <a class="nav-item" href="analytics.php"><span class="icon">📈</span> Analytics</a>
  <div class="nav-section">Management</div>
  <a class="nav-item" href="users.php"><span class="icon">👥</span> Users</a>
  <a class="nav-item" href="challenges.php"><span class="icon">🎯</span> Challenges</a>
  <a class="nav-item" href="battles.php"><span class="icon">⚔️</span> Battles</a>
  <a class="nav-item active" href="schedule.php"><span class="icon">🗓️</span> Scheduled Posts</a>
  <div class="nav-section">Security</div>
  <a class="nav-item" href="scanner.php"><span class="icon">🛡️</span> File Scanner</a>
  <a class="nav-item" href="logs.php"><span class="icon">📋</span> Admin Logs</a>
  <div class="sidebar-footer">
    <a href="../versus.php">← Back to Site</a>
    <a href="../logout.php" style="margin-top:4px">🚪 Logout</a>
  </div>
</aside>

<!-- ── Main ── -->
<div class="main">
  <div class="topbar">
    <button class="hamburger" aria-label="Toggle menu"><span></span></button>
    <div class="topbar-title">🗓️ Scheduled Posts</div>
    <div class="topbar-user">
      <?= e($user['username']) ?> <span class="admin-pill">ADMIN</span>
    </div>
  </div>

  <div class="content">

    <?php if ($flash): ?>
    <div class="flash <?= $flash[0] ?>">
      <?= $flash[0] === 'ok' ? '✅' : '❌' ?> <?= e($flash[1]) ?>
    </div>
    <?php endif ?>

    <!-- Stats row / filter -->
    <div class="stats-row">
      <?php
      $filterLabels = ['all'=>'All Posts','pending'=>'Pending','published'=>'Published','cancelled'=>'Cancelled'];
      $filterClasses = ['all'=>'c-all','pending'=>'c-pending','published'=>'c-published','cancelled'=>'c-cancelled'];
      foreach ($filterLabels as $f => $label):
        $isActive = $filter === $f;
      ?>
      <a href="?filter=<?= $f ?>" style="text-decoration:none">
        <div class="stat-card <?= $filterClasses[$f] ?> <?= $isActive ? 'active-filter' : '' ?>">
          <div class="label"><?= $label ?></div>
          <div class="value"><?= number_format($stats[$f] ?? 0) ?></div>
        </div>
      </a>
      <?php endforeach ?>
    </div>

    <!-- Bulk actions form -->
    <form method="POST" id="bulkForm">
      <input type="hidden" name="action" id="bulkAction" value="">

      <div class="toolbar">
        <label style="display:flex;align-items:center;gap:8px;font-size:13px;cursor:pointer;color:var(--muted)">
          <input type="checkbox" class="cb" id="selectAll" onchange="toggleAll(this)">
          Select All
        </label>
        <div class="bulk-actions">
          <span class="bulk-count" id="bulkCount">0 selected</span>
          <?php if ($filter === 'pending' || $filter === 'all'): ?>
          <button type="button" class="btn btn-green" onclick="bulkSubmit('bulk_approve')" id="btnBulkApprove" disabled>
            ✅ Approve Selected
          </button>
          <?php endif ?>
          <button type="button" class="btn btn-pink" onclick="bulkSubmit('bulk_delete')" id="btnBulkDelete" disabled>
            🗑️ Delete Selected
          </button>
        </div>
      </div>

      <!-- Table -->
      <div class="card">
        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <th class="th-check"></th>
                <th>Post</th>
                <th>User</th>
                <th>Scheduled At</th>
                <th>Status</th>
                <th>Versus</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
            <?php if (empty($rows)): ?>
              <tr>
                <td colspan="7">
                  <div class="empty">
                    <div class="ico">🗓️</div>
                    No scheduled posts found<?= $filter !== 'all' ? ' with status: '.$filter : '' ?>.
                  </div>
                </td>
              </tr>
            <?php else: foreach ($rows as $row):
              $ts        = strtotime($row['scheduled_at']);
              $isPending = $row['status'] === 'pending';
              $isOverdue = $isPending && $ts < time();
              $timeAgo   = time_ago($ts);
            ?>
              <tr>
                <td><input type="checkbox" class="cb row-cb" name="ids[]" value="<?= $row['id'] ?>" onchange="updateBulkCount()"></td>
                <td>
                  <div class="post-title" title="<?= e($row['title']) ?>"><?= e($row['title']) ?></div>
                  <?php if ($row['description']): ?>
                  <div class="post-desc"><?= e($row['description']) ?></div>
                  <?php endif ?>
                </td>
                <td style="font-size:12px">
                  <strong><?= e($row['username'] ?? '?') ?></strong><br>
                  <span style="color:var(--muted);font-size:10px"><?= e($row['email'] ?? '') ?></span>
                </td>
                <td>
                  <div class="sched-time <?= $isOverdue ? 'overdue' : '' ?>">
                    <?= date('M d, Y', $ts) ?><br>
                    <?= date('H:i', $ts) ?>
                  </div>
                  <div class="sched-ago <?= $isOverdue ? 'overdue' : '' ?>"><?= $isOverdue ? '⚠️ Overdue · ' : '' ?><?= $timeAgo ?></div>
                </td>
                <td>
                  <?php
                  $badgeClass = [
                    'pending'   => 'badge-yellow',
                    'published' => 'badge-green',
                    'cancelled' => 'badge-muted',
                  ][$row['status']] ?? 'badge-muted';
                  ?>
                  <span class="badge <?= $badgeClass ?>"><?= strtoupper($row['status']) ?></span>
                  <?php if ($row['showcase_post_id']): ?>
                  <br><a href="../showcase.php#post-<?= $row['showcase_post_id'] ?>" target="_blank" style="font-size:10px;color:var(--blue);margin-top:4px;display:inline-block">→ View #<?= $row['showcase_post_id'] ?></a>
                  <?php endif ?>
                </td>
                <td>
                  <?php if ($row['allow_versus']): ?>
                  <span class="vs-badge">⚔️ VS</span>
                  <?php else: ?>
                  <span style="font-size:11px;color:var(--muted)">—</span>
                  <?php endif ?>
                </td>
                <td>
                  <div class="tbl-actions">
                    <?php if ($isPending): ?>
                    <form method="POST" style="display:inline" onsubmit="return confirm('Approve and publish this post now?')">
                      <input type="hidden" name="action" value="approve">
                      <input type="hidden" name="id" value="<?= $row['id'] ?>">
                      <button type="submit" class="tbl-btn tbl-btn-approve">✅ Approve</button>
                    </form>
                    <?php endif ?>
                    <form method="POST" style="display:inline" onsubmit="return confirm('Delete this scheduled post permanently?')">
                      <input type="hidden" name="action" value="delete">
                      <input type="hidden" name="id" value="<?= $row['id'] ?>">
                      <button type="submit" class="tbl-btn tbl-btn-delete">🗑️ Delete</button>
                    </form>
                  </div>
                </td>
              </tr>
            <?php endforeach; endif ?>
            </tbody>
          </table>
        </div>

        <!-- Pagination -->
        <?php if ($pages > 1): ?>
        <div class="pagination">
          <?php if ($page > 1): ?>
          <a class="page-btn" href="?filter=<?= $filter ?>&p=<?= $page-1 ?>">← Prev</a>
          <?php endif ?>
          <?php for ($i = max(1,$page-2); $i <= min($pages,$page+2); $i++): ?>
          <a class="page-btn <?= $i === $page ? 'active' : '' ?>" href="?filter=<?= $filter ?>&p=<?= $i ?>"><?= $i ?></a>
          <?php endfor ?>
          <?php if ($page < $pages): ?>
          <a class="page-btn" href="?filter=<?= $filter ?>&p=<?= $page+1 ?>">Next →</a>
          <?php endif ?>
          <span class="page-info">Page <?= $page ?> / <?= $pages ?> · <?= number_format($total) ?> total</span>
        </div>
        <?php endif ?>
      </div>

    </form><!-- /bulkForm -->

  </div><!-- /content -->
</div><!-- /main -->
</div><!-- /layout -->

<script>
// ── Sidebar toggle ────────────────────────────────────────────────────────────
(function(){
  var btn = document.querySelector('.hamburger');
  var sidebar = document.querySelector('.sidebar');
  var overlay = document.querySelector('.sidebar-overlay');
  if (!btn) return;
  function open(){ sidebar.classList.add('open'); overlay.classList.add('visible'); document.body.style.overflow='hidden'; }
  function close(){ sidebar.classList.remove('open'); overlay.classList.remove('visible'); document.body.style.overflow=''; }
  btn.addEventListener('click', function(){ sidebar.classList.contains('open') ? close() : open(); });
  overlay.addEventListener('click', close);
  document.addEventListener('keydown', function(e){ if(e.key==='Escape') close(); });
})();

// ── Checkbox / select-all ─────────────────────────────────────────────────────
function toggleAll(master) {
  document.querySelectorAll('.row-cb').forEach(function(cb){ cb.checked = master.checked; });
  updateBulkCount();
}

function updateBulkCount() {
  var checked = document.querySelectorAll('.row-cb:checked').length;
  document.getElementById('bulkCount').textContent = checked + ' selected';
  var hasChecked = checked > 0;
  var btnApprove = document.getElementById('btnBulkApprove');
  var btnDelete  = document.getElementById('btnBulkDelete');
  if (btnApprove) btnApprove.disabled = !hasChecked;
  if (btnDelete)  btnDelete.disabled  = !hasChecked;
  // Sync master checkbox indeterminate state
  var total = document.querySelectorAll('.row-cb').length;
  var master = document.getElementById('selectAll');
  if (master) {
    master.indeterminate = (checked > 0 && checked < total);
    master.checked = (total > 0 && checked === total);
  }
}

function bulkSubmit(action) {
  var checked = document.querySelectorAll('.row-cb:checked').length;
  if (checked === 0) { alert('No posts selected.'); return; }
  var confirmMsg = action === 'bulk_approve'
    ? 'Approve and publish ' + checked + ' post(s) now?'
    : 'Permanently delete ' + checked + ' post(s)? This cannot be undone.';
  if (!confirm(confirmMsg)) return;
  document.getElementById('bulkAction').value = action;
  document.getElementById('bulkForm').submit();
}
</script>
</body>
</html>
<?php
// ── Helper ────────────────────────────────────────────────────────────────────
function time_ago(int $ts): string {
    $diff = abs(time() - $ts);
    if ($diff < 60)          return $diff . 's ago';
    if ($diff < 3600)        return floor($diff/60) . 'm ago';
    if ($diff < 86400)       return floor($diff/3600) . 'h ago';
    return floor($diff/86400) . 'd ago';
}
