<?php
require_once '../includes/config.php';
require_once 'guard.php';
requireAdmin();

$db = db();

// ── Stats ────────────────────────────────────────────────
$stats = [];
$stats['total_users']    = $db->query('SELECT COUNT(*) FROM users')->fetchColumn();
$stats['banned_users']   = $db->query('SELECT COUNT(*) FROM users WHERE is_banned=1')->fetchColumn();
$stats['admin_users']    = $db->query('SELECT COUNT(*) FROM users WHERE role=1')->fetchColumn();
$stats['total_rooms']    = $db->query('SELECT COUNT(*) FROM rooms')->fetchColumn();
$stats['active_rooms']   = $db->query("SELECT COUNT(*) FROM rooms WHERE status='active'")->fetchColumn();
$stats['finished_rooms'] = $db->query("SELECT COUNT(*) FROM rooms WHERE status='finished'")->fetchColumn();
$stats['total_challenges']= $db->query('SELECT COUNT(*) FROM challenges')->fetchColumn();
$stats['total_score']    = $db->query('SELECT SUM(total_score) FROM users')->fetchColumn() ?: 0;

// ── Recent users ─────────────────────────────────────────
$recentUsers = $db->query(
    'SELECT id, username, email, wins, losses, total_score, role, is_banned, created_at
     FROM users ORDER BY created_at DESC LIMIT 8'
)->fetchAll();

// ── Recent battles ───────────────────────────────────────
$recentBattles = $db->query(
    'SELECT r.id, r.code, r.status, r.created_at,
            h.username AS host, g.username AS guest,
            w.username AS winner
     FROM rooms r
     LEFT JOIN users h ON h.id = r.host_id
     LEFT JOIN users g ON g.id = r.guest_id
     LEFT JOIN users w ON w.id = r.winner_id
     ORDER BY r.created_at DESC LIMIT 8'
)->fetchAll();

// ── Top players ──────────────────────────────────────────
$topPlayers = $db->query(
    'SELECT id, username, wins, losses, total_score FROM users ORDER BY total_score DESC LIMIT 5'
)->fetchAll();

// ── Signups last 7 days ──────────────────────────────────
$signups7 = $db->query(
    "SELECT DATE(created_at) as d, COUNT(*) as cnt
     FROM users
     WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
     GROUP BY DATE(created_at) ORDER BY d ASC"
)->fetchAll(PDO::FETCH_KEY_PAIR);

// ── Recent admin log ─────────────────────────────────────
$adminLogs = $db->query(
    'SELECT al.*, u.username FROM admin_logs al
     LEFT JOIN users u ON u.id=al.admin_id
     ORDER BY al.created_at DESC LIMIT 10'
)->fetchAll();

$user = auth();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin — codeMe Versus</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;600;800&display=swap" rel="stylesheet">
<style>
:root{
  --green:#00ff87;--pink:#ff2d6f;--blue:#00c8ff;--yellow:#ffe14d;
  --orange:#ff8c42;--purple:#b14fff;
  --bg:#080b12;--bg2:#0e1320;--bg3:#141b2d;--bg4:#1a2240;
  --border:rgba(255,255,255,0.07);--text:#e8eaf0;--muted:#5a6380;
  --font-head:'Syne',sans-serif;--font-mono:'Space Mono',monospace;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{min-height:100%;background:var(--bg);color:var(--text);font-family:var(--font-head)}
a{color:inherit;text-decoration:none}
button,input,select,textarea{font-family:inherit}

/* ── Layout ── */
.layout{display:flex;min-height:100vh}

/* ── Sidebar ── */
.sidebar{
  width:220px;flex-shrink:0;background:var(--bg2);
  border-right:1px solid var(--border);
  display:flex;flex-direction:column;
  position:sticky;top:0;height:100vh;overflow-y:auto;
}
.sidebar-logo{padding:24px 20px 20px;border-bottom:1px solid var(--border)}
.sidebar-logo .brand{font-size:16px;font-weight:800;letter-spacing:-.5px}
.sidebar-logo .brand span{color:var(--green)}
.sidebar-logo .admin-badge{
  display:inline-block;margin-top:6px;padding:2px 8px;border-radius:4px;
  background:rgba(177,79,255,.15);color:var(--purple);
  font-size:10px;font-weight:700;letter-spacing:1px;border:1px solid rgba(177,79,255,.3)
}
.nav-section{padding:16px 12px 8px;font-size:10px;font-weight:700;letter-spacing:1.5px;color:var(--muted);text-transform:uppercase}
.nav-item{
  display:flex;align-items:center;gap:10px;
  padding:9px 16px;border-radius:10px;margin:2px 8px;
  font-size:13px;font-weight:600;color:var(--muted);
  transition:all .15s;cursor:pointer;
}
.nav-item:hover{color:#fff;background:rgba(255,255,255,.05)}
.nav-item.active{color:var(--green);background:rgba(0,255,135,.06)}
.nav-item .icon{font-size:15px;width:20px;text-align:center}
.sidebar-footer{margin-top:auto;padding:16px;border-top:1px solid var(--border)}
.sidebar-footer a{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--muted);padding:8px;border-radius:8px;transition:color .15s}
.sidebar-footer a:hover{color:#fff}

/* ── Main ── */
.main{flex:1;overflow-x:hidden}
.topbar{
  display:flex;align-items:center;justify-content:space-between;
  padding:0 32px;height:60px;background:var(--bg2);
  border-bottom:1px solid var(--border);position:sticky;top:0;z-index:10
}
.topbar-title{font-size:18px;font-weight:800}
.topbar-user{display:flex;align-items:center;gap:10px;font-size:13px;color:var(--muted)}
.topbar-user strong{color:var(--text)}
.admin-pill{padding:3px 10px;border-radius:20px;background:rgba(177,79,255,.15);color:var(--purple);font-size:11px;font-weight:700;border:1px solid rgba(177,79,255,.3)}

.content{padding:32px}

/* ── Stats Grid ── */
.stats-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:16px;margin-bottom:32px}
.stat-card{
  background:var(--bg2);border:1px solid var(--border);border-radius:14px;
  padding:20px;position:relative;overflow:hidden;transition:transform .2s;
}
.stat-card:hover{transform:translateY(-2px)}
.stat-card::before{
  content:'';position:absolute;inset:0;
  background:radial-gradient(circle at top right, var(--accent-color,transparent) 0%, transparent 70%);
  opacity:.06;pointer-events:none
}
.stat-card .label{font-size:11px;font-weight:600;color:var(--muted);text-transform:uppercase;letter-spacing:.8px;margin-bottom:12px}
.stat-card .value{font-size:32px;font-weight:800;font-family:var(--font-mono);color:var(--text);line-height:1}
.stat-card .sub{font-size:11px;color:var(--muted);margin-top:6px}
.stat-card.green{--accent-color:var(--green)} .stat-card.green .value{color:var(--green)}
.stat-card.pink{--accent-color:var(--pink)} .stat-card.pink .value{color:var(--pink)}
.stat-card.blue{--accent-color:var(--blue)} .stat-card.blue .value{color:var(--blue)}
.stat-card.yellow{--accent-color:var(--yellow)} .stat-card.yellow .value{color:var(--yellow)}
.stat-card.orange{--accent-color:var(--orange)} .stat-card.orange .value{color:var(--orange)}
.stat-card.purple{--accent-color:var(--purple)} .stat-card.purple .value{color:var(--purple)}

/* ── Section ── */
.section{margin-bottom:32px}
.section-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px}
.section-title{font-size:15px;font-weight:800;letter-spacing:-.3px}
.section-link{font-size:12px;color:var(--green);font-weight:600}

/* ── Card ── */
.card{background:var(--bg2);border:1px solid var(--border);border-radius:14px;overflow:hidden}

/* ── Table ── */
.table-wrap{overflow-x:auto}
table{width:100%;border-collapse:collapse}
th{padding:11px 16px;text-align:left;font-size:10px;font-weight:700;letter-spacing:1px;
   color:var(--muted);text-transform:uppercase;border-bottom:1px solid var(--border);background:var(--bg3)}
td{padding:12px 16px;font-size:13px;border-bottom:1px solid rgba(255,255,255,.04)}
tr:last-child td{border-bottom:none}
tr:hover td{background:rgba(255,255,255,.02)}

/* ── Badges ── */
.badge{display:inline-block;padding:2px 8px;border-radius:20px;font-size:11px;font-weight:700}
.badge-green{background:rgba(0,255,135,.1);color:var(--green);border:1px solid rgba(0,255,135,.2)}
.badge-pink{background:rgba(255,45,111,.1);color:var(--pink);border:1px solid rgba(255,45,111,.2)}
.badge-blue{background:rgba(0,200,255,.1);color:var(--blue);border:1px solid rgba(0,200,255,.2)}
.badge-purple{background:rgba(177,79,255,.1);color:var(--purple);border:1px solid rgba(177,79,255,.2)}
.badge-muted{background:rgba(90,99,128,.15);color:var(--muted);border:1px solid rgba(90,99,128,.2)}
.badge-yellow{background:rgba(255,225,77,.1);color:var(--yellow);border:1px solid rgba(255,225,77,.2)}

/* ── 2-col row ── */
.two-col{display:grid;grid-template-columns:1fr 1fr;gap:20px}
@media(max-width:900px){.two-col{grid-template-columns:1fr}}

/* ── Chart bar ── */
.bar-chart{padding:20px}
.bar-row{display:flex;align-items:center;gap:12px;margin-bottom:10px;font-size:12px}
.bar-label{width:80px;color:var(--muted);text-align:right;flex-shrink:0}
.bar-track{flex:1;height:8px;background:var(--bg3);border-radius:4px;overflow:hidden}
.bar-fill{height:100%;border-radius:4px;background:var(--green);transition:width .6s ease}
.bar-val{width:30px;color:var(--text);font-family:var(--font-mono);font-weight:700}

/* ── Alert ── */
.alert{padding:12px 16px;border-radius:10px;font-size:13px;margin-bottom:16px;display:flex;align-items:center;gap:10px}
.alert-info{background:rgba(0,200,255,.08);border:1px solid rgba(0,200,255,.2);color:var(--blue)}

/* ── RESPONSIVE / MOBILE ── */
.hamburger{
  display:none;align-items:center;justify-content:center;
  width:36px;height:36px;border-radius:8px;border:1px solid var(--border);
  background:var(--bg3);cursor:pointer;flex-shrink:0;
  transition:background .15s;
}
.hamburger:hover{background:rgba(255,255,255,.08)}
.hamburger span{display:block;width:16px;height:2px;background:var(--text);
  position:relative;transition:background .2s}
.hamburger span::before,.hamburger span::after{
  content:'';position:absolute;width:16px;height:2px;background:var(--text);
  left:0;transition:transform .25s,top .25s,opacity .25s}
.hamburger span::before{top:-5px}
.hamburger span::after{top:5px}
.hamburger.open span{background:transparent}
.hamburger.open span::before{top:0;transform:rotate(45deg)}
.hamburger.open span::after{top:0;transform:rotate(-45deg)}

.sidebar-overlay{
  display:none;position:fixed;inset:0;background:rgba(0,0,0,.65);
  z-index:99;backdrop-filter:blur(2px);
}
.sidebar-overlay.visible{display:block}

@media(max-width:768px){
  .hamburger{display:flex}

  .sidebar{
    position:fixed;top:0;left:0;height:100vh;z-index:100;
    transform:translateX(-100%);transition:transform .28s cubic-bezier(.4,0,.2,1);
    width:260px;
  }
  .sidebar.open{transform:translateX(0)}

  .main{width:100%;min-width:0}

  .topbar{padding:0 16px;gap:12px}
  .topbar-title{font-size:15px}
  .topbar-user{font-size:11px;gap:6px}

  .content{padding:16px}

  .stats-grid{grid-template-columns:repeat(2,1fr);gap:12px;margin-bottom:20px}
  .stat-card .value{font-size:24px}

  .two-col{grid-template-columns:1fr !important;gap:16px}

  .table-wrap{overflow-x:auto;-webkit-overflow-scrolling:touch}
  table{min-width:480px}
  th,td{padding:9px 12px;font-size:12px}

  .toolbar{flex-direction:column;align-items:stretch}
  .search-box{width:100%}
  .filter-tabs{overflow-x:auto;flex-wrap:nowrap;padding-bottom:2px}

  .btn{padding:4px 8px;font-size:10px}

  .pagination{flex-wrap:wrap;gap:6px}

  /* analytics / chart responsive */
  .chart-row{flex-direction:column}
  .chart-wrap{min-width:0 !important;width:100% !important}
}

@media(max-width:400px){
  .stats-grid{grid-template-columns:1fr}
  .topbar-user .admin-pill{display:none}
}

</style>
</head>
<body>
<div class="sidebar-overlay"></div>
<div class="layout">

<!-- ── Sidebar ── -->
<aside class="sidebar">
  <div class="sidebar-logo">
    <div class="brand">code<span>Me</span> Admin</div>
    <div class="admin-badge">⚡ ADMIN PANEL</div>
  </div>

  <div class="nav-section">Overview</div>
  <a class="nav-item active" href="index.php"><span class="icon">📊</span> Dashboard</a>
  <a class="nav-item" href="analytics.php"><span class="icon">📈</span> Analytics</a>

  <div class="nav-section">Management</div>
  <a class="nav-item" href="users.php"><span class="icon">👥</span> Users</a>
  <a class="nav-item" href="challenges.php"><span class="icon">🎯</span> Challenges</a>
  <a class="nav-item" href="battles.php"><span class="icon">⚔️</span> Battles</a>
  <a class="nav-item" href="schedule.php"><span class="icon">🗓️</span> Scheduled Posts</a>

  <div class="nav-section">Security</div>
  <a class="nav-item" href="scanner.php"><span class="icon">🛡️</span> File Scanner</a>
  <a class="nav-item" href="logs.php"><span class="icon">📋</span> Admin Logs</a>

  <div class="sidebar-footer">
    <a href="../versus.php">← Back to Site</a>
    <a href="../logout.php" style="margin-top:4px">🚪 Logout</a>
  </div>
</aside>

<!-- ── Main ── -->
<div class="main">
  <div class="topbar">
  <button class="hamburger" aria-label="Toggle menu"><span></span></button>
    <div class="topbar-title">Dashboard</div>
    <div class="topbar-user">
      Logged in as <strong><?= e($user['username']) ?></strong>
      <span class="admin-pill">ADMIN</span>
    </div>
  </div>

  <div class="content">

    <!-- Stats -->
    <div class="stats-grid">
      <div class="stat-card green">
        <div class="label">Total Users</div>
        <div class="value"><?= number_format($stats['total_users']) ?></div>
        <div class="sub"><?= $stats['admin_users'] ?> admins</div>
      </div>
      <div class="stat-card pink">
        <div class="label">Banned</div>
        <div class="value"><?= $stats['banned_users'] ?></div>
        <div class="sub">accounts suspended</div>
      </div>
      <div class="stat-card blue">
        <div class="label">Total Battles</div>
        <div class="value"><?= number_format($stats['total_rooms']) ?></div>
        <div class="sub"><?= $stats['active_rooms'] ?> active now</div>
      </div>
      <div class="stat-card yellow">
        <div class="label">Finished</div>
        <div class="value"><?= number_format($stats['finished_rooms']) ?></div>
        <div class="sub">completed rooms</div>
      </div>
      <div class="stat-card orange">
        <div class="label">Challenges</div>
        <div class="value"><?= $stats['total_challenges'] ?></div>
        <div class="sub">in the pool</div>
      </div>
      <div class="stat-card purple">
        <div class="label">Total Score</div>
        <div class="value"><?= number_format($stats['total_score']) ?></div>
        <div class="sub">across all players</div>
      </div>
    </div>

    <div class="two-col">
      <!-- Recent users -->
      <div class="section">
        <div class="section-header">
          <div class="section-title">Recent Users</div>
          <a class="section-link" href="users.php">View all →</a>
        </div>
        <div class="card">
          <div class="table-wrap">
            <table>
              <tr><th>User</th><th>W/L</th><th>Status</th></tr>
              <?php foreach($recentUsers as $u): ?>
              <tr>
                <td>
                  <a href="users.php?id=<?= $u['id'] ?>" style="color:var(--text)">
                    <?= e($u['username']) ?>
                  </a><br>
                  <small style="color:var(--muted)"><?= e($u['email']) ?></small>
                </td>
                <td style="font-family:var(--font-mono);font-size:12px">
                  <span style="color:var(--green)"><?= $u['wins'] ?>W</span>
                  <span style="color:var(--muted)"> / </span>
                  <span style="color:var(--pink)"><?= $u['losses'] ?>L</span>
                </td>
                <td>
                  <?php if($u['is_banned']): ?>
                    <span class="badge badge-pink">BANNED</span>
                  <?php elseif($u['role']==1): ?>
                    <span class="badge badge-purple">ADMIN</span>
                  <?php else: ?>
                    <span class="badge badge-green">OK</span>
                  <?php endif ?>
                </td>
              </tr>
              <?php endforeach ?>
            </table>
          </div>
        </div>
      </div>

      <!-- Top players -->
      <div class="section">
        <div class="section-header">
          <div class="section-title">Top Players</div>
          <a class="section-link" href="analytics.php">Analytics →</a>
        </div>
        <div class="card">
          <?php
          $maxScore = max(1, array_column($topPlayers,'total_score')[0] ?? 1);
          ?>
          <div class="bar-chart">
            <?php foreach($topPlayers as $i=>$p): ?>
            <div class="bar-row">
              <div class="bar-label"><?= e($p['username']) ?></div>
              <div class="bar-track">
                <div class="bar-fill" style="width:<?= round($p['total_score']/$maxScore*100) ?>%;background:<?= ['var(--green)','var(--blue)','var(--yellow)','var(--orange)','var(--purple)'][$i] ?>"></div>
              </div>
              <div class="bar-val"><?= $p['total_score'] ?></div>
            </div>
            <?php endforeach ?>
          </div>
        </div>
      </div>
    </div>

    <div class="two-col">
      <!-- Recent battles -->
      <div class="section">
        <div class="section-header">
          <div class="section-title">Recent Battles</div>
          <a class="section-link" href="battles.php">View all →</a>
        </div>
        <div class="card">
          <div class="table-wrap">
            <table>
              <tr><th>Code</th><th>Players</th><th>Status</th></tr>
              <?php foreach($recentBattles as $b): ?>
              <tr>
                <td style="font-family:var(--font-mono);font-size:12px;color:var(--blue)"><?= e($b['code']) ?></td>
                <td style="font-size:12px">
                  <?= e($b['host'] ?? '?') ?> vs <?= e($b['guest'] ?? '…') ?>
                </td>
                <td>
                  <?php
                  $cls = ['waiting'=>'badge-muted','active'=>'badge-blue','finished'=>'badge-green'][$b['status']] ?? 'badge-muted';
                  ?>
                  <span class="badge <?= $cls ?>"><?= strtoupper($b['status']) ?></span>
                </td>
              </tr>
              <?php endforeach ?>
            </table>
          </div>
        </div>
      </div>

      <!-- Admin log -->
      <div class="section">
        <div class="section-header">
          <div class="section-title">Admin Activity</div>
          <a class="section-link" href="logs.php">Full log →</a>
        </div>
        <div class="card">
          <div class="table-wrap">
            <table>
              <tr><th>Admin</th><th>Action</th><th>When</th></tr>
              <?php if(empty($adminLogs)): ?>
              <tr><td colspan="3" style="color:var(--muted);text-align:center;padding:20px">No activity yet</td></tr>
              <?php else: foreach($adminLogs as $log): ?>
              <tr>
                <td style="font-size:12px"><?= e($log['username'] ?? '?') ?></td>
                <td style="font-size:12px"><?= e($log['action']) ?><?php if($log['target_id']): ?> #<?= $log['target_id'] ?><?php endif ?></td>
                <td style="font-size:11px;color:var(--muted)"><?= date('m/d H:i', strtotime($log['created_at'])) ?></td>
              </tr>
              <?php endforeach; endif ?>
            </table>
          </div>
        </div>
      </div>
    </div>

  </div><!-- /content -->
</div><!-- /main -->
</div><!-- /layout -->
<script>
(function(){
  var btn     = document.querySelector('.hamburger');
  var sidebar = document.querySelector('.sidebar');
  var overlay = document.querySelector('.sidebar-overlay');
  if (!btn || !sidebar || !overlay) return;

  function openMenu() {
    sidebar.classList.add('open');
    overlay.classList.add('visible');
    btn.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  function closeMenu() {
    sidebar.classList.remove('open');
    overlay.classList.remove('visible');
    btn.classList.remove('open');
    document.body.style.overflow = '';
  }

  btn.addEventListener('click', function() {
    sidebar.classList.contains('open') ? closeMenu() : openMenu();
  });
  overlay.addEventListener('click', closeMenu);
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeMenu();
  });
})();
</script>
</body>
</html>
