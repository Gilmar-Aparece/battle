<?php
require_once '../includes/config.php';
require_once 'guard.php';
requireAdmin();

$db  = db();
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $cid    = (int)($_POST['chal_id'] ?? 0);

    if ($action === 'delete' && $cid) {
        $db->prepare('DELETE FROM challenges WHERE id=?')->execute([$cid]);
        adminLog('DELETE_CHALLENGE', 'challenge', $cid);
        $msg = ['ok', 'Challenge deleted.'];
    } elseif ($action === 'set_difficulty' && $cid) {
        $diff = $_POST['difficulty'] ?? 'medium';
        if (in_array($diff, ['easy','medium','hard'])) {
            $db->prepare('UPDATE challenges SET difficulty=? WHERE id=?')->execute([$diff, $cid]);
            adminLog('SET_DIFFICULTY', 'challenge', $cid, $diff);
            $msg = ['ok', 'Difficulty updated.'];
        }
    }
}

$challenges = $db->query(
    'SELECT c.*, u.username AS creator,
     (SELECT COUNT(*) FROM rooms WHERE challenge_id=c.id) AS uses
     FROM challenges c
     LEFT JOIN users u ON u.id=c.created_by
     ORDER BY c.created_at DESC'
)->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Challenges — Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;600;800&display=swap" rel="stylesheet">
<style>
:root{--green:#00ff87;--pink:#ff2d6f;--blue:#00c8ff;--yellow:#ffe14d;--orange:#ff8c42;--purple:#b14fff;--bg:#080b12;--bg2:#0e1320;--bg3:#141b2d;--border:rgba(255,255,255,0.07);--text:#e8eaf0;--muted:#5a6380;--font-head:'Syne',sans-serif;--font-mono:'Space Mono',monospace}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{min-height:100%;background:var(--bg);color:var(--text);font-family:var(--font-head)}
a{color:inherit;text-decoration:none}
button,select{font-family:inherit}
.layout{display:flex;min-height:100vh}
.sidebar{width:220px;flex-shrink:0;background:var(--bg2);border-right:1px solid var(--border);display:flex;flex-direction:column;position:sticky;top:0;height:100vh;overflow-y:auto}
.sidebar-logo{padding:24px 20px 20px;border-bottom:1px solid var(--border)}
.sidebar-logo .brand{font-size:16px;font-weight:800}
.sidebar-logo .brand span{color:var(--green)}
.admin-badge{display:inline-block;margin-top:6px;padding:2px 8px;border-radius:4px;background:rgba(177,79,255,.15);color:var(--purple);font-size:10px;font-weight:700;letter-spacing:1px;border:1px solid rgba(177,79,255,.3)}
.nav-section{padding:16px 12px 8px;font-size:10px;font-weight:700;letter-spacing:1.5px;color:var(--muted);text-transform:uppercase}
.nav-item{display:flex;align-items:center;gap:10px;padding:9px 16px;border-radius:10px;margin:2px 8px;font-size:13px;font-weight:600;color:var(--muted);transition:all .15s}
.nav-item:hover{color:#fff;background:rgba(255,255,255,.05)}
.nav-item.active{color:var(--green);background:rgba(0,255,135,.06)}
.nav-item .icon{font-size:15px;width:20px;text-align:center}
.sidebar-footer{margin-top:auto;padding:16px;border-top:1px solid var(--border)}
.sidebar-footer a{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--muted);padding:8px;border-radius:8px;transition:color .15s}
.sidebar-footer a:hover{color:#fff}
.main{flex:1}
.topbar{display:flex;align-items:center;padding:0 32px;height:60px;background:var(--bg2);border-bottom:1px solid var(--border);position:sticky;top:0;z-index:10}
.topbar-title{font-size:18px;font-weight:800}
.content{padding:32px}
.card{background:var(--bg2);border:1px solid var(--border);border-radius:14px;overflow:hidden}
table{width:100%;border-collapse:collapse}
th{padding:11px 16px;text-align:left;font-size:10px;font-weight:700;letter-spacing:1px;color:var(--muted);text-transform:uppercase;border-bottom:1px solid var(--border);background:var(--bg3)}
td{padding:11px 16px;font-size:13px;border-bottom:1px solid rgba(255,255,255,.04);vertical-align:middle}
tr:last-child td{border-bottom:none}
.badge{display:inline-block;padding:3px 9px;border-radius:20px;font-size:11px;font-weight:700}
.badge-easy{background:rgba(0,255,135,.1);color:var(--green);border:1px solid rgba(0,255,135,.2)}
.badge-medium{background:rgba(255,225,77,.1);color:var(--yellow);border:1px solid rgba(255,225,77,.2)}
.badge-hard{background:rgba(255,45,111,.1);color:var(--pink);border:1px solid rgba(255,45,111,.2)}
.btn{padding:6px 14px;border-radius:8px;border:none;font-size:12px;font-weight:700;cursor:pointer;transition:all .15s}
.btn-del{background:rgba(255,45,111,.08);color:#ff6b8a;border:1px solid rgba(255,45,111,.15)}
.btn-del:hover{background:rgba(255,45,111,.2)}
select.diff-sel{padding:5px 10px;border-radius:7px;border:1px solid var(--border);background:var(--bg3);color:var(--text);font-size:12px;cursor:pointer}
.msg{padding:12px 16px;border-radius:10px;margin-bottom:16px;font-size:13px}
.msg-ok{background:rgba(0,255,135,.08);border:1px solid rgba(0,255,135,.2);color:var(--green)}
.table-wrap{overflow-x:auto}

/* ── RESPONSIVE / MOBILE ── */
.hamburger{
  display:none;align-items:center;justify-content:center;
  width:36px;height:36px;border-radius:8px;border:1px solid var(--border);
  background:var(--bg3);cursor:pointer;flex-shrink:0;
  transition:background .15s;
}
.hamburger:hover{background:rgba(255,255,255,.08)}
.hamburger span{display:block;width:16px;height:2px;background:var(--text);
  position:relative;transition:background .2s}
.hamburger span::before,.hamburger span::after{
  content:'';position:absolute;width:16px;height:2px;background:var(--text);
  left:0;transition:transform .25s,top .25s,opacity .25s}
.hamburger span::before{top:-5px}
.hamburger span::after{top:5px}
.hamburger.open span{background:transparent}
.hamburger.open span::before{top:0;transform:rotate(45deg)}
.hamburger.open span::after{top:0;transform:rotate(-45deg)}

.sidebar-overlay{
  display:none;position:fixed;inset:0;background:rgba(0,0,0,.65);
  z-index:99;backdrop-filter:blur(2px);
}
.sidebar-overlay.visible{display:block}

@media(max-width:768px){
  .hamburger{display:flex}

  .sidebar{
    position:fixed;top:0;left:0;height:100vh;z-index:100;
    transform:translateX(-100%);transition:transform .28s cubic-bezier(.4,0,.2,1);
    width:260px;
  }
  .sidebar.open{transform:translateX(0)}

  .main{width:100%;min-width:0}

  .topbar{padding:0 16px;gap:12px}
  .topbar-title{font-size:15px}
  .topbar-user{font-size:11px;gap:6px}

  .content{padding:16px}

  .stats-grid{grid-template-columns:repeat(2,1fr);gap:12px;margin-bottom:20px}
  .stat-card .value{font-size:24px}

  .two-col{grid-template-columns:1fr !important;gap:16px}

  .table-wrap{overflow-x:auto;-webkit-overflow-scrolling:touch}
  table{min-width:480px}
  th,td{padding:9px 12px;font-size:12px}

  .toolbar{flex-direction:column;align-items:stretch}
  .search-box{width:100%}
  .filter-tabs{overflow-x:auto;flex-wrap:nowrap;padding-bottom:2px}

  .btn{padding:4px 8px;font-size:10px}

  .pagination{flex-wrap:wrap;gap:6px}

  /* analytics / chart responsive */
  .chart-row{flex-direction:column}
  .chart-wrap{min-width:0 !important;width:100% !important}
}

@media(max-width:400px){
  .stats-grid{grid-template-columns:1fr}
  .topbar-user .admin-pill{display:none}
}

</style>
</head>
<body>
<div class="sidebar-overlay"></div>
<div class="layout">
<aside class="sidebar">
  <div class="sidebar-logo">
    <div class="brand">code<span>Me</span> Admin</div>
    <div class="admin-badge">⚡ ADMIN PANEL</div>
  </div>
  <div class="nav-section">Overview</div>
  <a class="nav-item" href="index.php"><span class="icon">📊</span> Dashboard</a>
  <a class="nav-item" href="analytics.php"><span class="icon">📈</span> Analytics</a>
  <div class="nav-section">Management</div>
  <a class="nav-item" href="users.php"><span class="icon">👥</span> Users</a>
  <a class="nav-item active" href="challenges.php"><span class="icon">🎯</span> Challenges</a>
  <a class="nav-item" href="battles.php"><span class="icon">⚔️</span> Battles</a>
  <div class="nav-section">Security</div>
  <a class="nav-item" href="scanner.php"><span class="icon">🛡️</span> File Scanner</a>
  <a class="nav-item" href="logs.php"><span class="icon">📋</span> Admin Logs</a>
  <div class="sidebar-footer">
    <a href="../versus.php">← Back to Site</a>
    <a href="../logout.php" style="margin-top:4px">🚪 Logout</a>
  </div>
</aside>
<div class="main">
  <div class="topbar">
  <button class="hamburger" aria-label="Toggle menu"><span></span></button>
  <div class="topbar-title">Challenges (<?= count($challenges) ?>)</div></div>
  <div class="content">
    <?php if($msg): ?>
    <div class="msg msg-ok"><?= $msg[1] ?></div>
    <?php endif ?>
    <div class="card">
      <div class="table-wrap">
        <table>
          <tr><th>ID</th><th>Title</th><th>Creator</th><th>Difficulty</th><th>Uses</th><th>Created</th><th>Actions</th></tr>
          <?php foreach($challenges as $c): ?>
          <tr>
            <td style="color:var(--muted);font-family:var(--font-mono);font-size:11px"><?= $c['id'] ?></td>
            <td><strong><?= e($c['title']) ?></strong>
              <?php if($c['target_image']): ?>
              <br><small style="color:var(--muted)">Has image</small>
              <?php endif ?>
            </td>
            <td><?= e($c['creator'] ?? 'Unknown') ?></td>
            <td>
              <form method="POST" style="display:inline-flex;align-items:center;gap:6px">
                <input type="hidden" name="action" value="set_difficulty">
                <input type="hidden" name="chal_id" value="<?= $c['id'] ?>">
                <select name="difficulty" class="diff-sel" onchange="this.form.submit()">
                  <?php foreach(['easy','medium','hard'] as $d): ?>
                  <option value="<?= $d ?>" <?= $c['difficulty']===$d?'selected':'' ?>><?= ucfirst($d) ?></option>
                  <?php endforeach ?>
                </select>
              </form>
            </td>
            <td style="font-family:var(--font-mono);color:var(--blue)"><?= $c['uses'] ?></td>
            <td style="font-size:11px;color:var(--muted)"><?= date('Y-m-d', strtotime($c['created_at'])) ?></td>
            <td>
              <form method="POST" style="display:inline">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="chal_id" value="<?= $c['id'] ?>">
                <button class="btn btn-del" onclick="return confirm('Delete challenge &quot;<?= e($c['title']) ?>&quot;? This cannot be undone.')">Delete</button>
              </form>
            </td>
          </tr>
          <?php endforeach ?>
        </table>
      </div>
    </div>
  </div>
</div>
</div>
<script>
(function(){
  var btn     = document.querySelector('.hamburger');
  var sidebar = document.querySelector('.sidebar');
  var overlay = document.querySelector('.sidebar-overlay');
  if (!btn || !sidebar || !overlay) return;

  function openMenu() {
    sidebar.classList.add('open');
    overlay.classList.add('visible');
    btn.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  function closeMenu() {
    sidebar.classList.remove('open');
    overlay.classList.remove('visible');
    btn.classList.remove('open');
    document.body.style.overflow = '';
  }

  btn.addEventListener('click', function() {
    sidebar.classList.contains('open') ? closeMenu() : openMenu();
  });
  overlay.addEventListener('click', closeMenu);
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeMenu();
  });
})();
</script>
</body>
</html>
