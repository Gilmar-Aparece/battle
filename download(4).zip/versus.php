<?php
require_once 'includes/config.php';
require_once 'includes/layout.php';
requireLogin();

$user = auth();

// ── Safe column check helper ──────────────────────────────────────────
function columnExists(string $table, string $col): bool {
  try {
    $r = db()->query("SHOW COLUMNS FROM `{$table}` LIKE '{$col}'")->fetch();
    return (bool)$r;
  } catch (Exception $e) { return false; }
}

// ── Safe auto-migration (silently skips if ALTER not permitted) ───────
if (!columnExists('rooms', 'room_mode')) {
  try { db()->exec("ALTER TABLE `rooms` ADD COLUMN `room_mode` enum('1v1','open') NOT NULL DEFAULT '1v1'"); }
  catch (Exception $e) { /* ALTER not permitted on this host — run migration.sql manually */ }
}
if (!columnExists('rooms', 'max_players')) {
  try { db()->exec("ALTER TABLE `rooms` ADD COLUMN `max_players` tinyint(1) NOT NULL DEFAULT 2"); }
  catch (Exception $e) { /* ALTER not permitted on this host — run migration.sql manually */ }
}

// ── Handle challenge creation ──────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'create_challenge') {
  $title      = trim($_POST['title'] ?? '');
  $desc       = trim($_POST['description'] ?? '');
  $targetHtml = trim($_POST['target_html'] ?? '');
  $targetCss  = trim($_POST['target_css'] ?? '');
  $difficulty = in_array($_POST['difficulty'] ?? '', ['easy','medium','hard']) ? $_POST['difficulty'] : 'medium';

  if ($title && $desc) {
    $imagePath = null;
    if (!empty($_FILES['target_image']['tmp_name'])) {
      $ext = strtolower(pathinfo($_FILES['target_image']['name'], PATHINFO_EXTENSION));
      if (in_array($ext, ['png','jpg','jpeg','gif','webp'])) {
        $uploadDir = 'assets/challenges/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
        $filename = uniqid('ch_', true).'.'.$ext;
        if (move_uploaded_file($_FILES['target_image']['tmp_name'], $uploadDir.$filename)) {
          $imagePath = $uploadDir.$filename;
        }
      }
    }
    $stmt = db()->prepare(
      'INSERT INTO challenges (title, description, target_html, target_css, target_image, difficulty, created_by) VALUES (?,?,?,?,?,?,?)'
    );
    $stmt->execute([$title, $desc, $targetHtml, $targetCss, $imagePath, $difficulty, $user['id']]);
    $newChallengeId = (int)db()->lastInsertId();
    header('Location: versus.php?pick='.$newChallengeId); exit;
  }
}

// ── Column flags — must be defined BEFORE any POST handler ──────────
$hasRoomMode   = columnExists('rooms', 'room_mode');
$hasMaxPlayers = columnExists('rooms', 'max_players');

// ── Handle room creation ───────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'create') {
  $isPublic    = !empty($_POST['is_public']);
  $roomMode    = in_array($_POST['room_mode'] ?? '', ['1v1','open']) ? $_POST['room_mode'] : '1v1';
  $maxPlayers  = ($roomMode === 'open') ? 4 : 2;
  $challengeId = (int)($_POST['challenge_id'] ?? 0);

  $selectedChallenge = null;
  if ($challengeId > 0) {
    $chStmt = db()->prepare('SELECT * FROM challenges WHERE id=?');
    $chStmt->execute([$challengeId]);
    $selectedChallenge = $chStmt->fetch() ?: null;
  }
  if (!$selectedChallenge) {
    $rnd = db()->query('SELECT * FROM challenges ORDER BY RAND() LIMIT 1')->fetch();
    $selectedChallenge = $rnd ?: ['id'=>null,'title'=>'CSS Freestyle','description'=>'Create any CSS artwork you like!','target_html'=>'','target_css'=>'','target_image'=>null];
  }

  do {
    $code = strtoupper(substr(md5(uniqid()), 0, 6));
    $exists = db()->prepare('SELECT id FROM rooms WHERE code=?');
    $exists->execute([$code]);
  } while ($exists->fetch());

  // Always save room_mode + max_players if columns exist
  if ($hasRoomMode && $hasMaxPlayers) {
    $ins = db()->prepare('INSERT INTO rooms (code, host_id, challenge_id, challenge, is_public, room_mode, max_players) VALUES (?,?,?,?,?,?,?)');
    $ins->execute([$code, $user['id'], $selectedChallenge['id'], $selectedChallenge['description'], $isPublic ? 1 : 0, $roomMode, $maxPlayers]);
  } else {
    $ins = db()->prepare('INSERT INTO rooms (code, host_id, challenge_id, challenge, is_public) VALUES (?,?,?,?,?)');
    $ins->execute([$code, $user['id'], $selectedChallenge['id'], $selectedChallenge['description'], $isPublic ? 1 : 0]);
  }
  $roomId = (int)db()->lastInsertId(); // capture NOW before any other query resets it

  // ── Notify followers that the host opened a public game ──
  if ($isPublic && $roomId) {
    require_once __DIR__ . '/includes/notifications_helper.php';
    $followers = db()->prepare('SELECT follower_id FROM user_follows WHERE following_id = ?');
    $followers->execute([$user['id']]);
    foreach ($followers->fetchAll(PDO::FETCH_COLUMN) as $followerId) {
      pushNotification((int)$followerId, (int)$user['id'], 'arena_invite', $roomId, $code);
    }
  }

  header('Location: battle.php?code='.$code); exit;
}

// ── Load ALL challenges from all users ────────────────────────────────
$allChallenges = db()->query(
  'SELECT c.*, u.username AS creator_name, u.avatar AS creator_avatar
   FROM challenges c JOIN users u ON u.id=c.created_by
   ORDER BY c.id DESC'
)->fetchAll();

// ── Public waiting rooms ──────────────────────────────────────────────
$waitingRooms = db()->query(
  'SELECT r.*, u.username AS host_name, u.avatar AS host_avatar,
          c.title AS ch_title,
          (SELECT COUNT(*) FROM room_players rp WHERE rp.room_id=r.id) AS player_count
   FROM rooms r JOIN users u ON u.id=r.host_id
   LEFT JOIN challenges c ON c.id=r.challenge_id
   WHERE r.status="waiting" AND r.is_public=1
   ORDER BY r.created_at DESC LIMIT 12'
)->fetchAll();

$autoPickId = (int)($_GET['pick'] ?? 0);

pageHeader('Versus');
?>
<style>
/* ── Global ── */
*,*::before,*::after{box-sizing:border-box}

/* ── Mode Cards ── */
.mode-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;max-width:860px}
.mode-card{position:relative;background:var(--bg2);border:1px solid var(--border);border-radius:20px;padding:32px 28px;overflow:hidden;transition:border-color .3s,transform .3s,box-shadow .3s}
.mode-card:hover{transform:translateY(-4px)}
.mode-card.create-card:hover{border-color:rgba(0,255,135,.4);box-shadow:0 20px 60px rgba(0,255,135,.1)}
.mode-card.join-card:hover{border-color:rgba(0,200,255,.4);box-shadow:0 20px 60px rgba(0,200,255,.1)}
.card-glow{position:absolute;top:-60px;right:-60px;width:180px;height:180px;border-radius:50%;opacity:.08;pointer-events:none}
.create-card .card-glow{background:var(--green)}
.join-card .card-glow{background:var(--blue)}
.card-icon{font-size:32px;margin-bottom:16px;display:block}
.card-tag{display:inline-block;font-family:var(--font-mono);font-size:10px;letter-spacing:2px;text-transform:uppercase;padding:3px 10px;border-radius:4px;margin-bottom:12px}
.create-card .card-tag{color:var(--green);background:rgba(0,255,135,.1);border:1px solid rgba(0,255,135,.2)}
.join-card .card-tag{color:var(--blue);background:rgba(0,200,255,.1);border:1px solid rgba(0,200,255,.2)}
.card-title{font-size:22px;font-weight:800;letter-spacing:-.5px;margin-bottom:8px}
.card-desc{color:var(--muted);font-size:13px;line-height:1.6;margin-bottom:24px;font-family:var(--font-mono)}
.card-btn{display:inline-flex;align-items:center;gap:8px;padding:11px 22px;border-radius:10px;font-size:13px;font-weight:700;cursor:pointer;border:none;letter-spacing:.5px;transition:transform .2s,filter .2s}
.card-btn:hover{transform:scale(1.04);filter:brightness(1.1)}
.create-card .card-btn{background:var(--green);color:#080b12}
.join-card .card-btn{background:var(--blue);color:#080b12}

/* ── Rooms Grid ── */
.rooms-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:14px;max-width:860px}
.room-card{background:var(--bg2);border:1px solid var(--border);border-radius:14px;padding:18px;display:flex;flex-direction:column;gap:10px;transition:border-color .2s,transform .2s}
.room-card:hover{border-color:rgba(0,200,255,.25);transform:translateY(-2px)}
.room-code{font-family:var(--font-mono);font-size:18px;font-weight:700;letter-spacing:2px;color:var(--green)}
.room-host{font-size:12px;color:var(--muted);font-family:var(--font-mono)}
.room-host span{color:#fff}
.room-meta{display:flex;gap:6px;flex-wrap:wrap}
.rbadge{font-size:10px;font-family:var(--font-mono);padding:2px 8px;border-radius:4px;font-weight:700}
.rbadge.mode-1v1{background:rgba(0,255,135,.1);color:var(--green);border:1px solid rgba(0,255,135,.2)}
.rbadge.mode-open{background:rgba(0,200,255,.1);color:var(--blue);border:1px solid rgba(0,200,255,.2)}
.rbadge.waiting{color:#f0a500;background:rgba(240,165,0,.1);border:1px solid rgba(240,165,0,.2)}
.rbadge.neutral{background:var(--bg3);color:var(--muted);border:1px solid var(--border)}
.room-challenge{font-size:11px;color:var(--muted);font-family:var(--font-mono);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.room-join-btn{padding:9px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;background:rgba(0,200,255,.1);color:var(--blue);border:1px solid rgba(0,200,255,.2);font-family:var(--font-mono);transition:background .2s;text-align:center;text-decoration:none;display:block}
.room-join-btn:hover{background:rgba(0,200,255,.2)}
.room-join-btn.mine{background:rgba(0,255,135,.1);color:var(--green);border-color:rgba(0,255,135,.2)}

/* ── Overlay / Modal ── */
.overlay{display:none;position:fixed;inset:0;z-index:500;background:rgba(8,11,18,.92);backdrop-filter:blur(10px);justify-content:center;align-items:flex-start;padding:16px;overflow-y:auto}
.overlay.active{display:flex}
.modal{background:var(--bg2);border:1px solid var(--border);border-radius:20px;padding:28px 24px;width:100%;max-width:520px;margin:auto;position:relative;animation:popIn .3s cubic-bezier(.22,1,.36,1)}
@keyframes popIn{from{opacity:0;transform:scale(.94) translateY(12px)}to{opacity:1;transform:none}}
.modal-close{position:absolute;top:16px;right:18px;background:none;border:none;color:var(--muted);font-size:20px;cursor:pointer;line-height:1;transition:color .2s;padding:4px}
.modal-close:hover{color:#fff}
.modal-title{font-size:20px;font-weight:800;margin-bottom:4px}
.modal-sub{font-size:12px;color:var(--muted);font-family:var(--font-mono);margin-bottom:20px}

/* ── Room Mode Selector ── */
.mode-selector{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:18px}
.mode-opt{position:relative;cursor:pointer}
.mode-opt input{position:absolute;opacity:0;width:0;height:0}
.mode-opt-label{display:flex;flex-direction:column;gap:3px;padding:12px 14px;background:var(--bg3);border:2px solid var(--border);border-radius:12px;cursor:pointer;transition:border-color .2s,background .2s}
.mode-opt input:checked + .mode-opt-label{border-color:var(--green);background:rgba(0,255,135,.05)}
.mode-opt-icon{font-size:18px;margin-bottom:2px}
.mode-opt-title{font-size:13px;font-weight:700}
.mode-opt-desc{font-size:10px;color:var(--muted);font-family:var(--font-mono);line-height:1.4}

/* ── Toggle ── */
.toggle-row{display:flex;align-items:center;justify-content:space-between;padding:12px 14px;background:var(--bg3);border-radius:10px;margin-bottom:14px;gap:12px}
.toggle-label{font-size:13px;font-weight:600}
.toggle-sub{font-size:11px;color:var(--muted);font-family:var(--font-mono)}
.toggle{position:relative;width:44px;height:24px;flex-shrink:0}
.toggle input{opacity:0;width:0;height:0}
.slider{position:absolute;inset:0;background:var(--bg);border:1px solid var(--border);border-radius:999px;cursor:pointer;transition:.3s}
.slider:before{position:absolute;content:"";height:16px;width:16px;left:3px;bottom:3px;background:var(--muted);border-radius:50%;transition:.3s}
input:checked+.slider{background:rgba(0,255,135,.2);border-color:rgba(0,255,135,.5)}
input:checked+.slider:before{transform:translateX(20px);background:var(--green)}
.big-modal-btn{width:100%;padding:13px;border-radius:12px;font-size:14px;font-weight:700;cursor:pointer;border:none;background:var(--green);color:#080b12;transition:filter .2s;margin-top:8px}
.big-modal-btn:hover{filter:brightness(1.1)}
.big-modal-btn.blue{background:var(--blue)}
.join-input{width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:10px;padding:14px;color:var(--text);font-size:22px;font-family:var(--font-mono);letter-spacing:6px;font-weight:700;text-align:center;outline:none;text-transform:uppercase;margin-bottom:12px;transition:border-color .2s}
.join-input:focus{border-color:rgba(0,200,255,.4)}
.err-msg{color:var(--pink);font-family:var(--font-mono);font-size:12px;margin-bottom:14px;display:none}

/* ── Challenge picker ── */
.ch-section-label{font-size:10px;font-family:var(--font-mono);letter-spacing:2px;text-transform:uppercase;color:var(--muted);margin-bottom:8px}
.ch-list{display:flex;flex-direction:column;gap:8px;margin-bottom:12px;max-height:200px;overflow-y:auto}
.ch-item{display:flex;align-items:center;gap:10px;padding:9px 12px;background:var(--bg3);border:2px solid var(--border);border-radius:10px;cursor:pointer;transition:border-color .2s}
.ch-item:hover{border-color:rgba(0,255,135,.3)}
.ch-item.selected{border-color:var(--green);background:rgba(0,255,135,.05)}
.ch-item input[type=radio]{accent-color:var(--green);flex-shrink:0}
.ch-item-body{flex:1;min-width:0}
.ch-item-title{font-size:12px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ch-item-sub{font-size:10px;color:var(--muted);font-family:var(--font-mono)}
.ch-item-desc{font-size:10px;color:var(--muted);font-family:var(--font-mono);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.diff-badge{font-size:10px;font-family:var(--font-mono);padding:2px 6px;border-radius:4px;font-weight:700;flex-shrink:0;white-space:nowrap}
.diff-badge.easy{background:rgba(0,255,135,.15);color:var(--green)}
.diff-badge.medium{background:rgba(255,190,0,.15);color:#ffbe00}
.diff-badge.hard{background:rgba(255,45,111,.15);color:var(--pink)}
.ch-thumb{width:40px;height:28px;object-fit:cover;border-radius:4px;border:1px solid var(--border);flex-shrink:0}
.ch-thumb-placeholder{width:40px;height:28px;background:var(--bg);border:1px dashed var(--border);border-radius:4px;flex-shrink:0}

/* ── Inline new-challenge form ── */
.new-ch-toggle{display:flex;align-items:center;gap:8px;font-size:12px;font-family:var(--font-mono);color:var(--green);cursor:pointer;padding:6px 0;margin-bottom:4px}
.new-ch-toggle:hover{opacity:.8}
.new-ch-form{display:none;background:var(--bg3);border:1px solid var(--border);border-radius:12px;padding:14px;margin-bottom:12px}
.new-ch-form.open{display:block}
.ncf-field{margin-bottom:10px}
.ncf-field label{display:block;font-size:10px;font-family:var(--font-mono);letter-spacing:1px;text-transform:uppercase;color:var(--muted);margin-bottom:4px}
.ncf-field input,.ncf-field textarea,.ncf-field select{width:100%;background:var(--bg2);border:1px solid var(--border);border-radius:7px;color:var(--text);padding:8px 10px;font-size:12px;font-family:var(--font-mono)}
.ncf-field input:focus,.ncf-field textarea:focus{outline:none;border-color:rgba(0,255,135,.4)}
.ncf-field textarea{min-height:55px;resize:vertical}
.ncf-row{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.ncf-save-btn{padding:8px 16px;background:rgba(0,255,135,.15);color:var(--green);border:1px solid rgba(0,255,135,.3);border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;font-family:var(--font-mono);transition:background .2s}
.ncf-save-btn:hover{background:rgba(0,255,135,.25)}

/* ── References Section ── */
.ref-section{max-width:860px;margin-top:40px}
.ref-filters{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px}
.ref-filter-btn{padding:5px 12px;border-radius:8px;font-size:11px;font-family:var(--font-mono);font-weight:700;cursor:pointer;border:1px solid var(--border);background:var(--bg3);color:var(--muted);transition:all .2s;letter-spacing:.5px}
.ref-filter-btn.active,.ref-filter-btn:hover{background:rgba(0,255,135,.1);color:var(--green);border-color:rgba(0,255,135,.3)}
.ref-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:14px}
.ref-card{background:var(--bg2);border:1px solid var(--border);border-radius:14px;overflow:hidden;transition:border-color .3s,transform .3s;cursor:pointer;position:relative}
.ref-card:hover{border-color:rgba(0,255,135,.3);transform:translateY(-2px)}
.ref-card.active{border-color:var(--green);box-shadow:0 0 0 2px rgba(0,255,135,.15)}
.ref-use-badge{position:absolute;top:8px;right:8px;background:var(--green);color:#080b12;font-size:10px;font-weight:700;font-family:var(--font-mono);padding:3px 8px;border-radius:4px;z-index:5;display:none}
.ref-card.active .ref-use-badge{display:block}
.ref-thumb{width:100%;height:110px;background:var(--bg);border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:center;overflow:hidden}
.ref-thumb img{width:100%;height:110px;object-fit:cover}
.ref-thumb iframe{width:100%;height:110px;border:none;pointer-events:none}
.ref-body{padding:10px 12px}
.ref-title{font-size:12px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:2px;display:flex;align-items:center;justify-content:space-between;gap:6px}
.ref-creator{font-size:10px;color:var(--muted);font-family:var(--font-mono);margin-bottom:3px}
.ref-desc{font-size:11px;color:var(--muted);font-family:var(--font-mono);line-height:1.4;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}

/* ── Responsive ── */
@media(max-width:640px){
  .mode-grid{grid-template-columns:1fr;gap:12px}
  .mode-card{padding:22px 18px}
  .rooms-grid{grid-template-columns:1fr}
  .ref-grid{grid-template-columns:repeat(auto-fill,minmax(150px,1fr))}
  .ncf-row{grid-template-columns:1fr}
  .mode-selector{grid-template-columns:1fr}
  .modal{padding:22px 16px;border-radius:16px;width:calc(100% - 0px)}
  .page{padding:28px 16px}
  .page-hero h1{font-size:32px}
  .overlay{padding:12px;align-items:flex-start}
  .ch-list{max-height:160px}
  .card-title{font-size:18px}
  .card-btn{width:100%;justify-content:center}
}
@media(max-width:400px){
  .mode-card{padding:18px 14px}
  .modal{padding:18px 14px}
  .lobby-code{font-size:24px}
  .join-input{font-size:18px;letter-spacing:4px}
}
</style>

<div class="page">
  <div class="page-hero">
    <h1>Versus <span class="hi">Mode</span></h1>
    <p>Create a room, pick your challenge, share the code — first to finish wins.</p>
  </div>

  <div class="mode-grid">
    <div class="mode-card create-card">
      <div class="card-glow"></div>
      <span class="card-icon">⚡</span>
      <div class="card-tag">Host</div>
      <div class="card-title">Create Room</div>
      <div class="card-desc">Pick a challenge, choose 1v1 or open room, then share your code.</div>
      <button class="card-btn" id="openCreateBtn">Create Room →</button>
    </div>
    <div class="mode-card join-card">
      <div class="card-glow"></div>
      <span class="card-icon">🎯</span>
      <div class="card-tag">Join</div>
      <div class="card-title">Join Room</div>
      <div class="card-desc">Have a code? Paste it in and jump straight into the battle.</div>
      <button class="card-btn" id="openJoinBtn">Enter Code →</button>
    </div>
  </div>

  <!-- Open Rooms -->
  <div class="sec-label" style="margin-top:40px">Open Rooms</div>
  <?php if (!$waitingRooms): ?>
    <p style="color:var(--muted);font-family:var(--font-mono);font-size:13px">No open rooms right now. Create one!</p>
  <?php else: ?>
    <div class="rooms-grid">
      <?php foreach ($waitingRooms as $r):
        $mode   = $hasRoomMode   ? ($r['room_mode']   ?? '1v1') : '1v1';
        $maxP   = $hasMaxPlayers ? ($r['max_players'] ?? 2)     : 2;
        $curP   = (int)($r['player_count'] ?? 1);
      ?>
        <div class="room-card">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:8px">
            <div class="room-code"><?= e($r['code']) ?></div>
            <span class="rbadge waiting">WAITING</span>
          </div>
          <div class="room-meta">
            <span class="rbadge mode-<?= e($mode) ?>"><?= $mode==='1v1'?'⚔️ 1v1':'👥 OPEN' ?></span>
            <span class="rbadge neutral"><?= $curP ?>/<?= $maxP ?> players</span>
          </div>
          <div class="room-host">Host: <span><?= e($r['host_avatar'].' '.$r['host_name']) ?></span></div>
          <?php if (!empty($r['ch_title'])): ?><div class="room-challenge">📋 <?= e($r['ch_title']) ?></div><?php endif; ?>
          <?php if ($r['host_id'] != $user['id']): ?>
            <a href="battle.php?code=<?= e($r['code']) ?>" class="room-join-btn">Join Battle →</a>
          <?php else: ?>
            <a href="battle.php?code=<?= e($r['code']) ?>" class="room-join-btn mine">Re-enter Room →</a>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <!-- All References -->
  <div class="ref-section">
    <div class="sec-label">📚 All Challenge References</div>
    <div class="ref-filters">
      <button class="ref-filter-btn active" data-diff="all">All</button>
      <button class="ref-filter-btn" data-diff="easy">Easy</button>
      <button class="ref-filter-btn" data-diff="medium">Medium</button>
      <button class="ref-filter-btn" data-diff="hard">Hard</button>
      <button class="ref-filter-btn" data-diff="mine">Mine</button>
    </div>
    <?php if (empty($allChallenges)): ?>
      <p style="color:var(--muted);font-family:var(--font-mono);font-size:13px">No challenges yet.</p>
    <?php else: ?>
    <div class="ref-grid">
      <?php foreach ($allChallenges as $ch):
        $hasImg = !empty($ch['target_image']);
        $hasCSS = !empty($ch['target_css']) || !empty($ch['target_html']);
        $refSrcdocAttr = '';
        if ($hasCSS) {
          $refDoc = "<!DOCTYPE html><html><head><meta charset='utf-8'><style>*{margin:0;padding:0;box-sizing:border-box}body{display:flex;justify-content:center;align-items:center;min-height:100%;background:#0d1117;overflow:hidden}" . htmlspecialchars($ch['target_css'], ENT_QUOTES) . "</style></head><body>" . ($ch['target_html'] ?? '') . "</body></html>";
          $refSrcdocAttr = htmlspecialchars($refDoc, ENT_QUOTES);
        }
        $isMine = ($ch['created_by'] == $user['id']);
      ?>
      <div class="ref-card"
           data-id="<?= $ch['id'] ?>"
           data-title="<?= e($ch['title']) ?>"
           data-diff="<?= $ch['difficulty'] ?>"
           data-mine="<?= $isMine?'1':'0' ?>"
           onclick="pickRefCard(this)">
        <span class="ref-use-badge">✓ SELECTED</span>
        <div class="ref-thumb">
          <?php if ($hasImg): ?>
            <img src="<?= e($ch['target_image']) ?>" alt="<?= e($ch['title']) ?>" loading="lazy">
          <?php elseif ($hasCSS): ?>
            <iframe srcdoc="<?= $refSrcdocAttr ?>" sandbox="allow-scripts" scrolling="no" loading="lazy"></iframe>
          <?php else: ?>
            <span style="font-size:24px;opacity:.3">🎨</span>
          <?php endif; ?>
        </div>
        <div class="ref-body">
          <div class="ref-title">
            <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= e($ch['title']) ?></span>
            <span class="diff-badge <?= $ch['difficulty'] ?>"><?= strtoupper($ch['difficulty']) ?></span>
          </div>
          <div class="ref-creator"><?= e($ch['creator_avatar'].' '.$ch['creator_name']) ?><?= $isMine?' · <span style="color:var(--green)">You</span>':'' ?></div>
          <div class="ref-desc"><?= e($ch['description']) ?></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</div>

<!-- Create Room Modal -->
<div class="overlay" id="createOverlay">
  <div class="modal">
    <button class="modal-close" id="closeCreate">✕</button>
    <div class="modal-title">Create Room</div>
    <div class="modal-sub">Choose your mode, pick a challenge, then launch.</div>

    <div class="ch-section-label">Room Mode</div>
    <div class="mode-selector">
      <label class="mode-opt">
        <input type="radio" name="rm_mode_ui" value="1v1" checked>
        <div class="mode-opt-label">
          <span class="mode-opt-icon">⚔️</span>
          <span class="mode-opt-title">1v1 Duel</span>
          <span class="mode-opt-desc">2 players. Starts automatically when opponent joins.</span>
        </div>
      </label>
      <label class="mode-opt">
        <input type="radio" name="rm_mode_ui" value="open">
        <div class="mode-opt-label">
          <span class="mode-opt-icon">👥</span>
          <span class="mode-opt-title">Open Room</span>
          <span class="mode-opt-desc">Up to 4 players. You start the battle.</span>
        </div>
      </label>
    </div>

    <div class="ch-section-label">Choose a challenge</div>
    <div class="new-ch-toggle" id="newChToggle">＋ Create new challenge</div>
    <div class="new-ch-form" id="newChForm">
      <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="action" value="create_challenge">
        <div class="ncf-field"><label>Title</label><input type="text" name="title" required maxlength="120" placeholder="e.g. Centered Red Circle"></div>
        <div class="ncf-field"><label>Description</label><textarea name="description" required placeholder="What should players recreate?"></textarea></div>
        <div class="ncf-row">
          <div class="ncf-field"><label>Difficulty</label><select name="difficulty"><option value="easy">Easy</option><option value="medium" selected>Medium</option><option value="hard">Hard</option></select></div>
          <div class="ncf-field"><label>Reference image</label><input type="file" name="target_image" accept="image/*" style="font-size:11px;padding:5px"></div>
        </div>
        <div class="ncf-field"><label>Target HTML</label><textarea name="target_html" placeholder='<div class="box"></div>'></textarea></div>
        <div class="ncf-field"><label>Reference CSS (hidden from players)</label><textarea name="target_css" placeholder=".box { ... }"></textarea></div>
        <button type="submit" class="ncf-save-btn">💾 Save & Select</button>
      </form>
    </div>

    <?php if (empty($allChallenges)): ?>
      <p style="font-size:12px;font-family:var(--font-mono);color:var(--muted);padding:8px 0">No challenges yet. Create one above!</p>
    <?php else: ?>
    <div class="ch-list" id="chList">
      <?php foreach ($allChallenges as $ch): ?>
      <label class="ch-item <?= $autoPickId===(int)$ch['id']?'selected':'' ?>">
        <input type="radio" name="ch_pick" value="<?= $ch['id'] ?>" <?= $autoPickId===(int)$ch['id']?'checked':'' ?>>
        <?php if ($ch['target_image']): ?><img src="<?= e($ch['target_image']) ?>" class="ch-thumb"><?php else: ?><div class="ch-thumb-placeholder"></div><?php endif; ?>
        <div class="ch-item-body">
          <div class="ch-item-title"><?= e($ch['title']) ?></div>
          <div class="ch-item-sub">by <?= e($ch['creator_avatar'].' '.$ch['creator_name']) ?><?= !empty($ch['showcase_post_id']) ? ' &nbsp;<span style="font-size:9px;background:rgba(0,255,135,.12);color:var(--green);border:1px solid rgba(0,255,135,.25);border-radius:4px;padding:1px 5px;font-weight:700">SHOWCASE</span>' : '' ?></div>
        </div>
        <span class="diff-badge <?= $ch['difficulty'] ?>"><?= strtoupper($ch['difficulty']) ?></span>
      </label>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <form method="POST" id="launchForm">
      <input type="hidden" name="action" value="create">
      <input type="hidden" name="challenge_id" id="selectedChallengeId" value="<?= $autoPickId ?: 0 ?>">
      <input type="hidden" name="room_mode" id="selectedRoomMode" value="1v1">
      <div class="toggle-row">
        <div>
          <div class="toggle-label">Public Room</div>
          <div class="toggle-sub">Anyone can see and join from the lobby</div>
        </div>
        <label class="toggle"><input type="checkbox" name="is_public" checked><span class="slider"></span></label>
      </div>
      <button type="submit" class="big-modal-btn">⚡ Launch Room</button>
    </form>
  </div>
</div>

<!-- Join Room Modal -->
<div class="overlay" id="joinOverlay">
  <div class="modal">
    <button class="modal-close" id="closeJoin">✕</button>
    <div class="modal-title">Join a Room</div>
    <div class="modal-sub">Enter the 6-character room code.</div>
    <input type="text" class="join-input" id="joinCodeInput" maxlength="6" placeholder="ABCDEF">
    <div class="err-msg" id="joinError">Room not found or already full.</div>
    <button class="big-modal-btn blue" id="joinRoomBtn">Join Battle →</button>
  </div>
</div>
<script src="assets/security.js"></script>
<script>
const $ = id => document.getElementById(id);

$('openCreateBtn').onclick = () => $('createOverlay').classList.add('active');
$('closeCreate').onclick   = () => $('createOverlay').classList.remove('active');
$('openJoinBtn').onclick   = () => $('joinOverlay').classList.add('active');
$('closeJoin').onclick     = () => { $('joinOverlay').classList.remove('active'); $('joinCodeInput').value=''; $('joinError').style.display='none'; };
[$('createOverlay'),$('joinOverlay')].forEach(o => o.addEventListener('click', e => { if(e.target===o) o.classList.remove('active'); }));

document.querySelectorAll('input[name="rm_mode_ui"]').forEach(r => r.addEventListener('change', () => { $('selectedRoomMode').value = r.value; }));

$('newChToggle').onclick = () => {
  const open = $('newChForm').classList.toggle('open');
  $('newChToggle').textContent = open ? '✕ Cancel' : '＋ Create new challenge';
};

document.querySelectorAll('input[name="ch_pick"]').forEach(radio => {
  radio.addEventListener('change', () => {
    $('selectedChallengeId').value = radio.value;
    document.querySelectorAll('.ch-item').forEach(i => i.classList.remove('selected'));
    radio.closest('.ch-item').classList.add('selected');
  });
});

$('joinCodeInput').oninput = e => e.target.value = e.target.value.toUpperCase();
$('joinRoomBtn').onclick = () => {
  const code = $('joinCodeInput').value.trim().toUpperCase();
  if (code.length < 4) { $('joinError').style.display='block'; return; }
  window.location.href = 'battle.php?code=' + code;
};

<?php if ($autoPickId): ?>
document.addEventListener('DOMContentLoaded', () => $('createOverlay').classList.add('active'));
<?php endif; ?>

function pickRefCard(card) {
  document.querySelectorAll('.ref-card').forEach(c => c.classList.remove('active'));
  card.classList.add('active');
  $('selectedChallengeId').value = card.dataset.id;
  const radio = document.querySelector(`input[name="ch_pick"][value="${card.dataset.id}"]`);
  if (radio) { radio.checked = true; document.querySelectorAll('.ch-item').forEach(i => i.classList.remove('selected')); radio.closest('.ch-item')?.classList.add('selected'); }
  $('createOverlay').classList.add('active');
  showToast(`✓ "${card.dataset.title}" selected`);
}

document.querySelectorAll('.ref-filter-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.ref-filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const diff = btn.dataset.diff;
    document.querySelectorAll('.ref-card').forEach(card => {
      if (diff==='all') card.style.display='';
      else if (diff==='mine') card.style.display = card.dataset.mine==='1' ? '' : 'none';
      else card.style.display = card.dataset.diff===diff ? '' : 'none';
    });
  });
});
</script>
<?php pageFooter(); ?>
